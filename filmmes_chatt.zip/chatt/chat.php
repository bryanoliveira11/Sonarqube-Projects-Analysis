﻿<body  style='margin:0px;'>
<div style='float:left;width:450px'>
	<div style='float:left;width:100%;background:white;min-height:50px;'>
		<img src='img/logo.png' height='70px' style='float:left;margin:5px'>
	</div>
	<div style='float:left;width:450px;height:300px;overflow:scroll;margin:10px 0px 0px 0px'>
		<div style='float:left;width:100%'><div style='color:green;font-size:13px;width:100%'>Sistema: </div><div style='width:100%;font-size:13px;color;#666'>Por favor aguar em breve um de nossos atendentes irá atende-lo</div></div>
	</div>
	<div style='float:left;width:450px;height:70px;border-top:1px solid #666'>
	<textarea style='float:left;width:350px;height:60px;resize:none;'></textarea>
	<button style='float:left;width:100px;height:60px;border:0px;font-weight:bold;background:skyblue;font-size:20px;color:white;'>Enviar</button>
	</div>
</div>