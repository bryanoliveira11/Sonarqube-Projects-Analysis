<? $strings->changePageTitle($_SESSION['strIndexMenuProjectManagementManageUserEvents']); ?>
<div class="sessionTitle">
	<i class="<? echo $database->strEventLogDefaultIcon; ?>"></i> <span class="hidden-phone"><? echo $_SESSION['strIndexMenuProjectManagementManageUserEvents']; ?></span>
	(<span id="spanUserEventsCounter">0</span>)
    
    <span style="float:right;position:relative;top:-4px">
    <span class="input-append date" data-date-format="dd/mm/yyyy" style="display:inline-block">
        <input id="dtDateFrom" name="dtDateFrom" type="text" style="font-family:'Calibri';text-align:center;cursor:pointer;font-weight:bold;width:70px;" value="<? echo date("d/m/Y", strtotime("-1 month", time())); ?>" data-date-format="dd/mm/yyyy" onblur="usereventsLoad('tblUserEvents');">
        <span class="add-on"><i class="icon-calendar"></i></span>
    </span> - <span class="input-append date" data-date-format="dd/mm/yyyy" style="display:inline-block">
        <input id="dtDateTo" name="dtDateTo" type="text" style="font-family:'Calibri';text-align:center;cursor:pointer;font-weight:bold;width:70px;" value="<? echo date('d/m/Y', time()); ?>" data-date-format="dd/mm/yyyy" onblur="usereventsLoad('tblUserEvents');">
        <span class="add-on"><i class="icon-calendar"></i></span>
    </span>
    </span>
</div>
<select id="idUser" style="width:100%;margin-bottom:10px;" class="btn" onchange="usereventsLoad('tblUserEvents');">
	<option value="0">-- <? echo $_SESSION['stradmManageEventsAllUsers']; ?> ---------</option>
<?
	$arrUsers = $user->selectUsers($arrProject['idProject']);
	foreach($arrUsers as $arrUser1) {
		echo '<option value="' . $arrUser1['idUser'] . '">' . $arrUser1['strEmail'] . '</option>';
	}
?>
</select>
<select id="idEventType" style="width:100%;margin-bottom:10px;" class="btn" onchange="usereventsLoad('tblUserEvents');">
	<option value="0">-- <? echo $_SESSION['stradmManageEventsAllEvents']; ?> ---------</option>
<?
	$arrEventTypes = $database->selectEventTypes();
	foreach($arrEventTypes as $arrEventType) {
		echo '<option value="' . $arrEventType['idEventType'] . '">' . $arrEventType['strEventType'] . '</option>';
	}
?>
</select>
<table id="tblUserEvents" name="tblUserEvents" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
    <thead>
        <tr style="cursor:pointer;font-weight:bold;" class="btn-primary">
            <th style="text-align:center" width="130"><? echo $_SESSION['stradmManageEventsDate']; ?></th>
            <th style="text-align:center"><? echo $_SESSION['stradmManageEventsUser']; ?></th>
            <th style="text-align:center" width="300"><? echo $_SESSION['stradmManageEventsEventType']; ?></th>
            <!--<th style="text-align:center" class="hidden-phone"><? echo $_SESSION['stradmManageEventsDescription']; ?></th>-->
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>

<script>
    function usereventsLoad(idTable) {
        var table = document.getElementById(idTable);
        var tbody = table.getElementsByTagName("tbody")[0];
        tbody.innerHTML = '<tr><td colspan="4"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
        var result = $.ajax({
          url: "ajax.php?chrAction=UES" +
				  "&idProject=<? echo $arrProject['idProject']; ?>" + 
				  "&idUser=" + document.getElementById('idUser').value +
				  "&idEventType=" + document.getElementById('idEventType').value +
				  "&dtDateFrom=" + document.getElementById('dtDateFrom').value +
				  "&dtDateTo=" + document.getElementById('dtDateTo').value
        }).always(function() {
            var response 	= result.responseText;
            var arrResult 	= JSON.parse(response);
            tbody.innerHTML = '';
            var rows = tbody.getElementsByTagName("tr").length;
            for (var i=0;i<arrResult.length;i++) {
                var row = tbody.insertRow(i);
                row.id = idTable + '_' + arrResult[i]['idEvent'];
                var cell = row.insertCell(0);
                cell.innerHTML = arrResult[i]['strDateTime'];
                cell.style.textAlign = "center";
                var cell = row.insertCell(1);
                cell.innerHTML = arrResult[i]['strEmail'];
                var cell = row.insertCell(2);
                cell.innerHTML = arrResult[i]['strEventType'];
                cell.style.textAlign = "center";
            }
            document.getElementById('spanUserEventsCounter').innerHTML = arrResult.length;
        });
    }

	$(document).ready(function () {
		usereventsLoad('tblUserEvents');
		$('#dtDateFrom').datepicker().on('changeDate', function(ev){$('#dtDateFrom').datepicker('hide');usereventsLoad('tblUserEvents');});
		$('#dtDateTo').datepicker().on('changeDate', function(ev){$('#dtDateTo').datepicker('hide');usereventsLoad('tblUserEvents');});
	});
</script>