<?
// --------------------------------------------------------------------------------
// Vicon SAGA Platform
// --------------------------------------------------------------------------------
// License GNU/LGPL - Tiago Marino (http://www.tiagomarino.com) - May 2016
// --------------------------------------------------------------------------------
// Presentation:
//   Vicon SAGA is a platform for register and retrieve georreferenced events and 
//   entities into/from a database.
//
// Description:
//   See readme.txt and http://www.viconsaga.com.br
//
// Warning:
//   This library and the associated files are non commercial, non professional
//   work.
//   It should not have unexpected results. However if any damage is caused by
//   this software the author can not be responsible.
//   The use of this software is at the risk of the user.
// --------------------------------------------------------------------------------
	//phpinfo(); exit;
	session_start();
	// Initializing Engine Classes
	include_once 'engine/strings.php';
	$strings = new Strings();		
	$strings->checkCreateFolders();
	include_once 'engine/database.php';
	$database = new Database();	
	//If cannot connect, direct to instalation procedures
	if ($database->isConnected() === FALSE) { header("Location: install.php"); exit; }
	include_once 'engine/project.php';
	$project = new Project($database);
	include_once 'engine/user.php';
	$user = new User($database);
	include_once 'engine/form.php';
	$form = new Form($database);
	include_once 'engine/formrecord.php';
	$formrecord = new Formrecord($database);
	include_once 'engine/importer.php';
	$importer = new Importer($database);
	include_once 'engine/stats.php';
	$stats = new Stats($database);
	include_once 'engine/alert.php';
	$alert = new Alert($database);
	include_once 'engine/support.php';
	$support = new Support($database);
	include_once 'engine/toponymy.php';
	$toponymy = new Toponymy($database);
	include_once 'engine/report.php';
	$report = new Report($database);
	include_once 'engine/censo.php';
	$censo = new Censo($database);
	if (isset($_GET['strAlias'])) {
		$idProject = $project->selectidProjectByAlias($_GET['strAlias']);
		if ($idProject > 0) {
			$_GET['idProject'] = $idProject;
			$_GET['s'] = $strings->strSiteDefaultHomePage;
		} else {
			header("Location: site/home"); exit;
		}
	}
	
	// If no just index.php, no ?s=...
	if (! $_SERVER["QUERY_STRING"]) {
		header("Location: site/home"); exit;
	}

	if (isset($_GET['idProject'])) {
		$_SESSION['idProject'] = $_GET['idProject'];
	}

	if (isset($_GET['pid'])) { // Request from Vicon Mobile
		$_SESSION['idProject'] = $_GET['pid'];
	}
	
	if (! $_SESSION['idProject'] > 0) {
		header("Location: site/home"); exit;
	}
	
	$arrProject = $project->selectProjects($_SESSION['idProject']);
	$arrProject = $arrProject[0];

	// Loading strings according to selected language
	if ($_GET['language']) {
		$_SESSION['strSiteLanguage'] = $_GET['language'];
	} else if (! isset($_SESSION['strSiteLanguage'])) {
		$_SESSION['strSiteLanguage'] = $arrProject['strLanguageCode'];
	}
	$strings->loadLanguage($_SESSION['strSiteLanguage']);

	// Logout
	if ((! $_POST['hidLogin']) && (isset($_GET['logout']))) {
		$user->logout();
		echo "<script>history.pushState('', '', 'home');</script>";
	}

	if ($_SESSION['idUser'] > 0) {
		$arrUser = $user->selectUsers(0, $_SESSION['idUser']);
		$arrUser = $arrUser[0];
		if ($arrUser['idProject'] != $_SESSION['idProject']) {
			$user->logout();
		}
	}

	// If switch to PC version if blnMobile = 2
	if ($_GET['blnMobile'] == 2) {
		setcookie("blnMobile", 2, time() + $strings->intCookieLifeSec); $_COOKIE['blnMobile'] = 2;
	}
	
	// If acessing from mobile device, redirect to mobile page
	if ((! isset($_COOKIE['blnMobile'])) && ($strings->blnIsDevice('mobile'))) {
		header("Location: mobile"); exit;
	}
	
	if ((! $_GET['s']) || (! file_exists($_GET['s'] . '.php'))) {
		$_GET['s'] = $strings->strSiteDefaultHomePage;
	}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title><? echo strip_tags($arrProject['strName']); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="<? echo $arrProject['txtDescription']; ?>">
    <meta name="author" content="<? echo $strings->strSiteAuthorName; ?>">
    <meta name="application-name" content="<? echo $strings->strSiteName . ' - ' . $arrProject['strName']; ?>"/>
    <meta name="msapplication-TileColor" content="<? echo $arrProject['strRGBColor']; ?>"/>
    <meta name="msapplication-TileImage" content="<? echo $strings->strSiteURL . '/' . $arrProject['strBackgroundFileFullPath']; ?>"/>
    <meta name="description" content="<? echo $arrProject['txtDescription']; ?>"/>
    <meta property="og:locale" content="<? echo $arrProject['strLanguageCode']; ?>" />
    <meta property="og:title" content="<? echo $strings->strSiteName . ' - ' . $arrProject['strName']; ?>"/>
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="<? echo $strings->strSiteURL . '/' . $arrProject['strAlias']; ?>"/>
    <meta property="og:image" content="<? echo $strings->strSiteURL . '/' . $arrProject['strLogoFileFullPath']; ?>"/>
    <meta property="og:site_name" content="<? echo $arrProject['strName']; ?>"/>
    <meta property="og:description" content="<? echo $arrProject['txtDescription']; ?>"/>
    <link href="css/bootstrap.css" rel="stylesheet">
	<!-- Config Selected Theme -->
	<link id="bs-css" href="css/bootstrap-<? echo $arrProject['strThemeName']; ?>.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/jquery-ui.css" rel="stylesheet">
	<link href="css/charisma.css" rel="stylesheet">
	<!-- Custom Fonts -->
	<link href="fonts/fonts.css" rel="stylesheet">
    <!-- Fav and touch icons -->
    <link rel="shortcut icon" href="<? echo $arrProject['strLogoFileFullPath']; ?>">
	<!-- javascript Libs-->
    <script src="js/jquery-1.11.1.js"></script>
	<script src="js/jquery-ui.js"></script>
    <script src="js/bootstrap-modal.js"></script>
    <script src="js/bootstrap-dropdown.js"></script>
    <script src="js/bootstrap-tooltip.js"></script>
	<script src="js/bootstrap-button.js"></script>
	<script src="js/bootstrap-alert.js"></script>
    <!-- Color Picker -->
	<script src="js/colorpicker/jscolor.js"></script>
	<!-- Navbar Menu (expand & contract) -->
	<script src="js/bootstrap-collapse.js"></script>
	<!-- Backstretch -->
	<script src="js/jquery.backstretch.js"></script>
	<!-- Datepicker -->
	<script src="js/bootstrap-datepicker.js"></script>
	<!-- Data Tables -->
	<script src="js/jquery.dataTables.js"></script>
	<!-- autocomplete library -->
	<script src="js/bootstrap-typeahead.js"></script>
    <!-- Fancybox -->
	<script type="text/javascript" src="js/fancybox/jquery.easing-1.3.pack.js"></script>
	<script type="text/javascript" src="js/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
	<script type="text/javascript" src="js/fancybox/jquery.fancybox-1.3.4.js"></script>
	<link rel="stylesheet" type="text/css" href="js/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
	<!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
    <script src="js/fileupload/js/jquery.ui.widget.js"></script>
    <script src="js/fileupload/js/jquery.fileupload.js"></script>
    <!-- Autocomplete -->
    <script type="text/javascript" src="js/autocomplete/jquery.mockjax.js"></script>
    <script type="text/javascript" src="js/autocomplete/jquery.autocomplete.js"></script>
	<link rel="stylesheet" type="text/css" href="js/autocomplete/autocomplete.css" media="screen" />
    <!-- Chosen - Select Autocomplete -->
    <link rel="stylesheet" href="js/chosen/chosen.css">
	<script src="js/chosen/chosen.jquery.js" type="text/javascript"></script>
	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=visualization,places,geometry"></script>
	<!-- Google Search API -->
	<script src="https://www.google.com/jsapi"></script>
    <script src="js/main.js"></script>
	<!-- Google Analytics -->
	<? if ($arrProject['strGoogleAnalyticsID']) { ?>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
	  ga('create', '<? echo $arrProject['strGoogleAnalyticsID']; ?>', 'viconsaga.com.br');
	  ga('send', 'pageview');
	</script>
	<? } ?>
</head>
<body>
<style>
	/* Set autosize for Search Field Top Bar */
	.autocomplete-suggestions{ width:auto !important; }
	/* Hide Google Maps Footer Report a Bug , Scale Bar, Terms of Use */
	/* .gm-style-cc {display: none !important;} */
</style>
<form action="<? echo $_SERVER["PHP_SELF"] . '?' . $_SERVER["QUERY_STRING"]; ?>" method="post" name="frmForm" id="frmForm" enctype="multipart/form-data" onKeyPress="">
<div id="divLoadingFullScreen" style="display:none;position:absolute;top:0px;left:0px;width:100%;height:100%;z-index:9999" class="translucent30"><img src="img/loading.gif" style="top:50%;left:50%;position:absolute"></div>
<span id="alertInfo" class="alert alert-primary" style="display:none;z-index:9999;position:absolute;left:20%;text-align:center;width:50%;"><strong><span id="alertInfoMessage"></span></strong></span>
<span id="alertSuccess" class="alert alert-success" title="<? echo $_SESSION['strGlobalSaved']; ?>" style="display:none;z-index:9999;position:absolute;left:35%;width:20%;color:#008400;text-align:center;"><i class="icon-ok-circle"></i> <strong><span id="alertSuccessMessage"></span></strong></span>
<span id="top"></span>
<div id="divPageContainer" class="container" style="width:98%">
  <div id="divPageHeader" class="masthead hideSelection">
    <div class="navbar">
      <div class="navbar-inner" style="padding-left:2px;padding-right:0px;">
        <!-- Start Language Menu -->
        <input type="hidden" name="strSiteLanguage" id="strSiteLanguage">  
        <div class="btn-group pull-right" style="top:4px;position:relative"> 
          <a class="btn dropdown-toggle" data-toggle="dropdown" href="#"><img src="img/language/<? echo $_SESSION['Indice']; ?>.png" align="absmiddle" style="width:24px;height:24px;"> <span class="caret"></span></a>
          <ul class="dropdown-menu" style="padding:4px;width:210px;">
            <?
              $arrLanguages = $strings->loadLanguagesList();
              sort($arrLanguages);
              foreach($arrLanguages as $item) {
				  $arrTupla = explode(':', $item);
				  echo '<li><a href="#" style="font-size:12px;" onclick="window.location=\'index.php?' .  $_SERVER['QUERY_STRING'] . '&language=' . $arrTupla[1] . '\';"><img src="img/language/' . strtolower($arrTupla[1]) . '.png" align="absmiddle" style="width:24px;height:24px;"> <b>' . $arrTupla[0] . '</b></a></li>';
              }
            ?>
          </ul>
        </div>
        <!-- End Language Menu -->
        
        <!-- Alerts Menu -->
        <?
		  $intUserAlerts = 0;
		  if ($_SESSION['idUser'] > 0) {
			$intUserAlerts = $alert->intCountUserAlerts($_SESSION['idUser'], 1);
		  }
        ?>
		<? if ($intUserAlerts > 0) { ?>        
        <div class="btn-group pull-right input-append" style="float:right;position:relative;top:4px;padding-right:0px"> 
        <a id="btnUserAlerts" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" data-loading-text="..." style="padding:7px" onClick="userAlertEventsSetRead()"> 
          <i class="<? echo $alert->strDefaultIcon; ?> icon-white"></i> <span data-rel="tooltip" title="<? echo $_SESSION['strIndexUnreadAlerts']; ?>" class="userAlertEventsCounter" id="spanUserAlertEventsCounter">0</span> 
        </a> 
        <ul class="dropdown-menu" style="padding:4px;">
          <div id="divAlerts" style="font-size:11px;color:#000000;white-space:nowrap;"></div>
          <li class="divider" style="margin:0px"></li>
          <li><a href="manage-alerts"><i class="icon-cog"></i> 
          <? echo $_SESSION['strIndexMenuManageAlerts']; ?> (<? echo $intUserAlerts; ?>)</a></li>
        </ul>
        </div>
        <? } ?>
        <!-- End Alerts Menu -->

        <!-- Start User Menu -->
        <div class="btn-group pull-right" id="mnuUserMenu" style="top:4px;position:relative;padding-right:0px"> 
          <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" id="mnuUserMenu" style="padding:7px"> 
            <img src="img/menu.png"> <span class="hidden-phone" id="menuTitle"> <? if ($_SESSION['idUser'] > 0) { echo $arrUser['strEmailAbbreviated']; } else { echo $_SESSION['strMenuUserLogin']; } ?></span> <span class="caret"></span>
          </a> 
          <ul class="dropdown-menu" <? if ($_SESSION['idUser'] <= 0) { ?> style="padding:5px;width:200px" <? } ?> id="mnuUserMenuList">
          <? if ($_SESSION['idUser'] > 0) { ?>
            <li><a href="user-profile-edit"><i class="icon-pencil"></i> <? echo $_SESSION['strIndexMenuEditProfile']; ?></a></li>
            <li><a href="project-stats"><i class="<? echo $stats->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuStats']; ?></a></li>
            <li><a href="support"><i class="<? echo $support->strDefaultIcon; ?>"></i> <? $intNew = $support->intCountUnreadResponses($arrUser['idUser'], 0, 1); echo $_SESSION['strIndexMenuProjectManagementSupport'] . ' | <span ' . ($intNew > 0 ? 'style="font-weight:bold;color:#FF0000"' : '') . '>' . $intNew  . ' ' . $_SESSION['stradmSupportNewMessages'] . '</span>'; ?></a></li>
            <li><a href="manage-alerts"><i class="<? echo $alert->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuManageAlerts']; ?> (<? echo $intUserAlerts; ?>)</a></li>
            <li class="divider"></li>
            <li><a style="cursor:none;"><? echo $_SESSION['strHomeTools']; ?></a></li>
            <li><a href="tool-geocoder">&nbsp;&nbsp;&nbsp;<i class="icon-screenshot"></i> <? echo $_SESSION['strHomeToolsGeocoder']; ?></a></li>
            <li><a href="tool-conversor-coordinates">&nbsp;&nbsp;&nbsp;<i class="icon-resize-horizontal"></i> <? echo $_SESSION['strHomeToolsCoordinatesConversor']; ?></a></li>
            <? if ($arrUser['idUserLevel'] > 1) { ?>
              <li><a href="tool-importer">&nbsp;&nbsp;&nbsp;<i class="<? echo $importer->strDefaultIcon; ?>"></i> 
			  <? echo $_SESSION['strHomeToolsDataImporter']; ?> [.shp;.kml;.csv;.xls]</a></li>
			  <? if ($arrProject['strAlias'] == 'agendacidada') {  ?>
              <li><a href="tool-importer-agenda">&nbsp;&nbsp;&nbsp;<i class="icon-font"></i> Importador Agenda Cidad�</a></li>
              <? } ?>
			<? } ?>
			<? if ($arrUser['idUserLevel'] > 3) { ?>
            <li class="divider"></li>
            <li><a style="cursor:none;"><? echo $_SESSION['strIndexMenuProjectManagement']; ?></a></li>
            <li><a href="manage-project">&nbsp;&nbsp;&nbsp;<i class="icon-wrench"></i> <? echo $_SESSION['strIndexMenuProjectManagementConfiguration']; ?></a></li>
            <li><a href="manage-events">&nbsp;&nbsp;&nbsp;<i class="<? echo $database->strEventLogDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementManageUserEvents']; ?></a></li>
            <li><a href="manage-users">&nbsp;&nbsp;&nbsp;<i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementManageUsers'] . ' (' . $user->intCountUsers($arrProject['idProject']) . ')'; ?></a></li>
            <li><a href="manage-forms">&nbsp;&nbsp;&nbsp;<i class="<? echo $form->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementManageForms'] . ' (' . $form->intCountForms($arrProject['idProject']) . ')'; ?></a></li>
            <? } ?>
            <li class="divider"></li>
            <li><a href="logout"><i class="icon-off"></i> <? echo $_SESSION['strMenuUserLogout']; ?></a></li>
            <? } else { ?>
            <input  style="width:92%" type="text" id="strLoginEmail" name="strLoginEmail" placeholder="<? echo $_SESSION["strIndexMenuLogin_1"]; ?>" tabindex="1" value="<? echo $_POST['strLoginEmail']; ?>">
            <br>
            <input style="width:92%" type="password" id="strLoginPassword" name="strLoginPassword" placeholder="<? echo $_SESSION["strIndexMenuLogin_2"]; ?>" tabindex="2" onKeyDown="if(event.keyCode=='13') {userLogin();}
              " value="<? echo $_POST['strLoginPassword']; ?>">
            <br>
            <span id="btnLoginLogin" name="btnLoginLogin" style="float:left" data-loading-text="..." class="btn btn-primary" tabindex="3" onClick="
              if ((! document.getElementById('strLoginEmail').value) || (! document.getElementById('strLoginPassword').value)) {
                  showInfoAlert('<? echo $_SESSION['strIndexMenuLogin_6']; ?>');
              } else {
                  userLogin();
              }"><? echo $_SESSION["strIndexMenuLogin"]; ?> </span> 
            <span type="button" id="btnLoginForgotPassword" name="btnLoginForgotPassword" class="btn btn-primary" style="float:right" data-loading-text="<? echo $_SESSION["strIndexMenuLogin_5"]; ?>..." onClick="userForgotPassword(document.getElementById('strLoginEmail').value);"><? echo $_SESSION["strIndexMenuLogin_4"]; ?></span> 
            <? } ?>
          </ul>
        </div>
        <!-- End User Menu -->

        <!-- Start Create Record -->
        <? if (($_SESSION['idUser'] > 0) && ($arrUser['idUserLevel'] > 1)) { ?>          
        <div class="btn-group pull-right" style="top:4px;position:relative;padding-right:0px"> 
          <a class="btn btn-success dropdown-toggle" data-toggle="dropdown" href="#" style="padding:7px" data-rel="tooltip" title="<? echo $_SESSION["strIndexButtonCreateRecord"]; ?>"><i class="icon-map-marker icon-white"></i><i class="icon-plus icon-white"></i> 
          <i class="caret"></i></a> 
          <ul  class="dropdown-menu">
            <?
              $arrForms = $form->selectForms($arrProject['idProject'], 0, '', 1);
              foreach ($arrForms as $arrForm) {
                  echo '<li><a target="_self" href="record-edit-' . $arrForm['idForm'] . '" style="padding:4px"><div style="text-align: center;width:20px;display: inline-block;"><img src="' . $arrForm['strMarkerFullPath'] . '" style="max-height:18px;max-width:20px;margin-right:4px;" class="rounded" align="absmiddle"></div> ' . $arrForm['strName'] . '</a></li>';
              }
            ?>
          </ul>
        </div>
        <!-- Finish Create Record -->
        <? } ?>

        <!-- Button Join -->
		<? if (($arrProject['blnAllowJoin']) && ($_SESSION['idUser'] <= 0)) { ?>
        <a class="btn btn-success pull-right" style="padding:8px;position:relative;top:3px;margin-right:0px" onClick="userJoinShow();"><i class="icon-edit icon-white"></i><span class="hidden-tablet hidden-phone"> <? echo $_SESSION["strIndexJoin"]; ?></span></a>
        <? } ?>

        <!-- Agenda Cidad� Charts & Reports -->
        <? if ($arrProject['strAlias'] == 'agendacidada') {  ?>
            <a class="btn btn-info pull-right" style="padding:8px;position:relative;top:3px;margin-right:0px" href="agenda/">Gr�ficos</a> 
            <span class="btn pull-right" style="padding:8px;position:relative;top:3px;margin-right:0px"><img src="img/filetypes/pdf.png" style="height:16px;"> 
                <a href="https://www.dropbox.com/s/yc5ls565l3jp0od/Agenda%20Cidad%C3%A3%20-%20Relat%C3%B3rio%20Final.pdf?dl=0" target="_blank" data-rel="tooltip" title="Relat�rio Final do Projeto Agenda Cidad� (pdf)"><b>Relat�rio Final</b></a> | 
                <a href="https://www.dropbox.com/s/nl113uzy2d1ctui/Agenda%20Cidad%C3%A3%20-%20Agendas%20Escolas%20Participantes.pdf?dl=0" target="_blank" data-rel="tooltip" title="Agenda Cidad� - Agendas Escolas Participantes (pdf)"><b>ANEXO</b></a>
            </span>
        <? } ?>

		<? if (($arrProject['blnAllowAllView']) || ($_SESSION['idUser'] > 0)) { ?>
        <!-- Search Site -->
        <div id="divSearch" class="hidden-phone input-prepend pull-right" style="position:relative;top:11px;"> 
          <div class="btn-group dropdown" style="padding:0px"> <span id="cmbSearchType" class="dropdown-toggle add-on" data-toggle="dropdown" style="cursor:pointer" data-rel="tooltip" data-placement="top" title="<? echo $_SESSION['strIndexSearchType']; ?>"> 
            <i class="icon-map-marker"></i> <span class="caret"></span> </span> 
            <ul class="dropdown-menu" role="menu">
              <li><a id="aSearchType_1" href="#" onClick="searchSetType(1, true);"><i class="icon-list-alt"></i> 
                <? echo ucfirst($_SESSION['strIndexSearchTypeRecord']); ?></a></li>
              <li><a id="aSearchType_2" href="#" onClick="searchSetType(2, true);"><i class="icon-map-marker"></i> 
                <? echo ucfirst($_SESSION['strIndexSearchTypePlace']); ?></a></li>
              <li><a id="aSearchType_3" href="#" onClick="searchSetType(3, true);"><i class="icon-screenshot"></i> 
                <? echo ucfirst($_SESSION['strIndexSearchTypeCoordinates']); ?></a></li>
              <li><a id="aSearchType_4" href="#" onClick="searchSetType(4, true);"><i class="icon-user"></i> 
                <? echo ucfirst($_SESSION['strIndexSearchTypeUsers']); ?></a></li>
            </ul>
          </div>
          <span id="spanSearchMyPosition" data-rel="tooltip" title="<? echo $_SESSION['strHomeMyLocationTip']; ?>" class="add-on" style="cursor:pointer;" onClick="searchMapCenterMyLocation()"><img src="img/myLocation.png" style="width:16px;height:17px;position:relative;top:-1px;"></span> 
          <input type="hidden" id="idSearchType">
		  <input type="text" id="strSearch" name="strSearch" style="width:200px;background-position:right;background-repeat:no-repeat" autocomplete="off" placeholder="<? echo $_SESSION["strGlobalSearch"] . ' ' . $_SESSION['strIndexSearchTypePlace']; ?>..." value="<? echo (isset($_GET["q"]) ? $_GET["q"] : ''); ?>" onKeyDown="if(event.keyCode=='13') { search(); }">
          <!-- <span class="add-on" style="cursor:pointer"><i class="icon-search" onClick="search();"></i></span> -->
        </div>
        <? } ?>
  
        <!-- Main Menu -->
        <div style="height:50px;overflow-y:hidden;">
            <table style="width:100%">
            <tr style="height:50px;overflow-y:hidden;">
                <td style="vertical-align:top;width:50px;">
                <a href="home" data-rel="tooltip" title="<? echo $_SESSION["strMenuHome"]; ?>" class="navbar-link">
                <img id="imgLogo" src="<? echo $arrProject['strLogoFileFullPath']; ?>" style="height:50px;top:10px;" class="rounded">
                </a>
                </td>
                <td id="spanIndexProjectName" style="vertical-align:middle;font-family:'Candal';text-shadow:1px 1px #000000;font-size:20px;line-height:22px;max-width:150px;word-wrap:break-word;" class="hidden-phone" >
                <a href="home" data-rel="tooltip" title="<? echo $_SESSION["strMenuHome"]; ?>" class="navbar-link">
                <? echo $arrProject['strName']; ?>
                </a>
                </td>
            </tr>
            </table>
        </div>
      </div>
    </div><!-- /.navbar -->
  </div><!-- /.masterhead -->

  <div id="mainContent" class="row translucent70 shine rounded" style="padding-bottom:10px;text-align:justify;color:#000000;">
	<?
	  // Avoid non authorized user to enter adm area
	  if (
		  ((strpos($_GET['s'], 'adm') !== FALSE) && ($_SESSION['idUser'] != $arrUser['idUser']))
		  || (($_GET['s'] == 'recordEdit') && ($arrUser['idUserLevel'] < 2))
	  ) {
		  echo $_SESSION["strGlobalPageNonAuthorided"];
	  } else if ((! $_GET['s']) || (! file_exists($_GET['s'] . '.php'))) {
		  echo $_SESSION["strGlobalPageNoExists"];
	  } else {
		  @include($_GET['s'] . '.php');
	  }
	?>
  </div>

  <div id="divPageFooter" class="footer translucent70 hideSelection" style="position:fixed; padding:1px;left:0px; bottom:0px; height:20px; width:100%;text-align:right;z-index:-1;font-size:11px;color:#000000;font-weight:bold">
    <span style="float:left;margin-top:1px;">
	  <?
		echo
			($arrProject['strSkypeID'] ? $strings->strSkypeUserStatus($arrProject['strSkypeID'], 18, false) : '') .
			($arrProject['blnAllowAllView'] ? '<img src="img/earth.png" style="height:16px;cursor:pointer" title="Google Earth Live KML" onClick="googleEarthGenerate();">' : '')
		;
      ?>
    </span>
    <p style="margin-right:20px;">
      <span class="hidden-phone">
      <?
		echo
		  ($arrProject[0]['strAddress'] ? '<i class="icon-map-marker"></i> <a href="?s=contact" target="_self">' . $arrProject[0]['strAddress'] . '</a>' : '') . 
		  ' &copy; ' . date('Y', strtotime($arrProject['dtDateCreation'])) . ' - ' . date('Y') . ' � '
		;
      ?>
      </span> 
      <a href="help" target="_blank"><? echo $_SESSION["strIndexFooterHelp"]; ?></a>
      � <a href="help/terms-use" target="_blank"><? echo $_SESSION["strIndexFooterTermsUse"]; ?></a>
      � <a href="help/api" target="_blank">API</a>
      � <a href="mobile" target="_self"><? echo $_SESSION["strIndexFooterMobile"]; ?></a>
      � <? echo $_SESSION["strIndexFooterPoweredBy"] . ' <a href="' . $strings->strSiteURL . '/site/" target="_blank">' . $strings->strSiteName . '</a> <img src="' . $strings->strSiteLogoPath . '" style="height:24px;" align="baseline">'; ?>
    </p>
  </div>
</div>
    
<!-- Panel for Join User -->
<div class="modal hide fade hideSelection" id="modalUserJoin">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">�</button>
    <h4><i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexUserJoinTitle']; ?></h4>
  </div>    
  <div class="modal-body"> 
    <div class="control-group"> 
      <!-- strEmail --><label class="control-label">
      <? echo $_SESSION['stradmManageUsersEmail']; ?>: 
      <div class="controls"> 
        <input type="text" class="fullwith" id="strJoinUserEmail" name="strJoinUserEmail">
      </div>
      <!-- strName -->
      <label class="control-label"><? echo $_SESSION['stradmManageUsersName']; ?>:</label>
      <div class="controls"> 
        <input type="text" class="fullwith" id="strJoinUserName" name="strJoinUserName">
      </div>
    </div>
  </div>
  <div class="modal-footer">
      <a href="#" class="btn" id="btnModalJoinUserCancel" name="btnModalJoinUserCancel" data-dismiss="modal"><? echo $_SESSION['strGlobalCancel']; ?></a>
      <a href="#" class="btn btn-primary" id="btnModalJoinUserSubmit" name="btnModalJoinUserSave" data-loading-text="<? echo $_SESSION["strGlobalProcessing"]; ?>..." onClick="userJoinSubmit();"><? echo $_SESSION['strGlobalSubmit']; ?></a>
  </div>
</div>
</form>
<script>
  var map, idTreeItem, searchBoxListener;
  
  function searchResizeField() {
	  if (document.getElementById("divSearch")) {
		  document.getElementById("divSearch").style.display = $(document).width() > 360 ? "block" : "none";
		  document.getElementById("strSearch").style.width = ($(document).width() < 510 ? ($(document).width() > 420 ? "100" : "40") : "180")+ "px";
	  }
  }
  
  function searchMapCenterMyLocation() {
	  if (map) {
		  mapCenterMyLocation();
	  } else {
		  window.location = 'home';
	  }
  }
  
  function searchSetType(intSearchType, blnFocus) {
	  <? if ($_GET['s'] != "recordEdit") { ?>
	  $.ajax({url: 'ajax.php?chrAction=ISTU&intSearchType=' + intSearchType});
	  <? } ?>
	  var obj = document.getElementById('aSearchType_' + intSearchType);
	  var objSearch = document.getElementById('strSearch');
	  if (objSearch == null) return;
	  document.getElementById('cmbSearchType').innerHTML = obj.innerHTML + ' <span class="caret"></span>';
	  document.getElementById('cmbSearchType').innerHTML = '<i class="icon-' + (intSearchType == 1 ? 'list-alt' : intSearchType == 2 ? 'map-marker' : intSearchType == 3 ? 'screenshot' : 'user') + '"></i> <span class="caret"></span>';
	  document.getElementById('spanSearchMyPosition').style.display = (intSearchType == 1 || intSearchType == 4) ? 'none' : 'inline-block';
	  document.getElementById('idSearchType').value = intSearchType;
	  if (("<? echo $_GET['s']; ?>" == "") || ("<? echo $_GET['s']; ?>" == "home")) mapClearAllUserPositions();
	  $('#strSearch').tooltip('hide')
		.attr('data-original-title', '')
		.tooltip('fixTitle')
		.tooltip('show');
	  if ((intSearchType == 1) || (intSearchType == 4)) {
		  document.getElementById('strSearch').placeholder = "<? echo $_SESSION["strGlobalSearch"]; ?> " + (intSearchType == 1 ? "<? echo $_SESSION['strIndexSearchTypeRecord']; ?>" : "<? echo $_SESSION['strIndexSearchTypeUsers']; ?>") + "...";
		  google.maps.event.removeListener(searchBoxListener);
		  searchBoxListener = null;
		  searchBox = null;
		  google.maps.event.clearListeners(objSearch, "focus");
		  google.maps.event.clearListeners(objSearch, "blur");
		  google.maps.event.clearListeners(objSearch, "keydown");
		  // Preparing for autocomplete for search DB
		  $('#strSearch').autocomplete({
			  serviceUrl: 'ajax.php?chrAction=ISA&intSearchType=' + intSearchType + '&idProject=<? echo $arrProject['idProject']; ?>',
			  minChars:3,
			  deferRequestBy: 200,
			  width:"auto",
			  onSearchStart: function (query) {
				  document.getElementById('strSearch').style.backgroundImage="url(img/loading.gif)";
			  },
			  onSearchComplete: function (query, suggestions) {
				  document.getElementById('strSearch').style.backgroundImage = "";
			  },
			  onSelect: function(suggestion) {
				  document.getElementById('strSearch').value = suggestion.text;
				  var arrData = suggestion.data.split(':')
				  if ((map) && (intSearchType == 1)) {
					  idTreeItem = arrData[0] + ':' + arrData[1];
					  if (tree.getIndexById(idTreeItem)) {
						  treeHighlightRecord(arrData[0], arrData[1]);
						  treeOnClick(idTreeItem);
					  }
					  infoLoad(arrData[1]);
					  map.setCenter(new google.maps.LatLng(arrData[2], arrData[3]));
					  
				  } 
				  if (! map) {
					  window.open('home-' + arrData[1], '_blank');
				  }
			  }
		  });
	  } else if (intSearchType == 2) {
		  if ($('#strSearch').autocomplete()) {
			  $('#strSearch').autocomplete().dispose();
		  }
		  try {
			  document.getElementById('strSearch').placeholder = "<? echo $_SESSION["strGlobalSearch"] . ' ' . $_SESSION['strIndexSearchTypePlace']; ?>...";
			  mapSearchBoxInitialize('strSearch');
		  } catch(error) { }
	  } else if (intSearchType == 3) {
		  if ($('#strSearch').autocomplete()) {
			  $('#strSearch').autocomplete().dispose();
		  }
		  google.maps.event.removeListener(searchBoxListener);
		  searchBoxListener = null;
		  searchBox = null;
		  google.maps.event.clearListeners(objSearch, "focus");
		  google.maps.event.clearListeners(objSearch, "blur");
		  google.maps.event.clearListeners(objSearch, "keydown");
		  document.getElementById('strSearch').placeholder = "<? echo $_SESSION["strGlobalExample"]; ?>: -23.123456,-43.123456";
		  $('#strSearch').attr('data-original-title', "<div style='text-align:left'><? echo $_SESSION["strIndexSearchTypeCoordinatesTip"]; ?></div>");
	  }
	  if (blnFocus) document.getElementById('strSearch').focus();
  }
  
  function search() {
	  // Insert Search Terms in projectsearch
	  $.ajax({url: 'ajax.php?chrAction=IPS&idProject=<? echo $arrProject['idProject']; ?>&strSearch=' + document.getElementById('strSearch').value});
	  var idSearchType = document.getElementById('idSearchType').value;
	  if (idSearchType == 1) {
	  } else if (idSearchType == 2) {
	  } else if (idSearchType == 3) { // Center Map By Coordinates
		  // Formating coordinates
		  var arrCoordinates = document.getElementById('strSearch').value.split(',');
		  if (arrCoordinates.length < 2) return;
		  var dblLatitude = parseFloat(strCoordinatesFormat(arrCoordinates[0])).toFixed(7);
		  var dblLongitude = parseFloat(strCoordinatesFormat(arrCoordinates[1])).toFixed(7);
		  document.getElementById('strSearch').value = dblLatitude + ',' + dblLongitude;
		  var arrCoordinates = document.getElementById('strSearch').value.split(',');
		  if (arrCoordinates.length < 2) return;
		  var dblLatitude = parseFloat(arrCoordinates[0]);
		  if (isNaN(dblLatitude) || (dblLatitude < -90) || (dblLatitude > 90)) dblLatitude = 0;
		  var dblLongitude = parseFloat(arrCoordinates[1]);
		  if (isNaN(dblLongitude) || (dblLongitude < -180) || (dblLongitude > 180)) dblLongitude = 0;
		  map.panTo(new google.maps.LatLng(dblLatitude, dblLongitude));
		  document.getElementById('strSearch').value = dblLatitude + ',' + dblLongitude;
		  mapShowTargetMarker(dblLatitude, dblLongitude);
	  }
  }
  
  function userJoinShow() {
	  document.getElementById('strJoinUserEmail').value = '';
	  document.getElementById('strJoinUserName').value = '';
	  $('#modalUserJoin').modal('show');
	  document.getElementById('strJoinUserEmail').focus();
  }
  
  function userJoinSubmit() {
	  if ((! document.getElementById('strJoinUserEmail').value) || (document.getElementById('strJoinUserEmail').value.indexOf("@") < 0)) {
		  showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageUsersEmail']); ?>');
		  document.getElementById('strJoinUserEmail').focus();
		  return false;
	  }
	  
	  if (! document.getElementById('strJoinUserName').value) {
		  showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageUsersName']); ?>');
		  document.getElementById('strJoinUserName').focus();
		  return false;
	  }
  
	  $('#btnModalJoinUserSubmit').button('loading');
	  var result = $.ajax({
		  url: 'ajax.php?chrAction=UI' + 
			  '&idProject=<? echo $arrProject['idProject']; ?>' +
			  '&idProjectWorkgroup=0' +
			  '&idUserLevel=<? echo $arrProject['blnAllowJoinAsLevel3'] > 0 ? '3' : '1'; ?>' + 
			  '&blnActive=1' +
			  '&strEmail=' + document.getElementById('strJoinUserEmail').value +
			  '&strName=' + document.getElementById('strJoinUserName').value +
			  '&blnSendNotificationMail=1'
	  }).always(function() {
		  var response 	= result.responseText;
		  var arrResult 	= JSON.parse(response);
		  if (arrResult['idUser'] > 0) {
			  showInfoAlert("<? echo $_SESSION['strIndexUserJoinSuccess']; ?>");
			  $('#modalUserJoin').modal('hide');
		  } else if (arrResult['idUser'] == -1) {
			  showInfoAlert("<? echo $_SESSION['strErrorEmailAlreadyExists']; ?>");
		  } else {
			  showInfoAlert("<? echo $_SESSION['strIndexUserJoinError']; ?>");
		  }
		  $('#btnModalJoinUserSubmit').button('reset');
	  });
  }
	  
  function userLogin() {
	  $('#btnLoginLogin').button('loading');
	  var result = $.ajax({
		  url: "ajax.php?chrAction=UL" +
					  "&idProject=<? echo $arrProject['idProject']; ?>" +
					  "&strEmail=" + document.getElementById('strLoginEmail').value + 
					  "&strPassword=" + document.getElementById('strLoginPassword').value
	  }).done(function() {
		  $('#btnLoginLogin').button('reset');
		  if (result.responseText) {
			  var response 	= result.responseText;
			  if (result.responseText == "1") {
				  window.location = "home";
			  } else {
				  showInfoAlert("<? echo $_SESSION['strLoginFailWrongPassword']; ?>");
			  }
		  }
	  });
  }
  
  function userForgotPassword(strEmail) {
	  if (! strEmail) {
		  showInfoAlert('<? echo $_SESSION['strIndexMenuLogin_13']; ?>');
		  return;
	  }
	  $('#btnLoginForgotPassword').button('loading');
	  var strParams = 'chrAction=UFP' +
					  '&idProject=<? echo $arrProject['idProject']; ?>' +
					  '&strEmail=' + strEmail;
	  var result = $.ajax({
		  url: "ajax.php?" + strParams
	  }).done(function() {
		  showInfoAlert(result.responseText);
		  $('#btnLoginForgotPassword').button('reset');
	  });
  }
  
  function userAlertEventsLoad(){
	  var span = document.getElementById('spanUserAlertEventsCounter');
	  var divAlerts = document.getElementById('divAlerts');
	  divAlerts.innerHTML = '<div style="text-align:center;width:100%"><img src="img/loading1.gif"></div>';
	  var result = $.ajax({
		  url: 'ajax.php?chrAction=IUAES&idUser=<? echo $arrUser['idUser']; ?>&intLimit=20'
	  }).always(function() {
		  var response 	= result.responseText;
		  var arrResult 	= JSON.parse(response);
		  var strUserAlerts = '';
		  var intNumUnreadUserAlertEvents = 0;
		  if (arrResult.length == 0) {
			  strUserAlerts = "<i><? echo $_SESSION['strIndexAlertsNoAlerts']; ?></i>";
		  }
		  for (var i=0;i<arrResult.length;i++) {
			  strUserAlerts += '<div class="width:100%" style="' + (arrResult[i]['blnRead'] == "0" ? 'font-weight:bold' : '') + '">' + arrResult[i]['strEventInfo'] + '</div>';
			  // Check unread
			  if (arrResult[i]['blnRead'] == "0") intNumUnreadUserAlertEvents++;
		  }
		  strUserAlerts += '<div class="width:100%;font-size:12px;padding:0px;margin:0px"><a href="index.php?s=admManageAlerts&ss=1" style="text-align:center"><? echo $_SESSION['strIndexAlertsShowAllAlerts']; ?></a></div>';
		  divAlerts.innerHTML = strUserAlerts;
		  span.innerHTML = intNumUnreadUserAlertEvents;
		  span.style.display = (intNumUnreadUserAlertEvents > 0 ? 'block' : 'none');
	  });
  }
  
  function userAlertEventsUnreadCount(){
	  var span = document.getElementById('spanUserAlertEventsCounter');
	  var result = $.ajax({
		  url: 'ajax.php?chrAction=IUAEUC&idUser=<? echo $arrUser['idUser']; ?>'
	  }).always(function() {
		  var response 	= result.responseText;
		  var retorno 	= JSON.parse(response);
		  span.innerHTML = retorno['intNumUnreadUserAlertEvents'];
		  span.style.display = (retorno['intNumUnreadUserAlertEvents'] != "0" ? 'block' : 'none');
	  });
  }
  
  function userAlertEventsSetRead(){
	  var span = document.getElementById('spanUserAlertEventsCounter');
	  span.innerHTML = "0";
	  span.style.display = 'none';
	  $.ajax({url: 'ajax.php?chrAction=IUAESR&idUser=<? echo $arrUser['idUser']; ?>'});
  }
  
  function userAlertEventsShowDetails(idUserAlertEvent){
	  $('#btnUserAlerts').button('loading');
	  var result = $.ajax({
		  url: 'ajax.php?chrAction=IUAED&idUserAlertEvent=' + idUserAlertEvent
	  }).always(function() {
		  $('#btnUserAlerts').button('reset');
		  var response 	= result.responseText;
		  var retorno 	= JSON.parse(response);
		  if (! retorno['txtDetails']) return;
		  var strDetails = '<div style="width:600px;height:500px;overflow-x:hidden;overflow-y:auto;">' + retorno['txtDetails'] + '</div>';
		  $.fancybox({'title':'<? echo $_SESSION['stradmManageAlertsMailRecordInformation']; ?>','content':strDetails});
	  });
  }
  
  function formrecordShowLog(idFormRecord){
	  $('#btnFormRecordLog').button('loading');
	  var result = $.ajax({
		  url: 'ajax.php?chrAction=IFRSL&idFormRecord=' + idFormRecord
	  }).always(function() {
		  $('#btnFormRecordLog').button('reset');
		  var response 	= result.responseText;
		  var retorno 	= JSON.parse(response);
		  if (! retorno['strLog']) return;
		  var strLog = '<div style="width:600px;height:500px;overflow-x:hidden;overflow-y:auto;">' + retorno['strLog'] + '</div>';
		  $.fancybox({'title':'<? echo $_SESSION['strGlobalFormRecordLog']; ?>','content':strLog});
	  });
  }
  
  function googleEarthGenerate() {
	  showInfoAlert("<img src='img/loading.gif'>  <? echo $_SESSION['strGlobalProcessing']; ?>", 1);
	  var result = $.ajax({
		  url: "ajax.php?chrAction=IGEG&idProject=<? echo $arrProject['idProject']; ?>"
	  }).done(function() {
		  var response 	= result.responseText;
		  var retorno 	= JSON.parse(response);
		  window.location='output.php?strName=' + retorno['strFilePath'] + '&strFileName=' + retorno['strFilePathTMP'];
		  showInfoAlert("<img src='img/loading.gif'>  <? echo $_SESSION['strGlobalProcessing']; ?>", 2);
	  });
  }
  
  <? if ($_SESSION['idUser'] <= 0) { ?>
  $('#mnuUserMenuList').click(function(event){
	  event.stopPropagation();
   });
  <? } ?>
  
  $(document).ready( function () {
	  $.backstretch(["<? echo $arrProject['strBackgroundFileFullPath']; ?>"], {duration: 3000, fade: 2000});
	  // Set Map Resize by Window Size
	  searchResizeField();
	  window.onresize = function(event) { searchResizeField(event); }
	  //prevent # links from moving to top
	  $('a[href="#"][data-top!=true]').click(function(e){	e.preventDefault(); });
	  // Initializing Tooltip
	  $('[rel="tooltip"],[data-rel="tooltip"]').tooltip({"html":"true", "placement":"bottom", delay: { show: 100, hide: 400 }});
	  $(".scroll").click(function(event){
		  event.preventDefault();
		  $('html,body').animate({scrollTop:$(this.hash).offset().top}, 800);
	  });
	  // Search Tooltip
	  $("#strSearch").tooltip({placement:'bottom', trigger:'hover focus', html : true});
	  // Tooltip on Focus
	  $("#strUserPassword").tooltip({
		  disabled: true
	  }).on("focusin", function () {
		  $(this)
			  .tooltip("enable")
			  .tooltip("open");
	  }).on("focusout", function () {
		  $(this)
			  .tooltip("close")
			  .tooltip("disable");
	  });
	  // Select Chosen
	  $('.chosen-select').chosen();
	  // Detect if browser is IE.  If true, show alert to use another browser
	  if (blnIsIE()) {
		  showInfoAlert('<? echo $_SESSION['strIndexBrowserIE']; ?>', 1);
	  }
	  // Initializing search field
	  searchSetType(<? echo ($_GET['s'] == "recordEdit" ? '2' : ($_COOKIE['intSearchType'] > 0 ? $_COOKIE['intSearchType'] : '1')); ?>, false);
	  <? if ($intUserAlerts > 0) { ?>
	  // Count Unread Alert Events
	  userAlertEventsLoad();
	  <? } ?>  
  });
</script>
</body>
</html>