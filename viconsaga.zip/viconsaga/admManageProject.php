<? $strings->changePageTitle($_SESSION['strIndexMenuProjectManagementConfiguration']); ?>
<script>
	var arrSessions = new Array ("preferences", "theme", "permissions");
</script>
<div class="sessionTitle">
	<i class="<? echo $project->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementConfiguration']; ?>
    <div id="ContainerBar" class="progress" style="width:200px;border:1px solid #003300;display:none;float:right">
	    <div id="bar" class="bar"></div>
    </div>
</div>
<div class="box-content hideSelection">
    <table width="100%"><tr>
    <!-- Menu -->
    <td valign="top">
        <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF">
            <li id="menu_preferences" onClick="showSession(arrSessions, 0);" >
                <a><i class="icon-info-sign"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageProjectMenuPreferences']; ?></span></a>
            </li>
            <li id="menu_theme" onClick="showSession(arrSessions, 1);">
                <a><i class="icon-tint"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageProjectMenuAppearance']; ?></span></a>
            </li>
            <li id="menu_permissions" onClick="showSession(arrSessions, 2);">
                <a><i class="icon-lock"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageProjectMenuPermissions']; ?></span></a>
            </li>
        </ul>
    </td>
    <!-- End Menu -->
    <!-- Body -->
    <td valign="top" width="100%" style="padding-left:20px;background-color:transparent;">
        <div id="div_preferences">
			<div class="sessionTitle"><i class="icon-info-sign"></i> <? echo $_SESSION['stradmManageProjectMenuPreferences']; ?></div>

            <!-- strDateCreation -->
            <label class="control-label"><i class="icon-calendar"></i> <? echo $_SESSION['stradmManageProjectPreferencesCreation']; ?>: <? echo $arrProject['strDateCreation'] . ' ' . $_SESSION['strGlobalBy'] . ' <i class=' . $user->strDefaultIcon . '></i> ' . $arrProject['strUserCreator']; ?></label>

            <!-- strAlias -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesAlias']; ?>:</label>
            <div class="controls">
				<div class="input-prepend fullwith">
                <span class="add-on"><img id="imgAliasStatus" src="img/yes.png" style="height:100%;width:100%"></span>
                <input type="text" class="fullwith" id="strAlias" name="strAlias" value="<? echo $arrProject['strAlias']; ?>" onBlur="blnAliasExists();">
				</div>
            </div>

            <!-- strName -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesName']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="strName" name="strName" value="<? echo $arrProject['strName']; ?>" onKeyUp="projectUpdateLogoText();">
            </div>

            <!-- txtDescription -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesDescription']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="txtDescription" name="txtDescription" value="<? echo $arrProject['txtDescription']; ?>">
            </div>
            
            <!-- strAddress, dblLatitude, dblLongitude -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesLocation']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="strAddress" name="strAddress" value="<? echo $arrProject['strAddress']; ?>" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPreferencesLocationLocate']; ?>" style="cursor:pointer" readonly="readonly" onClick="
                    $.fancybox({
                        'href'	: 'mapLocate.php?dblLatitude=' + document.getElementById('dblLatitude').value + '&dblLongitude=' + document.getElementById('dblLongitude').value + '&strAddress=' + document.getElementById('strAddress').value,
                        'type'	: 'iframe',
                        'width'	: '100%',
                        'height': '100%'
                    });
                ">
                <input type="hidden" id="dblLatitude" name="dblLatitude" value="<? echo $arrProject['dblLatitude']; ?>">
                <input type="hidden" id="dblLongitude" name="dblLongitude" value="<? echo $arrProject['dblLongitude']; ?>">
            </div>
            
            <!-- strSiteURL -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesSiteURL']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="strSiteURL" name="strSiteURL" value="<? echo $arrProject['strSiteURL']; ?>">
            </div>

            <!-- strGoogleAnalyticsID -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesGoogleAnalyticsID']; ?>:</label>
            <div class="controls">
				<div class="input-prepend" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPreferencesGoogleAnalyticsIDTip']; ?>">
                    <span class="add-on">
                    <a href="http://www.google.com/analytics/" target="_blank" style="cursor:help">
                        <img src="img/googleAnalytics.png" style="height:16px;width:16px">
                    </a>
                    </span>
                    <input type="text" id="strGoogleAnalyticsID" name="strGoogleAnalyticsID" value="<? echo $arrProject['strGoogleAnalyticsID']; ?>" placeholder="<? echo $_SESSION['strGlobalExample']; ?>: UA-12345678-9">
				</div>
            </div>

            <!-- strSkypeID -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesSkypeID']; ?>:</label>
            <div class="controls">
				<div class="input-prepend" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPreferencesSkypeIDTip']; ?>">
                    <span class="add-on">
                    <a href="https://support.skype.com/pt-br/faq/FA605/como-faco-para-configurar-o-botao-do-skype-para-mostrar-meu-status-na-web-no-skype-para-windows-desktop" target="_blank" style="cursor:help">
                        <img src="img/skype.png" style="height:16px;width:16px">
                    </a>
                    </span>
                    <input type="text" id="strSkypeID" name="strSkypeID" value="<? echo $arrProject['strSkypeID']; ?>">
				</div>
            </div>
            
            <div class="controls">
                <a href="#" class="btn btn-success" id="btnProjectPreferencesSave" name="btnProjectPreferencesSave" data-loading-text="<? echo $_SESSION['strGlobalWait']; ?>" style="float:right" onclick="projectUpdate();"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></a>
            </div>
            <script>
            function projectUpdateLogoText(){
				document.getElementById('spanIndexProjectName').innerHTML = document.getElementById('strName').value;
			}
			
            function projectUpdate(){
				if (! document.getElementById('strAlias').value) {
					showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageProjectPreferencesAlias']); ?>');
					document.getElementById('strAlias').focus();
					return;
				}
				
				if (! document.getElementById('strName').value) {
					showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageProjectPreferencesName']); ?>');
					document.getElementById('strName').focus();
					return;
				}

				$('#btnProjectPreferencesSave').button('loading');
				var strParams = 'chrAction=PU' +
								'&idProject=<? echo $arrProject['idProject']; ?>' +
								'&strAlias=' + document.getElementById('strAlias').value +
								'&strName=' + document.getElementById('strName').value +
								'&txtDescription=' + document.getElementById('txtDescription').value +
								'&strAddress=' + document.getElementById('strAddress').value +
								'&dblLatitude=' + document.getElementById('dblLatitude').value +
								'&dblLongitude=' + document.getElementById('dblLongitude').value +
								'&strSiteURL=' + document.getElementById('strSiteURL').value +
								'&strGoogleAnalyticsID=' + document.getElementById('strGoogleAnalyticsID').value +
								'&strSkypeID=' + document.getElementById('strSkypeID').value +
								'&blnAllowAllView=' + (document.getElementById('blnAllowAllView').checked == true ? 1 : 0) +
								'&blnAllowJoin=' + (document.getElementById('blnAllowJoin').checked == true ? 1 : 0) +
								'&blnAllowJoinAsLevel3=' + (document.getElementById('blnAllowJoinAsLevel3').checked == true ? 1 : 0) +
								'&idProjectUserViewScope=' + document.getElementById('idProjectUserViewScope').value +
								'&idProjectUserEditScope=' + document.getElementById('idProjectUserEditScope').value
				var result = $.ajax({
				  url: "ajax.php?" + EliminateSpecialChars(strParams)
				}).done(function() {
					var resposta 	= result.responseText;

					var retorno 	= JSON.parse(resposta);
					$('#btnProjectPreferencesSave').button('reset');
					showSuccessAlert();
				});
			}

			function blnAliasExists() {
				document.getElementById('strAlias').value = document.getElementById('strAlias').value.toLowerCase();
				var strAlias = document.getElementById('strAlias').value;
				if (! strAlias) return;
				document.getElementById('imgAliasStatus').src="img/carregando.gif";
				var strParams = 'chrAction=SJA' +
								'&strAlias=' + strAlias;
				var result = $.ajax({
				  url: "ajax.php?" + EliminateSpecialChars(strParams)
				}).done(function() {
					var resposta 	= result.responseText;
					var retorno 	= JSON.parse(resposta);
					if ((retorno[0]['int'] == '0') || (strAlias == '<? echo $arrProject['strAlias']; ?>')) {
						document.getElementById('imgAliasStatus').src="img/yes.png";
						document.getElementById('btnProjectPreferencesSave').style.display="inline";
					} else {
						document.getElementById('imgAliasStatus').src="img/no.png";
						document.getElementById('btnProjectPreferencesSave').style.display="none";
					}
				});
			}
            </script>
        </div>

        <div id="div_theme">
			<div class="sessionTitle"><i class="icon-tint"></i> <? echo $_SESSION['stradmManageProjectMenuAppearance']; ?></div>
			<!-- CSS Themes -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectThemeSchema']; ?>:</label>
            <div class="controls">
	            <select id="cmbTheme" name="cmbTheme" onchange="projectUpdateTheme(this.value, $('option:selected', this).attr('strCSSThemeURL'));" class="fullwith">
                <?
                $arrThemes = $project->selectThemes();
                foreach ($arrThemes as $arrTheme) {
                    echo '<option strCSSThemeURL="' . $arrTheme['strCSSThemeURL'] . '" value="' . $arrTheme['idCSSTheme'] . '" ' . ($arrTheme['idCSSTheme'] == $arrProject['idCSSTheme'] ? 'selected' : '') . '>' . $arrTheme['strThemeName'] . '</option>';
                }
                ?>
                </select>
            </div>

        	<style>
				.imgBlock {
					width:150px;
					height:150px;
					cursor:pointer;
				}
            </style>
            <div style="text-align:center;">
                <div style="display:inline-block;cursor:pointer;" onclick="strField='strBackgroundFile';document.getElementById('fuBackgroundFile').click();">
                    <img id="imgBackgroundFile" src="<? echo $arrProject['strBackgroundFileFullPath']; ?>" class="img-polaroid imgBlock" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectThemeClickUploadTip']; ?>"/>
                    <div style="background-color:#ffffff;;font-family:Calibri;width:97%;margin:2%;top:-25px;text-align:center;position:relative;font-weight:bold;opacity:0.1;filter:alpha(opacity=10);" class="rounded">
                        <i class="icon-upload" style="float:left;margin-left:5px;"></i>
                        <? echo $_SESSION['stradmManageProjectThemeBackground']; ?>
                    </div>
                    <input id="fuBackgroundFile" type="file" name="files[]" style="display:none">
                    <input type="hidden" id="strBackgroundFile" name="strBackgroundFile"/>
                </div>
                <div style="display:inline-block;cursor:pointer" onclick="strField='strLogoFile';document.getElementById('fuLogoFile').click();">
                    <img id="imgLogoFile" src="<? echo $arrProject['strLogoFileFullPath']; ?>" class="img-polaroid imgBlock" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectThemeClickUploadTip']; ?>"/>
                    <div style="background-color:#ffffff;;font-family:Calibri;width:97%;margin:2%;top:-25px;text-align:center;position:relative;font-weight:bold;opacity:0.1;filter:alpha(opacity=10);" class="rounded">
                        <i class="icon-upload" style="float:left;margin-left:5px;"></i>
                        <? echo $_SESSION['stradmManageProjectThemeLogo']; ?>
                        <i class="icon-remove" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectThemeLogoDefault']; ?>" style="cursor:pointer;float:right;margin-right:5px;" onClick="projectSetDefault('strLogoFile');"></i>
                    </div>
                    <input id="fuLogoFile" type="file" name="files[]" style="display:none">
                    <input type="hidden" id="strLogoFile" name="strLogoFile"/>
                </div>
            </div>
			<!-- Suggested Backgrounds -->
			<div class="sessionTitle">
            	<i class="icon-picture"></i> <? echo $_SESSION['stradmManageProjectThemeBackgroundsSuggestionsTitle']; ?>
            	<span id="btnSaveBackground" class="btn btn-success" style="float:right;position:relative;top:-4px;" onclick="strField='strBackgroundFile';projectFileCopyUploaded(document.getElementById('strBackgroundFile').value);"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></span>
            </div>
            <div>
              <?
			  	$arrFiles = $strings->arrReturnListFilesFolder('img/backgrounds/');
				foreach ($arrFiles as $strFileName) {
					if (strpos($strFileName, '-150x150') === FALSE) continue;
					$strFileNameBig = str_replace('-150x150', '', $strFileName);
					echo '
					<span class="img-polaroid" style="float:left; margin:2px; padding:2px; width:100px; height:100px; cursor:pointer;">
						<img class="rounded" src="' . $strFileName .'" style="width:100%;height:100%;" onClick="projectChangeBackgroundImage(\'' . $strFileNameBig . '\')" data-rel="tooltip" title="' . $_SESSION['stradmManageProjectThemePreview'] . '">
					</span>
					';
				}
              ?>
            </div>
			<script>
                var strField;
                // Manipulating Files Upload
                $(function () {
                    // Change this to the location of your server-side upload handler:
                    var url = 'js/fileupload/index.php';
                    $('#fuBackgroundFile, #fuLogoFile').fileupload({
                        url: url,
                        dataType: 'json',
                        done: function (e, data) {
                            $.each(data.result.files, function (index, file) {
								if (! blnIsImage(file.name)) { 
									showInfoAlert('<? echo $_SESSION['strErrorInvalidFormat']; ?> JPG, PNG, GIF, BMP');
									return;
								}
                                projectFileCopyUploaded(file.name);
                            });
                            document.getElementById('ContainerBar').style.display='none';
                        },
                        start: function(e) {
                            $('#bar').css('width','0%');
                            document.getElementById('ContainerBar').style.display='inline-block';
                        },
                        progressall: function (e, data) {
                            var progress = parseInt(data.loaded / data.total * 100, 10);
                            $('#bar').css('width', progress + '%');
                        }
                    }).prop('disabled', !$.support.fileInput)
                        .parent().addClass($.support.fileInput ? undefined : 'disabled');
                });
    
                function projectFileCopyUploaded(strFileName) {
                    var result = $.ajax({
                        url: "ajax.php?chrAction=PFU&idProject=<? echo $arrProject['idProject']; ?>&strFileName=" + strFileName + "&strField=" + strField
                    }).done(function() {
                        var resposta 	= result.responseText;
                        var retorno 	= JSON.parse(resposta);
                        if (strField == 'strBackgroundFile') {
                            $.backstretch(['' + retorno['strFilePath']]);
                            document.getElementById('imgBackgroundFile').src = '' + retorno['strFilePath'];
                        } else if (strField == 'strLogoFile') {
                            document.getElementById('imgLogoFile').src = '' + retorno['strFilePath'];
                            document.getElementById('imgLogo').src = document.getElementById('imgLogoFile').src;
                        }
                        showSuccessAlert();
                    });
                }
    
                function projectSetDefault(strField) {
                    var result = $.ajax({
                        url: "ajax.php?chrAction=PFU&idProject=<? echo $arrProject['idProject']; ?>&strFileName=&strField=" + strField
                    }).done(function() {
                        showSuccessAlert();
                        if (strField == 'strLogoFile') {
                            document.getElementById('imgLogoFile').src = '<? echo $project->strProjectImageNoLogo; ?>';
                            document.getElementById('imgLogo').src = document.getElementById('imgLogoFile').src;
                        }
                    });
                }
                
                function projectUpdateTheme(idCSSTheme, strCSSThemeURL) {
                    $('#bs-css').attr('href',strCSSThemeURL);
                    var result = $.ajax({
                        url: "ajax.php?chrAction=PUT&idProject=<? echo $arrProject['idProject']; ?>&idCSSTheme=" + idCSSTheme
                    }).done(function() {
                        showSuccessAlert();
                    });
                }
    
                function projectChangeBackgroundImage(strFileName) {
                    $.backstretch([strFileName]);
                    document.getElementById('strBackgroundFile').value = strFileName;
                    document.getElementById('imgBackgroundFile').src = strFileName;
                    showInfoAlert("<? echo $_SESSION['stradmManageProjectThemeBackgroundSaveTip']; ?>");
                }
            </script>
        </div>
        <div id="div_permissions">
			<div class="sessionTitle"><i class="icon-lock"></i> <? echo $_SESSION['stradmManageProjectMenuPermissions']; ?></div>
            
            <!-- blnAllowAllView -->
            <div class="controls" style="margin-top:10px;">
                <input type="checkbox" id="blnAllowAllView" name="blnAllowAllView" <? echo ($arrProject['blnAllowAllView'] > 0 ? "checked" : ""); ?>> <label for="blnAllowAllView" style="display:inline;"> <? echo $_SESSION['stradmManageProjectPermissionsblnAllowAllView']; ?></label> <i data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPermissionsblnAllowAllViewTip']; ?>" class="icon-info-sign"></i>
            </div>
            
            <!-- blnAllowJoin -->
            <div class="controls" style="margin-top:10px;">
                <input type="checkbox" id="blnAllowJoin" name="blnAllowJoin" <? echo ($arrProject['blnAllowJoin'] > 0 ? "checked" : ""); ?>> <label for="blnAllowJoin" style="display:inline;"> <? echo $_SESSION['stradmManageProjectPermissionsblnAllowJoin']; ?></label> <i data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPermissionsblnAllowJoinTip']; ?>" class="icon-info-sign"></i>
            </div>
            
            <!-- blnAllowJoinAsLevel3 -->
            <div class="controls" style="margin-top:10px;padding-left:20px;">
                <input type="checkbox" id="blnAllowJoinAsLevel3" name="blnAllowJoinAsLevel3" <? echo ($arrProject['blnAllowJoinAsLevel3'] > 0 ? "checked" : ""); ?>> <label for="blnAllowJoinAsLevel3" style="display:inline;"> <? echo $_SESSION['stradmManageProjectPermissionsblnAllowJoinAsLevel3']; ?></label>
            </div>

            <!-- idProjectUserViewScope -->
            <label class="control-label" style="margin-top:10px;"><? echo $_SESSION['stradmManageProjectPermissionsidProjectUserViewScope']; ?></label>
            <div class="controls">
	            <select id="idProjectUserViewScope" name="idProjectUserViewScope" class="fullwith">
                <?
                $arrProjectUserScopes = $project->selectProjectUserScopes();
                foreach ($arrProjectUserScopes as $arrProjectUserScope) {
                    echo '<option value="' . $arrProjectUserScope['idProjectUserScope'] . '" ' . ($arrProjectUserScope['idProjectUserScope'] == $arrProject['idProjectUserViewScope'] ? 'selected' : '') . '>' . $arrProjectUserScope['strProjectUserScope'] . '</option>';
                }
                ?>
                </select>
            </div>
            
            <!-- idProjectUserEditScope -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPermissionsidProjectUserEditScope']; ?>:</label>
            <div class="controls">
	            <select id="idProjectUserEditScope" name="idProjectUserEditScope" class="fullwith">
                <?
                foreach ($arrProjectUserScopes as $arrProjectUserScope) {
                    echo '<option value="' . $arrProjectUserScope['idProjectUserScope'] . '" ' . ($arrProjectUserScope['idProjectUserScope'] == $arrProject['idProjectUserEditScope'] ? 'selected' : '') . '>' . $arrProjectUserScope['strProjectUserScope'] . '</option>';
                }
                ?>
                </select>
            </div>
            
            <div class="controls">
                <a href="#" class="btn btn-success" id="btnProjectPreferencesSave" name="btnProjectPreferencesSave" style="float:right" onclick="projectUpdate();"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></a>
            </div>
        </div>
    </td>
    </tr></table>
    <!-- End Body -->
</div>
<script>
	showSession(arrSessions, <? echo ($_GET['ss'] ? $_GET['ss'] : 0);?>);
</script>