<?
// Allow access from any host
header('Access-Control-Allow-Origin: *');
set_time_limit(300);
include_once 'engine/api.php';
$api = new Api();
$action				= $_GET['action'];
$strOutputFormat	= $_GET['output'];
if ($strOutputFormat == 'json') {
	header('Content-type: application/json');
} else {
	header('Content-type: text/xml');
}
switch ($action) {
case 'login':
	$strEmail 		= $_GET['email'];
	$strPassword 	= $_GET['password'];
	$strResponse	= $api->login($strEmail, $strPassword, false, $strOutputFormat);
	echo $strResponse;
	break;

case 'listuserprojects':
	$strToken 		= $_GET['token'];
	$strResponse 	= $api->listuserprojects($strToken, $strOutputFormat);
	echo $strResponse;
	break;

case 'listprojectusers': 
	$idProject 		= $_GET['pid'];
	$strToken 		= $_GET['token'];
	$strResponse 	= $api->listprojectusers($idProject, $strToken, $strOutputFormat);
	echo $strResponse;
	break;

case 'listprojectforms': 
	$idProject 		= $_GET['pid'];
	$strToken 		= $_GET['token'];
	$strResponse	= $api->listprojectforms($idProject, $strToken, $strOutputFormat);
	echo $strResponse;
	break;

case 'listforminfo':
	$idFormulario	= $_GET['idform'];
	$strToken 		= $_GET['token'];
	$strResponse 	= $api->listforminfo($idFormulario, $strToken, $strOutputFormat);
	echo $strResponse;
	break;
	
case 'deleterecord':
	$idFormRecord 	= $_GET['idrecord'];
	$strToken 		= $_GET['token'];
	$strResponse	= $api->deleterecord($idFormRecord, $strToken, $strOutputFormat);
	echo $strResponse;
	break;
	
case 'insertrecord':
	$idFormulario 	= $_GET['idform'];
	$dblLatitude	= $_GET['lat'];
	$dblLongitude	= $_GET['lng'];
	$strData	 	= $_GET['data'];
	$strToken 		= $_GET['token'];
	$strResponse 	= $api->insertrecord($idFormulario, $dblLatitude, $dblLongitude, $strData, $strToken, $strOutputFormat);
	echo $strResponse;
	break;	

case 'insertuserposition':
	$dblLatitude	= $_GET['lat'];
	$dblLongitude	= $_GET['lng'];
	$strToken 		= $_GET['token'];
	$strResponse 	= $api->insertuserposition($dblLatitude, $dblLongitude, $strToken, $strOutputFormat);
	echo $strResponse;
	break;	

case 'searchradius':
	$strSearchType 	= 1; // Search Radius
	$idProject	 	= $_GET['pid'];
	$dblLatitude 	= $_GET['lat'];
	$dblLongitude 	= $_GET['lng'];
	$intRadius 		= $_GET['radius'];
	$strToken 		= $_GET['token'];
	$strKeyword		= $_GET['keyword'];
	$intStart		= $_GET['start'];
	$idForm			= $_GET['idform'];
	$dtDateFrom		= $_GET['fromdate'];
	$dtDateTo		= $_GET['todate'];
	$intLimit		= $_GET['limit'];
	$strResponse	= $api->search($strSearchType, $idProject, $dblLatitude, $dblLongitude, $dblLatitude, $dblLongitude, $intRadius, $strKeyword, $strToken, $intStart, $idForm, $dtDateFrom, $dtDateTo, $intLimit, $strOutputFormat);
	echo $strResponse;
	break;

case 'searchrectangle':
	$strSearchType 	= 2; // Search by Rectangle
	$idProject	 	= $_GET['pid'];
	$dblLatitudeSW	= $_GET['latSW'];
	$dblLongitudeSW = $_GET['lngSW'];
	$dblLatitudeNE	= $_GET['latNE'];
	$dblLongitudeNE	= $_GET['lngNE'];
	$strToken 		= $_GET['token'];
	$strKeyword		= $_GET['keyword'];
	$intStart		= $_GET['start'];
	$idForm			= $_GET['idform'];
	$dtDateFrom		= $_GET['fromdate'];
	$dtDateTo		= $_GET['todate'];
	$intLimit		= $_GET['limit'];
	$strResponse	= $api->search($strSearchType, $idProject, $dblLatitudeSW, $dblLongitudeSW, $dblLatitudeNE, $dblLongitudeNE, 0, $strKeyword, $strToken, $intStart, $idForm, $dtDateFrom, $dtDateTo, $intLimit, $strOutputFormat);
	echo $strResponse;
	break;

case 'recordinfo':
	$idFormRecord	= $_GET['idrecord'];
	$strToken 		= $_GET['token'];
	$strResponse	= $api->recordinfo($idFormRecord, $strToken, $strOutputFormat);
	echo $strResponse;
	break;	

case 'generatereport':
	$idProject	 	= $_GET['pid'];
	$strExtension	= strtolower($_GET['ext']);
	$strToken 		= $_GET['token'];
	$strResponse	= $api->generatereport($idProject, $strExtension, $strToken, $strOutputFormat);
	echo $strResponse;
	break;	
	
case 'wfs':
	$idProject	 		= $_GET['pid'];
	$strEmail 			= $_GET['email'];
	$strPassword 		= $_GET['password'];
	$blnLoadRecordInfo	= $_GET['recordinfo'];
	$strResponse		= $api->wfs($idProject, $strEmail, $strPassword, $blnLoadRecordInfo, $_GET['REQUEST'], $_GET['TYPENAME']);
	echo $strResponse;
	break;	
}
?>