<? $strings->changePageTitle($_SESSION['strIndexMenuEditProfile']); ?>
<script>
	var arrSessions = new Array ("personal");
</script>
<div class="sessionTitle">
	<i class="icon-pencil"></i> <? echo $_SESSION['strIndexMenuEditProfile']; ?>
</div>
<div class="box-content">
    <table width="100%"><tr>
    <!-- Menu -->
    <td valign="top">
        <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF">
            <li id="menu_personal" onClick="showSession(arrSessions, 0);">
                <a><i class="icon-user"></i><span class="hidden-phone">  <? echo $_SESSION['stradmEditProfileMenuPersonalInformation']; ?></span></a>
            </li>
        </ul>
    </td>
    <!-- End Menu -->
    <!-- Body -->
    <td valign="top" width="100%" style="padding-left:20px;background-color:transparent;">
        <div id="div_personal">
			<div class="sessionTitle"><i class="icon-user"></i> <? echo $_SESSION['stradmEditProfileMenuPersonalInformation']; ?></div>
            <!-- Member Since -->
            <label class="control-label"><i class="icon-calendar"></i> <b><? echo $_SESSION['stradmEditProfilePersonalMemberSince']; ?></b>: <? echo $arrUser['strRegister']; ?></label>
            
            <!-- Access Level -->
            <label class="control-label"><i class="icon-lock"></i> <b><? echo $_SESSION['stradmEditProfilePersonalAccessLevel']; ?></b>: <? echo $arrUser['strUserLevel']; ?></label>
            
            <!-- Workgroup -->
            <label class="control-label"><i class="icon-user"></i> <b><? echo $_SESSION['strGlobalWorkgroup']; ?></b>: <? echo $arrUser['strWorkgroups']; ?></label>

            <!-- strName -->
            <label class="control-label"><? echo $_SESSION['stradmEditProfilePersonalName']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="strName" name="strName" value="<? echo $arrUser['strName']; ?>" onBlur="userUpdateBannerText();">
            </div>

            <!-- strEmail -->
            <label class="control-label"><? echo $_SESSION['stradmEditProfilePersonalEmail']; ?>:</label>
            <div class="controls">
                <input type="text" class="fullwith" id="strEmail" name="strEmail" value="<? echo $arrUser['strEmail']; ?>">
            </div>

            <!-- strPassword -->
            <label class="control-label"><? echo $_SESSION['stradmEditProfilePersonalPassword']; ?>:</label>
            <div class="controls">
                <input type="password" class="fullwith" id="strPassword" name="strPassword" placeholder="*************" value="" autocomplete="off">
            </div>
            
            <!-- dblLatitude, dblLongitude -->
            <label class="control-label" style="margin-top:7px;"><? echo $_SESSION['stradmEditProfilePersonalMyLocation']; ?>:</label>
            <div class="controls input-prepend">
				<span style="cursor:pointer" data-rel="tooltip" title="<? echo $_SESSION['stradmEditProfilePersonalMyLocationTip']; ?>" onClick="
                    $.fancybox({
                        'href'	: 'mapLocate.php?dblLatitude=' + document.getElementById('dblLatitude').value + '&dblLongitude=' + document.getElementById('dblLongitude').value,
                        'type'	: 'iframe',
                        'width'	: '100%',
                        'height': '100%'
                    });
                ">
	                <a id="btnLocate" class="btn"><i class="icon-map-marker"></i></a> 
    	            <span id="strMyLocation" name="strMyLocation" class="btn" style="font-weight:bold;"><? echo $arrUser['dblLatitude'] == 0 ? $_SESSION['stradmEditProfilePersonalMyLocationLastNavigated'] : number_format($arrUser['dblLatitude'], 7) . ':' . number_format($arrUser['dblLongitude'], 7); ?></span>
                </span>
                <span id="strMyLocationSetNone" class="btn" title="<? echo $_SESSION['stradmEditProfilePersonalMyLocationSetNoneTip']; ?>" onClick="userLocationSetNone();"><i class="icon-remove"></i></span>
                <input type="hidden" id="dblLatitude" name="dblLatitude" value="<? echo $arrUser['dblLatitude']; ?>">
                <input type="hidden" id="dblLongitude" name="dblLongitude" value="<? echo $arrUser['dblLongitude']; ?>">
            </div>
            
            <!-- strSkypeID -->
            <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesSkypeID']; ?>:</label>
            <div class="controls">
				<div class="input-prepend" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPreferencesSkypeIDTip']; ?>">
                    <span class="add-on">
                    <a href="https://support.skype.com/pt-br/faq/FA605/como-faco-para-configurar-o-botao-do-skype-para-mostrar-meu-status-na-web-no-skype-para-windows-desktop" target="_blank" style="cursor:help">
                        <img src="img/skype.png" style="height:16px;width:16px">
                    </a>
                    </span>
                    <input type="text" id="strSkypeID" name="strSkypeID" value="<? echo $arrUser['strSkypeID']; ?>">
				</div>
            </div>
            
            <div class="controls">
                <a href="#" class="btn btn-success" id="btnPersonalSave" name="btnPersonalSave" style="float:right" data-loading-text="<? echo $_SESSION["strGlobalProcessing"]; ?>..." onClick="userUpdate();"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></a>
            </div>
            <script>
            function userUpdate() {
				if (! document.getElementById('strEmail').value) {
					showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmEditProfilePersonalEmail']); ?>');
					document.getElementById('strEmail').focus();
					return;
				}

				$('#btnPersonalSave').button('loading');
				var strParams = 'chrAction=UU' +
								'&idUser=<? echo $arrUser['idUser']; ?>' +
								'&strName=' + document.getElementById('strName').value +
								'&strEmail=' + document.getElementById('strEmail').value +
								'&strSkypeID=' + document.getElementById('strSkypeID').value +
								'&strPassword=' + document.getElementById('strPassword').value +
								'&dblLatitude=' + (document.getElementById('dblLatitude') ? document.getElementById('dblLatitude').value : "0") +
								'&dblLongitude=' + (document.getElementById('dblLongitude') ? document.getElementById('dblLongitude').value : "0")
				var result = $.ajax({
				  url: "ajax.php?" + EliminateSpecialChars(strParams)
				}).done(function() {
					var resposta 	= result.responseText;
					var retorno 	= JSON.parse(resposta);
					$('#btnPersonalSave').button('reset');
					showSuccessAlert();
				});
			}
			
			function userLocationSetNone() {
				document.getElementById('dblLatitude').value = "0";
				document.getElementById('dblLongitude').value = "0";
				document.getElementById('strMyLocation').innerHTML = "<? echo $_SESSION['stradmEditProfilePersonalMyLocationLastNavigated']; ?>";
				userUpdate();
			}
            </script>
        </div>
    </td>
    </tr></table>
    <!-- End Body -->
</div>
<script>
	$(document).ready( function () {
		showSession(arrSessions, 0);
	});	
</script>