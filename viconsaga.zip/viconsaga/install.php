<?
	session_start();
	include_once 'engine/strings.php';
	$strings = new Strings();
	@include_once $strings->strConnectionFileName;
	
	if ($_POST['blnLogout']) {
		unset($_COOKIE['blnAdmin']);
		setcookie("blnAdmin", 0, time() + 999999);
		$_COOKIE['blnAdmin'] = 0;
	}	

	// Logged OR First Run - Installation
	if (($_POST['strAdminPassword'] == $admPassword) || (! file_exists($strings->strConnectionFileName))) {
		unset($_COOKIE['blnAdmin']);
		setcookie("blnAdmin", 1, time() + 60*30); // 30 min
		$_COOKIE['blnAdmin'] = 1;
	}
	
	// Loading strings according to selected language
	if ($_GET['language']) {
		$_SESSION['strSiteLanguage'] = $_GET['language'];
	} else if (! $_SESSION['strSiteLanguage']) {
		$_SESSION['strSiteLanguage'] = $strings->strSiteDefaultLanguage;
	}
	$strings->loadLanguage($_SESSION['strSiteLanguage']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title><? echo $strings->strSiteName . ' | ' . $_SESSION['strInstallTitle']; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap-cerulean.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/charisma.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/logofav.png">
    <script src="js/jquery-1.11.1.js"></script>
    <script src="js/bootstrap-modal.js"></script>
	<script src="js/jquery.backstretch.js"></script>
	<script src="js/bootstrap-dropdown.js"></script>
	<script src="js/bootstrap-button.js"></script>
	<script src="js/main.js"></script>
    <style>
    li {line-height:30px;margin-left:10px;}
    </style>
</head>
<body>
<form action="<? echo $_SERVER["PHP_SELF"]; ?>" method="post" name="frmForm" id="frmForm" enctype="multipart/form-data" onKeyPress="">
<span id="alertInfo" class="alert alert-primary" style="display:none;z-index:9999;position:absolute;left:20%;text-align:center;width:50%;"><strong><span id="alertInfoMessage"></span></strong></span>
<span id="alertSuccess" class="alert alert-success" title="<? echo $_SESSION['strGlobalSaved']; ?>" style="display:none;z-index:9999;position:absolute;left:35%;width:20%;color:#008400;text-align:center;"><i class="icon-ok-circle"></i> <strong><span id="alertSuccessMessage"></span></strong></span>
<div class="container" style="width:98%">
	<div class="masthead">
        <div class="navbar">
          <div class="navbar-inner" style="padding-left:2px;padding-right:0px;">
			<!-- Start Language Menu -->
            <input type="hidden" name="strSiteLanguage" id="strSiteLanguage">
            <div class="btn-group pull-right" style="position:relative;top:4px;">
                <a class="btn dropdown-toggle" data-toggle="dropdown">
                	<img src="img/language/<? echo $_SESSION['Indice']; ?>.png" align="absmiddle" style="width:24px;height:24px;">
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu" style="padding:4px;width:210px;">
                <?
                $arrLanguages = $strings->loadLanguagesList();
                sort($arrLanguages);
                foreach($arrLanguages as $item) {
                    $arrTupla = explode(':', $item);
                    echo '<li><a style="font-size:12px;" onclick="window.location=\'?' .  $_SERVER['QUERY_STRING'] . '&language=' . $arrTupla[1] . '\';"><img src="img/language/' . strtolower($arrTupla[1]) . '.png" align="absmiddle" style="width:24px;height:24px;"> <b>' . $arrTupla[0] . '</b></a></li>';
                }
                ?>
                </ul>
            </div>
   			<!-- End Language Menu -->

			<!-- Main Menu -->
            <div style="height:50px;overflow-y:hidden;cursor:pointer">
                <table>
                <tr style="height:50px;overflow-y:hidden;">
                    <td style="vertical-align:top;width:50px;"><a href="site/home" title="<? echo $_SESSION['strMenuHome']; ?>"><img id="imgLogo" src="img/logo.png" style="width:100%;top:10px;"></a></td>
                    <td style="vertical-align:middle;font-size:20px;line-height:22px;width:auto;word-wrap:break-word;color:#FFFFFF;">
                    	<span class="hidden-phone"><? echo $strings->strSiteName; ?> � </span><? echo $_SESSION['strInstallTitle']; ?>
					</td>
                </tr>
                </table>
			</div>
	    </div><!-- /.navbar -->
      </div><!-- /.masterhead -->
    <div id="mainContent" class="row translucent70 shine rounded" style="padding-bottom:10px;text-align:justify;color:#000000;">    
    <? if (! $_COOKIE['blnAdmin'] > 0){ ?>
        <!-- strAdminPassword -->
        <label class="control-label"><? echo $_SESSION['strGlobalPassword']; ?>:</label>
        <div class="controls">
            <input type="password" class="fullwith" id="strAdminPassword" name="strAdminPassword">
        </div>
        
        <div class="controls">
            <input type="submit" class="btn btn-success" id="btnAdminPasswordSubmit" name="btnAdminPasswordSubmit" value="<? echo $_SESSION['strGlobalSubmit']; ?>" onClick="$('#btnAdminPasswordSubmit').button('loading'); document.getElementById('frmForm').submit();">
        </div>        

    <? } else { ?>
		<? $strings->changePageTitle($_SESSION['strIndexMenuProjectManagementManagePlatform']); ?>
        <script>
            var arrSessions = new Array ("adm", "database", "projects", "support");
        </script>
        <div class="sessionTitle">
        	<i class="icon-cog"></i>
            <span class="hidden-phone"> <? echo $_SESSION['strIndexMenuProjectManagementManagePlatform'] . ' - ' . $_SESSION['strGlobalVersion'] . ' ' . $strings->strCurrentReleaseDate() . ' | <a href="http://www.viconsaga.com.br/site/download" target="_blank">' . $_SESSION['strGlobalCheckNewReleases'] . '...</a>'; ?></span>
			<span id="btnTMPClean" class="btn btn-primary" style="float:right;position:relative;top:-4px" onClick="TMPClean();"><i class="icon-trash icon-white"></i> <? echo $_SESSION['strInstallProjectClearTmp']; ?></span>
		</div>
        <table width="100%"><tr>
        <!-- Menu -->
        <td valign="top">
            <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;">
                <li id="menu_adm" onClick="showSession(arrSessions, 0);" >
                    <a><i class="icon-user"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionAdm']; ?></span></a>
                </li>
                <li id="menu_database" onClick="showSession(arrSessions, 1);">
                    <a id="aDatabaseStatus"><i id="iDatabaseStatus"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionDatabase']; ?></span></a>
                </li>
                <li id="menu_projects" onClick="showSession(arrSessions, 2);">
                    <a><i class="icon-globe"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionProjects']; ?> (<span id="spanProjectsCounter">0</span>)</span></a>
                </li>
                <li id="menu_support" onClick="showSession(arrSessions, 3);">
                    <a><i class="icon-question-sign"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionSupport']; ?> (<span id="spanSupportsCounter">0</span>)</span></a>
                </li>
                <li>
	                <input type="hidden" id="blnLogout" name="blnLogout">
                    <a onClick="document.getElementById('blnLogout').value=1;document.getElementById('frmForm').submit();"><i class="icon-off"></i><span class="hidden-phone"> <? echo $_SESSION['strMenuUserLogout']; ?></span></a>
                </li>
            </ul>
        </td>
        <td valign="top" width="100%" style="padding-left:20px;background-color:transparent;">
            <div id="div_adm">
                <div class="sessionTitle">
                    <i class="icon-user"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionAdm']; ?></span>
                </div>
                <!-- blnSiteAllowProjectCreation -->
                <div class="controls">
                    <input type="checkbox" id="blnSiteAllowProjectCreation" name="blnSiteAllowProjectCreation" <? echo $blnSiteAllowProjectCreation ? "checked" : ""?>> <label for="blnSiteAllowProjectCreation" style="display:inline-block"><? echo $_SESSION['strInstallProjectblnSiteAllowProjectCreation']; ?></label>
                </div>
                
                <!-- strLogin -->
                <label class="control-label"><? echo $_SESSION['strInstallSessionAdmEmail']; ?>: <span style="font-weight:bold"><? echo $strings->strSiteDefaultAdminEmail; ?></span></label>
    
                <!-- strGlobalPassword -->
                <label class="control-label"><? echo $_SESSION['strGlobalPassword']; ?>:</label>
                <div class="controls">
                    <input type="text" class="fullwith" id="strAdmPassword" name="strAdmPassword" placeholder="*************" value="<? echo ($admPassword ? $admPassword : $strings->strSiteDefaultAdminPassword); ?>" autocomplete="off">
                </div>
                
                <div class="controls">
					<a class="btn btn-success" id="btnDatabaseSave" name="btnDatabaseSave" onClick="connectionSaveToFile();"><? echo $_SESSION['strGlobalSave']; ?></a>
                </div>
            </div>
            <div id="div_database">
                <div class="sessionTitle">
                    <i class="<? echo $database->strDefaultIcon; ?>"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionDatabase']; ?></span>
                </div>

                <!-- strHostname -->
                <label class="control-label">Hostname or IP:</label>
                <div class="controls">
                    <input type="text" class="fullwith" id="strDatabaseHostname" name="strDatabaseHostname" value="<? echo $server; ?>">
                </div>
                
                <!-- strUsername -->
                <label class="control-label">Username:</label>
                <div class="controls">
                    <input type="text" class="fullwith" id="strDatabaseUsername" name="strDatabaseUsername" value="<? echo $username; ?>">
                </div>
                
                <!-- strPassword -->
                <label class="control-label">Password:</label>
                <div class="controls">
                    <input type="text" class="fullwith" id="strDatabasePassword" name="strDatabasePassword" value="<? echo $password; ?>">
                </div>
                
                <!-- strDatabase -->
                <label class="control-label">Database Name:</label>
                <div class="controls">
                    <input type="text" class="fullwith" id="strDatabaseDatabase" name="strDatabaseDatabase" value="<? echo $database; ?>">
                </div>    
                
                <div id="divNoConnection" class="alert alert-danger" style="display:none;font-weight:bold">
					<p><? echo $_SESSION['strInstallNoConnection']; ?></p>
                </div>
                
                <div id="divNoDatabase" class="alert alert-danger" style="display:none;font-weight:bold">
					<p style="color:#006600"><? echo $_SESSION['strInstallEmptyDatabase_1']; ?></p>
					<p><? echo $_SESSION['strInstallEmptyDatabase_2']; ?> <a class="btn btn-success" id="btnDatabasePopulate" name="btnDatabasePopulate" onClick="connectionDatabaseInstall();"><i class="icon-play icon-white"></i> <? echo $_SESSION['strInstallDatabaseInstall']; ?></a></p>
					<p><? echo $_SESSION['strInstallEmptyDatabase_3']; ?> <a href="<? echo $strings->strSQLDatabaseFile; ?>" target="_blank"><? echo $strings->strSQLDatabaseFile; ?></a></p>
                </div>
                
                <div class="controls">
					<a class="btn btn-success" id="btnDatabaseSave" name="btnDatabaseSave" onClick="connectionSaveToFile();"><? echo $_SESSION['strGlobalSave']; ?></a>
					<span id="spanTest" style="padding:5px;font-weight:bold;position:relative;top:3px;"></span>
                </div>
                
                <script>
					function connectionDatabaseInstall() {
						connectionSaveToFile();
						$('#btnDatabasePopulate').button('loading');
                        var result = $.ajax({
							url: "ajax.php?chrAction=IDI"
						}).always(function() {
							$('#btnDatabasePopulate').button('reset');
                            showSuccessAlert();
							connectionTest();
                        });
					}

                    function connectionSaveToFile() {
                        var result = $.ajax({url: "ajax.php?chrAction=ISF" +
							"&blnSiteAllowProjectCreation=" + (document.getElementById('blnSiteAllowProjectCreation').checked ? "1" : "0") + 
							"&admPassword=" + document.getElementById('strAdmPassword').value + 
							"&server=" + document.getElementById('strDatabaseHostname').value + 
							"&username=" + document.getElementById('strDatabaseUsername').value + 
							"&password=" + document.getElementById('strDatabasePassword').value + 
							"&database=" + document.getElementById('strDatabaseDatabase').value
						}).always(function() {
                            showSuccessAlert();
							connectionTest();
                        });
                    }					
					
                    function connectionTest() {
                        document.getElementById('spanTest').className = '';
                        document.getElementById('spanTest').innerHTML = '<img src="img/loading1.gif" style="width:16px;height:16px">';
                        var result = $.ajax({
							url: "ajax.php?chrAction=ICT"
						}).always(function() {
							var response 	= result.responseText;
							var retorno 	= JSON.parse(response);
							document.getElementById('divNoConnection').style.display = (retorno['blnConnected'] ? "none" : "block");							
                            document.getElementById('spanTest').className = retorno['blnConnected'] && retorno['blnDatabase'] ? 'notification green' : 'notification red';
                            document.getElementById('spanTest').innerHTML = '<i class="icon-thumbs-' + (retorno['blnConnected'] && retorno['blnDatabase'] ? 'up' : 'down') + ' icon-white"></i> ' + (retorno['blnConnected'] && retorno['blnDatabase'] ? '<? echo $_SESSION['strInstallTestYes']; ?>' : '<? echo $_SESSION['strInstallTestNo']; ?>');
							document.getElementById('iDatabaseStatus').className = 'icon-thumbs-' + (retorno['blnConnected'] && retorno['blnDatabase'] ? 'up' : 'down');
							document.getElementById('aDatabaseStatus').style.color = (retorno['blnConnected'] && retorno['blnDatabase'] ? '#006600' : '#FF0000');
							document.getElementById('divNoDatabase').style.display = (retorno['blnDatabase'] ? "none" : "block");
							if (retorno['blnConnected']) {
								projectsLoad('tblProjects');
								supportsLoad('tblSupports');
							}
                        });
                    }                    
                </script>            
            </div>
            <div id="div_projects">
                <div class="sessionTitle">
                    <i class="icon-globe"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionProjects']; ?></span>
                    <a class="btn btn-success" style="float:right;position:relative;top:-4px;" onClick="projectLoad(-1);"><i class="icon-plus-sign icon-white"></i> <span class="hidden-phone"><? echo $_SESSION['strInstallProjectButtonCreate']?></span></a>
                </div>
                <table id="tblProjects" name="tblProjects" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
                    <thead>
                        <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF" class="btn-primary">
                            <th style="text-align:center" width="40" class="hidden-phone hidden-tablet"></th>
                            <th style="text-align:center" width="1" class="hidden-phone">ID</th>
                            <th style="text-align:center" width="50" class="hidden-phone hidden-tablet"><? echo $_SESSION['strInstallProjectDateCreation']; ?></th>
                            <th style="text-align:center;white-space:nowrap;" width="60" class="hidden-phone hidden-tablet"><? echo $_SESSION['strInstallProjectDateLastAccess'] . ' - ' . $_SESSION['strGlobalDays']; ?></th>
							<th width="300"><? echo $_SESSION['strInstallProjectName']; ?></th>
                            <th width="1" style="text-align:center;white-space:nowrap;" class="hidden-phone"><? echo $_SESSION['strGlobalAlias']; ?></th>
                            <!--<th width="400" class="hidden-phone hidden-tablet"><? echo $_SESSION['strInstallProjectPlace']; ?></th>-->
                            <th width="1" style="text-align:center" class="hidden-phone hidden-tablet"><? echo $_SESSION['strGlobalUsers']; ?></th>
                            <th width="1" style="text-align:center" class="hidden-phone hidden-tablet"><? echo $_SESSION['strGlobalForms']; ?></th>
                            <th width="1" style="text-align:center" class="hidden-phone"><? echo $_SESSION['strGlobalRecords']; ?></th>
                            <th width="1" style="text-align:center"><? echo $_SESSION['strGlobalActive']; ?></th>
                            <th style="text-align:center;white-space:nowrap;" width="130"><? echo $_SESSION['strGlobalActions']; ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                
                <!-- Panel for Insert Project -->
                <div class="modal hide fade hideSelection" id="modalProject">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">�</button>
                        <h4><i class="icon-globe"></i> <? echo $_SESSION['strInstallProject']; ?></h4>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="idProject" name="idProject" value="">
                        <input type="hidden" id="strAlias" name="strAlias" value="">
                        <div class="control-group">
                            <!-- strEmail -->
                            <label class="control-label"><? echo $_SESSION['stradmEditProfilePersonalEmail']; ?>:
                            <div class="controls">
                                <input type="text" class="fullwith" id="strUserEmail" name="strUserEmail">
                            </div>
                
                            <!-- strName -->
                            <label class="control-label"><? echo $_SESSION['strInstallProjectName']; ?>:</label>
                            <div class="controls">
                                <input type="text" class="fullwith" id="strProjectName" name="strProjectName">
                            </div>
                            
                            <!-- strAlias -->
                            <label class="control-label"><? echo $_SESSION['strGlobalAlias']; ?>:</label>
                            <div class="controls">
                                <? echo $strings->strSiteURL; ?>/
                                <div class="input-append">
                                    <input type="text" class="fullwith" id="strProjectAlias" name="strProjectAlias" onBlur="blnAliasExists();">
                                    <span class="add-on"><img id="imgProjectAliasStatus" src="img/yes.png" style="height:100%;width:100%"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-primary" id="btnModalProjectSave" name="btnModalProjectSave" onClick="projectInsertUpdate(document.getElementById('idProject').value);" data-loading-text="..."><? echo $_SESSION['strGlobalSave']; ?></a>
                    </div>
                </div>
				<script>			
                    function projectLoad(idProject) {
                        document.getElementById('idProject').value = idProject;
                        document.getElementById('strUserEmail').value = '';
                        document.getElementById('strProjectName').value = '';
                        document.getElementById('strProjectAlias').value = '';
                        document.getElementById('strAlias').value = '';
                        document.getElementById('strUserEmail').readOnly = false;
                        if (idProject > 0) {
                            var result = $.ajax({
                              url: "ajax.php?chrAction=PS&idProject=" + idProject
                            }).always(function() {
                                if (result.responseText) {
                                    var response 	= result.responseText;
                                    var retorno 	= JSON.parse(response);
                                    document.getElementById('idProject').value = idProject;
                                    document.getElementById('strUserEmail').value = retorno[0]['strUserCreator'];
                                    document.getElementById('strProjectName').value = retorno[0]['strName'];
                                    document.getElementById('strProjectAlias').value = retorno[0]['strAlias'];
			                        document.getElementById('strAlias').value = retorno[0]['strAlias'];
			                        document.getElementById('strUserEmail').readOnly = true;
                                }
                            });
                        }
                        $('#modalProject').modal('show');
                        document.getElementById('strUserEmail').focus();
                    }
                
                    function checkProjectFormRequiredFields () {
                        if (! document.getElementById('strUserEmail').value) {
                            showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmEditProfilePersonalEmail']); ?>');
                            document.getElementById('strUserEmail').focus();
                            return false;
                        }

                        if (! document.getElementById('strProjectAlias').value) {
                            showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['strGlobalAlias']); ?>');
                            document.getElementById('strProjectAlias').focus();
                            return false;
                        }
                        return true;
                    }

                    function projectInsertUpdate(idProject) {
                        if (! checkProjectFormRequiredFields()) return;
						$('#btnModalProjectSave').button('loading');
                        chrAction = (idProject >= 0 ? 'IPU' : 'SJI');
                        var result = $.ajax({
                          url: "ajax.php?chrAction=" + chrAction +
                                '&idProject=' + idProject +
                                '&strUserEmail=' + document.getElementById('strUserEmail').value +
                                '&strProjectName=' + document.getElementById('strProjectName').value +
                                '&strProjectAlias=' + document.getElementById('strProjectAlias').value
                        }).always(function() {
                            if (chrAction == "I") {
                                var response 	= result.responseText;
                                var arrResult 	= JSON.parse(response);
                                if (arrResult['idProject'] == -1) {
                                    showInfoAlert("<? echo $_SESSION['strErrorEmailAlreadyExists']; ?>");
                                    return;
                                }
                            }
                            $('#modalProject').modal('hide');
							$('#btnModalProjectSave').button('reset');
                            projectsLoad('tblProjects');
                        });
                    }
                    
                    function projectDelete(idProject) {
                        var blnDelete = confirm('<? echo $_SESSION['strInstallProjectConfirmDelete']; ?>');
                        if (! blnDelete) return;
                        $('#btnProjectDelete_' + idProject).button('loading');
                        var result = $.ajax({
                          url: "ajax.php?chrAction=PD&idProject=" + idProject
                        }).always(function() {
                            if (result.responseText > 0) {
                                $('#tblProjects_' + idProject).fadeOut(100, function(){
                                    $('#tblProjects_' + idProject).remove();
                                    $('#btnProjectDelete_' + idProject).button('reset');
                                });
                                document.getElementById('spanProjectsCounter').innerHTML = document.getElementById('spanProjectsCounter').innerHTML - 1;
                            }
                        });
                    }
                
                    function projectActiveUpdate(idProject, blnActive) {
                        $.ajax({url: "ajax.php?chrAction=PUAS&idProject=" + idProject + "&blnActive=" + (blnActive ? "1" : "0")});
                    }
                
                    function projectsLoad(idTable) {
                        var table = document.getElementById(idTable);
                        var tbody = table.getElementsByTagName("tbody")[0];
                        tbody.innerHTML = '<tr><td colspan="11"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
                        var strCellContent;
                        var result = $.ajax({
                          url: "ajax.php?chrAction=IPS2"
                        }).always(function() {
                            var response 	= result.responseText;
                            var arrResult 	= JSON.parse(response);
                            document.getElementById('spanProjectsCounter').innerHTML = arrResult.length;
                            tbody.innerHTML = ''; // Cleaning table
                            var rows = tbody.getElementsByTagName("tr").length;
                            for (var i=0;i<arrResult.length;i++) {
                                var row = tbody.insertRow(i);
                                row.id = idTable + '_' + arrResult[i]['idProject'];
                                var cell = row.insertCell(0);
                                cell.innerHTML = '<img src="' + arrResult[i]['strLogoFileFullPath'] + '" style="width:24px;height:24px" class="img-circle">';
                                cell.className = "hidden-phone hidden-tablet";
                                cell.style.verticalAlign = "middle";
                                cell.style.textAlign = "center";
                                cell.style.padding = "0px";
                                cell.width = "40px";
                                var cell = row.insertCell(1);
                                cell.innerHTML = arrResult[i]['idProject'];
                                cell.style.textAlign = "center";
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(2);
                                cell.innerHTML = arrResult[i]['strDateCreation'];
                                cell.style.textAlign = "center";
                                cell.className = "hidden-phone hidden-tablet";
                                var cell = row.insertCell(3);
                                cell.innerHTML = arrResult[i]['strDateLastAccess'] + ' (<span style="' + (arrResult[i]['intDaysSinceLastAccess'] >= 60 ? 'color:#FF0000' : '') + '">' + arrResult[i]['intDaysSinceLastAccess'] + '</span>)';
                                cell.style.textAlign = "center";
                                cell.style.whiteSpace = "nowrap";
                                cell.className = "hidden-phone hidden-tablet";
                                var cell = row.insertCell(4);
                                cell.innerHTML = '<a href="index.php?idProject=' + arrResult[i]['idProject'] + '" target="_blank">' + (arrResult[i]['blnAllowAllView'] == 0 ? '<i class="icon-lock"></i> ' : '') + arrResult[i]['strName'] + '</a>';
                                var cell = row.insertCell(5);
                                cell.innerHTML = arrResult[i]['strAlias'];
                                cell.style.textAlign = "left";
                                cell.className = "hidden-phone";
                                cell.style.whiteSpace = "nowrap";
                                //var cell = row.insertCell(6);
                                //cell.innerHTML = arrResult[i]['strAddress'] + ' ' + arrResult[i]['strCountryName'];
                                //cell.className = "hidden-phone hidden-tablet";
                                var cell = row.insertCell(6);
                                cell.innerHTML = arrResult[i]['intUsers'];
                                cell.style.textAlign = "center";
                                cell.className = "hidden-phone hidden-tablet";
                                var cell = row.insertCell(7);
                                cell.innerHTML = arrResult[i]['intForms'];
                                cell.style.textAlign = "center";
                                cell.className = "hidden-phone hidden-tablet";
                                var cell = row.insertCell(8);
                                cell.innerHTML = arrResult[i]['intRecords'];
                                cell.style.textAlign = "center";
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(9);
                                cell.style.textAlign = "center";
                                cell.innerHTML = '<input type="checkbox" onClick="projectActiveUpdate(' + arrResult[i]['idProject'] + ', this.checked);" ' + (arrResult[i]['blnActive'] == true ? 'checked' : '') + '>';
                                var cell = row.insertCell(10);
                                cell.style.textAlign = "center";
                                cell.style.whiteSpace = "nowrap";
                                strCellContent = '';
                                strCellContent += '<div class="btn btn-danger" id="btnProjectDelete_' + arrResult[i]['idProject'] + '" style="margin-left:3px;" data-loading-text="..." data-rel="tooltip" onClick="projectDelete(' + arrResult[i]['idProject'] + ');"><i class="icon-trash icon-white"></i></div>' +
													'<div class="btn btn-success" style="margin-left:3px;" data-rel="tooltip" onClick="projectLoad(' + arrResult[i]['idProject'] + ');"><i class="icon-edit icon-white"></i></div>';
                                cell.innerHTML = strCellContent;
                            }
                        });
                    }
					
					function blnAliasExists() {
						document.getElementById('strProjectAlias').value = document.getElementById('strProjectAlias').value.toLowerCase();
						var strAlias = document.getElementById('strProjectAlias').value;
						if (! strAlias) return;
						document.getElementById('imgProjectAliasStatus').src="img/carregando.gif";
						var strParams = 'chrAction=SJA' +
										'&strAlias=' + strAlias;
						var result = $.ajax({
						  url: "ajax.php?" + EliminateSpecialChars(strParams)
						}).done(function() {
							var resposta 	= result.responseText;
							var retorno 	= JSON.parse(resposta);
							if ((retorno[0]['int'] == '0') || (strAlias == document.getElementById('strAlias').value)) {
								document.getElementById('imgProjectAliasStatus').src="img/yes.png";
								document.getElementById('btnModalProjectSave').style.display = "inline-block";
							} else {
								document.getElementById('imgProjectAliasStatus').src="img/no.png";
								document.getElementById('btnModalProjectSave').style.display = "none";
							}
						});
					}
				</script>
            </div>
            <div id="div_support">
                <div class="sessionTitle">
                    <i class="icon-question-sign"></i><span class="hidden-phone"> <? echo $_SESSION['strInstallSessionSupport']; ?></span></span>
                </div>
                <table id="tblSupports" name="tblSupports" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
                    <thead>
                        <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF" class="btn-primary">
                              <th width="20"></th>
                              <th width="30" class="hidden-phone" style="text-align:center"><i class="icon-file"></i></th>
                              <th width="90" style="text-align:center"><? echo $_SESSION['stradmSupportTableHeaderOpen']; ?></th>
                              <th width="200" class="hidden-phone"><? echo $_SESSION['strIndexMenuUser']; ?></th>
                              <th width="200"><? echo $_SESSION['stradmSupportTableHeaderSubject']; ?></th>
                              <th style="text-align:center" class="hidden-phone"><? echo $_SESSION['stradmSupportTableHeaderInteractions']; ?></th>
                              <th style="text-align:center" class="hidden-phone"><? echo $_SESSION['stradmSupportTableHeaderLastAnswer']; ?></th>
                              <th width="110" style="text-align:center;white-space:nowrap;"><? echo $_SESSION['strGlobalActions']; ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
				</table>
                
                <!-- Panel for View/Insert Response -->
                <div class="modal hide fade hideSelection" id="modalSupportResponse">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">�</button>
                        <h4><i class="icon-question-sign"></i> <? echo $_SESSION['strMailSupportInteraction']; ?></h4>
                    </div>
                    <div class="modal-body">
                        <div class="control-group">
                            <!-- idSupport -->
                            <input type="hidden" id="idSupport" name="idSupport" value="">
                            <!-- txtMessageResponse -->
                            <label class="control-label"><? echo $_SESSION['strInstallSupportAnswer']; ?>:</label>
                            <div class="controls">
                                <textarea class="fullwith" rows="3" id="txtMessageResponse" name="txtMessageResponse"></textarea>
                            </div>
                
                            <div name="divMessageResponseLog" id="divMessageResponseLog" class="controls">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-primary" onClick="supportResponseInsert();"><? echo $_SESSION['strGlobalSubmit']; ?></a>
                    </div>
                </div>
                <script>
                    function supportLoad(idSupport) {
                        if (! idSupport > 0) {
							return;
						}
						var result = $.ajax({
						  url: "ajax.php?chrAction=SS&idSupport=" + idSupport + '&blnFromSupport=0'
						}).always(function() {
							if (result.responseText) {
								var response 	= result.responseText;
								var retorno 	= JSON.parse(response);
								document.getElementById('divMessageResponseLog').innerHTML = '';
								var strContent = '';
								// Load interactions
								// Responses
								var arrResponses = retorno[0]['arrResponses'];
								for (var i=0;i<arrResponses.length;i++) {
									strContent += '' +
									'<div style="border:1px solid #EEEEEE;margin:5px;padding:5px;background-color:' + (i % 2 == 1 ? '#fdfdfd' : '#f9f9f9') + '" class="rounded">' +
										'<div style="font-weight:bold">' +
											'<span class="notification yelow">' + arrResponses[i]['strDateTime'] + '</span> ' +
											'<span class="' + (arrResponses[i]['blnFromSupport'] > 0 ? 'notification green"><? echo $_SESSION['strInstallSupportAdministrator']; ?>:' : 'notification red"><? echo $_SESSION['strIndexMenuUser']; ?>:') + '</span> ' +
											'<i>' + arrResponses[i]['txtMessage'] + '</i>' +
										'</div>' +
									'</div>';
								}
								// First Message
								strContent += '' +
								'<div style="border:1px solid #EEEEEE;margin:5px;padding:5px;background-color:#fdfdfd" class="rounded">' +
									'<div style="font-weight:bold">' +
										'<span class="notification yelow">' + retorno[0]['strDateTime'] + '</span> ' +
										'<span class="notification red"><? echo $_SESSION['strIndexMenuUser']; ?>:</span> ' +
										'<i>' + retorno[0]['strSubject'] + '<br>' + retorno[0]['txtMessage'] + '</i>' +
									'</div>' +
								'</div>';
								document.getElementById('idSupport').value = idSupport;
								document.getElementById('divMessageResponseLog').innerHTML = strContent;
								document.getElementById('txtMessageResponse').value = '';
								$('#modalSupportResponse').modal('show');
								document.getElementById('txtMessageResponse').focus();
							}
						});
                    }
                
                    function supportResponseInsert() {
                        var result = $.ajax({
                          url: "ajax.php?chrAction=SRI&idSupport=" + document.getElementById('idSupport').value + "&txtMessage=" + document.getElementById('txtMessageResponse').value + "&blnFromSupport=1"
                        }).always(function() {
                            $('#modalSupportResponse').modal('hide');
                            supportsLoad('tblSupports');
                        });
                    }
                
                    function supportsLoad(idTable) {
                        var table = document.getElementById(idTable);
                        var tbody = table.getElementsByTagName("tbody")[0];
                           tbody.innerHTML = '<tr><td colspan="8"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
                        var result = $.ajax({
                          url: "ajax.php?chrAction=SS"
                        }).always(function() {
                            var response 	= result.responseText;
                            var arrResult 	= JSON.parse(response);
                            tbody.innerHTML = ''; // Cleaning table
                            var rows = tbody.getElementsByTagName("tr").length;
							var intTotalNew = 0;
                            for (var i=0;i<arrResult.length;i++) {
								intTotalNew += parseInt(arrResult[i]['intAdminUnreadInteractions'], 0);
                                var row = tbody.insertRow(i);
                                row.id = idTable + '_' + arrResult[i]['idSupport'];
                                var cell = row.insertCell(0);
                                cell.innerHTML = (i+1);
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(1);
                                cell.innerHTML = (arrResult[i]['strFileName'] ? '<a href="' + arrResult[i]['strFileNameFull'] + '" target="_blank"><i class="icon-file" title="' + arrResult[i]['strFileName'] + '"></i></a>' : '');
                                var cell = row.insertCell(2);
                                cell.innerHTML = arrResult[i]['strDateTime'];
                                var cell = row.insertCell(3);
                                cell.innerHTML = arrResult[i]['strName'] + ' - ' + arrResult[i]['strProjectName'];
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(4);
                                cell.innerHTML = '<a href="#" title="<? echo $_SESSION['strInstallSupportViewCall']; ?>"  onClick="supportLoad(' + arrResult[i]['idSupport'] + ');">' + arrResult[i]['strSubject'] + '</a>';
                                var cell = row.insertCell(5);
                                cell.innerHTML = arrResult[i]['intInteractions'] + (arrResult[i]['intAdminUnreadInteractions'] > 0 ? '<br><span style="font-weight:bold;color:#FF0000">' + arrResult[i]['intAdminUnreadInteractions'] + ' <? echo $_SESSION['stradmSupportNewMessages']; ?></span>': '');
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(6);
                                cell.innerHTML = arrResult[i]['strDateTimeLastInteraction'];
                                cell.className = "hidden-phone";
                                var cell = row.insertCell(7);
                                cell.innerHTML = 	'<span class="btn btn-success" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['strInstallSupportViewLog']; ?>" onClick="supportLoad(' + arrResult[i]['idSupport'] + ');"><i class="icon-eye-open icon-white"></i></span>';
                                // Setting cells alignment
                                for (var j=0;j<=7;j++) {
                                    tbody.rows[i].cells[j].style.textAlign = "center";
                                }
                                tbody.rows[i].cells[3].style.textAlign = "left";
                                tbody.rows[i].cells[4].style.textAlign = "left";
                            }
                            document.getElementById('spanSupportsCounter').innerHTML = '<span style="font-weight:bold;color:#FF0000">' + intTotalNew + '</span>/' + arrResult.length;
                        });
                    }
                </script>
            </div>
        </td>
        </tr></table>
        <script>
			function TMPClean() {		
				$('#btnTMPClean').button('loading');
				var result = $.ajax({
				  url: "ajax.php?chrAction=ITFC"
				}).always(function() {
					$('#btnTMPClean').button('reset');
				});	
			}
		
            showSession(arrSessions, 0);
            $(document).ready( function () {
				connectionTest();
            });	
        </script>
    <? }  ?>
	</div>
    <script>
		$(document).ready( function () {
			$.backstretch(["<? echo $strings->strSiteDefaultBackgroundFile; ?>"], {duration: 3000, fade: 2000});
			$('#modalSupportResponse').on('hidden.bs.modal', function (e) {
				supportsLoad('tblSupports');
			});
		});
    </script>
</form>
</body>
</html>