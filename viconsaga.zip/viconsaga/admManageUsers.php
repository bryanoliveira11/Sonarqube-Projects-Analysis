<? $strings->changePageTitle($_SESSION['strIndexMenuProjectManagementManageUsers']); ?>
<script>
	var arrSessions = new Array ("users", "workgroups");
</script>
<div class="sessionTitle"><i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementManageUsers']; ?></div>
<div class="box-content">
    <table width="100%"><tr>
    <!-- Menu -->
    <td valign="top">
        <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF">
            <li id="menu_users" onClick="showSession(arrSessions, 0);" >
                <a><i class="<? echo $user->strDefaultIcon; ?>"></i><span class="hidden-phone"> <? echo $_SESSION['stradmStatsTitleUsers']; ?></span></a>
            </li>
            <li id="menu_workgroups" onClick="showSession(arrSessions, 1);">
                <a><i class="icon-gift"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageProjectMenuWorkgroups']; ?></span></a>
            </li>
        </ul>
    </td>
    <!-- End Menu -->
    <!-- Body -->
    <td valign="top" width="100%" style="padding-left:20px;background-color:transparent;">
        <div id="div_users">
            <div class="sessionTitle">
                <i class="<? echo $user->strDefaultIcon; ?>"></i> <span class="hidden-phone"><? echo $_SESSION['stradmStatsTitleUsers']; ?></span>
                (<span id="spanUsersCounter">0</span>)
            
                <span style="float:right;position:relative;top:-9px;text-align:right;position:relative;top:-4px;">
                    <select id="cmbActionUsers" name="cmbActionUsers" class="btn" style="width:30%;min-width:155px;text-align:left;" onChange="usersAction(this.value);">
                        <option value="0"><? echo $_SESSION['strGlobalSelected']; ?> ----------</option>
                        <option value="1"><? echo $_SESSION['stradmManageUsersActionsTransferRecords']; ?></option>
                        <option value="4"><? echo $_SESSION['stradmManageUsersActionsChangeUserLevel']; ?></option>
                        <option value="0">------------------------------</option>
                        <option value="2"><? echo $_SESSION['strGlobalDelete']; ?></option>
                    </select>
                    
                    <select id="cmbUsers" name="cmbUsers" class="btn" style="display:none;width:30%;min-width:145px;text-align:left;" onChange="usersAction(3);"></select>
                    
                    <select id="cmbUsersLevel" name="cmbUsersLevel" class="btn" style="display:none;width:30%;min-width:165px;text-align:left;" onChange="if (this.selectedIndex == 0) return; usersAction(5);">
                        <option value="0"><? echo $_SESSION['strGlobalSelect']; ?> ----------</option>
						<?
                        $arrUserLevels = $user->selectUserLevels();
                        foreach ($arrUserLevels as $arrUserLevel) {
                            echo '<option value="' . $arrUserLevel['idUserLevel'] . '">' . $arrUserLevel['strLevel'] . '</option>';
                        }
                        ?>
                    </select>
                    
                    <a class="btn btn-success" onclick="userLoad(-1);"><i class="icon-plus-sign icon-white"></i> <span class="hidden-phone"><? echo $_SESSION['stradmManageUsersButtonInsert']?></span></a>
                </span>
            </div>
            
            <table id="tblUsers" name="tblUsers" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
                <thead>
                    <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF" class="btn-primary">
                        <th width="1"><input type="checkbox" id="ckAll" onClick="checkAllTable(this.checked, 'tblUsers');"/></th>
                        <th style="text-align:center" width="50" class="hidden-phone hidden-tablet"><? echo $_SESSION['stradmManageUsersDateRegister']; ?></th>
                        <th style="text-align:center" width="90" class="hidden-phone hidden-tablet"><? echo $_SESSION['stradmManageUsersDateLastAccess']; ?></th>
                        <th style="text-align:center;" width="120" class="hidden-phone"><? echo $_SESSION['strGlobalWorkgroup']; ?></th>
                        <th style="text-align:center" width="250"><? echo $_SESSION['stradmManageUsersEmail']; ?></th>
                        <th style="text-align:center" width="250" class="hidden-phone hidden-tablet"><? echo $_SESSION['stradmManageUsersName']; ?></th>
                        <th style="text-align:center" width="200" class="hidden-phone"><? echo $_SESSION['stradmManageUsersLevel']; ?></th>
                        <th style="text-align:center" width="1" class="hidden-phone"><? echo $_SESSION['stradmManageUsersRecordsCreated']; ?></th>
                        <th style="text-align:center;white-space:nowrap;" width="160"><? echo $_SESSION['strGlobalActions']; ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            
            <!-- Panel for Insert User -->
            <div class="modal hide fade hideSelection" id="modalUser">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">�</button>
                    <h4><i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo $_SESSION['stradmManageUsersModalTitle']; ?></h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="idUser" name="idUser" value="">
                    <div class="control-group">
	                    <!-- blnSendNotificationMail -->
						<input type="checkbox" id="blnSendNotificationMail"> <label for="blnSendNotificationMail" style="display:inline-block;font-weight:bold"> <? echo $_SESSION['stradmManageUsersSendNotificationMail']; ?></label>
                        
                        <!-- cmbProjectWorkgroup -->
                        <label class="control-label"><? echo $_SESSION['strGlobalWorkgroup']; ?>:</label>
                        <div class="controls">
                            <select id="cmbProjectWorkgroup" name="cmbProjectWorkgroup" style="width:100%" multiple></select>
                        </div>
                       
                        <!-- idUserLevel -->
                        <label class="control-label"><? echo $_SESSION['stradmManageUsersLevel']; ?>:</label>
                        <div class="controls">
                            <select id="idUserLevel" name="idUserLevel" style="width:100%">
                            <?
                            foreach ($arrUserLevels as $arrUserLevel) {
                                echo '<option value="' . $arrUserLevel['idUserLevel'] . '">' . $arrUserLevel['strLevel'] . '</option>';
                            }
                            ?>
                            </select>
                        </div>
                                         
                        <!-- strEmail -->
                        <label class="control-label"><? echo $_SESSION['stradmManageUsersEmail']; ?>:
                        <div class="controls">
                            <input type="text" class="fullwith" id="strEmail" name="strEmail">
                        </div>
            
                        <!-- strName -->
                        <label class="control-label"><? echo $_SESSION['stradmManageUsersName']; ?>:</label>
                        <div class="controls">
                            <input type="text" class="fullwith" id="strName" name="strName">
                        </div>
                        
                        <!-- strPassword -->
                        <label class="control-label"><? echo $_SESSION['stradmManageUsersPassword']; ?>:</label>
                        <div class="controls">
                            <input type="password" class="fullwith" id="strPassword" name="strPassword">
                        </div>
            
                        <!-- strSkypeID -->
                        <label class="control-label"><? echo $_SESSION['stradmManageProjectPreferencesSkypeID']; ?>:</label>
                        <div class="controls">
                            <div class="input-prepend" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectPreferencesSkypeIDTip']; ?>">
                                <span class="add-on">
                                <a href="https://support.skype.com/pt-br/faq/FA605/como-faco-para-configurar-o-botao-do-skype-para-mostrar-meu-status-na-web-no-skype-para-windows-desktop" target="_blank" style="cursor:help">
                                    <img src="img/skype.png" style="height:16px;width:16px">
                                </a>
                                </span>
                                <input type="text" id="strSkypeID" name="strSkypeID">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn" id="btnModalUserCancel" name="btnModalUserCancel" data-dismiss="modal"><? echo $_SESSION['strGlobalCancel']; ?></a>
                    <a href="#" class="btn btn-primary" id="btnModalUserSave" name="btnModalUserSave" data-loading-text="<? echo $_SESSION['strGlobalWait']; ?>" onclick="userInsertUpdate(document.getElementById('idUser').value);"><? echo $_SESSION['strGlobalSave']; ?></a>
                </div>
            </div>
			<script>
                function userLoad(idUser) {
					$('#btnModalUserSave').button('reset');
                    document.getElementById('idUser').value = idUser;					
					document.getElementById('blnSendNotificationMail').checked = idUser > 0 ? 0 : 1;
                    document.getElementById('strEmail').value = '';
                    document.getElementById('strName').value = '';
                    document.getElementById('strPassword').value = '';
                    document.getElementById('strPassword').placeholder = '********';
                    document.getElementById('idUserLevel').selectedIndex = 0;
                    document.getElementById('cmbProjectWorkgroup').selectedIndex = 0;
                    document.getElementById('strSkypeID').value = '';
                    if (idUser > 0) {
                        var result = $.ajax({
                          url: "ajax.php?chrAction=US&idUser=" + idUser
                        }).always(function() {
                            if (result.responseText) {
                                var response 	= result.responseText;
                                var retorno 	= JSON.parse(response);
                                document.getElementById('idUser').value = idUser;
                                document.getElementById('strEmail').value = retorno[0]['strEmail'];
                                document.getElementById('strName').value = retorno[0]['strName'];
                                document.getElementById('strSkypeID').value = retorno[0]['strSkypeID'];
                                comboSelectByValue(document.getElementById('idUserLevel'), retorno[0]['idUserLevel']);
								comboMultipleSelectByValue(document.getElementById('cmbProjectWorkgroup'), retorno[0]['idProjectWorkgroups']);
                            }
							$('#modalUser').modal('show');
							document.getElementById('strEmail').focus();
                        });
                    } else {
						$('#modalUser').modal('show');
						document.getElementById('strEmail').focus();
					}
                }
            
                function checkUserFormRequiredFields () {
                    if (! document.getElementById('strEmail').value) {
                        showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageUsersEmail']); ?>');
                        document.getElementById('strEmail').focus();
                        return false;
                    }
                    return true;
                }
                			
                function userInsertUpdate(idUser) {
                    $('#btnModalUserSave').button('reset');
                    if (! checkUserFormRequiredFields()) return;
                    $('#btnModalUserSave').button('loading');
                    chrAction = (idUser >= 0 ? 'U' : 'I');
                    var result = $.ajax({
                      url: "ajax.php?chrAction=U" + chrAction +
                            '&idUser=' + idUser +
                            '&idProject=<? echo $arrProject['idProject']; ?>' +
                            '&strIdProjectWorkgroups=' + comboGetSelectedValues(document.getElementById('cmbProjectWorkgroup')) +
                            '&strEmail=' + document.getElementById('strEmail').value +
                            '&strName=' + document.getElementById('strName').value +
                            '&strSkypeID=' + document.getElementById('strSkypeID').value +
                            '&strPassword=' + document.getElementById('strPassword').value +
                            '&idUserLevel=' + document.getElementById('idUserLevel').value +
                            '&blnSendNotificationMail=' + (document.getElementById('blnSendNotificationMail').checked ? '1' : '0') +
                            (chrAction == "I" ? "&blnActive=1" : "")
                    }).always(function() {
                        if (chrAction == "I") {
                            var response 	= result.responseText;
                            var arrResult 	= JSON.parse(response);
                            if (arrResult['idUser'] == -1) {
                                showInfoAlert("<? echo $_SESSION['strErrorEmailAlreadyExists']; ?>");
                                return;
                            }
                        }
	                    $('#btnModalUserSave').button('reset');
                        $('#modalUser').modal('hide');
                        usersLoad('tblUsers');
                    });
                }
            
                function userDelete(idUser) {
                    var blnDelete = confirm('<? echo $_SESSION['stradmManageUsersConfirmDelete']; ?>');
                    if (! blnDelete) return;
                    var result = $.ajax({
                      url: "ajax.php?chrAction=UD&idUser=" + idUser
                    }).always(function() {
                        if (result.responseText > 0) {
                            $('#tblUsers_' + idUser).fadeOut(800, function(){
                                $('#tblUsers_' + idUser).remove();
                            });
                            document.getElementById('spanUsersCounter').innerHTML = document.getElementById('spanUsersCounter').innerHTML - 1;
                        }
                    });
                }
            
                function usersLoad(idTable) {
                    comboClear("cmbUsers");
                    var cmbUsers = document.getElementById("cmbUsers");
                    var opt = document.createElement('option');
                    opt.value = '';
                    opt.text = '<? echo $_SESSION['strGlobalSelect']; ?>';
                    cmbUsers.add(opt);
                    var table = document.getElementById(idTable);
                    var tbody = table.getElementsByTagName("tbody")[0];
                    tbody.innerHTML = '<tr><td colspan="9"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
                    var result = $.ajax({
                      url: "ajax.php?chrAction=US&idProject=<? echo $arrProject['idProject']; ?>"
                    }).always(function() {
                        var response 	= result.responseText;
                        var arrResult 	= JSON.parse(response);
                        tbody.innerHTML = '';
                        var rows = tbody.getElementsByTagName("tr").length;
                        for (var i=0;i<arrResult.length;i++) {
                            // Insert into Combo Users
                            var opt = document.createElement('option');
                            opt.value = arrResult[i]['idUser'];
                            opt.text = arrResult[i]['strEmail'];
                            cmbUsers.add(opt);
                            // Insert into Table
                            var row = tbody.insertRow(i);
                            row.id = idTable + '_' + arrResult[i]['idUser'];
                            var cell = row.insertCell(0);
                            cell.innerHTML = '<input type="checkbox" id="ckUser_' + arrResult[i]['idUser'] + '" value="' + arrResult[i]['idUser'] + '">';
                            cell.style.textAlign = "center";
                            var cell = row.insertCell(1);
                            cell.innerHTML = arrResult[i]['strRegister'];
                            cell.className = "hidden-phone hidden-tablet";
                            cell.style.textAlign = "center";
                            var cell = row.insertCell(2);
                            cell.innerHTML = arrResult[i]['strDateLastAccess'];
                            cell.className = "hidden-phone hidden-tablet";
                            cell.style.textAlign = "center";
                            var cell = row.insertCell(3);
                            cell.innerHTML = arrResult[i]['strWorkgroups'];
                            cell.className = "hidden-phone";
                            cell.style.textAlign = "center";
                            cell.style.wordWrap = "break-word";
                            var cell = row.insertCell(4);
                            cell.innerHTML = arrResult[i]['strEmail'] + (arrResult[i]['strSkypeStatus'] ? '<span style="float:right">' + arrResult[i]['strSkypeStatus'] + '</span>': '');
                            var cell = row.insertCell(5);
                            cell.innerHTML = arrResult[i]['strName'];
                            cell.className = "hidden-phone hidden-tablet";
                            var cell = row.insertCell(6);
                            cell.innerHTML = arrResult[i]['strUserLevel'];
                            cell.style.textAlign = "center";
                            cell.className = "hidden-phone";
                            var cell = row.insertCell(7);
                            cell.innerHTML = arrResult[i]['intNumRecords'];
                            cell.className = "hidden-phone";
                            cell.style.textAlign = "center";
                            var cell = row.insertCell(8);
                            cell.innerHTML =	(arrResult[i]['idUser'] != <? echo $arrProject['idUserCreator']; ?> ? '<span id="btnUserActive_' + arrResult[i]['idUser'] +  '" class="btn btn-' + (arrResult[i]['blnActive'] > 0 ? "success" : "danger") + '" data-rel="tooltip" title="' + (arrResult[i]['blnActive'] > 0 ? "<? echo $_SESSION['stradmManageUsersActiveHint']; ?>" : "<? echo $_SESSION['stradmManageUsersBlockedHint']; ?>") + '" onClick="userSetActive(' + arrResult[i]['idUser'] + ');"><i id="iUserActive_' + arrResult[i]['idUser'] +  '" class="icon-thumbs-' + (arrResult[i]['blnActive'] > 0 ? "up" : "down") + ' icon-white"></i></span>' +
                                                '<span class="btn btn-success" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmManageUsersbtnEditUserHint']; ?>" onClick="userLoad(' + arrResult[i]['idUser'] + ');"><i class="icon-edit icon-white"></i></span>' +
                                                '<span class="btn btn-danger" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmManageUsersbtnDeleteUserHint']; ?>" onClick="userDelete(' + arrResult[i]['idUser'] + ');"><i class="icon-trash icon-white"></i></span>'
												 : '<b><? echo $_SESSION['stradmManageUsersProjectOwner']; ?></b>');
                            cell.style.textAlign = "center";
							cell.style.whiteSpace = "nowrap";
                        }
                        document.getElementById('spanUsersCounter').innerHTML = arrResult.length;
                    });
            
                }
            
                function userSetActive(idUser) {
                    //$('#btnUserActive_' + idUser).button('loading');
                    showInfoAlert('<? echo $_SESSION['strGlobalProcessing']; ?>...', 1);
                    var blnActive = document.getElementById('iUserActive_' + idUser).className.indexOf('up') > 0 ? 0 : 1;
                    var result = $.ajax({
                      url: "ajax.php?chrAction=UUA&idUser=" + idUser + "&blnActive=" + blnActive
                    }).always(function() {
                        document.getElementById('iUserActive_' + idUser).className = "icon-thumbs-" + (blnActive ? "up" : "down") + " icon-white";
                        document.getElementById('btnUserActive_' + idUser).className = "btn btn-" + (blnActive ? "success" : "danger");
                        document.getElementById('btnUserActive_' + idUser).title = (blnActive ? "<? echo $_SESSION['stradmManageUsersActiveHint']; ?>" : "<? echo $_SESSION['stradmManageUsersBlockedHint']; ?>");
	                    showInfoAlert('<? echo $_SESSION['strGlobalProcessing']; ?>...', 2);
                        //$('#btnUserActive_' + idUser).button('reset');
                    });
                }
            
                function usersAction(intValue) {
                    if (intValue == 1) { // Migrate Recors from/to User
                        document.getElementById("cmbUsers").style.display = "inline-block";
                        document.getElementById("cmbUsers").focus();
                        return;
                    } else {
                        document.getElementById("cmbUsers").style.display = "none";
                    } 
					if (intValue == 4) { // Change Users Level
                        document.getElementById("cmbUsersLevel").style.display = "inline-block";
                        document.getElementById("cmbUsersLevel").focus();
                        return;
                    } else {
                        document.getElementById("cmbUsersLevel").style.display = "none";
					}
                    if (intValue == 0) {
                        return;
                    } else if (intValue == 2) { // Delete
                        var blnDelete = confirm('<? echo $_SESSION['stradmManageUsersConfirmDelete']; ?>');
                        if (! blnDelete) {
                            document.getElementById('cmbActionUsers').selectedIndex = 0;
                            return;
                        }
                    } else if (intValue == 3) {
                        if (! document.getElementById("cmbUsers").value) return;
                    }
                    showInfoAlert('<? echo $_SESSION['strGlobalProcessing']; ?>...', 1);
                    var strIDs = strSerializeChecksTable('tblUsers');
                    var result = $.ajax({
                      url: "ajax.php?chrAction=UA" +
					  		"&intValue=" + intValue + 
					  		"&idUser=<? echo $arrUser['idUser']; ?>" + 
					  		"&idUserCreator=<? echo $arrProject['idUserCreator']; ?>" + 
							"&strIDs=" + strIDs + 
							"&idUserTo=" + document.getElementById("cmbUsers").value + 
							"&idUsersLevel=" + document.getElementById("cmbUsersLevel").value
                    }).always(function() {
                        document.getElementById('cmbActionUsers').selectedIndex = 0;
						document.getElementById('cmbUsersLevel').selectedIndex = 0;
                        showInfoAlert('<? echo $_SESSION['strGlobalProcessing']; ?>...', 2);
                        if ((intValue == 3) || (intValue == 5)) {
                            showSuccessAlert();
                        }
						document.getElementById('ckAll').checked = false;
                        usersLoad('tblUsers');
                    });
                }            
            </script>
		</div>
        <div id="div_workgroups">
			<div class="sessionTitle">
            	<i class="icon-gift"></i> <? echo $_SESSION['stradmManageProjectMenuWorkgroups']; ?>
				<a id="btnWorkgroupInsert" class="btn btn-success" style="float:right;position:relative;top:-4px;" data-loading-text="..." data-rel="tooltip" onClick="workgroupInsertUpdate(-1, '');"><i class="icon-plus-sign icon-white"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageProjectWorkgroupsAdd']; ?></span></a>
			</div>
            <table id="tblWorkgroups" name="tblWorkgroups" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
                <thead>
                    <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF" class="btn-primary">
                        <th style="text-align:center"><? echo $_SESSION['strGlobalWorkgroup']; ?></th>
                        <th style="text-align:center" width="80"><? echo $_SESSION['strGlobalActions']; ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
			<script>
                function workgroupInsertUpdate(idProjectWorkgroup, strOldWorkgroup) {
			    	var strWorkgroup = prompt('<? echo $_SESSION['stradmManageFormsInsertPrompt']; ?>:', strOldWorkgroup);
					if (! strWorkgroup) return;
					$('#btnWorkgroupInsert').button('loading');
                    chrAction = (idProjectWorkgroup >= 0 ? 'U' : 'I');
                    var result = $.ajax({
                      url: "ajax.php?chrAction=PW" + chrAction +
                            '&idProjectWorkgroup=' + idProjectWorkgroup +
                            '&idProject=<? echo $arrProject['idProject']; ?>' +
                            '&strWorkgroup=' + strWorkgroup
                    }).always(function() {
                        workgroupsLoad('tblWorkgroups');
						$('#btnWorkgroupInsert').button('reset');
                    });
                }
            
                function workgroupDelete(idProjectWorkgroup) {
                    var blnDelete = confirm('<? echo $_SESSION['stradmManageProjectWorkgroupsConfirmDelete']; ?>');
                    if (! blnDelete) return;
                    var result = $.ajax({
                      url: "ajax.php?chrAction=PWD&idProjectWorkgroup=" + idProjectWorkgroup
                    }).always(function() {
                        if (result.responseText > 0) {
							/*
                            $('#tblWorkgroups_' + idProjectWorkgroup).fadeOut(800, function(){
                                $('#tblWorkgroups_' + idProjectWorkgroup).remove();

                            });
							*/
							workgroupsLoad('tblWorkgroups');
							usersLoad('tblUsers');
                        }
                    });
                }
			
                function workgroupsLoad(idTable) {
                    var table = document.getElementById(idTable);
                    var tbody = table.getElementsByTagName("tbody")[0];
                    tbody.innerHTML = '<tr><td colspan="2"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
					// User Workgroup
					comboClear("cmbProjectWorkgroup");
					var cmbWorkgroup = document.getElementById("cmbProjectWorkgroup");
                    var result = $.ajax({
                      url: "ajax.php?chrAction=PWS&idProject=<? echo $arrProject['idProject']; ?>"
                    }).always(function() {
                        var response 	= result.responseText;
                        var arrResult 	= JSON.parse(response);
                        tbody.innerHTML = '';
                        var rows = tbody.getElementsByTagName("tr").length;
                        for (var i=0;i<arrResult.length;i++) {
							// Workgroup
                            var opt = document.createElement('option');
                            opt.value = arrResult[i]['idProjectWorkgroup'];
                            opt.text = arrResult[i]['strWorkgroup'];
                            cmbWorkgroup.add(opt);
							// Table Row
                            var row = tbody.insertRow(i);
                            row.id = idTable + '_' + arrResult[i]['idProjectWorkgroup'];
                            var cell = row.insertCell(0);
                            cell.innerHTML = arrResult[i]['strWorkgroup'];
                            var cell = row.insertCell(1);
							if (arrResult[i]['idProjectWorkgroup'] > 0) {
	                            cell.innerHTML =	'<span class="btn btn-info" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectWorkgroupsRenameTip']; ?>" onClick="workgroupInsertUpdate(' + arrResult[i]['idProjectWorkgroup'] + ', \'' + arrResult[i]['strWorkgroup'] + '\');"><i class="icon-refresh icon-white"></i></span>' +
    	                                            '<span class="btn btn-danger" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmManageProjectWorkgroupsDeleteTip']; ?>" onClick="workgroupDelete(' + arrResult[i]['idProjectWorkgroup'] + ');"><i class="icon-trash icon-white"></i></span>';
        	                    cell.style.textAlign = "center";
							}
                        }
                    });
                }
            </script>
		</div>
    </td>
    </tr></table>
    <!-- End Body -->
</div>
<script>
	showSession(arrSessions, <? echo ($_GET['ss'] ? $_GET['ss'] : 0);?>);
	$(document).ready( function () {
		usersLoad('tblUsers');
		workgroupsLoad('tblWorkgroups');
	});	
</script>