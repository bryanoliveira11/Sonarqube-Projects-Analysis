<?
	// Initializing Engine Classes
	include_once 'engine/strings.php';
	$strings = new Strings();
	include_once 'engine/database.php';
	$database = new Database();	
	include_once 'engine/project.php';
	$project = new Project($database);
	include_once 'engine/report.php';
	$report = new Report($database);

	// Live KML
	if (! is_numeric($_GET['idProject'])) {
		echo '<kml><Document><open>1</open><Folder><name>Invalid Project</name><gx:balloonVisibility>1</gx:balloonVisibility></Folder></Document></kml>';
		exit;
	}
	
	$arrProject = $project->selectProjects($_GET['idProject']);
	$arrProject = $arrProject[0];
	if (count($arrProject) == 0) {
		echo '<kml><Document><open>1</open><Folder><name>Invalid Project</name><gx:balloonVisibility>1</gx:balloonVisibility></Folder></Document></kml>';
		exit;
	}
	
	if (! $arrProject['blnAllowAllView']) {
		echo '<kml><Document><open>1</open><Folder><name>Private Records</name><gx:balloonVisibility>1</gx:balloonVisibility></Folder></Document></kml>';
		exit;
	}
	set_time_limit(1800); // Increasing Timeout to Garantee Enough Time
	$arrReport = $report->generateReport($arrProject['idProject'], 'kml', '', true, true, false, 0, 0, '', '', '', '', false);
	echo $arrReport['strReport'];
?>