<?php
include_once 'engine/database.php';
$database = new Database();
include_once 'engine/strings.php';
$strings = new Strings();
include_once 'engine/project.php';
$project = new Project($database);
include_once 'engine/user.php';
$user = new User($database);
include_once 'engine/form.php';
$form = new Form($database);
include_once 'engine/formrecord.php';
$formrecord = new Formrecord($database);
include_once 'engine/importer.php';
$importer = new Importer($database);
include_once 'engine/map.php';
$map = new Map($database);
include_once 'engine/report.php';
$report = new Report($database);
include_once 'engine/stats.php';
$stats = new Stats($database);
include_once 'engine/alert.php';
$alert = new Alert($database);
include_once 'engine/support.php';
$support = new Support($database);
include_once 'engine/toponymy.php';
$toponymy = new Toponymy($database);
include_once 'engine/conversor.php';
$conversor = new Conversor($database);
include_once 'engine/censo.php';
$censo = new Censo();
// Just allow call by ajax request from files in server.  Prevents calling this page by navigator URL or from another host but localhost
if (
	($_SERVER['HTTP_X_REQUESTED_WITH'] != 'XMLHttpRequest') && 
	(strpos($_SERVER['HTTP_REFERER'], getenv('HTTP_HOST')) === FALSE)
) { 
	header("HTTP/1.0 403 Forbidden"); exit; 
}
  
set_time_limit(1200);
$chrAction	= $_GET['chrAction'];
switch ($chrAction) {
// Install
case 'IDI': // Install Database Install
	echo $database->install();
	break;

case 'ISF': // Install Save To File
	$fh = fopen($strings->strConnectionFileName, 'w');
	$strText =	'<?' . chr(13) .
				'$blnSiteAllowProjectCreation=' . $_GET['blnSiteAllowProjectCreation']  . ';' . chr(13) .
				'$admPassword="' . $_GET['admPassword']  . '";' . chr(13) .
				'$server="' . $_GET['server'] . '";' . chr(13) .
				'$username="' . $_GET['username'] . '";' . chr(13) .
				'$password="' . $_GET['password'] . '";' . chr(13) .
				'$database="' . $_GET['database'] . '";' . chr(13) .
				'?>';
	fwrite($fh, $strText);
	fclose($fh);
	echo 1;
	break;

case 'ICT': // Install Connection Test
	$arrResult = array();
	$arrResult['blnConnected'] = $database->isConnected();
	$arrResult['blnDatabase'] = true;
	if ($arrResult['blnConnected']) {
		$arrResult['blnDatabase'] = $database->blnTableExists();
	}
	echo json_encode($arrResult);
	break;

case 'IPS2': // Projects Select
	$arrProjects = $project->selectProjects(0, '', 0, true, true);
	echo json_encode($project->strings->encodeArray($arrProjects));
	break;
	
case 'IPU': // Install Project Update
	$arrResult = $project->updateProjectInstall(
		$_GET['idProject'], 
		$_GET['strProjectAlias'],
		$_GET['strProjectName']
	);
	echo json_encode($arrResult);
	break;

case 'ITFC': // Install tmp Folder Clean
	$strTMPDir = $strings->strSiteTmpFileFolder;
	if ((strlen($strTMPDir) > 2) && (file_exists($strTMPDir))) {
		$strings->sureRemoveDir($strTMPDir, false);
	}
	echo true;
	break;

// Site Join
case 'SJA': // Site Join Check Alias
	$arrResult = $project->blnCheckAliasExists($_GET['strAlias']);
	echo json_encode($arrResult);
	break;
case 'SJI': // Site Join
	$arrResult = $project->insertProject($_GET['strUserEmail'], $_GET['strProjectName'], $_GET['strProjectAlias']);
	echo json_encode($arrResult);
	break;

// Site Index
case 'SIPS': // Index Insert Project Search
	$return = $project->selectProjects(0, $_GET['query'], 1, false, false, 0);
	echo json_encode($project->strings->encodeArray(array('suggestions'=>$return)));
	break;

// Index
case 'IPS': // Index Insert Project Search
	$stats->insertProjectSearch($_GET['idProject'], $_GET['strSearch']);
	break;
	
case 'ISTU': // Index Search Type Update
	unset($_COOKIE['intSearchType']);
	setcookie("intSearchType", $_GET['intSearchType'], time() + 999999);
	$_COOKIE['intSearchType'] = $_GET['intSearchType'];
	break;
	
case 'ISA': // Index Search Autocomplete
	$arrResult = array();
	$arrResult['query'] = $_GET['query'];
	$arrValues = $formrecord->selectSuggestedValUES($_GET['idProject'], $_GET['query'], $_GET['intSearchType']);
	$arrResult['suggestions'] = $arrValues;
	echo json_encode($project->strings->encodeArray($arrResult));
	break;
	
case 'IGEG': // Index Google Earth Generate
	$arrResult = $report->liveGoogleEarthKML($_GET['idProject']);
	echo json_encode($report->strings->encodeArray($arrResult));
	break;
	
case 'IUAES': // Index User Alert Events Select
	$return = $alert->selectUserAlertEvents($_GET['idUser'], $_GET['intLimit']);
	echo json_encode($alert->strings->encodeArray($return));
	break;

case 'IUAESR': // Index User Alert Events Set All Read
	$return = $alert->updateUserAlertEvent($_GET['idUser'], 1, 0);
	echo json_encode($alert->strings->encodeArray($return));
	break;

case 'IUAUER': // Index User Alert Events Unread Count
	$return = $alert->intCountUserAlertEventUnread($_GET['idUser']);
	echo json_encode($return);
	break;
	
case 'IUAED': // Index User Alert Events Details
	$return = $alert->selectUserAlertEventDetails($_GET['idUserAlertEvent']);
	echo json_encode($alert->strings->encodeArray($return));
	break;
	
case 'IFRSL': // Index Form Record Show Log
	$return = $formrecord->selectFormRecordLog($_GET['idFormRecord']);
	echo json_encode($formrecord->strings->encodeArray($return));
	break;
	

// Tool Conversor
case 'CC': // Conversor Convert
	include_once 'engine/coordinate.php';
	$coordinate = new Coordinate($database);
	$arrResult = $coordinate->strBatchConvertCoordinates($_GET['txtInput'], $_GET['idType'], $_GET['idDatumIn'], $_GET['idDatumOut'], $_GET['blnDownload']);
	unset($_COOKIE['idDatumIn']); setcookie("idDatumIn", $_GET['idDatumIn'], time() + $user->strings->intCookieLifeSec); $_COOKIE['idDatumIn'] = $_GET['idDatumIn'];
	unset($_COOKIE['idDatumOut']); setcookie("idDatumOut", $_GET['idDatumOut'], time() + $user->strings->intCookieLifeSec); $_COOKIE['idDatumOut'] = $_GET['idDatumOut'];
	echo json_encode($user->strings->encodeArray($arrResult));
	break;
	
// Tool Site Conversor Vector to RS2
case 'VEC2RS2': // Tool Site Conversor Vector to RS2
	if ($_GET['idDatumIn']) { unset($_COOKIE['idDatumIn']); setcookie("idDatumIn", $_GET['idDatumIn'], time() + $user->strings->intCookieLifeSec); $_COOKIE['idDatumIn'] = $_GET['idDatumIn']; }
	if ($_GET['intUTMZone']) { unset($_COOKIE['intUTMZone']); setcookie("intUTMZone", $_GET['intUTMZone'], time() + $user->strings->intCookieLifeSec); $_COOKIE['intUTMZone'] = $_GET['intUTMZone']; }
	if ($_GET['chrUTMHemisphere']) { unset($_COOKIE['chrUTMHemisphere']); setcookie("chrUTMHemisphere", $_GET['chrUTMHemisphere'], time() + $user->strings->intCookieLifeSec); $_COOKIE['chrUTMHemisphere'] = $_GET['chrUTMHemisphere']; }
	$arrResult = $conversor->VEC2RS2($_GET['strExt'], $_GET['strOriginalFileName'], $_GET['strBaseFileName'], $_GET['intDBFFieldIndex'], $_GET['idDatumIn'], $_GET['intResolution'], $_GET['dblLatSW'], $_GET['dblLatNE'], $_GET['dblLngSW'], $_GET['dblLngNE'], $_GET['intUTMZone'], $_GET['chrUTMHemisphere']);
	echo json_encode($arrResult);
	break;
	
case 'SHP2RS2UD': // Tool Site Conversor SHP to RS2 Update Dimensions
	if ($_GET['intUTMZone']) { unset($_COOKIE['intUTMZone']); setcookie("intUTMZone", $_GET['intUTMZone'], time() + $user->strings->intCookieLifeSec); $_COOKIE['intUTMZone'] = $_GET['intUTMZone']; }
	if ($_GET['chrUTMHemisphere']) { unset($_COOKIE['chrUTMHemisphere']); setcookie("chrUTMHemisphere", $_GET['chrUTMHemisphere'], time() + $user->strings->intCookieLifeSec); $_COOKIE['chrUTMHemisphere'] = $_GET['chrUTMHemisphere']; }
	require 'engine/shapefile/reader/shpParser.php';
	$shp = new shpParser();
	$shp->load($_GET['strSHPFileName']);
	$shpBB = $shp->headerInfo['boundingBox'];
	$gPoint = new gPoint($database, $_GET['idDatumIn']);
	$shpBB = $conversor->arrCheckConvertCoordinatesSystem($shpBB, $gPoint, $_GET['intUTMZone'] . $_GET['chrUTMHemisphere']);
	echo json_encode($shpBB);
	break;
	
// Tool Site Conversor XLS to DBF
case 'XLS2DBF': // Tool Site Conversor SHP to RS2
	$arrResult = $conversor->XLS2DBF($_GET['strFileNameXLS']);
	echo json_encode($arrResult);
	break;

// Tool Importer
case 'II': // Importer Import
	unset($_COOKIE['idDatumIn']); setcookie("idDatumIn", $_GET['idDatumIn'], time() + $user->strings->intCookieLifeSec); $_COOKIE['idDatumIn'] = $_GET['idDatumIn'];
	if ($_GET['intUTMZone']) { unset($_COOKIE['intUTMZone']); setcookie("intUTMZone", $_GET['intUTMZone'], time() + $user->strings->intCookieLifeSec); $_COOKIE['intUTMZone'] = $_GET['intUTMZone']; }
	if ($_GET['chrUTMHemisphere']) { unset($_COOKIE['chrUTMHemisphere']); setcookie("chrUTMHemisphere", $_GET['chrUTMHemisphere'], time() + $user->strings->intCookieLifeSec); $_COOKIE['chrUTMHemisphere'] = $_GET['chrUTMHemisphere']; }
	$strZone = $_GET['intUTMZone'] . $_GET['chrUTMHemisphere'];
	$arrResult = $importer->importDataFromFile($_GET['idProject'], $_GET['idUser'], $_GET['idForm'], $_GET['strFormName'], $_GET['strFileName'], $_GET['idLatitude'], $_GET['idLongitude'], $strZone, $_GET['idDatumIn']);
	echo json_encode($arrResult);
	break;

// Tool Geocoder
case 'GD': // Geocoder Download
	$arrResult = $project->strings->writeStringToFile($_POST['txtInput'], '<br>', '.csv');
	echo json_encode($project->strings->encodeArray($arrResult));
	break;

// Site Tool Censo
case 'SCSV': // Site Censo Search Vars
	$arrResult = $censo->selectTabelaVariaveis(0, $_GET['query']);
	echo json_encode($arrResult);
	break;	
	
case 'SCME': // Site Censo Map Export
	setcookie("dblResolution", $_GET['dblResolution'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblResolution'] = $_GET['dblResolution'];
	setcookie("dblLatSW", $_GET['dblLatSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatSW'] = $_GET['dblLatSW'];
	setcookie("dblLngSW", $_GET['dblLngSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngSW'] = $_GET['dblLngSW'];
	setcookie("dblLatNE", $_GET['dblLatNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatNE'] = $_GET['dblLatNE'];
	setcookie("dblLngNE", $_GET['dblLngNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngNE'] = $_GET['dblLngNE'];
	$return = $censo->mapExport($_GET['strExt'], $_GET['dblLatSW'], $_GET['dblLngSW'], $_GET['dblLatNE'], $_GET['dblLngNE'], $_GET['dblResolution']);
	echo json_encode($censo->strings->encodeArray($return));
	break;
	
case 'SCDE': // Site Censo Data Export
	setcookie("dblLatSW", $_GET['dblLatSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatSW'] = $_GET['dblLatSW'];
	setcookie("dblLngSW", $_GET['dblLngSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngSW'] = $_GET['dblLngSW'];
	setcookie("dblLatNE", $_GET['dblLatNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatNE'] = $_GET['dblLatNE'];
	setcookie("dblLngNE", $_GET['dblLngNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngNE'] = $_GET['dblLngNE'];
	$return = $censo->dataExport($_GET['strExt'], $_GET['dblLatSW'], $_GET['dblLngSW'], $_GET['dblLatNE'], $_GET['dblLngNE'], $_GET['intMode'], $_POST['strVars']);
	echo json_encode($censo->strings->encodeArray($return));
	break;
	
case 'SCDEC': // Site Censo Data Export Class
	setcookie("dblResolution", $_GET['dblResolution'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblResolution'] = $_GET['dblResolution'];
	setcookie("dblLatSW", $_GET['dblLatSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatSW'] = $_GET['dblLatSW'];
	setcookie("dblLngSW", $_GET['dblLngSW'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngSW'] = $_GET['dblLngSW'];
	setcookie("dblLatNE", $_GET['dblLatNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLatNE'] = $_GET['dblLatNE'];
	setcookie("dblLngNE", $_GET['dblLngNE'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['dblLngNE'] = $_GET['dblLngNE'];
	setcookie("intClasses", $_GET['intClasses'], time() + $censo->strings->intCookieLifeSec); $_COOKIE['intClasses'] = $_GET['intClasses'];
	$return = $censo->mapExportClass($_GET['dblLatSW'], $_GET['dblLngSW'], $_GET['dblLatNE'], $_GET['dblLngNE'], $_GET['dblResolution'], $_GET['intClasses'], $_GET['strVars']);
	echo json_encode($censo->strings->encodeArray($return));
	break;

case 'CIIMS': // Censo Importer Import Malha Setores<br />
	$return = $censo->importMalhaSetores($_GET['strUF']);
	echo json_encode($censo->strings->encodeArray($return));
	break;
	
case 'CIITC': // Censo Importer Import Tabelas CSV
	$return = $censo->importTabelaCSV($_GET['idTabela'], $_GET['strUF']);
	echo json_encode($censo->strings->encodeArray($return));
	break;
	
case 'CICLT': // Censo Importer Clear Table
	$arrTabelas = json_decode($_POST['strTabelas'], true);
	foreach ($arrTabelas as $arrTabela) {
		$censo->clearTabela($arrTabela['idTabela']);
	}
	echo true;
	break;
	
case 'CICLM': // Censo Importer Clear Malha
	$censo->clearMalhaSetores();
	echo true;
	break;

// User
case 'US': // User Select
	$arrResult = $user->selectUsers($_GET['idProject'], $_GET['idUser'], $_GET['strSearch']);
	echo json_encode($user->strings->encodeArray($arrResult));
	break;

case 'UI': // User Insert
	$arrResult = $user->insertUser(
		$_GET['idProject'],
		$_GET['idUserLevel'], 
		$_GET['blnActive'], 
		$_GET['strName'], 
		$_GET['strEmail'],
		$_GET['strPassword'],
		$_GET['dblLatitude'],
		$_GET['dblLongitude'],
		$_GET['strSkypeID'],
		$_GET['blnSendNotificationMail']
	);
	echo json_encode($arrResult);
	break;
	
case 'UU': // User Update
	$arrResult = $user->updateUser(
		$_GET['idUser'], 
		$_GET['strIdProjectWorkgroups'], 
		$_GET['idUserLevel'], 
		$_GET['blnActive'], 
		$_GET['strName'],
		$_GET['strEmail'],
		$_GET['strPassword'],
		$_GET['dblLatitude'],
		$_GET['dblLongitude'],
		$_GET['strSkypeID'],
		$_GET['blnSendNotificationMail'],
		false
	);
	echo json_encode($arrResult);
	break;

case 'UD': // User Delete
	$arrResult = $user->deleteUser($_GET['idUser']);
	echo $arrResult;
	break;

case 'UFP': // User Forgot password
	$intResult = $user->forgotPassword($_GET['idProject'], $_GET['strEmail']);
	if ($intResult == $user->USER_DONT_EXISTS) {			// User not found in database
		$strResult = $_SESSION['strLoginForgotPassworUserDontExists'];
	} else if ($intResult == $user->USER_COULD_NOT_SEND_MAIL) {	// Couldn't send email
		$strResult = $_SESSION['strLoginForgotPasswordCouldNotSendMail'];
	} else if ($intResult == 1) { 									// Success - New password sent to email
		$strResult = $_SESSION['strLoginForgotPasswordSuccess'] . ' ' . $_GET['strEmail'];
	}
	echo utf8_encode($strResult);
	break;
	
case 'UL': // User Login
	$arrResult = $user->login($_GET['idProject'], $_GET['strEmail'], md5($_GET['strPassword']));
	echo $arrResult;
	break;

case 'UA': // Users Action
	$arrIDs = explode(',', $_GET['strIDs']);
	$intResult = 0;
	foreach ($arrIDs as $idUser) {
		if (! is_numeric($idUser)) continue;
		if ($_GET['intValue'] == 2) {
			if ($idUser != $_GET['idUserCreator']) {
				$user->deleteUser($idUser);
			}
		} else if ($_GET['intValue'] == 3) {
			$intResult += $formrecord->updateUserCreator($idUser, $_GET['idUserTo']);
		} else if ($_GET['intValue'] == 5) {
			if ($idUser == $_GET['idUser']) continue;
			if ($idUser != $_GET['idUserCreator']) {
				$user->updateUserLevel($idUser, $_GET['idUsersLevel']);
			}
		}
	}
	echo $intResult;
	break;

case 'UUA': // User Update Active
	$arrResult = $user->updateUserActive($_GET['idUser'], $_GET['blnActive'], true);
	echo $arrResult;
	break;
	
// Project
case 'PS': // Projects Select
	$arrProjects = $project->selectProjects($_GET['idProject']);
	foreach ($arrProjects as $i => $arrProject) {
		$arrProjects[$i]['intNumRecords'] = $formrecord->intCountFormRecords($arrProjects[$i]['idProject']);
	}
	echo json_encode($project->strings->encodeArray($arrProjects));
	break;
	
case 'PSS': // Projects Select Site
	$arrProjects = $project->selectProjects($_GET['idProject'], '', 0, 0, 0, true);
	echo json_encode($project->strings->encodeArray($arrProjects));
	break;

case 'PU': // Project Update
	$arrResult = $project->updateProject(
		$_GET['idProject'], 
		$_GET['strAlias'],
		$_GET['strName'],
		$_GET['txtDescription'],
		$_GET['strAddress'],
		$_GET['dblLatitude'],
		$_GET['dblLongitude'],
		$_GET['strSiteURL'],
		$_GET['strGoogleAnalyticsID'],
		$_GET['strSkypeID'],
		$_GET['blnAllowAllView'],
		$_GET['blnAllowJoin'],
		$_GET['blnAllowJoinAsLevel3'],
		$_GET['idProjectUserViewScope'],
		$_GET['idProjectUserEditScope']
	);
	echo json_encode($arrResult);
	break;
	
case 'PUT': // Project Update Theme
	$arrResult = $project->updateProperty(
		$_GET['idProject'],
		'idCSSTheme',
		$_GET['idCSSTheme']
	);
	echo json_encode($arrResult);
	break;
	
case 'PUAS': // Project Update Active State
	$arrResult = $project->updateProperty(
		$_GET['idProject'],
		'blnActive',
		$_GET['blnActive']
	);
	echo json_encode($arrResult);
	break;
	
case 'PFU': // Project File Upload
	$arrResult = $project->updateFile($_GET['idProject'], $_GET['strFileName'],  $_GET['strField']);
	echo json_encode($arrResult);
	break;

case 'PD': // Project Delete
	$result = $project->deleteProject($_GET['idProject']);
	echo $result;
	break;

// Project Workgroup
case 'PWS': // Project Workgroup Select
	$arrResult = $user->selectProjectWorkgroups($_GET['idProject']);
	echo json_encode($project->strings->encodeArray($arrResult));
	break;

case 'PWI': // Project Workgroup Insert
	$arrResult = $user->insertProjectWorkgroup(
		$_GET['idProject'],
		$_GET['strWorkgroup']
	);
	echo json_encode($arrResult);
	break;
	
case 'PWU': // Project Workgroup Update
	$arrResult = $user->updateProjectWorkgroup(
		$_GET['idProjectWorkgroup'], 
		$_GET['strWorkgroup']
	);
	echo json_encode($arrResult);
	break;

case 'PWD': // Project Workgroup Delete
	$arrResult = $user->deleteProjectWorkgroup(0, $_GET['idProjectWorkgroup']);
	echo $arrResult;
	break;

// Events
case 'UES': // Form Select
	$arrResult = $database->selectUserEvents($_GET['idProject'], $_GET['idUser'], $_GET['idEventType'], $_GET['dtDateFrom'], $_GET['dtDateTo'], 500);
	echo json_encode($user->strings->encodeArray($arrResult));
	break;


// Form
case 'FS': // Form Select
	$arrResult = $form->selectForms($_GET['idProject'], $_GET['idForm']);
	echo json_encode($form->strings->encodeArray($arrResult));
	break;
	
case 'FI': // Form Insert
	$arrResult = $form->insertForm($_GET['idUser'], $_GET['idProject'], $_GET['strName']);
	echo json_encode($arrResult);
	break;
	
case 'FD': // Form Delete
	$arrResult = $form->deleteForm($_GET['idUser'], $_GET['idForm']);
	echo $arrResult;
	break;
	
case 'FDR': // Form Delete Records
	$arrResult = $form->deleteForm($_GET['idUser'], $_GET['idForm'], true);
	echo $arrResult;
	break;

case 'FUP': // Form Update Property
	$arrResult = $form->updateFormProperty($_GET['idForm'], $_GET['strField'], $_GET['strValue']);
	echo $arrResult;
	break;
	
case 'FUMG': // Form Update Marker Google Image
	if ($_GET['idProject'] > 0) {
		if (! $_GET['idMarker']) {
			$arrMarker = $form->uploadFileMarker($_GET['idProject'], $_GET['strFileName'], true);
			$_GET['idMarker'] = $arrMarker['idMarker'];
			echo $arrMarker['strMarkerFullPath'];
		}
	}
	if ($_GET['idForm'] > 0) {
		$form->updateFormProperty($_GET['idForm'], 'idMarker', $_GET['idMarker']);
	}
	if ($_GET['idUserFilter'] > 0) {
		$user->updateUserFilterMarker($_GET['idUserFilter'], $_GET['idMarker']);
	}
	break;

// Form Fields 
case 'FFS': // Form Fields Select
	setcookie("idForm", strtoupper($_GET['idForm']), time() + $form->strings->intCookieLifeSec); $_COOKIE['idForm'] = strtoupper($_GET['idForm']);
	$arrForm = $form->selectForms(0, $_GET['idForm']);
	$arrFields = $form->selectFormFields($_GET['idForm'], $_GET['idFormField']);
	$arrResult = array();
	$arrResult['arrFields'] = $arrFields;
	$arrResult['arrForm'] = $arrForm[0];
	echo json_encode($form->strings->encodeArray($arrResult));
	break;
	
case 'FFI': // Form Field Insert
	$arrResult = $form->insertFormField($_GET['idForm']);
	echo json_encode($form->strings->encodeArray($arrResult));
	break;	

case 'FFU': // Form Field Update
	$arrResult = $form->updateFormField($_GET['idFormField'], $_GET['strName'], $_GET['idFormFieldType'], $_GET['strTip']);
	echo $arrResult;
	break;
	
case 'FFD': // Form Field Delete
	$arrResult = $form->deleteFormField($_GET['idFormField']);
	echo $arrResult;
	break;
	
case 'FFR': // Form Field Reorder
	$arrResult = $form->reorderFormFields($_GET['strIds']);
	echo $arrResult;
	break;

// Marker
case 'MS': // Marker Select
	$arrResult = $form->selectMarkers($_GET['idMarker'], $_GET['idProject']);
	echo json_encode($form->strings->encodeArray($arrResult));
	break;
	
case 'MD': // Marker Delete
	$arrResult = $form->deleteMarker($_GET['idMarker']);
	echo $arrResult;
	break;
	
case 'MUF': // Marker Upload File
	$arrResult = $form->uploadFileMarker($_GET['idProject'], $_GET['strFileName']);
	echo $arrResult;
	break;
	
// Form Field Alternatives
case 'FFAS': // Form Field Alternatives Select
	$arrResult = $form->selectFieldAlternatives($_GET['idFormField']);
	echo json_encode($form->strings->encodeArray($arrResult));
	break;
	
case 'FFAI': // Form Field Alternatives Insert
	$arrResult = $form->insertFieldAlternative($_GET['idFormField'], $_GET['strAlternative'], $_GET['blnPublic']);
	echo json_encode($form->strings->encodeArray($arrResult));
	break;
	
case 'FFAIB': // Form Field Alternatives Batch Insert
	$result = $form->insertFieldAlternativeBatch($_GET['idFormField'], $_GET['strAlternatives']);
	echo $result;
	break;
	
case 'FFAU': // Form Field Alternatives Update
	$arrResult = $form->updateFieldAlternative($_GET['idFormFieldAlternative'], $_GET['strAlternative']);
	echo $arrResult;
	break;
	
case 'FFAD': // Form Field Alternatives Delete
	$arrResult = $form->deleteFieldAlternatives($_GET['idFormField'], $_GET['idFormFieldAlternative']);
	echo $arrResult;
	break;
	
// Home
case 'HAAR': // Abort Ajax Requests
	$database->abortQuery();
	break;

case 'HQRC': // QR Code
	include_once 'engine/qrcode/qrlib.php';
	$arrResult = array();
	$arrResult['strFilePathTMP'] = $strings->strSiteTmpFileFolder . '/' . $_GET['strLabel'] . '.png';
	QRcode::png($_GET['strURL'], $arrResult['strFilePathTMP'], 8, 8, true);
	// Add Text on Image Center
	list($intW, $intH) = getimagesize($arrResult['strFilePathTMP']);
	$imgQRCode = imagecreatefrompng ($arrResult['strFilePathTMP']);
	$imgColor	= ImageColorAllocate($imgQRCode, 255, 0, 0);
	$intFontSize = round($intH*0.05);
	$strFontName = 'fonts/Oswald-Bold.ttf';
	$arrLabeDim = imagettfbbox ($intFontSize, 0, $strFontName, $_GET['strLabel']);
	$intLabelW = abs($arrLabeDim[4] - $arrLabeDim[0]);
	$intLabelH = abs($arrLabeDim[5] - $arrLabeDim[1]);
	imagefttext($imgQRCode, $intFontSize, 0, round($intW/2 - $intLabelW/2), round($intH/2 + $intLabelH/2), $imgColor, $strFontName, $_GET['strLabel']);
	imagepng($imgQRCode, $arrResult['strFilePathTMP']);
	// Finish Adding Text
	echo json_encode($strings->encodeArray($arrResult));
	break;

// Map Records
case 'HMRS': // Map Records Select
	// Form Records
	set_time_limit(60);
	$arrCoordinates = array();
	$arrCoordinates[0]['dblLat'] = $_GET['dblLatNE'];
	$arrCoordinates[0]['dblLng'] = $_GET['dblLngNE'];
	$arrCoordinates[1]['dblLat'] = $_GET['dblLatSW'];
	$arrCoordinates[1]['dblLng'] = $_GET['dblLngSW'];
	// Google Maps Zoom 0 (Minimum) 20 (Maximum)
	// Limit result by Zoom.  The more close, more records
	//$intLimit = ($_GET['intZoom']*100);
	$intLimit = ($_GET['intZoom'] <= 10 ? 50 : 99999);
	$strOrderBy = ($_GET['intZoom'] <= 10 ? "RAND()" : "");
	$arrResult = $formrecord->selectFormRecordsByPolygon('R', $_GET['idProject'], $arrCoordinates, $_GET['strJSONScope'], '', $intLimit); // Rectangle
	// Updating BoundBox for Next Load
	setcookie("blnTrafficLayer", $_GET['blnTrafficLayer'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['blnTrafficLayer'] = $_GET['blnTrafficLayer'];
	setcookie("blnFullscreen", $_GET['blnFullscreen'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['blnFullscreen'] = $_GET['blnFullscreen'];
	setcookie("intMapPolygonsOpacity", $_GET['intMapPolygonsOpacity'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intMapPolygonsOpacity'] = $_GET['intMapPolygonsOpacity'];
	setcookie("strMapTypeId", strtoupper($_GET['strMapTypeId']), time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['strMapTypeId'] = strtoupper($_GET['strMapTypeId']);
	setcookie("dblLatC", $_GET['dblLatC'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['dblLatC'] = $_GET['dblLatC'];
	setcookie("dblLngC", $_GET['dblLngC'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['dblLngC'] = $_GET['dblLngC'];
	setcookie("intZoom", $_GET['intZoom'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intZoom'] = $_GET['intZoom'];
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;

case 'HMPAR': // Map Pan to All Records
	$arrResult = $formrecord->selectProjectBoundingBox($_GET['idProject'], $_GET['strJSONScope']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'HMSR': // Map Select By Radius
	$arrCoordinates = array();
	$arrCoordinates[0]['dblLat'] = $_GET['dblLat'];
	$arrCoordinates[0]['dblLng'] = $_GET['dblLng'];
	$arrResult = $formrecord->selectFormRecordsByPolygon('C', $_GET['idProject'], $arrCoordinates, $_GET['strJSONScope'], $_GET['dblRadius']); // Circle
	setcookie("dblRadius", $_GET['dblRadius'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['dblRadius'] = $_GET['dblRadius'];
	setcookie("intSnapNeighborsVertexsMaxDistance", $_GET['intSnapNeighborsVertexsMaxDistance'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intSnapNeighborsVertexsMaxDistance'] = $_GET['intSnapNeighborsVertexsMaxDistance'];
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'HMSP': // Map Select By Polygon
	$arrLat = explode(',', $_GET['strLats']);
	$arrLng = explode(',', $_GET['strLngs']);
	$arrCoordinates = array();
	for ($i=0; $i < count($arrLat); $i++) {
		$arrCoordinates[$i]['dblLat'] = $arrLat[$i];
		$arrCoordinates[$i]['dblLng'] = $arrLng[$i];
	}
	$arrResult = $formrecord->selectFormRecordsByPolygon('P', $_GET['idProject'], $arrCoordinates, $_GET['strJSONScope']); // Polygon
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;

case 'HRLI': // Record Load Information
	$arrFormRecord = $formrecord->selectFormRecords(0, 0, 0, $_GET['idFormRecord']);
	// Alerady Deleted Record
	if (! count($arrFormRecord)) {
		$arrResult = array();
		$arrResult['blnExists'] = false;
	} else {
		$database->insertEvent(28, $_GET['idUser'], $_GET['idFormRecord']);
		$arrResult = $formrecord->arrPrintFormRecordData($arrFormRecord[0], 1);
		$arrResult['blnExists'] = true;
	}
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'HRCC': // Record Change Color
	$formrecord->updateFormRecordProperty($_GET['idFormRecord'], 'strCustomMarkerRGBColor', $_GET['strCustomMarkerRGBColor']);
	break;
	
case 'HRD': // Record Delete
	$formrecord->deleteFormRecord($_GET['idFormRecord']);
	break;
		
case 'HMTS': // Home Map Toponymys Select
	setcookie("blnToponymyShow", 1, time() + $toponymy->strings->intCookieLifeSec); $_COOKIE['blnToponymyShow'] = 1;
	$arrResult = $toponymy->selectToponymys($_GET['idProject'], $_GET['idUser']);
	echo json_encode($toponymy->strings->encodeArray($arrResult));
	break;
	
case 'HMTH': // Home Map Toponymys Hide
	setcookie("blnToponymyShow", 0, time() + $toponymy->strings->intCookieLifeSec); $_COOKIE['blnToponymyShow'] = 0;	
	break;

case 'HMTI': // Home Map Toponymy Insert
	$arrResult = $toponymy->insertToponymy($_GET['idUser'], $_GET['dblLatitude'], $_GET['dblLongitude'], $_GET['strToponymy']);
	echo json_encode($toponymy->strings->encodeArray($arrResult));
	break;
	
case 'HMTU': // Home Map Toponymy Update
	$toponymy->updateToponymy($_GET['idToponymy'], $_GET['dblLatitude'], $_GET['dblLongitude'], $_GET['strToponymy']);
	$arrResult = array();
	$arrResult['idToponymy'] = $_GET['idToponymy'];
	echo json_encode($toponymy->strings->encodeArray($arrResult));
	break;
	
case 'HMTD': // Home Map Toponymy Delete
	echo $toponymy->deleteToponymy(0, $_GET['idToponymy']);
	break;
	
case 'HUPS': // Home User Positions Select
	$arrResult = $user->selectUserPositions($_GET['idProject'], $_GET['idUser'], $_GET['dtDate'], $user->intUserPositionMinDistanceMts);
	echo json_encode($user->strings->encodeArray($arrResult));
	break;
	
case 'HUPD': // Home User Positions Delete
	$arrResult = $user->deleteUserPositions($_GET['idUser'], $_GET['dtDate']);
	echo $arrResult;
	break;
	
case 'HMG': // Map Export
	$arrResult = $map->generateMap($_GET['idProject'], $_GET['strExtension'], $_POST['strJSONFormRecords'], $_GET['intResolution'], $_GET['dblLatSW'], $_GET['dblLngSW'], $_GET['dblLatNE'], $_GET['dblLngNE'], $_GET['blnFinishingGoogleMaps'], $_GET['blnFinishingLegends'], $_GET['blnFinishingGrid'], $_GET['idFinishingMaskFormRecord'], $_GET['blnRS2LegendID'], $_GET['intMapPolygonsOpacity'], $_GET['intBufferRadius'], $_GET['idBufferForm'], $_GET['strMapType'], $_GET['strJSONScope'], $_GET['strEmail']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'HRG': // Report Generate
	$arrResult = $report->generateReport($_GET['idProject'], $_GET['strExtension'], $_POST['strJSONFormRecords'], $_GET['blnAllRecords'], false, false, $_GET['dblLatC'], $_GET['dblLngC'], $_GET['intMapPolygonsOpacity'], $_GET['strMapType'], '', $_GET['strJSONScope'], $_GET['strEmail']);
	break;

case 'FRFFS': // Filter Record Form Field Suggestions
	$arrResult = array();
	$arrResult['query'] = $_GET['query'];
	$arrValues = $formrecord->selectSuggestedFormFieldValues($_GET['idFormField'], $_GET['query']);
	$arrResult['suggestions'] = $arrValues;
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'HUFS': // Home User Filters Select
	$arrUserFilters = $user->selectUserFilters($_GET['idUserFilter'], $_GET['idUser']);
	// Create a first filter if there is no filter
	if (count($arrUserFilters) == 0) {
		$user->insertUserFilter($_GET['idUser'], $_SESSION['strHomeFilterNameDefault'] . ' 1');
		$arrUserFilters = $user->selectUserFilters($_GET['idUserFilter'], $_GET['idUser']);
	}
	echo json_encode($user->strings->encodeArray($arrUserFilters));
	break;

case 'HUFDM': // Home User Filter Set Default Marker
	$result = $user->updateUserFilterSetDefaultMarker($_GET['idUserFilter']);
	echo json_encode($user->strings->encodeArray($result));
	break;


case 'HUFI': // Home User Filter Insert
	$result = $user->insertUserFilter($_GET['idUser'], $_GET['strName']);
	echo json_encode($user->strings->encodeArray($result));
	break;

case 'HUFU': // Home User Filter Update
	$result = $user->updateUserFilter($_GET['idUserFilter'], $_GET['strName']);
	echo json_encode($user->strings->encodeArray($result));
	break;

case 'HUFD': // Home User Filter Delete
	echo $user->deleteUserFilter($_GET['idUserFilter']);
	break;

case 'HUF': // Home User Filter
	set_time_limit(90);
	$arrResult = $formrecord->selectFormRecordsByUserFilter($_GET['idUserFilter'], $_GET['strModeANDOR'], $_GET['strJSONScope']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;

case 'HUFCS': // Home User Filter Clauses Select
	$arrUserFilterClauses = $user->selectUserFilterClauses($_GET['idUserFilter']);
	echo json_encode($user->strings->encodeArray($arrUserFilterClauses));
	break;

case 'HUFCI': // Home User Filter Clause Insert
	$result = $user->insertUserFilterClause($_GET['idUserFilter'], $_GET['idFormField'], $_GET['intOperador'], $_GET['strValue']);
	echo json_encode($user->strings->encodeArray($result));
	break;

case 'HUFCD': // Home User Filter Clause Delete
	echo $user->deleteUserFilterClauses(0, $_GET['idUserFilterClause']);
	break;
	
case 'HSRA': // Home Selected Records Action
	$result = $formrecord->updateFormRecords($_GET['strAction'], $_POST['strJSONFormRecords'], $_GET['strNewValue']);
	echo json_encode($result);
	break;

// Home Heatmap
case 'HHMS': // Home Heatmap Select
	setcookie("intHeatmapRadius", strtoupper($_GET['intHeatmapRadius']), time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intHeatmapRadius'] = strtoupper($_GET['intHeatmapRadius']);
	$result = $formrecord->selectFormRecordsHeatmap($_GET['idProject'], $_GET['strJSONScope']);
	echo json_encode($result);
	break;
	
// Home Image Overlay
case 'HIOS': // Home Image Overlay Select
	$arrUserImageOverlays = $user->selectUserImageOverlays($_GET['idUserImageOverlay'], $_GET['idUser']);
	echo json_encode($user->strings->encodeArray($arrUserImageOverlays));
	break;
	
case 'HIOFU': // Home Image Overlay File Upload
	$result = $user->insertUserImageOverlay($_GET['idProject'], $_GET['idUser'], $_GET['dblLatSW'], $_GET['dblLongSW'], $_GET['dblLatNE'], $_GET['dblLongNE'], $_GET['strFileName']);
	echo json_encode($user->strings->encodeArray($result));
	break;

case 'HIOU': // Home Image Overlay Update
	$result = $user->updateUserImageOverlay($_GET['idUserImageOverlay'], $_GET['dblLatSW'], $_GET['dblLongSW'], $_GET['dblLatNE'], $_GET['dblLongNE']);
	echo json_encode($user->strings->encodeArray($result));
	break;

case 'HIOD': // Home Image Overlay Delete
	echo $user->deleteUserImageOverlay($_GET['idUserImageOverlay']);
	echo $result;
	break;
	
case 'HFMS': // Home Flush Map Select
	$result = $formrecord->selectFormRecordFlushMap($_GET['idProject'], $_GET['strJSONScope'], $_GET['idFormFieldID'], $_GET['idFormFieldIDTo']);
	echo json_encode($formrecord->strings->encodeArray($result));
	break;
	
case 'HBFS': // Home Buffer Select
	setcookie("intBufferRadius", strtoupper($_GET['intBufferRadius']), time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intBufferRadius'] = strtoupper($_GET['intBufferRadius']);
	$result = $formrecord->selectFormRecordBuffer($_GET['idProject'], $_GET['strJSONScope'], $_GET['idForm'], $_GET['idFormField']);
	echo json_encode($formrecord->strings->encodeArray($result));
	break;
	
case 'HBCA': // Home Buffer Cover Area Report
	$result = $report->bufferCoverArea($_GET['idProject'], $_GET['strJSONScope'], $_GET['idForm'], $_GET['intRadiusMts'], $_GET['idFormCoverBy'], $_GET['strEmail']);
	echo json_encode($formrecord->strings->encodeArray($result));
	break;
	
// Tree View Load
case 'HTVL':
	// Form Records
	$arrResult = $formrecord->strLoadTreeViewItemsXML($_GET['idProject'], $_GET['strJSONScope'], 200);
	//$strXML .= $toponymy->strLoadTreeViewToponymyXML($_GET['idProject']);
	$arrResult['strXML'] = '<?xml version="1.0" encoding="iso-8859-1"?><tree id="0">' . $arrResult['strXML'] . '</tree>';
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
// Record Edit
case 'REFS': // Record Edit Files Select
	$arrResult = $formrecord->selectFormRecordFiles($_GET['idProject'], $_GET['idFormRecord']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'REU': // Record Edit Update
	setcookie("intBufferRadius", strtoupper($_GET['intBufferRadius']), time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['intBufferRadius'] = strtoupper($_GET['intBufferRadius']);
	$arrResult = $formrecord->insertUpdateFormRecord($_GET['idUser'], $_GET['idForm'], $_GET['idFormRecord'], $_POST['strJSONData']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;

case 'REFR': // Record Edit File Reorder
	$arrResult = $formrecord->reorderFormRecordFiles($_GET['strIds']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'REFU': // Record Edit File Upload
	$arrResult = $formrecord->insertFormRecordFile($_GET['idProject'], $_GET['idFormRecord'], $_GET['strFileName'], basename($_GET['strFileName']));
	echo json_encode($arrResult);
	break;

case 'REFSV': // Record Edit File Street View Save
	$arrResult = $formrecord->insertFormRecordFileStreetView($_GET['idProject'], $_GET['idFormRecord'], $_GET['strFileName']);
	echo json_encode($arrResult);
	break;
	
case 'REFUI': // Record Edit File URL Insert
	$arrResult = $formrecord->insertFormRecordFileURL($_GET['idProject'], $_GET['idFormRecord'], $_GET['strURL']);
	echo json_encode($arrResult);
	break;
	
case 'REFD': // Record Edit File Delete
	$arrResult = $formrecord->deleteFormRecordFile($_GET['idProject'], $_GET['idFormRecordFile']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
case 'REFUD': // Record Edit File Update Description
	$arrResult = $formrecord->updateDescriptionFormRecordFile($_GET['idFormRecordFile'], $_GET['strDescription']);
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
	
// admStats
case 'STD': // Stats Download
	$return = $stats->downloadStats($_GET['idProject']);
	echo $return;
	break;
case 'SDL': // Stats Data Load
	setcookie("dtDateFrom", strtoupper($_GET['dtDateFrom']), time() + $stats->strings->intCookieLifeSec); $_COOKIE['dtDateFrom'] = strtoupper($_GET['dtDateFrom']);
	setcookie("dtDateTo", strtoupper($_GET['dtDateTo']), time() + $stats->strings->intCookieLifeSec); $_COOKIE['dtDateTo'] = strtoupper($_GET['dtDateTo']);
	$arrResult = $stats->chartLoadData($_GET['idChart'], $_GET['idProject'], $_GET['dtDateFrom'], $_GET['dtDateTo']);
	echo json_encode($stats->strings->encodeArray($arrResult));
	break;

// User Alerts
case 'UAS': // User Alert Select
	$return = $alert->selectUserAlerts($_GET['idUserAlert'], $_GET['idUser']);
	echo json_encode($alert->strings->encodeArray($return));
	break;
	
case 'UAD': // Delete User Alert
	$return = $alert->deleteUserAlert($_GET['idUserAlert'], $_GET['idUser']);
	echo json_encode($return);
	break;
	
case 'UAI': // User Alert Insert
	$return = $alert->insertUserAlert($_GET['idUser'], $_GET['idForm'], $_GET['strName'], $_GET['blnOnRecordCreate'], $_GET['blnOnRecordUpdate'], $_GET['blnOnRecordDelete'], $_GET['strActionEmailTo'], $_GET['intNotifyAfterDaysFromEvent']);
	echo json_encode($return);
	break;
	
case 'UAU': // User Alert Update
	$return = $alert->updateUserAlert($_GET['idUserAlert'], $_GET['strName'], $_GET['blnOnRecordCreate'], $_GET['blnOnRecordUpdate'], $_GET['blnOnRecordDelete'], $_GET['strActionEmailTo'], $_GET['intNotifyAfterDaysFromEvent']);
	echo json_encode($return);
	break;

case 'UAUA': // User Alert Update Active
	$return = $alert->updateUserAlertActive($_GET['idUserAlert'], $_GET['blnActive']);
	echo json_encode($return);
	break;
	
case 'UACS': // User Alert Clauses Load
	$return = $alert->selectUserAlertClauses($_GET['idUserAlert']);
	echo json_encode($return);
	break;
	
case 'UACI': // User Alert Clause Insert
	// If Inserting Clause but haven't created Alert yet
	if ($_GET['idUserAlert'] < 0) {
		$return = $alert->insertUserAlert($_GET['idUser'], $_GET['idForm'], $_GET['strName']);
		$_GET['idUserAlert'] = $return['idUserAlert'];
	}
	$return = $alert->insertUserAlertClause($_GET['idUserAlert'], $_GET['idFormField'], $_GET['strOperador'], $_GET['strValue']);
	$return['idUserAlert'] = $_GET['idUserAlert'];
	echo json_encode($return);
	break;

case 'UACD': // User Alert Clause Delete
	$return = $alert->deleteUserAlertClause($_GET['idUserAlertClause'], $_GET['idUserAlert']);
	echo json_encode($return);
	break;

case 'UAED': // User Alert Events Delete
	$return = $alert->deleteUserAlertEvent($_GET['idUser']);
	echo json_encode($return);
	break;

// Support Calls
case 'SS': // Supports Select
	$return = $support->selectSupports($_GET['idSupport']);
	// if $_GET['idSupport'] mark as read
	if ($_GET['idSupport'] > 0) {
		$support->markSupportResponseRead($_GET['idSupport'], $_GET['blnFromSupport']);
	}
	echo json_encode($support->strings->encodeArray($return));
	break;
	
case 'SD': // Delete Support
	$return = $support->deleteSupport($_GET['idSupport']);
	echo json_encode($return);
	break;
	
case 'SRI': // Support Response Insert
	$return = $support->insertSupportResponse($_GET['idSupport'], $_GET['txtMessage'], $_GET['blnFromSupport']);
	echo json_encode($return);
	break;

// Timeline
case 'TUPAU': // User Position Active Update
	//unset($_COOKIE['blnUserPosition']); setcookie("blnUserPosition", $_GET['blnUserPosition'], time() + $user->strings->intCookieLifeSec); $_COOKIE['blnUserPosition'] = $_GET['blnUserPosition'];
	$_SESSION['blnUserPosition'] = $_GET['blnUserPosition'];
	break;
	
case 'TUPI': // User Position Insert
	$user->insertUserPosition($_GET['idUser'], $_GET['dblLatitude'], $_GET['dblLongitude']);
	break;
	
case 'TRL': // Timeline Records Load
	$arrResult = array();
	$_SESSION['blnShowStaticMap'] = $_GET['blnShowStaticMap'];
	$_SESSION['blnShowMyRecords'] = $_GET['blnShowMyRecords'];
	//unset($_COOKIE['blnShowStaticMap']); setcookie("blnShowStaticMap", $_GET['blnShowStaticMap'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['blnShowStaticMap'] = $_GET['blnShowStaticMap'];
	//unset($_COOKIE['blnShowMyRecords']); setcookie("blnShowMyRecords", $_GET['blnShowMyRecords'], time() + $formrecord->strings->intCookieLifeSec); $_COOKIE['blnShowMyRecords'] = $_GET['blnShowMyRecords'];
	$arrFormRecords = $formrecord->selectFormRecordsTimeline($_GET['idProject'], $_GET['idUser'], $_GET['strIDForms'], $_GET['strSearch'], $_GET['dblLat'], $_GET['dblLng'], $_GET['strJSONScope'], $_GET['intFrom'], $_GET['intLimit']);
	foreach ($arrFormRecords as $arrFormRecord) {
		$arrFormRecordData = $formrecord->arrPrintFormRecordData($arrFormRecord, 3);
		if ($_GET['blnShowStaticMap']) {
			$arrFormRecordData['strInfo'] = '<td style="text-align:center"><a href="' . $arrFormRecordData['strMapLinkURL'] . '"><img src="' . $arrFormRecordData['strStaticMap'] . '" style="width:100%;"></a></td>' . $arrFormRecordData['strInfo'];
		}
		$arrResult[] = $arrFormRecordData['strInfo'];
	}
	echo json_encode($formrecord->strings->encodeArray($arrResult));
	break;
}
?>