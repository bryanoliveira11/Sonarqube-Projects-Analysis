<?	if (($arrProject['blnAllowAllView']) || ($_SESSION['idUser'] > 0)) { ?>
<?
	if ($arrUser['idUser'] > 0) {
		$database->insertEvent(19, $arrUser['idUser']);
		$strJSONScope = json_encode($user->arrUserViewScope($arrUser, $arrProject['idProjectUserViewScope']));
	} else {
		$database->insertEvent(19, $arrProject['idUserCreator']);
		$arrUser['idUser'] = -1;
	}
	
	$arrUserFilters = $user->selectUserFilters(0, $arrUser['idUser'] ? $arrUser['idUser'] : $arrProject['idProject']);
?>
<style>
	html {overflow:hidden;}
	.title { text-align:center;font-weight:bold;padding:5px;/*background-color:#F9F9F9;*/border:solid 1px #E8E8E8;list-style:none;min-height:0px;border-radius:0px;margin:0px !important;}
	.panel {color:#000000;display:none;left:20%; /*position:fixed;*/top:60%; min-height:100px;width:70%;height:30%;overflow:hidden;z-index:2;background-color:#FFFFFF;border:solid 1px #888888; position:absolute;padding:0px !important;}
	.sidePanel { display:none;height:100%;overflow:hidden;position:absolute;left:0px;top:0px;width:10%;min-width:250px;z-index:999;background-color:#FFFFFF;border-right:solid 1px #888888;padding:0px !important;margin:0px !important;}
	.liSelected { font-weight:bold;background-color:#F5F5F5}
	.ui-resizable-e {width: 9px;}
	.standartTreeRow {white-space:normal;word-break: break-word;text-align:left} /* Tree View */
	.btn-disabled { pointer-events: none;cursor:not-allowed;background-color:#e6e6e6;background-image:none;opacity:0.65;filter: alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow: none;}
	#mapcanvas:focus,#divInfo:focus {outline: none;}
	#tblInfoContent td{padding:2px;}
	.standartTreeImage{max-height:18px;}
</style>
<!-- OverlappingMarkerSpiderfier -->
<script type="text/javascript" src="js/overlappingmarkerspiderfier/oms.min.js"></script>
<!-- Marker with label -->
<script type="text/javascript" src="js/markerwithlabel.js"></script>
<!-- Tree View -->
<link rel="stylesheet" type="text/css" href="js/treeview/dhtmlxtree.css">
<script type="text/javascript" src="js/treeview/dhtmlxcommon.js"></script>
<script type="text/javascript" src="js/treeview/dhtmlxtree.js"></script>
<script type="text/javascript" src="js/treeview/dhtmlxtree_attrs.js"></script>
<script type="text/javascript" src="js/treeview/ext/dhtmlxtree_start.js"></script>
<input class="color {pickerOnfocus:false, pickerClosable:true}" style="position:absolute;visibility:hidden;left:45%;top:5px;" name="strRGBSelected" id="strRGBSelected" onChange="mapSelectedRecordsAction('CC');" value="<? echo $strings->strSiteBaseColor; ?>">
<input class="color {pickerOnfocus:false, pickerClosable:true}" style="position:absolute;visibility:hidden;left:45%;top:5px;" name="strRGB" id="strRGB" onChange="markerChangeColor(this.value);" value="<? echo $strings->strSiteBaseColor; ?>">
<!-- Google Map Canvas -->
<div id="mapcanvas" style="width:100%;" onClick="mapCanvasClick();" tabindex="0"></div>
<div id="mapToolbar" style="margin-right:10px;margin-top:4px;display:none;z-index:9999;white-space:nowrap;">
    <!-- Filtered Actions -->
    <select id="cmbFilteredUsers" name="cmbFilteredUsers" style="display:none;margin:0px;" onChange="mapSelectedRecordsAction('TR');"></select>
    <input type="hidden" id="strNewValue" name="strNewValue" value=""/>
    <div id="divFilteredActions" class="btn-group" style="display:none;">
        <a class="btn dropdown-toggle btn-primary" data-toggle="dropdown" href="#" onClick="document.getElementById('cmbFilteredUsers').style.display = 'none';"><span class="hidden-phone"><? echo $_SESSION['strHomeFiltered']; ?></span> (<span id="spanFilteredActionsSelectedCount">0</span>) <span class="caret"></span></a>
        <ul class="dropdown-menu" style="padding:2px;width:210px;">
            <li><a style="padding:4px;" href="#" onclick="mapPanToarrMarkers();"><i class="icon-map-marker"></i> <? echo $_SESSION['strHomeFilterPanToRecords']; ?></a></li>
            <? if ($arrUser['idUserLevel'] >= 4) { ?>
            <li><a style="padding:4px;" href="#" onclick="userFiltersLoad();"><i class="icon-user"></i> 
                <? echo $_SESSION['stradmManageUsersActionsTransferRecords']; ?>
            </a></li>
            <? } ?>
            <? if ($arrUser['idUserLevel'] >= 2) { ?>
            <li><a style="padding:4px;" href="#" onclick="document.getElementById('strRGBSelected').color.showPicker();"><i class="icon-tint"></i> <? echo $_SESSION['strHomeToolsItemFilterChangeColor']; ?>...</a></li>
            <? } ?>
            <? if ($arrUser['idUserLevel'] >= 4) { ?>
            <li>
            <a style="padding:4px;" href="#">
                <span onclick="$.fancybox({'href' : 'markers.php?s=home&idProject=<? echo $arrProject['idProject']; ?>', 'type' : 'iframe', 'width' : '100%', 'height': '100%'});">
                    <i class="icon-picture"></i> <? echo $_SESSION['strHomeToolsItemFilterChangeIcon']; ?>...
                </span>
                <i class="icon-repeat" style="float:right;cursor:pointer" onClick="mapSelectedRecordsAction('CI0');" title="<? echo $_SESSION["strHomeFilterSetDefaultFormMarkerTip"]; ?>"></i>
            </a>
            </li>
            <? } ?>
            <? if ($arrUser['idUserLevel'] >= 4) { ?>
            <li><a style="padding:4px;" href="#" onclick="mapSelectedRecordsAction('DEL');"><i class="icon-trash"></i> <? echo $_SESSION['strHomeToolsItemDelete']; ?></a></li>
            <? } ?>
        </ul>
    </div>
    <!-- End Filtered Actions -->
    <!-- User Filter Combo -->
	<? if (count($arrUserFilters)) { ?>
    <div id="divUserFilters" class="btn-group" title="<?=$_SESSION["strHomeToolsItemFilterRecords"] . '. ' . $_SESSION["strHomeToolsItemFilterRecordsDoubleClickTip"];?>" style="margin-left:0px">
        <a id="aUserFilters" class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-loading-text="...">
	        <i class="icon-filter" onDblClick="toolFilterFormRecordsCreateDestroy(true, true, false);"></i> <span class="caret"></span>
		</a>        
        <ul class="dropdown-menu" style="padding:5px;width:180px;">
			<li onclick="toolFilterFormRecordsCreateDestroy(false);"><a style="padding:2px;"><label style="display:inline-block"><input type="radio" name="radioUserFilter" id="radioUserFilter_0" value="0" checked> <?=$_SESSION["strHomeFilterDisabled"];?></label></a></li>
		  <? foreach ($arrUserFilters as $arrUserFilter) { ?>
			<li onclick="toolMeasureCreateDestroy(false);toolFilterByAreaCreateDestroy(false);toolFilterByRadiusCreateDestroy(false);document.getElementById('userFilter').value=<?=$arrUserFilter['idUserFilter'];?>;toolFilterFormRecordsCreateDestroy(true, false);">
            	<a style="padding:2px;white-space:normal">
                	<label style="display:inline-block">
                    	<input type="radio" name="radioUserFilter" id="radioUserFilter_<?=$arrUserFilter['idUserFilter'];?>" value="<?=$arrUserFilter['idUserFilter'];?>">
						<? if ($arrUserFilter['strMarkerFullPath']) { ?>
                        <img src="<?=$arrUserFilter['strMarkerFullPath'];?>" style="width:16px;height:16px;">
						<? } ?>
                         <?=$arrUserFilter['strName'];?>
					</label>
				</a>
			</li>
          <? } ?>
        </ul>
    </div>
	<? } ?>
    <!-- End User Filter Combo -->
    <!-- Map Search By Radius Toggle Button -->
    <a id="btnMapSearchByRadius" class="btn" style="padding:5px;" data-rel="tooltip" title="<? echo $_SESSION["strHomeToolsItemSearchByRadius"]; ?>">
	    <span onClick="
            if (document.getElementById('btnMapSearchByRadius').className == 'btn') {
                toolsAction('MSR');
            } else {
                toolFilterByRadiusCreateDestroy(false);mapRecordsLoad();
            }
        "><img src="img/shape-circle.png" style="width:16px;" align="absmiddle"></span>
    </a>
    <!-- Map Search By Polygon Toggle Button -->
    <a id="btnMapSearchByArea" class="btn" style="padding:5px;" data-rel="tooltip" title="<? echo $_SESSION["strHomeToolsItemSearchByArea"]; ?>">
	    <span onClick="
            if (document.getElementById('btnMapSearchByArea').className == 'btn') {
                toolsAction('MSP');
            } else {
                toolFilterByAreaCreateDestroy(false);mapRecordsLoad();
            }
        "><img src="img/shape-polygon.png" style="width:16px;" align="absmiddle"></span>
    </a>
    <!-- Map Show info Toggle Button -->
    <a id="btnShowInfo" class="btn btn-primary" style="padding:5px;" onclick="this.className = 'btn' + (this.className == 'btn' ? ' btn-primary' : '');showInfoUpdate();" data-rel="tooltip" title="<? echo $_SESSION['strHomeMapButtonShowInfo']; ?>"><i class="icon-info-sign"></i></a>
    <!-- Map Full Screen Toggle Button -->
    <a id="btnFullscreen" class="btn" style="padding:5px;" onclick="mapFullscreen();" data-rel="tooltip" title="<? echo $_SESSION['strHomeMapButtonFullScreen']; ?>"><img src="img/fullscreen-expand.png" id="imgFullscreen" style="width:16px;height:16px;"/></a>
    <!-- Google Traffic Layer Toggle Button -->
    <a id="btnTrafficLayer" class="btn" style="padding:5px;" onclick="mapTrafficLayer();" data-rel="tooltip" title="<? echo $_SESSION['strHomeMapButtonTrafficLayer']; ?>"><img src="img/traffic.png" style="height:16px;"/></a>
    <!-- Google Map Search -->
    <input type="text" id="txtMapSearch" style="display:none;width:200px;position:relative;top:5px;" placeholder="<? echo $_SESSION["strGlobalSearch"] . ' ' . $_SESSION['strIndexSearchTypePlace']; ?>..." onblur="this.style.display='none'"/>
    <a id="btnMapSearch" class="btn" style="padding:5px;" onclick="document.getElementById('txtMapSearch').style.display='inline-block';document.getElementById('txtMapSearch').select();" data-rel="tooltip" title="<? echo $_SESSION["strGlobalSearch"] . ' ' . $_SESSION['strIndexSearchTypePlace']; ?>..."><i class="icon-search"></i></a>
</div>

<!-- Radius Filter Input -->
<input type="text" id="toolSearchRadius" onChange="toolFilterUpdateRadius(this.value);" onKeyDown="if(event.keyCode=='13'){toolFilterUpdateRadius(this.value);}" onKeyPress="return justNumbers(event);" style="width:70px;text-align:center;display:none;margin-bottom:15px;padding:3px;" value="<? echo $_COOKIE['dblRadius'] ? $_COOKIE['dblRadius'] : 500; ?>"/>
<!-- Report Status Bar -->
<div id="divProgress" style="width:220px;margin-left:-80px;margin-bottom:8px;display:none;z-index:9999">
	<a id="btnProgressCancel" class="btn btn-danger" onclick="progressCancel();" data-loading-text="..." title="<? echo $_SESSION['strGlobalCancel']; ?>" style="float:left; margin-right:5px;"><i class="icon-stop icon-white"></i></a>
    <div id="divProgressContainer" class="progress progress-striped progress-success active" style="color:#000000;height:27px;font-weight:bold;">
        <div id="divProgressLabel" style="position:absolute;text-align:center;width:100%;padding-top: 4px;"></div>
        <div id="divProgressBar" class="bar" style="width:0%;line-height:27px;height:27px;color:#000000;text-indent:5px;text-align:center;"></div>
    </div>
</div>

<!-- Status bar - coordinates info -->
<div id="divMapStatusBar" style="margin-bottom:7px;color:#000000;font-weight:bold;font-size:12px;display:none">
	<div id="divMapLoading" style="display:none;"><img id="imgMapLoading" src="img/loading1.gif"/></div>
	<span id="spanMapStatusBarCoordinates" class="mapStatusBar"></span>
	<span id="spanMapStatusBarDistance"></span>
</div>
<!-- End Google Map Canvas -->

<!-- Filter Panel -->
<div id="divFilter" class="panel" style="left:20%;min-width:230px;width:50%;top:20%;height:235px;z-index:999;">
    <div id="divFilterTitle" name="divFilterTitle" class="title btn-primary" style="cursor:move;width:99%;height:15px;">
		<i class="icon-remove icon-white" style="float:right;cursor:pointer;margin-left:4px;margin-right:5px;" onclick="toolFilterFormRecordsCreateDestroy(false);"></i>
        <i class="icon-minus icon-white" style="float:right;cursor:pointer;margin-right:5px;" onclick="divShowHide('divFilter', false);"></i>
        <span id="spanFilterTitle"><? echo $_SESSION["strHomeToolsItemFilterRecords"]; ?></span>
    </div>
    <div id="divFilterContent" style="width:100%;overflow:hidden;height:100%;background-color:#<? echo $strings->strSiteBaseColorLighter; ?>">
        <table style="width:100%" cellpadding="3">
        <tr><td colspan="3">
        	<table style="width:100%"><tr>
            <td width="1%" style="text-align:center;white-space:nowrap;" data-rel="tooltip" title="<? echo $_SESSION['strHomeFilterSetDefaultFormMarkerTip']; ?>">
		        <a class="btn btn-warning" id="btnUserFilterSetDefaultFormMarker" data-loading-text="..." onClick="userFilterSetDefaultMarker();"><b>0</b></a>
			</td>
            <td width="1%" style="text-align:center;white-space:nowrap;" data-rel="tooltip" title="<? echo $_SESSION['strHomeFilterMarkerTip']; ?>" >
                <a class="btn" id="btnUserFilterFormMarker"  style="padding:2px;text-align:center;width:30px;height:20px;" onclick="
                    $.fancybox({
                        'href'	: 'markers.php?s=home&idUserFilter=' + document.getElementById('userFilter').value + '&idProject=<? echo $arrProject['idProject']; ?>',
                        'type'	: 'iframe',
                        'width'	: '100%',
                        'height': '100%'
                    });
                ">
	                <img id="imgUserFilterMarker" src="<? echo $user->strUserFilterNoMarkerURL; ?>" style="max-height:20px;max-width:20px;cursor:pointer;" class="rounded"/>
                </a>
            </td>
            <td style="width:97%">
				<select id="userFilter" class="btn" style="width:100%;font-weight:bold" onchange="userFilterLoadFilter();">
                    <option value=""><? echo $_SESSION['strGlobalSelect']; ?></option>
					<? foreach ($arrUserFilters as $arrUserFilter) { ?>
                    <option value="<?=$arrUserFilter['idUserFilter'];?>"><?=$arrUserFilter['strName'];?></option>
                    <? } ?>
                </select>
            </td>
            <td width="1%" style="text-align:center;white-space:nowrap;">
                <a id="btnUserFilterInsert" class="btn btn-success" onclick="userFilterInsert();"><i class="icon-plus-sign icon-white"></i></a>
                <a id="btnUserFilterUpdate" class="btn btn-info" onclick="userFilterUpdate();"><i class="icon-font icon-white"></i></a>
                <a id="btnUserFilterDelete" class="btn btn-danger" onclick="userFilterDelete();"><i class="icon-trash icon-white"></i></a>
            </td>
            </tr></table>
		<td></tr>
        <tr><td colspan="3">
            <select id="filterForm" style="width:100%;margin:0px" onchange="filterFormFieldsLoad();">
            <? 
                $arrForms = $form->selectForms($arrProject['idProject'], 0, '', 1); 
                foreach ($arrForms as $arrForm) {
                    echo '<option value="' . $arrForm['idForm'] . '">' . $arrForm['strName']  . ' (' . $arrForm['intRecords'] . ')</option>';
                }
            ?>
            </select>
        </td></tr>
        <tr><td colspan="3"><select id="filterFormField" style="width:100%;margin:0px"  onchange="filterInitialize();"></select></td></tr>
        <tr>
            <td width="1%">
                <select id="filterOperator" style="width:60px;margin:0px;text-align:center">
                    <option value="1">=</option>
                    <option value="2">&gt;</option>
                    <option value="3">&ge;</option>
                    <option value="4">&lt;</option>
                    <option value="5">&le;</option>
                    <option value="6">&ne;</option>
                </select> 
            </td>
            <td width="96%" style="text-align:left"><input type="text" id="txtFilterValue" style="width:94%;margin:0px;background-position:right;background-repeat:no-repeat" autocomplete="off" onKeyDown="if(event.keyCode=='13'){userFilterClauseInsert();}"/> </td>
            <td width="1%">
            	<a id="btnUserFilterClauseInsert" class="btn btn-success" data-loading-text="..." onclick="userFilterClauseInsert();"><i class="icon-plus-sign icon-white"></i></a>
			</td>
        </tr>
        <tr>
            <td width="1%">
                <select id="filterModeANDOR" style="width:60px;margin:0px;text-align:center" onchange="userFilterClausesLoad();">
                    <option value="OR"><? echo $_SESSION["strHomeFilterOr"]; ?></option>
                    <option value="AND"><? echo $_SESSION["strHomeFilterAnd"]; ?></option>
                </select> 
            </td>
            <td width="97%" style="text-align:center" valign="top">
				<select id="filterClauses" style="width:100%;height:60px;" size="2"></select>
            </td>
            <td width="1%" valign="top">
            	<a id="btnUserFilterClauseDelete" class="btn btn-danger" data-loading-text="..." onclick="userFilterClauseDelete();"><i class="icon-minus-sign icon-white"></i></a>
				<a id="btnFilterUpdate" class="btn btn-success" onclick="userFilterClausesLoad();" data-loading-text="..." style="margin-top:3px;"><i class="icon-filter icon-white"></i></a>
			</td>
        </tr>
        </table>
	</div>
</div>
<!-- End Filter Panel -->

<!-- Record Information Panel -->
<div id="divInfo" class="navbar panel" style="min-width:200px;">
    <div id="divInfoTitle" name="divInfoTitle" class="navbar-inner title" style="cursor:move;width:99%;height:15px;">
        <i id="iInfoDelete" class="icon-trash icon-white" style="float:left;cursor:pointer;margin-right:6px;" title="[Del] <? echo $_SESSION["strHomeToolsItemDelete"]; ?>" onclick="toolsAction('RD');"></i>
        <i id="iInfoEdit" class="icon-edit icon-white" style="float:left;cursor:pointer;margin-right:6px;" title="[E] <? echo $_SESSION["strHomeToolsItemEdit"]; ?>" onclick="toolsAction('RE');"></i>
        <i class="icon-print icon-white" style="float:left;cursor:pointer;" title="[P] <? echo $_SESSION["strHomeToolsItemPrint"]; ?>" onclick="toolsAction('RP');"></i>
        <i class="icon-remove icon-white" style="float:right;cursor:pointer;margin-right:5px;" onclick="divShowHide('divInfo', false);"></i>
        <i id="iInfoResize" class="icon-resize-full icon-white" style="float:right;margin-right:10px;cursor:pointer;" onclick="infoResize();"></i>
        <span id="spanInfoTitle"><? echo $_SESSION["strHomeInfoTitle"]; ?></span>
    </div>
    <div id="divInfoContent" style="width:100%;overflow:auto;overflow-x:hidden;height:95%;">
	    <table id="tblInfoContent" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF;"></table>
	</div>
</div>
<!-- End Record Information Panel -->

<!-- Side Tree View Records List -->
<div id="divTree" class="navbar sidePanel hideSelection" style="max-width:500px;">
    <li class="navbar-inner title">
        <i class="icon-refresh icon-white" style="float:left;cursor:pointer;" onclick="treeInitialize(true);"></i>
        <i class="icon-remove icon-white" style="float:right;cursor:pointer;" onclick="divShowHide('divTree', false);"></i>
        <span id="spanTreeFormRecordsCount">0</span> <? echo $_SESSION["strHomeTreeTitle"]; ?>
    </li>
    <span id="spanTree" style="overflow-y:auto;overflow-x:hidden"></span>
</div>
<!-- End Side Tree View Records List -->

<!-- Side Toolbar Menu -->
<div id="divTools" class="sidePanel hideSelection" style="overflow:auto;">
	<ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF;">
    	<!-- Menu Header - Title -->
        <div class="navbar" style="margin:0px;padding:0px !important;">
        <li class="navbar-inner title">
        	<i class="icon-remove icon-white" style="float:right;cursor:pointer;" onclick="divShowHide('divTools', false);"></i>
			<? echo $_SESSION["strHomeToolsTitle"]; ?>
		</li>
        </div>
        
        <!-- Selected Record Actions Section -->
        <li id="liR" class="title btn-primary"><? echo $_SESSION["strHomeToolsItemSelectedRecord"]; ?></li>
        <li id="liRZE" onClick="toolsAction('RZE');"><a><img src="img/zoom-extent.png" style="width:16px;" align="absmiddle"> [Z] <? echo $_SESSION["strHomeToolsItemZoomToExtent"]; ?></a></li>
        <li id="liRP" onClick="toolsAction('RP');"><a><i class="icon-print"></i> [P] <? echo $_SESSION["strHomeToolsItemPrint"]; ?></a></li>
        <li id="liRE" onClick="toolsAction('RE');"><a><i class="icon-edit"></i> [E] <? echo $_SESSION["strHomeToolsItemEdit"]; ?></a></li>
        <li id="liRFA" onClick="toolsAction('RFA');"><a><img src="img/shape-polygon.png" style="width:16px;" align="absmiddle"> [A] <? echo $_SESSION["strHomeToolsItemFilterByThisArea"]; ?></a></li>
        <li id="liRCC" onClick="toolsAction('RCC');"><a><img src="img/pallete.png" style="width:16px;" align="absmiddle"> [C] <? echo $_SESSION["strHomeToolsItemFilterChangeColor"]; ?></a></li>
        <li id="liRD" onClick="toolsAction('RD');"><a><i class="icon-trash"></i> [Del] <? echo $_SESSION["strHomeToolsItemDelete"]; ?></a></li>

        <!-- General Tools & Filter Modes Section -->
        <li class="title btn-primary"><? echo $_SESSION["strHomeToolsItemTools"]; ?></li>
        <li><a data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemPolygonOpacityTip']; ?>">
			<input id="intMapPolygonsOpacity" type="number" min="0" max="100" step="10" onChange="mapPolygonChangeOpacity();" onKeyPress="return justNumbers(event);" style="width:45px;text-align:center;float:right;margin:0px;padding:2px;margin-right:3px;position:relative;top:-3px;" value="<? echo isset($_COOKIE['intMapPolygonsOpacity']) ? $_COOKIE['intMapPolygonsOpacity'] : 10; ?>"/>
			<img src="img/opacity.png" style="width:16px;" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemPolygonOpacity"]; ?>
		</a></li>
        <li><a><span onClick="toolsAction('MPA');"><img src="img/fullextent.png" style="width:16px;" align="absmiddle"> [L] <? echo $_SESSION["strHomeToolsItemFullExtent"]; ?></span></a></li>
		<? if ($arrUser['idUser'] > 0) { ?>
        <li><a>
            <i class="icon-plus" style="float:right;cursor:pointer;" data-rel="tooltip" title="[T] <? echo $_SESSION["strHomeToolsItemMapToponymyInsert"]; ?>" onClick="toolsAction('MTI');"></i>
        	<i class="<? echo $toponymy->strDefaultIcon; ?>"></i> <input id="chkToponymyShow" type="checkbox" onchange="toolUserToponymyCreateDestroy(this.checked);" <? echo $_COOKIE['blnToponymyShow'] == 1 ? "checked" : ""; ?>/> <label for="chkToponymyShow" style="display:inline-block;"><? echo $_SESSION["strHomeToolsItemMapToponymy"]; ?></label>
		</a></li>
		<? } ?>
		<? if ($user->intCountUserPosition($arrProject['idProject']) > 0) { ?>
        <li id="liUR"><a>
            <i id="iUR" class="icon-remove" style="float:right;cursor:pointer;display:none;" onclick="toolUserPositionsCreateDestroy(false);"></i>
            <span onClick="toolsAction('UR');"><img src="img/userRoute.png" style="width:16px;" align="absmiddle"> [R] <? echo $_SESSION["strHomeToolsItemUserPositions"]; ?></span>
		</a></li>
		<? } ?>
        <li id="liMIO"><a>
            <i id="iMIO" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolImageOverlayCreateDestroy(false);"></i>
        	<span onClick="toolsAction('MIO');"><img src="img/map-layer.png" style="width:16px;" align="absmiddle"> [O] <? echo $_SESSION["strHomeToolsItemImageOverlay"]; ?></span>
		</a></li>
        <li id="liMHM"><a>
            <i id="iMHM" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolHeatmapCreateDestroy(false, false);"></i>
            <input id="intHeatmapRadius" type="number" min="10" max="500" step="10" onChange="toolHeatmapCreateDestroy(true);//if (gHeatmap) {gHeatmap.set('radius', parseInt(this.value));}" onKeyPress="return justNumbers(event);" style="width:45px;text-align:center;display:none;float:right;margin:0px;padding:2px;margin-right:3px;position:relative;top:-3px;" value="<? echo isset($_COOKIE['intHeatmapRadius']) ? $_COOKIE['intHeatmapRadius'] : 10; ?>" data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemHeatMapRadiusTip']; ?>"/>
        	<span onClick="toolsAction('MHM');"><img src="img/heatmap.png" style="width:16px;" align="absmiddle"> [H] <? echo $_SESSION["strHomeToolsItemHeatMap"]; ?></span>
		</a></li>
        <li id="liMCC" onClick="toolsAction('MCC');"><a><img src="img/target.png" style="width:16px;" align="absmiddle"> [M] <? echo $_SESSION["strHomeToolsItemCenterCoordinates"]; ?></a></li>
        <li id="liMMD"><a>
            <i id="iMMD" class="icon-remove" style="float:right;cursor:pointer;display:none;" onclick="toolMeasureCreateDestroy(false);"></i>
            <span onClick="toolsAction('MMD');"><img src="img/ruller.png" style="width:16px;" align="absmiddle"> [D] <? echo $_SESSION["strHomeToolsItemMeasureDistances"]; ?></span>
		</a></li>
        <li id="liMFR"><a>        	
            <i id="iMFR" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolFilterFormRecordsCreateDestroy(false);mapRecordsLoad();"></i>
            <span onClick="toolsAction('MFR');"><i class="icon-filter"></i> [1] <? echo $_SESSION["strHomeToolsItemFilterRecords"]; ?></span>
		</a></li>
        <li id="liMSP"><a>			
            <i id="iMSP" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolFilterByAreaCreateDestroy(false);mapRecordsLoad();"></i>
            <span onClick="toolsAction('MSP');"><img src="img/shape-polygon.png" style="width:16px;" align="absmiddle"> [2] <? echo $_SESSION["strHomeToolsItemSearchByArea"]; ?></span>
		</a></li>
        <li id="liMSR"><a>
            <i id="iMSR" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolFilterByRadiusCreateDestroy(false);mapRecordsLoad();"></i>
            <span onClick="toolsAction('MSR');"><img src="img/shape-circle.png" style="width:16px;" align="absmiddle"> [3] <? echo $_SESSION["strHomeToolsItemSearchByRadius"]; ?></span>
		</a></li>
		<li id="liIBGE"><a>
            <i id="iIBGE" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolIBGECreateDestroy(false);"></i>
        	<span onClick="toolsAction('MIBGE');"><img src="img/ibge.png" style="height:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemExternalMapsIBGE"]; ?></span>
		</a></li>
        
        <!-- Spatial Analysis Section -->
        <li class="title btn-primary"><? echo $_SESSION["strHomeToolsItemSpatialAnalysis"]; ?></li>
        <li id="liMFM"><a>
            <i id="iMFM" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolFlushMapCreateDestroy(false);"></i>
        	<span onClick="toolsAction('MFM');"><img src="img/flow.png" style="width:16px;" align="absmiddle"> [F] <? echo $_SESSION["strHomeToolsItemFlushMap"]; ?></span>
		</a></li>
        <li id="liMBF"><a>
            <i id="iMBF" class="icon-remove" style="float:right;cursor:pointer;display:none" onclick="toolBufferCreateDestroy(false);"></i>
        	<span onClick="toolsAction('MBF');"><img src="img/buffer.png" style="width:16px;" align="absmiddle"> [B] <? echo $_SESSION["strHomeToolsItemBuffer"]; ?></span>
		</a></li>
        
        <!-- Export Map Section -->
        <li class="title btn-primary"><? echo $_SESSION["strHomeToolsItemExportMap"]; ?></li>
        <li onClick="toolsAction('ERS2');"><a><img src="img/filetypes/rs21.png" style="height:16px" align="absmiddle"> Raster/SAGA (.rs2)</a></li>
        <li onClick="toolsAction('EKML');"><a><img src="img/earth.png" style="height:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemKMLArcGIS"]; ?> (.kml)</a></li>
        <li onClick="toolsAction('ESHP');"><a><img src="img/arcgis.png" style="height:16px" align="absmiddle"> ESRI ArcGIS Shapefile (.shp)</a></li>
        <li onClick="toolsAction('EPNG');"><a><img src="img/map.png" style="height:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemImage"]; ?> (.png)</a></li>
        <li><a href="help/apis#wfs" target="_blank"><img src="img/ogc.png" style="height:16px" align="absmiddle"> WFS - Web Feature Service</a></li>
        
        <!-- Report Section -->
        <li class="title btn-primary"><? echo $_SESSION["strHomeToolsItemGenerateReport"]; ?></li>
        <li onClick="toolsAction('RDT');"><a><img src="img/table.png" style="width:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemDistanceTable"]; ?> (.xlsx)</a></li>
        <li onClick="toolsAction('RXLS');"><a><img src="img/filetypes/xlsx1.png" style="height:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemExcelWorksheet"]; ?> (.xls)</a></li>
        <li onClick="toolsAction('RKML');"><a><img src="img/earth.png" style="height:16px" align="absmiddle"> Google Earth (.kml)</a></li>
        <li onClick="toolsAction('RHTML');"><a><img src="img/filetypes/html.png" style="height:16px" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemHTMLPage"]; ?> (.html)</a></li>
    </ul>
</div>

<!-- Side Menus Buttons -->
<span id="btnTree" onClick="divShowHide('divTree', true);" style="position:absolute;top:44%;left:-3px;cursor:pointer;width:28px;background-color:#FFFFFF;height:28px;border:solid 1px #000000" class="rounded" title="<? echo $_SESSION['strHomeBtnTreeTip'] . ' - ' . $_SESSION["strGlobalShortcutKey"] . ': Alt + R'; ?>"><img src="img/treeView.png" style="position:relative;top:2px;height:24px"></span>
<span id="btnTools" onClick="divShowHide('divTools', true);" style="position:absolute;top:56%;left:-3px;cursor:pointer;width:28px;background-color:#FFFFFF;height:28px;border:solid 1px #000000" class="rounded" title="<? echo $_SESSION['strHomeToolsTitle'] . ' - ' . $_SESSION["strGlobalShortcutKey"] . ': Alt + T'; ?>"><img src="img/tools.png" style="position:relative;top:2px;left:2px;height:24px"></span>

<!-- Map Export Panel -->
<div class="hide" id="modalMapExport" style="width:320px;position:absolute;top:90px;left:35px;background-color:#FFFFFF;z-index:3">
    <div class="modal-header" style="background-color: #f5f5f5;cursor:move;">
        <h4>
        	<i class="icon-map-marker"></i> <? echo $_SESSION['strHomeToolsMapExportTitle']; ?> <span id="spanModalExportExtension"></span>
	        <i class="icon-remove" id="btnModalMapExportCancel" name="btnModalMapExportCancel" onClick="mapExportHideModal();" style="cursor:pointer;float:right"></i>
		</h4>
    </div>
    <div style="padding:5px;">
    	<input type="hidden" id="hidMapExportExtension" />
        <table style="width:100%">
        <tr style="display:none"><td colspan="4" style="width:100%;white-space:nowrap;"><input type="radio" id="rbMapExportType1" name="rbMapExportType" value="1" onchange="mapExportTypeUpdate();"/> <label style="display:inline-block" for="rbMapExportType1"><? echo $_SESSION['strHomeToolsMapExportAllRecords']; ?></label></td></tr>
        <tr><td colspan="4" style="width:100%;white-space:nowrap;"><input type="radio" id="rbMapExportType2" name="rbMapExportType" value="2" checked="checked" onchange="mapExportTypeUpdate();"/> <label style="display:inline-block" for="rbMapExportType2"><? echo $_SESSION['strHomeToolsMapExportDelimitArea']; ?></label></td></tr>
        <tr id="trMapExportCoordinates1">
            <td style="width:1%;white-space:nowrap;text-align:right;vertical-align:middle">Lat SW:</td>
			<td style="width:49%"><input type="text" id="txtMapExportLatSW" onKeyPress="return justNumbers(event);" onBlur="this.value=parseFloat(this.value);mapExportUpdateBBRectangle();" style="padding:2px;width:80px;margin:0px"/></td>
            <td style="width:1%;white-space:nowrap;text-align:right;vertical-align:middle">Lat NE:</span></td>
            <td style="width:49%"><input type="text" id="txtMapExportLatNE" onkeypress="return justNumbers(event);"  onBlur="this.value=parseFloat(this.value);mapExportUpdateBBRectangle();" style="padding:2px;width:80px;margin:0px"/></td>
        </tr>
		<tr id="trMapExportCoordinates2">
            <td style="width:1px;white-space:nowrap;text-align:right;vertical-align:middle">Lng SW:</td>
            <td><input type="text" id="txtMapExportLngSW" onKeyPress="return justNumbers(event);"  onBlur="this.value=parseFloat(this.value);mapExportUpdateBBRectangle();" style="padding:2px;width:80px;margin:0px"/></td>
		    <td style="white-space:nowrap;text-align:right;vertical-align:middle">Lng NE:</span></td>
		    <td><input type="text" id="txtMapExportLngNE" onkeypress="return justNumbers(event);" onBlur="this.value=parseFloat(this.value);mapExportUpdateBBRectangle();" style="padding:2px;width:80px;margin:0px"/></td>
		</tr>
        <tr id="trMapExportResolution">
        	<td colspan="4" style="text-align:left;line-height:25px;vertical-align:middle">
				<? echo $_SESSION['strHomeToolsMapExportResolution']; ?> (m/pixel): 
                <input id="intMapExportResolution" type="number" value="10" style="width:40px;text-align:center;margin:0px" onchange="mapExportUpdateInfoBounds();" title="<? echo $_SESSION['strHomeToolsMapExportResolutionTip']; ?>"/>
            </td>
        </tr>
        <tr id="trMapExportRS2LagendsAsID">
        	<td colspan="4" style="text-align:left;line-height:25px;vertical-align:middle">
				<input id="chkMapExportRS2LagendsAsID" type="checkbox" checked="checked"/> <label for="chkMapExportRS2LagendsAsID" style="display:inline-block;margin-right:10px;" data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsMapExportClassesAsIDTip']; ?>"><? echo $_SESSION['strHomeToolsMapExportClassesAsID']; ?> <i class="icon-info-sign"></i></label>
            </td>
        </tr>
        <tr id="trMapExportPNGFinishing">
        	<td colspan="4" style="text-align:left;font-weight:bold;line-height:25px;">
				<div><? echo $_SESSION['strHomeToolsMapExportPNGFinishingTitle']; ?>:</div>
                <div style="margin-left:10px;">
				<input id="chkMapExportPNGFinishingGoogleMaps" type="checkbox" checked="checked"/> <label for="chkMapExportPNGFinishingGoogleMaps" style="display:inline-block;margin-right:10px;"><? echo $_SESSION['strHomeToolsMapExportPNGFinishingGoogleMaps']; ?></label><br />
				<input id="chkMapExportPNGFinishingLegends" type="checkbox" checked="checked"/> <label for="chkMapExportPNGFinishingLegends" style="display:inline-block;margin-right:10px;"><? echo $_SESSION['strHomeToolsMapExportPNGFinishingLegends']; ?></label>
				<input id="chkMapExportPNGFinishingGrid" type="checkbox" checked="checked" onchange="mapExportUpdateInfoBounds();"/> <label for="chkMapExportPNGFinishingGrid" style="display:inline-block;margin-right:10px;"><? echo $_SESSION['strHomeToolsMapExportPNGFinishingGrid']; ?></label>
				<br /><input id="chkMapExportPNGFinishingMask" type="checkbox"/> <label for="chkMapExportPNGFinishingMask" style="display:inline-block;margin-right:10px;" data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsMapExportPNGFinishingMaskTip']; ?>"><? echo $_SESSION['strHomeToolsMapExportPNGFinishingMask']; ?> <span id="spanMapExportPNGFinishingMaskFormRecord"/></span></label>
                </div>
            </td>
        </tr>
        <tr id="trMapExportCoordinates3">
        	<td colspan="4" id="tdMapExportInfoDim" style="text-align:center;font-weight:bold;line-height:25px;"></td>
        </tr>
        </table>
    </div>
    <div class="modal-footer" style="padding: 5px 5px 5px;">
        <span id="spanModalMapExportDownload"></span>
        <a href="#" class="btn btn-primary" id="btnModalMapExportProcess" name="btnModalMapExportProcess" onclick="mapExportProcess()" data-loading-text="<? echo $_SESSION['strGlobalProcessing']; ?>..."><? echo $_SESSION['strGlobalExport']; ?></a>
    </div>
</div>
<!-- End Map Export Panel -->

<!-- Image Overlay Panel -->
<div class="hide" id="modalImageOverlay" style="width:320px;position:absolute;top:81px;left:25px;background-color:#FFFFFF;">
    <div class="modal-header" style="background-color: #f5f5f5;cursor:move;">
        <h4>
        	<img src="img/map-layer.png" style="width:16px;" align="absmiddle"> <? echo $_SESSION['strHomeToolsItemImageOverlay']; ?>
            <i class="icon-remove" style="float:right;cursor:pointer;margin-left:7px;" onclick="toolImageOverlayCreateDestroy(false);"></i>
	        <i class="icon-minus" onClick="divShowHide('modalImageOverlay', false);" style="cursor:pointer;float:right"></i>
		</h4>
    </div>
    <div style="padding:3px;">
        <table style="width:100%">
        <tr><td colspan="4">
        	<table style="width:100%;margin-bottom:4px;"><tr>
            <td style="width:99%">
				<select id="imageOverlay" class="btn" style="width:100%;font-weight:bold" onchange="imageOverlayLoad();" data-loading-text="..."></select>
            </td>
            <td width="1%" style="text-align:center;white-space:nowrap;">
                <a id="btnImageOverlayUpload" class="btn btn-success" onclick="document.getElementById('fuImageOverlayFile').click();" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemImageOverlayUploadTip']; ?>"><i class="icon-upload icon-white"></i></a>
				<input id="fuImageOverlayFile" type="file" name="files[]" style="display:none">
				<input id="hidImageOverlayFileNameFullPath" type="hidden" value="">
                <a id="btnImageOverlayDelete" class="btn btn-danger" onclick="imageOverlayDelete();" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemImageOverlayDeleteTip']; ?>"><i class="icon-trash icon-white"></i></a>
            </td>
            </tr></table>
		<td></tr>
        <tr id="trImageOverlayExtent1" style="display:none">
            <td valign="baseline" style="width:1%;white-space:nowrap;text-align:right">Lat SW:</td>
			<td style="width:49%"><input type="text" id="txtImageOverlayLatSW" onKeyPress="return justNumbers(event);" onBlur="this.value=parseFloat(this.value);imageOverlayUpdate();" style="padding:2px;width:80px;"/></td>
            <td valign="baseline" style="width:1%;white-space:nowrap;text-align:right">Lat NE:</span></td>
            <td style="width:49%"><input type="text" id="txtImageOverlayLatNE" onkeypress="return justNumbers(event);"  onBlur="this.value=parseFloat(this.value);imageOverlayUpdate();" style="padding:2px;width:80px;"/></td>
        </tr>
		<tr id="trImageOverlayExtent2" style="display:none">
            <td valign="baseline" style="width:1px;white-space:nowrap;text-align:right">Lng SW:</td>
            <td><input type="text" id="txtImageOverlayLongSW" onKeyPress="return justNumbers(event);"  onBlur="this.value=parseFloat(this.value);imageOverlayUpdate();" style="padding:2px;width:80px;"/></td>
		    <td valign="baseline" style="white-space:nowrap;text-align:right">Lng NE:</span></td>
		    <td><input type="text" id="txtImageOverlayLongNE" onkeypress="return justNumbers(event);" onBlur="this.value=parseFloat(this.value);imageOverlayUpdate();" style="padding:2px;width:80px;"/></td>
		</tr>
        </table>
        <div id="divImageOverlayProgressBar" class="progress" style="width:100%;border:1px solid #003300;display:none;">
            <div id="bar" class="bar"></div>
        </div>
    </div>
</div>
<!-- End Image Overlay Panel -->

<!-- Flush Map Panel -->
<div class="hide" id="modalFlushMap" style="width:320px;position:absolute;top:81px;left:25px;background-color:#FFFFFF;">
    <div class="modal-header" style="background-color: #f5f5f5;cursor:move;">
        <h4>
			<img src="img/flow.png" style="width:16px;" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemFlushMap"]; ?>
            <i class="icon-remove" style="float:right;cursor:pointer;margin-left:7px;" onclick="toolFlushMapCreateDestroy(false);"></i>
	        <i class="icon-minus" id="btnModalFlushMapClose" onClick="divShowHide('modalFlushMap', false);" style="cursor:pointer;float:right"></i>
		</h4>
    </div>
    <div style="padding:3px;margin:2px;">
		<select id="flushMapForm" style="width:100%;" onchange="flushMapFormFieldsLoad();">
		<? 
            foreach ($arrForms as $arrForm) {
                echo '<option value="' . $arrForm['idForm'] . '">' . $arrForm['strName']  . ' (' . $arrForm['intRecords'] . ')</option>';
            }
        ?>
        </select>
		<select id="flushMapFormFieldID" style="width:100%;" data-loading-text="..."></select>
		<select id="flushMapFormFieldIDTo" style="width:100%;" data-loading-text="..."></select>
		<a id="btnFlushMapDraw" class="btn btn-success" onclick="flushMapDraw();" style="float:right;margin-bottom:4px;" data-loading-text="..."><i class="icon-refresh icon-white"></i> <? echo $_SESSION['strHomeToolsItemFlushMapDraw']; ?></a>
    </div>
</div>
<!-- End Flush Map Panel -->

<!-- Flush Buffer Panel -->
<div class="hide" id="modalBuffer" style="width:320px;position:absolute;top:81px;left:25px;background-color:#FFFFFF;z-index:2;">
    <div class="modal-header" style="background-color: #f5f5f5;cursor:move;">
        <h4>
			<img src="img/buffer.png" style="width:16px;" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemBuffer"]; ?>
            <i class="icon-remove" style="float:right;cursor:pointer;margin-left:7px;" onclick="toolBufferCreateDestroy(false);"></i>
	        <i class="icon-minus" onClick="divShowHide('modalBuffer', false);" style="cursor:pointer;float:right"></i>
		</h4>
    </div>
    <div style="padding:3px;white-space:nowrap;">
		<select id="cmbBufferForm" style="width:220px;margin-bottom:0px;" onchange="bufferDraw();">
		<? 
            foreach ($arrForms as $arrForm) {
                echo '<option value="' . $arrForm['idForm'] . '">' . $arrForm['strName'] . ' (' . $arrForm['intRecords'] . ')</option>';
            }
        ?>
        </select>
		<input id="intBufferRadius" type="number" min="1" onKeyPress="return justNumbers(event);" onBlur="bufferRadiusUpdate();" style="width:70px;text-align:center;margin-bottom:0px;" value="<? echo $_COOKIE['intBufferRadius'] ? $_COOKIE['intBufferRadius'] : 100; ?>" data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemBufferRadiusTip']; ?>"/>
		<!--<a id="btnBufferDraw" class="btn" onclick="bufferDraw();" style="margin-left:3px;width:20px;" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['strHomeToolsItemBufferDraw']; ?>"><img src="img/buffer.png" style="width:16px;" align="absmiddle"></a>-->
        <div style="width:100%;margin-top:5px;">
		<select id="cmbBufferCoverAreaByForm" style="width:100%;margin-bottom:0px;" onchange="bufferGenerateCoverAreaReport();">
        <option value=""><? echo $_SESSION['strHomeToolsItemBufferCoverArea']; ?></option>
		<? 
            foreach ($arrForms as $arrForm) {
                echo '<option value="' . $arrForm['idForm'] . '">' . $arrForm['strName'] . ' (' . $arrForm['intRecords'] . ')</option>';
            }
        ?>
        </select>
        </div>
    </div>
    <div id="divBufferProgress" class="progress progress-striped progress-success active" style="color:#000000;height:27px;font-weight:bold;display:none">
        <div id="divBufferProgressLabel" style="position:absolute;text-align:center;width:100%;padding-top: 4px;"></div>
        <div id="divBufferProgressBar" class="bar" style="width:0%;line-height:27px;height:27px;color:#000000;text-indent:5px;text-align:center;"></div>
    </div>
</div>
<!-- End Buffer Panel -->

<!-- IBGE Panel -->
<div class="hide" id="divIBGE" style="width:auto;height:auto;position:absolute;top:81px;left:25px;background-color:#FFFFFF;">
    <div class="modal-header" id="divIBGETitle" style="background-color: #f5f5f5;cursor:move;"><h4>
      <img src="img/ibge.png" style="width:16px;" align="absmiddle"> <? echo $_SESSION["strHomeToolsItemExternalMapsIBGE"]; ?>
      <i class="icon-remove" style="float:right;cursor:pointer;margin-left:7px;" onclick="document.getElementById('divIBGE').style.display = 'none';"></i>
	</h4></div>
    <iframe id="ifrIBGE" style="width:650px;border:none;height:400px;padding:0px;"></iframe>
</div>
<!-- End IBGE Panel -->

<script type="text/javascript">
	var oms, mkCurrent, tree, poly;
	var blnIsFiltering = false;
	var arrMarkers = [];
	var arrToponymy = [];
	var arrUserPositions = [];
	var arrBuffers = [];
	var intVertexsLimit = 50000;
	var intNumVertexs = 0;
	var intMaxVertexPathPoly = 200;
	var intIconMaxSize = 16;
	var ptOrigin = new google.maps.LatLng(<? echo $arrUser['dblLatitude'] != 0 ? $arrUser['dblLatitude'] : (is_numeric($_COOKIE['dblLatC']) ? $_COOKIE['dblLatC'] : (is_numeric($arrProject['dblLatitude']) ? $arrProject['dblLatitude'] : '0')); ?>, <? echo $arrUser['dblLongitude'] != 0 ? $arrUser['dblLongitude'] : (is_numeric($_COOKIE['dblLngC']) ? $_COOKIE['dblLngC'] : (is_numeric($arrProject['dblLongitude']) ? $arrProject['dblLongitude'] : '0')); ?>);
	var mapBounds;
	var xhr;
	var result;
	var strReportEmail = '<? echo $arrUser['strEmail']; ?>';
	var gHeatmap, imageOverlay, trafficLayer;
	var blnIsFilteringByPolygonArea = false;
	var IBGEFusionLayer;

	function mapInitialize() {
		// Positioning navigation controls
		var mapOptions = {
			zoom: <? echo is_numeric($_COOKIE['intZoom']) ? $_COOKIE['intZoom'] : 7; ?>, 
			mapTypeId: google.maps.MapTypeId.<? echo ($_COOKIE['strMapTypeId'] ? $_COOKIE['strMapTypeId'] : $strings->strGoogleMapsDefaultTypeMap); ?>, 
			center: ptOrigin,
			panControl: false,
			zoomControl: true,
			zoomControlOptions: {
				style: google.maps.ZoomControlStyle.LARGE,
				position: google.maps.ControlPosition.RIGHT_TOP
			},
			scaleControl: true,
			scaleControlOptions: {
				position: google.maps.ControlPosition.RIGHT_BOTTOM
			},
			streetViewControl: true,
			streetViewControlOptions: {
				position: google.maps.ControlPosition.RIGHT_TOP
			}
		}
		map = new google.maps.Map(document.getElementById("mapcanvas"), mapOptions);
		map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('divMapLoading'));
		map.controls[google.maps.ControlPosition.BOTTOM_LEFT].push(document.getElementById('divMapStatusBar'));
		map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(document.getElementById('divProgress'));
		map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(document.getElementById('toolSearchRadius'));
		map.controls[google.maps.ControlPosition.TOP_RIGHT].push(document.getElementById('mapToolbar'));
		// Initializing Traffic Layer
		trafficLayer = new google.maps.TrafficLayer();
		// Initializing Cluster Component for Google Maps
		oms = new OverlappingMarkerSpiderfier(map, {markersWontMove: true, markersWontHide: true, keepSpiderfied: true});
		// Initializing Callbacks
		mapResize();
		google.maps.event.addListener(map, 'idle', function() {mapChangeBounds();});
		google.maps.event.addListener(map, 'mousemove', function(point) {
			document.getElementById('spanMapStatusBarCoordinates').innerHTML =
				point.latLng.lat().toFixed(7) + ":" + point.latLng.lng().toFixed(7);
		});
		// Map Search
		mapSearchBoxInitialize('txtMapSearch');
	}
	
	function mapChangeBounds(){
		mapRecordsLoad();
	}
	
	function mapClearAllUserPositions(){
		while(arrUserPositions[0]) {
		  arrUserPositions.pop().setMap(null);
		}
		arrUserPositions = [];
	}
	
	function mapClearAllBuffers(){
		while(arrBuffers[0]) {
		  arrBuffers.pop().setMap(null);
		}
		arrBuffers = [];
	}
	
	function mapClearAllToponymys(){
		$.ajax({url: 'ajax.php?chrAction=HMTH'});
		while(arrToponymy[0]) {
		  arrToponymy.pop().setMap(null);
		}
		arrToponymy = [];
	}
	
	function mapClearAllObjects(){
		while(arrMarkers[0]) {
		  arrMarkers.pop().setMap(null);
		}
		intNumVertexs = 0;
		arrMarkers = [];
		filterUpdateCounter(0);
	}
		
	function mapCanvasClick() {
		if (document.getElementById('toolSearchRadius').style.display != 'none') return;
		divShowHide('divTools', false);
	}
	
	function mapFullscreen() {
		var btnFullscreen = document.getElementById('btnFullscreen');
		var blnSetFullscreen = (btnFullscreen.className == 'btn' ? true : false);
		btnFullscreen.className = 'btn' + (blnSetFullscreen ? ' btn-primary' : '');
		document.getElementById("divPageHeader").style.display = (blnSetFullscreen ? 'none' : 'block');
		document.getElementById("divPageFooter").style.display = (blnSetFullscreen ? 'none' : 'block');
		document.getElementById("divPageContainer").style.width = (blnSetFullscreen ? '100%' : '98%');
		document.getElementById("mainContent").style.padding = (blnSetFullscreen ? '0px' : '10px');
		document.getElementById("mainContent").style.marginTop = (((blnSetFullscreen) || ($(window).width() >= 980)) ? '0px' : '25px');
		document.body.style.padding = '0px';
		mapResize();
	}
	
	function mapTrafficLayer() {
		var btnTrafficLayer = document.getElementById('btnTrafficLayer');
		var blnShowTrafficLayer = (btnTrafficLayer.className == 'btn' ? true : false);
		btnTrafficLayer.className = 'btn' + (blnShowTrafficLayer ? ' btn-primary' : '');
		trafficLayer.setMap(blnShowTrafficLayer ? map : null);
	}	
	
	function ajaxAbortAllRequests() {
		if (! result) return;
		result.abort();
		var result = $.ajax({url: 'ajax.php?chrAction=HAAR'}).always(function() {
			result = null;
		});
		mapShowLoading(false);
	}
	
	function mapRecordsLoad() {
		if (blnIsFiltering) return;
		//ajaxAbortAllRequests();
		// If current BBox is inside last loaded BBOx, don't load
		/*
		if (
			(mapBounds) &&
			(map.getBounds().getNorthEast().lat() <= mapBounds.getNorthEast().lat()) && 
			(map.getBounds().getSouthWest().lat() >= mapBounds.getSouthWest().lat()) && 
			(map.getBounds().getNorthEast().lng() <= mapBounds.getNorthEast().lng()) && 
			(map.getBounds().getSouthWest().lng() >= mapBounds.getSouthWest().lng())
		) {
			return;
		}
		*/
		mapShowLoading(true);
		document.getElementById('divMapStatusBar').style.display = "block";
		document.getElementById('mapToolbar').style.display = "block";
		if (intNumVertexs >= intVertexsLimit)	{
			mapClearAllObjects();
		}
		var mapBoundsNE = map.getBounds().getNorthEast();
		var mapBoundsSW = map.getBounds().getSouthWest();
		mapBounds = map.getBounds();
		result = $.ajax({
			url: 'ajax.php?chrAction=HMRS' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>' +
				'&dblLatNE=' + mapBoundsNE.lat().toFixed(7) + 
				'&dblLngNE=' + mapBoundsNE.lng().toFixed(7) + 
				'&dblLatSW=' + mapBoundsSW.lat().toFixed(7) + 
				'&dblLngSW=' + mapBoundsSW.lng().toFixed(7) +
				'&dblLatC='	 + map.getCenter().lat().toFixed(7) +
				'&dblLngC='  + map.getCenter().lng().toFixed(7) +
				'&intZoom='  + map.getZoom() +
				'&strMapTypeId=' + map.getMapTypeId() +
				'&intMapPolygonsOpacity=' + document.getElementById('intMapPolygonsOpacity').value +
				'&blnFullscreen=' + (document.getElementById('btnFullscreen').className == 'btn' ? "0" : "1") + 
				'&blnTrafficLayer=' + (document.getElementById('btnTrafficLayer').className == 'btn' ? "0" : "1")
		}).always(function() {
			if (blnIsFiltering) return;
			mapPlotMarkers(result.responseText);
		});
	}

	function mapPlotMarkers(strJSON) {
		mapShowLoading(false);
		// Prevent when return "undefined" - Console "u token" error
		if (! strJSON) return; 
		var arrResult 	= JSON.parse(strJSON);
		mapShowLoading(true);
		var blnVisible = true;
		var strMarkerFullPath = '';
		var intWidth, intHeight;
		//var iconBlank	= new google.maps.MarkerImage('img/blank.png', null, null, null, new google.maps.Size(1, 1, 'px' , 'px'));
		for (var i=0;i<arrResult.length;i++) {
			// Check if object is alteady ploted
			//console.log(arrResult[i]['idFormRecord'] + ':' + arrResult[i]['arrVertex'][0]['dblLatitude']);
			if (arrMarkersSearch(1, arrResult[i]['idFormRecord']) >= 0) { continue; }
			blnVisible = (tree.isItemChecked(arrResult[i]['idForm']) ? true : false); 
			if (arrResult[i]['idShapeType'] == 1) { // Marker
				// Get Marker Dimensions
				if (strMarkerFullPath != arrResult[i]['strMarkerFullPath']) {
					strMarkerFullPath = arrResult[i]['strMarkerFullPath'];
					var img = document.createElement('img');
					img.src = arrResult[i]['strMarkerFullPath'];
					intWidth = img.width;
					intHeight = img.height;
					if ((img.width > intIconMaxSize) || (img.height > intIconMaxSize)) {
						intHeight = intIconMaxSize;
						intWidth = Math.round(intIconMaxSize*img.width/img.height);
					}
				}
				var icon = new google.maps.MarkerImage(strMarkerFullPath, null, null, null, new google.maps.Size(intWidth, intHeight, 'px' , 'px'));
				//var icon = new google.maps.MarkerImage(arrResult[i]['strMarkerFullPath'], null, null, null, new google.maps.Size(16, 16, 'px', 'px'));
				var marker = new google.maps.Marker({position: new google.maps.LatLng(arrResult[i]['arrVertex'][0]['dblLatitude'], arrResult[i]['arrVertex'][0]['dblLongitude']), draggable: false, icon: icon, visible: blnVisible, map: map, clickable: true});
				oms.addMarker(marker);
				intNumVertexs++;
			} else if (arrResult[i]['idShapeType'] == 2) { // Polyline
				var arrPath = new google.maps.MVCArray();
				for (j=0; j < arrResult[i]['arrVertex'].length; j++) {
					arrPath.push(new google.maps.LatLng(arrResult[i]['arrVertex'][j]['dblLatitude'], arrResult[i]['arrVertex'][j]['dblLongitude']));
				}
				intNumVertexs += arrResult[i]['arrVertex'].length;
				var pOptions = {strokeColor: arrResult[i]['strCustomMarkerRGBColor'], strokeOpacity: document.getElementById('intMapPolygonsOpacity').value/100, strokeWeight: 4, visible: blnVisible, map: map, zIndex: 1, path: arrPath, clickable: true};
				var marker = new google.maps.Polyline(pOptions);
			} else if (arrResult[i]['idShapeType'] == 3) { //Polygon
				var arrPath = new google.maps.MVCArray();
				for (j=0; j < arrResult[i]['arrVertex'].length; j++) {
					arrPath.push(new google.maps.LatLng(arrResult[i]['arrVertex'][j]['dblLatitude'], arrResult[i]['arrVertex'][j]['dblLongitude']));
				}
				intNumVertexs += arrResult[i]['arrVertex'].length;
				var pOptions = {strokeColor: arrResult[i]['strCustomMarkerRGBColor'], fillColor: arrResult[i]['strCustomMarkerRGBColor'], strokeOpacity: 0.5, strokeWeight: 3, fillOpacity: document.getElementById('intMapPolygonsOpacity').value/100, visible: blnVisible, map: map, zIndex: 1, path: arrPath, clickable: true};
				var marker = new google.maps.Polygon(pOptions);
			}
			marker.idKind = 1;
			marker.id = arrResult[i]['idFormRecord'];
			marker.idForm = arrResult[i]['idForm'];
			marker.idUser = arrResult[i]['idUser'];
			marker.idFormRecord = arrResult[i]['idFormRecord'];
			marker.idShapeType = arrResult[i]['idShapeType'];
			marker.strFormMarkerFullPath = arrResult[i]['strFormMarkerFullPath'];
			marker.strCustomMarkerRGBColor = arrResult[i]['strCustomMarkerRGBColor'];
			marker.dblLatitude = arrResult[i]['dblLatitude'];
			marker.dblLongitude = arrResult[i]['dblLongitude'];
			marker.strMarkerFullPath = arrResult[i]['strMarkerFullPath'];
			marker.dblDistanceFromCenterMts = arrResult[i]['dblDistanceFromCenterMts'];
			arrMarkers.push(marker);
			with ({mark: marker}) {
				google.maps.event.addListener(marker, "click", function(event) {
					mkCurrent = mark;
					if (mark.idShapeType == 3) {
						document.getElementById('spanMapExportPNGFinishingMaskFormRecord').innerHTML = mark.idFormRecord;
						mapExportUpdateBBByPolygon(mark);
					}
					var blnShowInfo = (document.getElementById('btnShowInfo').className == 'btn' ? false : true);
					if (blnShowInfo) {
						arrMarkerBlink(mark, 2);
						infoLoad(mark.idFormRecord);
					}
					treeHighlightRecord(mark.idKind, mark.idFormRecord);
					// Filter By Area Activated
					if ((! blnIsFilteringByPolygonArea) && (poly) && (document.getElementById('liMSP').className == 'liSelected')) {
						poly.getPath().insertAt(poly.getPath().length, event.latLng);
					}
					// Tool Distance Measure Activated
					if ((poly) && (document.getElementById('liMMD').className == 'liSelected')) {
						poly.getPath().insertAt(poly.getPath().length, event.latLng);
						toolMeasureUpdateInfo();
					}
				});
				google.maps.event.addListener(marker, 'rightclick', function(pt) {
					mkCurrent = mark;
					treeHighlightRecord(mark.idKind, mark.idFormRecord);
					if (poly == null) {
						divShowHide('divTools', true);
					}
				});
				google.maps.event.addListener(marker, 'mousemove', function(point) {
					document.getElementById('spanMapStatusBarCoordinates').innerHTML =
						point.latLng.lat().toFixed(7) + ":" + point.latLng.lng().toFixed(7);
				});
			}
		}
		if (blnIsFiltering) {
			filterUpdateCounter();
		}
		mapShowLoading(false);
	}

	function mapResize(event) {
		var blnSetFullscreen = (document.getElementById('btnFullscreen').className == 'btn' ? true : false);
		document.getElementById("mapcanvas").style.height = ($(window).height() - (blnSetFullscreen ? 117 : 0)) + "px";
	}
	
	function mapPanToarrMarkers(){
		if (arrMarkers.length == 0) return;
		var bounds = new google.maps.LatLngBounds();
		var path;
		for(i=0;i<arrMarkers.length;i++) {
			if (arrMarkers[i].idShapeType == 1) {
				bounds.extend(arrMarkers[i].getPosition());
			} else {
				path = arrMarkers[i].getPath();
				bounds.extend(path.getAt(0));
			}
		}
		map.fitBounds(bounds);
	}
	
	function mapPanAllRecords(){
		mapShowLoading(true);
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMPAR' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>'
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			var bounds = new google.maps.LatLngBounds(
				new google.maps.LatLng(arrResult['dblLatSW'], arrResult['dblLngSW']),
				new google.maps.LatLng(arrResult['dblLatNE'], arrResult['dblLngNE'])
			);
			map.fitBounds(bounds);
			mapShowLoading(false);
		});
	}
	
	function mapPolygonChangeOpacity() {
		var intMapPolygonsOpacity = parseInt(document.getElementById('intMapPolygonsOpacity').value)/100;
		// Circle from Filter By Radius
		if (poly) {
			//poly.setOptions({fillOpacity:intMapPolygonsOpacity});
		}
		// Buffers
		for (i=0;i<arrBuffers.length;i++) {
			arrBuffers[i].setOptions({fillOpacity:intMapPolygonsOpacity});
		}
		// Polylines
		for(i=0;i<arrMarkers.length;i++) {
			if (arrMarkers[i].idShapeType == 2) {
				arrMarkers[i].setOptions({strokeOpacity:intMapPolygonsOpacity});
			} else if (arrMarkers[i].idShapeType == 3) {
				arrMarkers[i].setOptions({fillOpacity:intMapPolygonsOpacity});
			}
		}
	}
	
	function mapShortcutKeysInitialize(blnCreate) {	
		$('#mapcanvas').unbind("keyup");
		if (blnCreate) {
			$('#mapcanvas').keyup(function(event) {
				if ((document.getElementById("toolSearchRadius") === document.activeElement) || (document.getElementById("txtMapSearch") === document.activeElement)) { return;}
				switch(event.which) {
					case 27: // Esc - Close panels
						divShowHide('divInfo', false);
						divShowHide('divTree', false);
						divShowHide('divTools', false);
						toolMeasureCreateDestroy(false);
						toolFilterByAreaCreateDestroy(false);
						toolFilterByRadiusCreateDestroy(false);
						toolFilterFormRecordsCreateDestroy(false);
						toolHeatmapCreateDestroy(false);
						toolImageOverlayCreateDestroy(false);
						toolFlushMapCreateDestroy(false);
						toolBufferCreateDestroy(false);
						toolIBGECreateDestroy(false);
						mapRecordsLoad();
						progressCancel();
						break;
					case 82: 
						// Alt + R - Show Records Tree
						if (event.altKey) {
							divShowHide('divTools', false);
							divShowHide('divTree', true);
						} else {
						// R - Users Routes
						<? if ($user->intCountUserPosition($arrProject['idProject']) > 0) { ?>
							toolsAction('UR');
						<? } ?>
						}
						break;
					case 84: 
						// Alt + T - Show Tools
						if (event.altKey) {
							divShowHide('divTree', false);
							divShowHide('divTools', true);
						} else {
						// T - Insert Map Toponymy
						<? if ($arrUser['idUser'] > 0) { ?>
							toolsAction('MTI');
						<? } ?>
						}
						break;
					case 46: // Delete - Delete Record
						if (mkCurrent.idToponymy) {
							toponymyDelete(mkCurrent);
						} else {
							toolsAction('RD');
						}
						break;
					case 49: // 1 - Filter Records
						toolsAction('MFR');
						break;
					case 50: // 2 - Filter by Area
						toolsAction('MSP');
						break;
					case 51: // 3 - Filter by Radius
						toolsAction('MSR');
						break;
					case 65: // A - Filter by Area Record
						toolsAction('RFA');
						break;
					case 66: // B - Buffer
						toolsAction('MBF');
						break;
					case 67: // C - Change Color Record
						toolsAction('RCC');
						break;
					case 68: // D - Measure Distances
						toolsAction('MMD');
						break;
					case 69: // E - Edit Record
						toolsAction('RE');
						break;
					case 70: // F - Flush Map
						toolsAction('MFM');
						break;
					case 72: // H - Heat Map
						toolsAction('MHM');
						break;
					case 76: // L - Map Zoom All Records
						toolsAction('MPA');
						break;
					case 77: // M - Center Map into Coordinates
						toolsAction('MCC');
						break;
					case 79: // O - Overlay Image
						toolsAction('MIO');
						break;
					case 80: // P - Print Record
						toolsAction('RP');
						break;
					case 90: // Z - Zoom to Poly Extent
						toolsAction('RZE');
						break;
				}
			});
		} else {
			$('#mapcanvas').keyup(function(event) {
				switch(event.which) {
					case 27: // Esc - Close panels
						divShowHide('divInfo', false);
						divShowHide('divTree', false);
						divShowHide('divTools', false);
						toolMeasureCreateDestroy(false);
						toolFilterByAreaCreateDestroy(false);
						toolFilterByRadiusCreateDestroy(false);
						toolFilterFormRecordsCreateDestroy(false);
						toolHeatmapCreateDestroy(false);
						toolImageOverlayCreateDestroy(false);
						toolFlushMapCreateDestroy(false);
						toolBufferCreateDestroy(false);
						toolIBGECreateDestroy(false);
						mapRecordsLoad();
						progressCancel();
						break;
				}
			});
		}
	}
	
	function mapExportShowModal(strExtension) {
		toolMeasureCreateDestroy(false);
		toolFilterByAreaCreateDestroy(false);
		toolFilterByRadiusCreateDestroy(false);
		toolFilterFormRecordsCreateDestroy(false);
		toolHeatmapCreateDestroy(false);
		toolImageOverlayCreateDestroy(false);
		toolFlushMapCreateDestroy(false);
		//toolBufferCreateDestroy(false);
		toolIBGECreateDestroy(false);
		document.getElementById("spanModalMapExportDownload").innerHTML = '';
		document.getElementById("hidMapExportExtension").value = strExtension;
		document.getElementById("spanModalExportExtension").innerHTML = strExtension;
		document.getElementById("trMapExportPNGFinishing").style.display = (strExtension == 'PNG' ? 'table-row' : 'none');
		document.getElementById("trMapExportResolution").style.display = ((strExtension == 'PNG' || strExtension == 'RS2') ? 'table-row' : 'none');
		document.getElementById("trMapExportRS2LagendsAsID").style.display = (strExtension == 'RS2' ? 'table-row' : 'none');
		document.getElementById("modalMapExport").style.display = "block";
		mapExportTypeUpdate();
	}
	
	function mapExportHideModal() {
		if (poly != null) poly.setMap(null);
		poly == null;
		map.setOptions({draggableCursor:'pointer'});
		document.getElementById("modalMapExport").style.display = "none";
		$('#btnModalMapExportProcess').button('reset');
	}
	
	function mapExportTypeUpdate(){
		var intType = document.getElementById("rbMapExportType1").checked ? 1 : 2;
		document.getElementById("trMapExportCoordinates1").style.display = (intType == 1 ? 'none' : 'table-row');
		document.getElementById("trMapExportCoordinates2").style.display = document.getElementById("trMapExportCoordinates1").style.display;
		document.getElementById("trMapExportCoordinates3").style.display = document.getElementById("trMapExportCoordinates1").style.display;
		if (intType == 1) {
			if (poly != null) poly.setMap(null);
			poly == null;
			map.setOptions({draggableCursor:'pointer'});
		} else {
			if (poly != null) poly.setMap(null);	
			poly = new google.maps.Rectangle({strokeWeight: 3, fillColor: '#FF0000', fillOpacity: 0.1, editable: true, bounds: map.getBounds(), map: map});
			map.setOptions({draggableCursor:'crosshair'});
			google.maps.event.addListener(poly, 'bounds_changed', function (){ mapExportUpdateBBFields()});
			mapExportUpdateBBFields();
		}
	}
		
	function mapExportUpdateBBFields() {
		var mapBoundsNE = poly.getBounds().getNorthEast();
		var mapBoundsSW = poly.getBounds().getSouthWest();
		document.getElementById("txtMapExportLatSW").value = mapBoundsSW.lat().toFixed(7);
		document.getElementById("txtMapExportLngSW").value = mapBoundsSW.lng().toFixed(7);
		document.getElementById("txtMapExportLatNE").value = mapBoundsNE.lat().toFixed(7);
		document.getElementById("txtMapExportLngNE").value = mapBoundsNE.lng().toFixed(7);
		mapExportUpdateInfoBounds(true);
	}
	
	function mapExportUpdateBBRectangle(){
		var bounds = new google.maps.LatLngBounds(
			new google.maps.LatLng(document.getElementById('txtMapExportLatSW').value, document.getElementById('txtMapExportLngSW').value),
			new google.maps.LatLng(document.getElementById('txtMapExportLatNE').value,document.getElementById('txtMapExportLngNE').value)
		);
		poly.setBounds(bounds);
		mapExportUpdateInfoBounds();
	}

	function mapExportUpdateBBByPolygon(marker) {
		if ((document.getElementById("modalMapExport").style.display != "none") && (document.getElementById("chkMapExportPNGFinishingMask").checked)) {
			var bounds = mapPolygonGetBounds(marker);
			poly.setBounds(bounds);
			map.fitBounds(bounds);
			mapExportUpdateBBFields();
		}
	}
	
	function mapPolygonGetBounds(polygon) {
	    var bounds = new google.maps.LatLngBounds()
    	polygon.getPath().forEach(function(element,index){bounds.extend(element)})
	    return bounds
	}

	function mapExportUpdateInfoBounds(blnEvalResolution) {
		var blnEvalResolution = blnEvalResolution ? blnEvalResolution : false;
		var strExt = document.getElementById("hidMapExportExtension").value.toLowerCase();
		if ((strExt == 'shp') || (strExt == 'kml')) {
			document.getElementById("tdMapExportInfoDim").innerHTML = 'Datum WGS 1984';
		} else {
			intMaxMapDimension = 5000;
			var bounds = poly.getBounds();
			var ptSE = new google.maps.LatLng(bounds.getSouthWest().lat(), bounds.getNorthEast().lng());
			var path = new google.maps.MVCArray;
			path.insertAt(path.length, bounds.getNorthEast());
			path.insertAt(path.length, ptSE);
			var dblHeightMts = google.maps.geometry.spherical.computeLength(path);
			var path2 = new google.maps.MVCArray;
			path2.insertAt(path2.length, bounds.getSouthWest());
			path2.insertAt(path2.length, ptSE);
			var dblWidthMts = google.maps.geometry.spherical.computeLength(path2);
			//var dblHeightMts = google.maps.geometry.spherical.computeDistanceBetween(new google.maps.LatLng(bounds.getNorthEast()), new google.maps.LatLng(bounds.getSouthEast()));
			//var dblWidthMts = google.maps.geometry.spherical.computeDistanceBetween(new google.maps.LatLng(bounds.getSouthWest()), new google.maps.LatLng(bounds.getSouthEast()));	
			if (blnEvalResolution) {
				var dblGreaterDimMts = Math.max(dblWidthMts, dblHeightMts);
				var intResolutionIdeal = Math.ceil(dblGreaterDimMts/intMaxMapDimension);
				document.getElementById('intMapExportResolution').value = intResolutionIdeal;
				document.getElementById('intMapExportResolution').min = intResolutionIdeal;
			}
			var intResolution = document.getElementById('intMapExportResolution').value;
			var intWidthPixels = Math.floor(dblWidthMts/intResolution);
			var intHeightPixels = Math.floor(dblHeightMts/intResolution);
			document.getElementById('tdMapExportInfoDim').innerHTML = 
				dblWidthMts.toFixed(2) + 'm X ' + dblHeightMts.toFixed(2) + 'm' +
				'<BR>' + intWidthPixels + 'px X ' + intHeightPixels + 'px [Res. ' + intResolution + ' m/px]';
		}
	}
	
	function mapExportProcess(){
		if (! blnEmailCheck()) return;
		showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 1);
		$('#btnModalMapExportProcess').button('loading');
		var strExtension = document.getElementById("hidMapExportExtension").value;
		document.getElementById("spanModalMapExportDownload").innerHTML = '';
		var strJSONFormRecords = 'ALL';
		var intType = document.getElementById("rbMapExportType1").checked ? 1 : 2;
		if (intType == 2) {
			var rectBBNE = poly.getBounds().getNorthEast();
			var rectBBSW = poly.getBounds().getSouthWest();
			var arrFormRecords = [];
			var p, path;
			//Get visible shapes inside rectangle and put into array
			for (var i=0; i<arrMarkers.length; i++) {
				if (! arrMarkers[i].getVisible()) continue;
				if (arrMarkers[i].idShapeType == 1) {
					p = arrMarkers[i].getPosition();
					if (
						p.lat() >= rectBBSW.lat() && 
						p.lat() <= rectBBNE.lat() && 
						p.lng() <= rectBBNE.lng() &&
						p.lng() >= rectBBSW.lng()
					) {
						arrFormRecords.push({'idFormRecord' : arrMarkers[i].idFormRecord, 'idForm' : arrMarkers[i].idForm, 'idShapeType' : arrMarkers[i].idShapeType, 'strCustomMarkerRGBColor' : arrMarkers[i].strCustomMarkerRGBColor, 'strMarkerFullPath' : arrMarkers[i].strMarkerFullPath});
					}
				} else {
					path = arrMarkers[i].getPath();
					for(var j = 0; j < path.getLength(); j++) {
						p = path.getAt(j);
						if (
							p.lat() >= rectBBSW.lat() && 
							p.lat() <= rectBBNE.lat() && 
							p.lng() <= rectBBNE.lng() &&
							p.lng() >= rectBBSW.lng()
						) {
							arrFormRecords.push({'idFormRecord' : arrMarkers[i].idFormRecord, 'idForm' : arrMarkers[i].idForm, 'idShapeType' : arrMarkers[i].idShapeType, 'strCustomMarkerRGBColor' : arrMarkers[i].strCustomMarkerRGBColor});
							break;
						}
					}
				}
			}
			strJSONFormRecords = JSON.stringify(arrFormRecords);
			strJSONFormRecords = strChangeHash(strJSONFormRecords);
		}
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMG' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>' +
				'&strEmail=' + strReportEmail +
				'&strExtension=' + strExtension + 
				'&blnFinishingGoogleMaps=' + (document.getElementById("chkMapExportPNGFinishingGoogleMaps").checked ? 1 : 0) + 
				'&blnFinishingLegends=' + (document.getElementById("chkMapExportPNGFinishingLegends").checked ? 1 : 0) + 
				'&blnFinishingGrid=' + (document.getElementById("chkMapExportPNGFinishingGrid").checked ? 1 : 0) + 
				'&idFinishingMaskFormRecord=' + (document.getElementById("chkMapExportPNGFinishingMask").checked ? document.getElementById("spanMapExportPNGFinishingMaskFormRecord").innerHTML : 0) + 
				'&blnRS2LegendID=' + (document.getElementById("chkMapExportRS2LagendsAsID").checked ? 1 : 0) + 
				'&intMapPolygonsOpacity=' + document.getElementById('intMapPolygonsOpacity').value +
				'&strMapType=' + map.getMapTypeId() + 
				'&intResolution=' + document.getElementById('intMapExportResolution').value +
				'&idBufferForm=' + (document.getElementById('iMBF').style.display == 'inline' ? document.getElementById('cmbBufferForm').value : 0) +
				'&intBufferRadius=' + (document.getElementById('iMBF').style.display == 'inline' ? document.getElementById('intBufferRadius').value : 0) +
				'&dblLatSW=' + (intType == 1 ? '-90' : rectBBSW.lat()) + 
				'&dblLngSW=' + (intType == 1 ? '-180' : rectBBSW.lng()) + 
				'&dblLatNE=' + (intType == 1 ? '90' : rectBBNE.lat()) + 
				'&dblLngNE=' + (intType == 1 ? '180' : rectBBNE.lng()),
			type:"post",
			timeout:false,
			data:{strJSONFormRecords:strJSONFormRecords},
			complete:function() {
				$('#btnModalMapExportProcess').button('reset');
				showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 2);
				var response 	= result.responseText;
				var retorno 	= JSON.parse(response);
				document.getElementById("spanModalMapExportDownload").innerHTML = '';
				for (var i=0; i<retorno.length; i++){
					var arrFile = retorno[i]['strFilePath'].split('.');
					document.getElementById("spanModalMapExportDownload").innerHTML += '<span class="btn btn-success" onClick="window.location=\'output.php?strName=' + retorno[i]['strFilePath'].toLowerCase() + '&strFileName=' + retorno[i]['strFilePathTMP'] + '\';"><i class="icon-download icon-white"></i> .' + arrFile[1] + '</span> ';
				}
			}
		});
	}
	
	function mapSelectedRecordsAction(strAction) {
		if (strAction == 'TR') {			// Change Records Owner
			document.getElementById('cmbFilteredUsers').style.display = 'none';
			document.getElementById('strNewValue').value = document.getElementById('cmbFilteredUsers').value;
		} else if (strAction == 'CC') {		// Change Color
			document.getElementById('strNewValue').value = document.getElementById('strRGBSelected').value;
		} else if (strAction == 'CI') {		// Change Icon
			var icon = new google.maps.MarkerImage(document.getElementById('strNewValue').value, null, null, null, new google.maps.Size(intIconMaxSize, intIconMaxSize, 'px' , 'px'));
		} else if (strAction == 'DEL') {	// Delete
	        var blnDelete = confirm('<? echo $_SESSION['strHomeToolsRecordDeleteConfirm']; ?>');
    	    if (! blnDelete) return;
		}
		mapShowLoading(true);
		var arrFormRecords = [];
		for (var i=0; i<arrMarkers.length; i++) {
			arrFormRecords.push({'idFormRecord' : arrMarkers[i].idFormRecord, 'i' : i});
		}
		var strJSONFormRecords = JSON.stringify(arrFormRecords);
		strJSONFormRecords = strChangeHash(strJSONFormRecords);
		var result = $.ajax({
			url: 'ajax.php?chrAction=HSRA' + 
				'&strAction=' + strAction + 
				'&strNewValue=' + encodeURIComponent(document.getElementById('strNewValue').value),
			type : "post",
			timeout : false,
			data : {strJSONFormRecords:strJSONFormRecords},
			complete : function() {
				for (var i=0; i<arrFormRecords.length; i++) {
					var intIndex = arrFormRecords[i]['i'];
					var mk = arrMarkers[intIndex];
					if (! mk) continue;
					if (strAction == 'CC') {
						if (mk.idShapeType > 1) {
							var strRGB = document.getElementById('strNewValue').value;
							if (mk.idShapeType == 2) {
								mk.setOptions({strokeColor: '#' + strRGB});
							} else if (mk.idShapeType == 3) {
								mk.setOptions({strokeColor: '#' + strRGB, fillColor: '#' + strRGB});
							}
						}
					} else if (strAction == 'CI') {
						if (mk.idShapeType == 1) {
							mk.setIcon(icon);
						}
					} else if (strAction == 'CI0') {
						if (mk.idShapeType == 1) {
							mk.setIcon(new google.maps.MarkerImage(mk.strFormMarkerFullPath, null, null, null, new google.maps.Size(intIconMaxSize, intIconMaxSize, 'px' , 'px')));
						}
					}
				}
				if (strAction == 'DEL') {
					filterUpdateCounter(0);
					treeInitialize(true);
				}
				//showSuccessAlert();
				mapShowLoading(false);
			}
		});
	}


	function blnEmailCheck() {
		if (strReportEmail.indexOf('@') < 0) {
			strPrompt = prompt('<? echo $_SESSION['strHomeEmailPrompt']; ?>:', strReportEmail);
			if (strPrompt) {
				if (strPrompt.indexOf('@') >= 0) {
					strReportEmail = strPrompt;
					return true;
				} else {
					showInfoAlert("<? echo $_SESSION['strGlobalInvalidEmail'] . '. ' . $_SESSION['strGlobalOperationCanceled']; ?>");
					return false;
				}
			} else {
				return false;
			}
		}
		return true;
	}

	function reportProcess(strExtension){
		if (! blnEmailCheck()) return;
		showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 1);
		var blnAllRecords = ! blnIsFiltering;
		var arrFormRecords = [];
		showLoadingFullScreen(true);
		if (! blnAllRecords) {
			for (var i=0; i<arrMarkers.length; i++) {
				if (! arrMarkers[i].getVisible()) continue;
				arrFormRecords.push({'idFormRecord' : arrMarkers[i].idFormRecord, 'idForm' : arrMarkers[i].idForm, 'dblDistanceFromCenterMts' : arrMarkers[i].dblDistanceFromCenterMts, 'dblLatitude' : arrMarkers[i].dblLatitude, 'dblLongitude' : arrMarkers[i].dblLongitude});
			}
		}
		var strJSONFormRecords = JSON.stringify(arrFormRecords);
		strJSONFormRecords = strChangeHash(strJSONFormRecords);
		var result = $.ajax({
			url: 'ajax.php?chrAction=HRG' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>' +
				'&strEmail=' + strReportEmail +
				'&strExtension=' + strExtension +
				'&blnAllRecords=' + (blnAllRecords ? '1' : '0') +
				'&dblLatC=' + ((document.getElementById('liMSR').className == 'liSelected' && poly != null) ? poly.getCenter().lat() : "0") +
				'&dblLngC=' + ((document.getElementById('liMSR').className == 'liSelected' && poly != null) ? poly.getCenter().lng() : "0") +
				'&intMapPolygonsOpacity=' + document.getElementById('intMapPolygonsOpacity').value +
				'&strMapType=' + map.getMapTypeId(),
			type:"post",
			timeout:false,
			data:{strJSONFormRecords:strJSONFormRecords },
			complete:function() {
				showLoadingFullScreen(false);
				showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 2);
				if ((strExtension == 'DISTANCES') && ((blnAllRecords) || (arrMarkers.length >= <? echo $report->intTableDistanceLimit; ?>))) {
					showInfoAlert("<? echo $_SESSION['strReportDistanceTableLimitWarn'] . ': '. $report->intTableDistanceLimit . ' ' . strtolower($_SESSION['strGlobalRecords']); ?>");
				}
				var response 	= result.responseText;
				var arrResponse = response.split("|");
				response = arrResponse[1];
				var retorno 	= JSON.parse(response);
				if ((strExtension == 'KML') || (strExtension == 'XLS')) {
					window.location='output.php?strName=' + retorno['strFilePath'].toLowerCase() + '&strFileName=' + retorno['strFilePathTMP'];
				} else {
					window.open(retorno['strFilePathTMP']);
				}
			}
		});
	}

	function progressBarUpdate(intCurrent) {
		$('#btnProgressCancel').button('reset');
		var progress = document.getElementById('divProgress');
		if (! intCurrent) {
			progress.style.display = 'none';
			return;
		}
		var arrProgress = intCurrent.split("/");
		intCurrent = arrProgress[0];
		var intTotal = arrProgress[1];
		if ((intCurrent >= 0) && (intCurrent <= intTotal)) {
			progress.style.display = 'block';
			var progressBar = document.getElementById('divProgressBar');
			var progressLabel = document.getElementById('divProgressLabel');
			var intWidth = intTotal > 0 ? (intCurrent/intTotal*100).toFixed(2) : 0;
			progressBar.style.width = intWidth + '%';
			progressLabel.innerHTML = numberWithThousands(intCurrent) + '/' + numberWithThousands(intTotal) + ' (' + intWidth + '%)';
		}
	}
	
	function progressCancel(){
		if (xhr) {
			xhr.abort();
		}
		showLoadingFullScreen(false);
		progressBarUpdate();
	}
	
	function markerChangeColor(strRGB){
		if (mkCurrent.idShapeType == 2) {
			mkCurrent.setOptions({strokeColor: '#' + strRGB});
		} else if (mkCurrent.idShapeType == 3) {
			mkCurrent.setOptions({strokeColor: '#' + strRGB, fillColor: '#' + strRGB});
		}
		$.ajax({url: 'ajax.php?chrAction=HRCC&idFormRecord=' + mkCurrent.idFormRecord + '&strCustomMarkerRGBColor=' + strRGB});
		showSuccessAlert();
	}
	
	function markerGetPolyBounds(poly) {
		var bounds = new google.maps.LatLngBounds();
		var path = poly.getPath();
		for (var i = 0; i < path.getLength(); i++) {
			bounds.extend(path.getAt(i));
		}
		return bounds;
	}
	
	function markerSetToolButtonsVisibility(marker) {
		document.getElementById('liR').style.display = (marker != null ? 'block' : 'none');
		document.getElementById('liRZE').style.display = (marker != null ? 'block' : 'none');
		document.getElementById('liRP').style.display = (marker != null ? 'block' : 'none');
		document.getElementById('liRFA').style.display = ((marker != null) && (marker.idShapeType == 3) ? 'block' : 'none');
		document.getElementById('liRCC').style.display = ((marker != null) && (marker.idShapeType != 1) && (<? echo ($arrUser['idUserLevel'] ? $arrUser['idUserLevel'] : "0"); ?> > 1) ? 'block' : 'none');
		document.getElementById('liRE').style.display = ((marker != null) && ((marker.idUser == <? echo ($arrUser['idUser'] ? $arrUser['idUser'] : "0"); ?>) || (<? echo ($arrUser['idUserLevel'] ? $arrUser['idUserLevel'] : "0"); ?> == 4)) ? 'block' : 'none');
		document.getElementById('iInfoEdit').style.display = document.getElementById('liRE').style.display;
		document.getElementById('liRD').style.display = (marker != null && ((marker.idUser == <? echo ($arrUser['idUser'] ? $arrUser['idUser'] : "0"); ?>) || (<? echo ($arrUser['idUserLevel'] ? $arrUser['idUserLevel'] : "0"); ?> == 4)) ? 'block' : 'none');		
		document.getElementById('iInfoDelete').style.display = document.getElementById('liRD').style.display;
	}
	
	function pathReduceVertexs(path) {
		var intPLength = path.getLength();
		var intStep = Math.ceil(intPLength/intMaxVertexPathPoly);
		var i = intPLength;
		while (i > 0) {
			for (var j=0; j<intStep; j++) {
				path.removeAt(i);
				i--;
			}
			i--;
		}
		return path;
	}
	
	function arrMarkersSearch(idKind, id) {
		for (var i=0; i<arrMarkers.length; i++) {
			if ((arrMarkers[i].idKind == idKind) && (arrMarkers[i].id == id)) {
				return i;
			}
		}
		return -1;
	}
	
	function arrMarkersSetVisibility(idForm, idFormRecord, blnVisible) {
		var intVisibleMarkers = 0;
		for (var i=0; i<arrMarkers.length; i++) {
			if ((arrMarkers[i].idForm == idForm) && ((arrMarkers[i].idFormRecord == idFormRecord) || (idFormRecord == 0))) {
				arrMarkers[i].setVisible(blnVisible == 1 ? true : false);
				if (idFormRecord > 0) return;
			}
			if (arrMarkers[i].getVisible()) intVisibleMarkers++;
		}
		// Update Filter Results Counter
		filterUpdateCounter(intVisibleMarkers);
		
		for (var i=0; i<arrBuffers.length; i++) {
			if (arrBuffers[i].idForm == idForm) {
				arrBuffers[i].setVisible(blnVisible == 1 ? true : false);
			}
		}	
	}
	
	function arrMarkersDelete(idKind, id) {
		for (var i=0; i<arrMarkers.length; i++) {
			if ((arrMarkers[i].idKind == idKind) && ((arrMarkers[i].id == id) || (id == 0))) {
				arrMarkers = arrMarkers.slice(i);
				if (id > 0) return;
			}
		}
	}
	
	function arrMarkerBlink(marker, intTimes) {
		mkCurrent = marker;
		var blnVisible = mkCurrent.getVisible();
		var intTimes = intTimes ? intTimes : 5;
		var intMSec = 200;
		if (mkCurrent.idShapeType == 1) {
			mkCurrent.setZIndex(99999);
			mkCurrent.setAnimation(google.maps.Animation.DROP); // BOUNCE or DROP
			//setTimeout("mkCurrent.setAnimation(null);", 3000);
		} else {
			mkCurrent.setVisible(false);
			for (var j=1; j<=intTimes; j++) {
				setTimeout("mkCurrent.setVisible(" + (j%2 == 1 ? "true" : "false") + ")", j*intMSec);
			}
			setTimeout("mkCurrent.setVisible(" + blnVisible + ")", (intTimes+1)*intMSec);
		}
		markerSetToolButtonsVisibility(mkCurrent);
	}
	
	function arrMarkerCenterMap(i) {
		map.panTo(new google.maps.LatLng(arrMarkers[i].dblLatitude, arrMarkers[i].dblLongitude));
	}
	
	function filterUpdateCounter(intFiltered) {
		if (intFiltered == null) {
			var intFiltered = 0;
			for (var i=0; i<arrMarkers.length; i++) {
				if (arrMarkers[i].getVisible()) intFiltered++;
			}
		}
		document.getElementById("spanFilteredActionsSelectedCount").innerHTML = intFiltered;
	}
	
	function treeInitialize(blnUpdateMap) {
		var blnUpdateMap = (blnUpdateMap != null ? blnUpdateMap : false);
		if (blnUpdateMap) {
			mapClearAllObjects();
		}
		$("#divTree").resizable({handles: "e"});
		document.getElementById("spanTree").innerHTML = '<div style="text-align:center"><img src="img/loading.gif"></div>';
		var result = $.ajax({
			url: 'ajax.php?chrAction=HTVL' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>'
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			document.getElementById("spanTree").innerHTML = '';
			tree = new dhtmlXTreeObject("spanTree","100%","95%", 0);
			tree.setImagePath("js/treeview/imgs/csh_dhx_skyblue/");
			tree.setSkin("skyblue");
			tree.enableTreeImages(true);
			tree.setOnCheckHandler(treeOnCheck);
			tree.enableThreeStateCheckboxes(true);
			tree.enableHighlighting(true);
			tree.enableCheckBoxes(1);
			tree.attachEvent("onClick",function(id){ treeOnClick(id)});
			tree.loadXMLString(arrResult['strXML']);
			tree.closeAllItems();
			document.getElementById("spanTreeFormRecordsCount").innerHTML = arrResult['intRecords'];
			if (blnUpdateMap) {
				mapRecordsLoad();
			}
		});
	}
	
	function treeDeleteItem(marker){
		var idItem = marker.idKind + ':' + marker.id;
		var strFormName = tree.getItemText(marker.idForm);
		var intFormRecordsCount = strFormName.substring(strFormName.indexOf('(')+1,strFormName.indexOf(')'));
		intFormRecordsCount--;
		strFormName = strFormName.substring(0, strFormName.indexOf('(')) + '(' + intFormRecordsCount + ')';
		tree.setItemText(marker.idForm, strFormName);
		tree.deleteItem(idItem, true);
	}
	
	function treeCenterMap(idItem) {
		if (map == null) return;
		var dblLatitude = tree.getAttribute(idItem, "dblLatitude");
		var dblLongitude = tree.getAttribute(idItem, "dblLongitude");
		if (dblLatitude) {
			map.panTo(new google.maps.LatLng(dblLatitude, dblLongitude));
		}
	}
	
	function treeOnCheck(idItem, blnChecked) {
		var idForm = tree.getAttribute(idItem, "idForm");
		var idFormRecord = tree.getAttribute(idItem, "idFormRecord");
		if (isNaN(idFormRecord)) { idFormRecord = 0; }
		arrMarkersSetVisibility(idForm, idFormRecord, blnChecked);
	}
	
	function treeOnClick(idItem) {
		var idFormRecord = tree.getAttribute(idItem, "idFormRecord");
		if ((! isNaN(idFormRecord)) && (idFormRecord > 0)) { 
			treeCenterMap(idItem);
			infoLoad(idFormRecord);
			var idKind = tree.getAttribute(idItem, "idKind");
			var i = arrMarkersSearch(idKind, idFormRecord);
			if (i >= 0) {
				arrMarkerBlink(arrMarkers[i]);
			} else {
				if (! mkCurrent) { mkCurrent = arrMarkers[0]; }
				if (mkCurrent != null) {
					mkCurrent.idFormRecord = idFormRecord;
					mkCurrent.idShapeType = tree.getAttribute(idItem, "idShapeType");
					mkCurrent.idUser = tree.getAttribute(idItem, "idUser");
					markerSetToolButtonsVisibility(mkCurrent);
				}
			}
			document.getElementById("mapcanvas").focus();
		}
	}
	
	function treeHighlightRecord (idKind, idFormRecord){
		var idTreeItem = idKind + ':' + idFormRecord;
		if (tree.getIndexById(idTreeItem) != null) {
			tree.selectItem(idTreeItem, false, false);
			tree.focusItem(idTreeItem);
		}
	}

	function infoInitialize() {
		$("#divInfo").draggable({handle:"#divInfoTitle"});
		$("#divInfo").resizable({handles: "all", ghost: true});
	}
	
	function infoResize() {
		blnMaximize = document.getElementById("iInfoResize").className == 'icon-resize-full icon-white';
		document.getElementById("iInfoResize").className = 'icon-resize-' + (blnMaximize ? 'small' : 'full') + ' icon-white';
		document.getElementById("divInfo").style.left = (blnMaximize ? "0px" : "20%");
		document.getElementById("divInfo").style.width = (blnMaximize ? "100%" : "70%");
		document.getElementById("divInfo").style.height = (blnMaximize ? "100%" : "30%");
		document.getElementById("divInfo").style.top = (blnMaximize ? "0px" : "60%");
	}
	
	function infoLoad(idFormRecord) {
		divShowHide('divInfo', true);
		document.getElementById("tblInfoContent").innerHTML = '<div style="text-align:center"><img src="img/loading.gif"></div>';
		var result = $.ajax({
			url: 'ajax.php?chrAction=HRLI&idUser=<? echo ($arrUser['idUser'] ? $arrUser['idUser'] : 0); ?>&idFormRecord=' + idFormRecord
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			if (arrResult['blnExists']) {
				document.getElementById("tblInfoContent").innerHTML = arrResult['strInfo'];
				if (mkCurrent != null) {
					mkCurrent.idFormRecord = idFormRecord;
				}
			} else {
				showInfoAlert("<? echo $_SESSION['strHomeInfoRecordAlreadyDeleted']; ?>");
				document.getElementById("tblInfoContent").innerHTML = '';
				divShowHide('divInfo', false);
			}
		});
	}
	
	function toolUserToponymyCreateDestroy(blnCreate) {
		mapClearAllToponymys();
		if (blnCreate) {
			toponymysLoad();
		} else {
			divShowHide('divTools', false);
		}
	}

	function toponymysLoad() {
		mapShowLoading(true);
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMTS&idProject=<? echo $arrProject['idProject']; ?>'
		}).always(function() {
            var arrResult = JSON.parse(result.responseText);
			for (var i=0;i<arrResult.length;i++) {
				toponymyInsertMarker(arrResult[i]['idToponymy'], arrResult[i]['idUser'], arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude'], arrResult[i]['strToponymy']);
			}			
			mapShowLoading(false);
		});
	}
	
	function toponymyInsertUpdate(marker, idUser, idToponymy, dblLatitude, dblLongitude, strToponymy, blnPrompt) {
		if (idUser != <? echo $arrUser['idUser']; ?>) return;
		if (blnPrompt) {
			var strToponymy = prompt('<? echo $_SESSION['strHomeToolsItemMapToponymyPrompt']; ?>:', strToponymy);
			if (! strToponymy) return;
		}
		strToponymy = replaceAll(strToponymy,"'",'');
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMT' + (idToponymy >= 0 ? 'U' : 'I') +
					'&idUser=<? echo $arrUser['idUser']; ?>' +
					'&idToponymy=' + idToponymy + 
					'&dblLatitude=' + dblLatitude +
					'&dblLongitude='+ dblLongitude +
					'&strToponymy=' + encodeURIComponent(strToponymy)
		}).always(function() {
			if ((idToponymy < 0) || (blnPrompt)) {
				if (marker) {
					marker.setMap(null);
				}
				if (idToponymy < 0) {
		            var arrResult 	= JSON.parse(result.responseText);
					idToponymy = arrResult['idToponymy'];
				}
				toponymyInsertMarker(idToponymy, idUser, dblLatitude, dblLongitude, strToponymy);
			}
		});
	}
	
	function toponymyInsertMarker(idToponymy, idUser, dblLatitude, dblLongitude, strToponymy) {
		marker = new MarkerWithLabel({icon: new google.maps.MarkerImage('img/blank.png', null, null, null, new google.maps.Size(1, 1, 'px' , 'px')), position: new google.maps.LatLng(dblLatitude, dblLongitude), draggable: (idUser == <? echo $arrUser['idUser']; ?> ? true : false), clickable: true, map: map, labelContent: strToponymy, labelAnchor: new google.maps.Point(25,0), labelClass: "map-marker-label-autowidth" + (idUser == <? echo $arrUser['idUser']; ?> ? " map-marker-label-autowidth-green" : ""), labelStyle: {opacity: 1}, zIndex:4, title: (idUser == <? echo $arrUser['idUser']; ?> ? "<? echo $_SESSION['strHomeToolsItemMapToponymyRenameHint'] . '. \n' . $_SESSION['strHomeToolsItemMapToponymyMoveHint'] . '. \n' . $_SESSION['strHomeToolsItemMapToponymyDeleteHint']; ?>" : "")});
		marker.idUser = idUser;
		marker.idToponymy = idToponymy;
		marker.strToponymy = strToponymy;
		arrToponymy.push(marker);
		with ({mark: marker}) {
			google.maps.event.addListener(marker, 'dblclick', function() { 
				toponymyInsertUpdate(mark, mark.idUser, mark.idToponymy, mark.getPosition().lat(), mark.getPosition().lng(), mark.strToponymy, true);
			});
			google.maps.event.addListener(mark, "mousedown", function(event) {
				mkCurrent = mark;
			});
			google.maps.event.addListener(mark, 'dragend', function(event) {
				toponymyInsertUpdate(mark, mark.idUser, mark.idToponymy, mark.getPosition().lat(), mark.getPosition().lng(), mark.strToponymy, false);
			});
		}
	}

	function toponymyDelete(marker) {
		if (marker.idUser != <? echo $arrUser['idUser']; ?>) return;
		var blnDelete = confirm('<? echo $_SESSION['strHomeToolsItemMapToponymyConfirmDelete']; ?> "' + marker.strToponymy + '"?');
		if (! blnDelete) return;
		var result = $.ajax({url: 'ajax.php?chrAction=HMTD&idToponymy=' + marker.idToponymy})
		.always(function() {
			marker.setMap(null);
		});
	}
	
	function userPositionsLoad(idUser, dtDate) {
		mapShowLoading(true);
		mapClearAllUserPositions();
		var idUser = (idUser != null ? idUser : 0);
		var dtDate = (dtDate != null ? dtDate : '');
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUPS&idProject=<? echo $arrProject['idProject']; ?>&idUser=' + idUser + '&dtDate=' + dtDate
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			var iconPosition = new google.maps.MarkerImage('img/route-position.png', null, null, null, new google.maps.Size(8, 8, 'px' , 'px'));
			iconPosition.anchor = new google.maps.Point(4,4);
			var idUser;
			var bounds = new google.maps.LatLngBounds();
			for (var i=0;i<arrResult.length;i++) {
				if (idUser != arrResult[i]['idUser'] || i == arrResult.length-1) {
					// Inserting Marker into Start Point
					if (idUser != arrResult[i]['idUser']) {
						//marker = new MarkerWithLabel({icon: new google.maps.MarkerImage('img/route-start.png', null, null, null, new google.maps.Size(20, 20, 'px' , 'px')), position: new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']), draggable: false, map: map, labelContent: arrResult[i]['strEmail'], labelAnchor: new google.maps.Point(25,0), labelClass: "map-marker-label map-marker-label-user", labelStyle: {opacity: 1}, zIndex:4});
						marker = new google.maps.Marker({icon: new google.maps.MarkerImage('img/route-start.png', null, null, null, new google.maps.Size(intIconMaxSize, intIconMaxSize, 'px' , 'px')), position: new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']), draggable: false, map: map, zIndex:3});
						arrUserPositions.push(marker);
						idUser = arrResult[i]['idUser'];
						var path = new google.maps.MVCArray();
					}
					// Inserting Marker into Finish Point
					if (i > 0) {
						marker = new google.maps.Marker({icon: new google.maps.MarkerImage('img/route-finish.png', null, null, null, new google.maps.Size(intIconMaxSize, intIconMaxSize, 'px' , 'px')), position: new google.maps.LatLng(arrResult[i == arrResult.length - 1 ? arrResult.length - 1 : i - 1].dblLatitude, arrResult[i == arrResult.length - 1 ? arrResult.length - 1 : i - 1].dblLongitude), draggable: false, clickable: false, visible:true, map: map, zIndex:3});
						arrUserPositions.push(marker);
						marker = new google.maps.Polyline({strokeColor: getRandomColor(), strokeOpacity: 0.9, strokeWeight:2, visible: true, map: map, zIndex: 1, path: path});
						arrUserPositions.push(marker);
					}
				} else {
					marker = new MarkerWithLabel({icon: iconPosition, position: new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']), draggable: false, map: map, labelContent: arrResult[i]['strDate'] + ' (' + arrResult[i]['strEmailAbbreviated'] + ')', labelAnchor: new google.maps.Point(0,-5), labelClass: "map-marker-label", labelStyle: {opacity: 1}, zIndex:2});
					arrUserPositions.push(marker);
					var marker = new google.maps.Marker({icon: iconPosition, position: new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']), draggable: false, map: map, zIndex:2});
					arrUserPositions.push(marker);
				}
				bounds.extend(new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']));
				path.push(new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']));
			}
			if (arrResult.length > 0) {
				map.fitBounds(bounds);
				// Pan to First Position
				//map.panTo(new google.maps.LatLng(arrResult[0]['dblLatitude'], arrResult[0]['dblLongitude']));
			}
			mapShowLoading(false);
			document.getElementById("mapcanvas").focus();
		});
	}
	
	function userPositionsDelete(idUser, dtDate) {
		var dtDate = (dtDate != null ? dtDate : '');
		var blnDelete = confirm('<? echo $_SESSION['strHomeUserPositionDeleteConfirm']; ?> "' + (dtDate != '' ? dtDate : '<? echo $_SESSION['strGlobalAll']; ?>' )+ '"?');
		if (! blnDelete) return;
		mapShowLoading(true);
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUPD&idUser=' + idUser + '&dtDate=' + dtDate
		}).always(function() {
            if (result.responseText > 0) {
				var strId = 'spanUserRouteDate_' + idUser + '_' + dtDate;
				document.getElementById(strId).className = 'input-prepend btn-disabled';
				mapClearAllUserPositions();
				showInfoAlert("<? echo $_SESSION['strHomeUserPositionDeleted']; ?>");
            }
			mapShowLoading(false);
		});
	}
	
	function toolMeasureUpdateInfo() {
		var dblLength = google.maps.geometry.spherical.computeLength(poly.getPath());
		document.getElementById("spanMapStatusBarDistance").innerHTML = " [<? echo $_SESSION['strGlobalDistance']; ?>: "  + formatNumber(dblLength) + " m]";		
	}
	
	function toolUserPositionsCreateDestroy(blnCreate) {
		document.getElementById('iUR').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liUR').className = (blnCreate ? 'liSelected' : '');
		mapClearAllUserPositions();
		if (blnCreate) {
			userPositionsLoad();
			showInfoAlert("<? echo $_SESSION['strHomeToolsItemUserPositionsCloseTip'] . $_SESSION['strGlobalClickXDeactivate']; ?>");
		} else {
			divShowHide('divTools', false);
		}
	}
	
	function toolMeasureCreateDestroy(blnCreate) {
		document.getElementById('iMMD').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMMD').className = (blnCreate ? 'liSelected' : '');
		if (blnCreate) {
			if (poly == null) {
				poly = new google.maps.Polyline({strokeWeight: 3, strokeColor: '<? echo $strings->strSiteBaseColor; ?>', editable: true, map: map, path: new google.maps.MVCArray([]), zIndex:9999});
				map.setOptions({draggableCursor:'crosshair'});
				google.maps.event.addListener(map, 'click', function (event){
					poly.getPath().insertAt(poly.getPath().length, event.latLng);
					toolMeasureUpdateInfo();
				});
				google.maps.event.addListener(poly, 'rightclick', function(event) {
					var i = event.vertex;
					if (i !== undefined) poly.getPath().removeAt(i);
					toolMeasureUpdateInfo();
				});
				google.maps.event.addListener(poly.getPath(), 'insert_at', function(event) { toolMeasureUpdateInfo() });
				google.maps.event.addListener(poly.getPath(), 'set_at', function(event) { toolMeasureUpdateInfo() });
				google.maps.event.addListener(poly, 'mouseover', function(point) { toolMeasureUpdateInfo(); });
				google.maps.event.addListener(poly, 'mousemove', function(point) { toolMeasureUpdateInfo(); });
				showInfoAlert("<? echo $_SESSION['strHomeToolsItemMeasureDistancesCloseTip'] . $_SESSION['strGlobalClickXDeactivate']; ?>");
			}
		} else {
			if (poly) {
				poly.setMap(null);
				poly = null;
			}
			document.getElementById("spanMapStatusBarDistance").innerHTML = '';
			map.setOptions({draggableCursor:'pointer'});
			divShowHide('divTools', false);
		}
	}
	
	function toolFilterByPolygonArea(){
		if ((! mkCurrent) || (mkCurrent.idShapeType != 3)) {
			blnIsFiltering = false;
			showInfoAlert("<? echo $_SESSION['strHomeToolsRecordFilterAreaOnlyPolygon']; ?>");
			return;
		}
		blnIsFiltering = true;
		poly = mkCurrent;
		mapClearAllObjects();
		poly.setMap(map);
		toolFilterByAreaSearch();
		showInfoAlert("<? echo $_SESSION['strHomeToolsItemSearchByAreaCloseTip'] . $_SESSION['strGlobalClickXDeactivate']; ?>");
	}
	
	function toolFilterByAreaCreateDestroy(blnCreate, polygon) {
		document.getElementById('iMSP').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMSP').className = (blnCreate ? 'liSelected' : '');
		if (document.getElementById('btnMapSearchByArea')) {
			document.getElementById('btnMapSearchByArea').className = (blnCreate ? 'btn btn-primary' : 'btn');
		}
		blnIsFilteringByPolygonArea = polygon ? true : false;
		if (poly) {
			poly.setMap(null);
			poly = null;
		}
		if (blnCreate) {
			blnIsFiltering = true;
			var path = (blnIsFilteringByPolygonArea ? polygon.getPath() : new google.maps.MVCArray([]));			
			// If has too much vertexs, remove part
			if (path.getLength() > intMaxVertexPathPoly) {
				path = pathReduceVertexs(path);
			}
			poly = new google.maps.Polygon({strokeWeight: 3, strokeColor: '<? echo $strings->strSiteBaseColor; ?>', fillOpacity: 0.1, editable: (blnIsFilteringByPolygonArea ? false : true), map: map, path: path});
			if (! blnIsFilteringByPolygonArea) {
				map.setOptions({draggableCursor:'crosshair'});
				google.maps.event.addListener(map, 'click', function (event){
					poly.getPath().insertAt(poly.getPath().length, event.latLng);
					toolFilterByAreaSearch(); 
				});
				google.maps.event.addListener(poly, 'rightclick', function(event) {
					var i = event.vertex;
					if (i !== undefined) poly.getPath().removeAt(i);
					toolFilterByAreaSearch(); 
				});
				google.maps.event.addListener(poly.getPath(), 'insert_at', function(event) { toolFilterByAreaSearch(); });
				google.maps.event.addListener(poly.getPath(), 'set_at', function(event) { toolFilterByAreaSearch(); });
			}
			mapClearAllObjects();
			blnIsFiltering = true;
			toolFilterByAreaSearch();
			divShowHide('divTree', false);
			showInfoAlert("<? echo $_SESSION['strHomeToolsItemSearchByAreaCloseTip']; ?>");
		} else {
			document.getElementById('cmbFilteredUsers').style.display = 'none';
			blnIsFiltering = false;
			divShowHide('divTools', false);
		}
		document.getElementById('divFilteredActions').style.display = (blnCreate ? 'inline-block' : 'none');
	}	
	
	function toolFilterByAreaSearch() {
		var path = poly.getPath();
		// If has too much vertexs, remove part
		if (path.getLength() > intMaxVertexPathPoly) {
			path = pathReduceVertexs(path);
		}
		// If less than 3 vertexes, don't search
		if (path.getLength() < 3) { return }
		mapShowLoading(true);
		var strLats = ""; 
		var strLngs = "";
		for(var i = 0; i < path.getLength(); i++) {
			strLats += path.getAt(i).lat() + (i < path.getLength()-1 ? "," : "");
			strLngs += path.getAt(i).lng() + (i < path.getLength()-1 ? "," : "");
		}

		mapClearAllObjects();
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMSP' +
					'&idProject=<? echo $arrProject['idProject']; ?>' +
					'&strJSONScope=<? echo $strJSONScope; ?>' +
					'&strLats=' + strLats +
					'&strLngs='+ strLngs
		}).always(function() {
			mapPlotMarkers(result.responseText);
		});
	}
	
	function toolFilterByRadiusCreateDestroy(blnCreate) {
		mapShortcutKeysInitialize(! blnCreate);
		document.getElementById('liMSR').className = (blnCreate ? 'liSelected' : '');
		document.getElementById('iMSR').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('toolSearchRadius').style.display = (blnCreate ? 'inline' : 'none');
		if (document.getElementById('btnMapSearchByRadius')) {
			document.getElementById('btnMapSearchByRadius').className = (blnCreate ? 'btn btn-primary' : 'btn');
		}
		if (blnCreate) {
			blnIsFiltering = true;
			if (poly == null) {
				var dblRadius = parseFloat(document.getElementById('toolSearchRadius').value);
				if (isNaN(dblRadius)) dblRadius = 500;
				poly = new google.maps.Circle({strokeWeight: 3, strokeColor: '<? echo $strings->strSiteBaseColor; ?>', fillOpacity: 0.1, editable: true, zIndex: 9999, map: map, center: map.getCenter(), radius: dblRadius});
				google.maps.event.addListener(poly, 'radius_changed', function () {toolFilterByRadiusSearch();});
				google.maps.event.addListener(poly, 'center_changed', function () {toolFilterByRadiusSearch();});
				map.setOptions({draggableCursor:'crosshair'});
				mapClearAllObjects();
				toolFilterByRadiusSearch();
				document.getElementById('toolSearchRadius').select();
				showInfoAlert("<? echo $_SESSION['strHomeToolsItemSearchByRadiusCloseTip']; ?>");
			}
			searchSetType(2);
		} else {
			if (poly) {
				poly.setMap(null);
				poly = null;
			}
			blnIsFiltering = false;
			document.getElementById('cmbFilteredUsers').style.display = 'none';
			map.setOptions({draggableCursor:'pointer'});
			divShowHide('divTools', false);
		}
		document.getElementById('divFilteredActions').style.display = (blnCreate ? 'inline-block' : 'none');
	}
		
	function toolFilterByRadiusSearch() {
		mapShowLoading(true);
		document.getElementById('toolSearchRadius').value = poly.getRadius().toFixed(2);
		mapClearAllObjects();
		var result = $.ajax({
			url: 'ajax.php?chrAction=HMSR' +
					'&idProject=<? echo $arrProject['idProject']; ?>' +
					'&strJSONScope=<? echo $strJSONScope; ?>' +
					'&dblLat=' + poly.getCenter().lat() +
					'&dblLng='+ poly.getCenter().lng() +
					'&dblRadius=' + poly.getRadius()
		}).always(function() {
			mapPlotMarkers(result.responseText);
		});
	}

	function toolFilterUpdateRadius(dblRadius) {
		var dblRadius = parseFloat(dblRadius);
		if (isNaN(dblRadius)) {
			dblRadius = 500;
			document.getElementById('toolSearchRadius').value = dblRadius;
		}
		poly.setRadius(dblRadius);
		map.fitBounds(poly.getBounds());
	}
	
	function toolFilterFormRecordsCreateDestroy(blnCreate, blnShowPanel, blnExecuteFilter) {
		var blnShowPanel = blnShowPanel != null ? blnShowPanel : blnCreate;
		var blnExecuteFilter = blnExecuteFilter != null ? blnExecuteFilter : true;
		blnIsFiltering = blnCreate;
		if (! document.getElementById('iMFR')) return;
		if (blnCreate) {
			if (blnExecuteFilter) {
			userFilterLoadFilter();
			showInfoAlert("<? echo $_SESSION['strHomeToolsItemFilterCloseTip']; ?>");
			}
		} else {
			divShowHide('divTools', false);
			if (document.getElementById('radioUserFilter_0')) {
				document.getElementById('radioUserFilter_0').checked = true;
			}
			$('#aUserFilters').button('reset');
		}
		divShowHide('divFilter', blnShowPanel);
		document.getElementById('iMFR').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMFR').className = (blnCreate ? 'liSelected' : '');
		document.getElementById('divFilteredActions').style.display = (blnCreate ? 'inline-block' : 'none');
		document.getElementById('cmbFilteredUsers').style.display = 'none';
		if (document.getElementById('aUserFilters')) {
			document.getElementById('aUserFilters').className = "btn dropdown-toggle" + (blnCreate ? ' btn-primary' : '');
		}
	}

	function filterInitialize() {
		filterSetButtonsState();
		$("#divFilter").draggable({handle:"#divFilterTitle"});
		//$("#divFilter").resizable();
  		$("#imgUserFilterMarker").tooltip({placement:'right', trigger:'hover'});
		var objSearch = document.getElementById('txtFilterValue');
		objSearch.value = '';
		$('#txtFilterValue').autocomplete({
			serviceUrl: 'ajax.php?chrAction=FRFFS&idFormField=' + document.getElementById('filterFormField').value,
			minChars:1,
			onSearchStart: function (query) {
				objSearch.style.backgroundImage="url(img/loading.gif)";
			},
			onSearchComplete: function (query, suggestions) {
				objSearch.style.backgroundImage = "";
			},
			onSelect: function(suggestion) {
				document.getElementById('txtFilterValue').value = suggestion.text;
			}
		});
	}

	function filterResize() {
		blnMaximize = document.getElementById("iFilterResize").className == 'icon-resize-full icon-white';
		document.getElementById("iFilterResize").className = 'icon-resize-' + (blnMaximize ? 'small' : 'full') + ' icon-white';
		document.getElementById("divFilter").style.left = (blnMaximize ? "0px" : "30%");
		document.getElementById("divFilter").style.width = (blnMaximize ? "100%" : "40%");
		document.getElementById("divFilter").style.height = (blnMaximize ? "100%" : "20%");
		document.getElementById("divFilter").style.top = (blnMaximize ? "0px" : "20%");
	}
	
	function userFilterLoadFilter() {
		var cmbUserFilter = document.getElementById('userFilter');
		if (! cmbUserFilter.value) return;
		var imgMarker = document.getElementById("imgUserFilterMarker");
		document.getElementById("radioUserFilter_" + cmbUserFilter.value).checked = true;
		imgMarker.src = 'img/loading3.gif';
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUFS&idUserFilter=' + cmbUserFilter.value
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			imgMarker.src = '<? echo $user->strUserFilterNoMarkerURL; ?>';
			if ((arrResult != null) && (arrResult.length > 0)){
				imgMarker.src = arrResult[0]['strMarkerFullPath'];
			}
			filterSetButtonsState();
		  	userFilterClausesLoad();
		});
	}
	
	function userFilterSetDefaultMarker(){
		$('#btnUserFilterSetDefaultFormMarker').button('loading');
		var cmbUserFilter = document.getElementById('userFilter');
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUFDM&idUserFilter=' + cmbUserFilter.value
		}).always(function() {
			$('#btnUserFilterSetDefaultFormMarker').button('reset');
			userFilterLoadFilter();
		});
	}
	
	function userFilterInsert(strFilterName) {
		var strFilterName = (strFilterName != null ? strFilterName : prompt('<? echo $_SESSION['strHomeFilterNamePrompt']; ?>:', ''));
		if (! strFilterName) return;
		var imgMarker = document.getElementById("imgUserFilterMarker");
		imgMarker.src = 'img/loading3.gif';
		var result = $.ajax({url: 'ajax.php?chrAction=HUFI' +
								'&idUser=<? echo $arrUser['idUser'] ? $arrUser['idUser'] : -$arrProject['idProject']; ?>' +
								'&strName=' + strFilterName
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			var opt = document.createElement('option');
			opt.value = arrResult['idUserFilter'];
			opt.text = arrResult['strName'];
			document.getElementById('userFilter').add(opt);
			document.getElementById('userFilter').selectedIndex = document.getElementById('userFilter').length - 1;
			imgMarker.src = '<? echo $user->strUserFilterNoMarkerURL; ?>';
			userFilterClausesLoad();
		});
	}
	
	function userFilterUpdate() {
		var objFilter = document.getElementById('userFilter');
		var strFilterName = prompt('<? echo $_SESSION['strHomeFilterNamePrompt']; ?>:', objFilter.options[objFilter.selectedIndex].text);
		if (! strFilterName) return;
		var result = $.ajax({url: 'ajax.php?chrAction=HUFU' +
								'&idUserFilter=' + document.getElementById('userFilter').value  + 
								'&strName=' + strFilterName
		}).always(function() {
			objFilter.options[objFilter.selectedIndex].text = strFilterName;
		});
	}

	function userFilterDelete() {
		var blnDelete = confirm('<? echo $_SESSION['strHomeFilterDeleteConfirm']; ?>');
		if (! blnDelete) return;
		var idUserFilter = document.getElementById("userFilter").value;
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUFD&idUserFilter=' + idUserFilter
		}).always(function() {
			if (result.responseText > 0) {
				document.getElementById("userFilter").remove(document.getElementById("userFilter").selectedIndex);
				if (document.getElementById("userFilter").selectedIndex >= 0) {
					userFilterLoadFilter();
				}
			}
		});
	}
	
	function userFilterClausesLoad() {	
		var idUserFilter = document.getElementById("userFilter").value;
		var cmbFilterClauses = document.getElementById("filterClauses");
		$('#btnFilterUpdate').button('loading');
		$('#aUserFilters').button('loading');
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUFCS&idUserFilter=' + idUserFilter
		}).always(function() {
			// Clear Form Combo Items
			for (var i=cmbFilterClauses.options.length-1;i>=0;i--) { cmbFilterClauses.remove(i); }
            var arrClauses	= JSON.parse(result.responseText);
			if (arrClauses) {
				for (var i=0;i<arrClauses.length;i++) {
					var opt = document.createElement('option');
					opt.value = arrClauses[i]['idUserFilterClause'];
					opt.text = arrClauses[i]['strForm'] + '.' + arrClauses[i]['strFormField'] + arrClauses[i]['chrOperator'] + arrClauses[i]['strValue'];
					cmbFilterClauses.add(opt);
				}
			}
			mapClearAllObjects();
			mapShowLoading(true);
			var result2 = $.ajax({
				url: 'ajax.php?chrAction=HUF&idUserFilter=' + idUserFilter  + '&strModeANDOR=' + document.getElementById("filterModeANDOR").value + '&strJSONScope=<? echo $strJSONScope; ?>'
			}).always(function() {
				$('#aUserFilters').button('reset');
				$('#btnFilterUpdate').button('reset');
				//alert(result2.responseText);
				mapPlotMarkers(result2.responseText);
				var imgMarker = document.getElementById("imgUserFilterMarker");
				if (imgMarker.src.indexOf('<? echo $user->strUserFilterNoMarkerURL; ?>') < 0) {
					document.getElementById('strNewValue').value = imgMarker.src;
					mapSelectedRecordsAction('CI'); // Update Markers
				}
				mapPanToarrMarkers();
				filterSetButtonsState();
				mapShowLoading(false);
			});
		});

	}
	
	function userFilterClauseInsert() {
		$('#btnUserFilterClauseInsert').button('loading');
		var idFormFieldType = $('option:selected', document.getElementById("filterFormField")).attr('idFormFieldType');
		if (idFormFieldType == 2) { // Numeric
			var objValue = document.getElementById("txtFilterValue");
			objValue.value = replaceAll(objValue.value, ',', '.');
			objValue.value = parseFloat(objValue.value);
			if (objValue.value == 'NaN') objValue.value = 0;
		}
		var result = $.ajax({url: 'ajax.php?chrAction=HUFCI' +
								'&idUserFilter=' + document.getElementById("userFilter").value +
								'&idFormField=' + document.getElementById("filterFormField").value +
								'&intOperador=' + document.getElementById("filterOperator").value +
								'&strValue=' + document.getElementById("txtFilterValue").value
		}).always(function() {
			$('#btnUserFilterClauseInsert').button('reset');
			userFilterClausesLoad();
		});
	}

	function userFilterClauseDelete() {
		$('#btnUserFilterClauseDelete').button('loading');
		var idUserFilterClause = document.getElementById("filterClauses").value;
		var result = $.ajax({
			url: 'ajax.php?chrAction=HUFCD&idUserFilterClause=' + idUserFilterClause
		}).always(function() {
			$('#btnUserFilterClauseDelete').button('reset');
			if (result.responseText > 0) {
				userFilterClausesLoad();
			}
		});
	}

	function filterFormFieldsLoad(){
		var cmbFormFields = document.getElementById('filterFormField');
		var result = $.ajax({
			url: 'ajax.php?chrAction=FFS&idForm=' + document.getElementById("filterForm").value
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			// Clear Form Combo Items
			for (var i=cmbFormFields.options.length-1;i>=0;i--) { cmbFormFields.remove(i); 	}
            for (var i=0;i<arrResult['arrFields'].length;i++) {
				var opt = document.createElement('option');
				opt.value = arrResult['arrFields'][i]['idFormField'];
				opt.text = arrResult['arrFields'][i]['strName'];
				opt.setAttribute("idFormFieldType", arrResult['arrFields'][i]['idFormFieldType']);
				cmbFormFields.add(opt);
            }
		});
	}

	function filterSetButtonsState() {
		document.getElementById("btnUserFilterFormMarker").style.display =  (document.getElementById('userFilter').value ? 'inline-block' : 'none');
		document.getElementById("btnUserFilterSetDefaultFormMarker").style.display =  (document.getElementById('userFilter').value ? 'inline-block' : 'none');
		document.getElementById("btnUserFilterUpdate").className = 'btn btn-info' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnUserFilterDelete").className = 'btn btn-danger' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnUserFilterSetDefaultFormMarker").className = 'btn btn-warning' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnUserFilterFormMarker").className = 'btn' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnUserFilterClauseInsert").className = 'btn btn-success' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnUserFilterClauseDelete").className = 'btn btn-danger' + (document.getElementById('filterClauses').length > 0 ? '' : ' btn-disabled');
		document.getElementById("btnFilterUpdate").className = 'btn btn-success' + (document.getElementById('userFilter').length > 0 ? '' : ' btn-disabled');
	}
	
	function userFiltersLoad() {
		comboClear("cmbFilteredUsers");
		var cmbUsers = document.getElementById("cmbFilteredUsers");
		var opt = document.createElement('option');
		opt.value = '';
		opt.text = '<? echo $_SESSION['strGlobalSelect']; ?>...';
		cmbUsers.add(opt);
		cmbUsers.selectedIndex = 0;
		cmbUsers.style.display = 'inline';
		var result = $.ajax({
		  url: "ajax.php?chrAction=US&idProject=<? echo $arrProject['idProject']; ?>"
		}).always(function() {
			var response 	= result.responseText;
			var arrResult 	= JSON.parse(response);
			for (var i=0;i<arrResult.length;i++) {
				// Insert into Combo Users
				var opt = document.createElement('option');
				opt.value = arrResult[i]['idUser'];
				opt.text = arrResult[i]['strEmail'];
				cmbUsers.add(opt);
			}
		});

	}

	function toolHeatmapCreateDestroy(blnCreate, blnShowAlert) {
		var blnShowAlert = blnShowAlert ? blnShowAlert : true;
		document.getElementById('iMHM').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMHM').className = (blnCreate ? 'liSelected' : '');
		document.getElementById('intHeatmapRadius').style.display = (blnCreate ? 'inline' : 'none');
		if (blnCreate) {
			mapShowLoading(true);
			if (gHeatmap != null) {
				gHeatmap.setMap(null);
			}
	   		$("#intHeatmapRadius").tooltip({placement:'bottom', trigger:'hover focus'});
			// Load Form Records Coordinates
			var intHeatmapRadius = parseInt(document.getElementById('intHeatmapRadius').value);
			var heatmapData = [];
			if (blnIsFiltering) {
				for (var i=0; i<arrMarkers.length; i++) {
					heatmapData.push(new google.maps.LatLng(arrMarkers[i].dblLatitude, arrMarkers[i].dblLongitude));
				}
				gHeatmap = new google.maps.visualization.HeatmapLayer({
					data: heatmapData,
					map: map,
					radius: intHeatmapRadius
				});
				mapShowLoading(false);
				document.getElementById('intHeatmapRadius').select();
				if (blnShowAlert) showInfoAlert("<? echo $_SESSION['strHomeToolsItemHeatMapCloseTip'] . $_SESSION['strGlobalClickXDeactivate']; ?>");
			} else {
				var result = $.ajax({
					url: 'ajax.php?chrAction=HHMS' + 
						'&idProject=<? echo $arrProject['idProject']; ?>' +
						'&strJSONScope=<? echo $strJSONScope; ?>' +
						'&intHeatmapRadius=' + intHeatmapRadius
				}).always(function() {
					var arrResult 	= JSON.parse(result.responseText);
					for (var i=0;i<arrResult.length;i++) {
						heatmapData.push(new google.maps.LatLng(arrResult[i]['dblLatitude'], arrResult[i]['dblLongitude']));
					}
					if (gHeatmap != null) {
						gHeatmap.setMap(null);
					}
					gHeatmap = new google.maps.visualization.HeatmapLayer({
						data: heatmapData,
						map: map,
						radius: intHeatmapRadius
					});
					mapShowLoading(false);
					document.getElementById('intHeatmapRadius').select();
					if (blnShowAlert) showInfoAlert("<? echo $_SESSION['strHomeToolsItemHeatMapCloseTip'] . $_SESSION['strGlobalClickXDeactivate']; ?>");
				});
			}
		} else {
			divShowHide('divTools', false);
			if (gHeatmap != null) {
				gHeatmap.setMap(null);
			}
		}
	}

	function toolImageOverlayCreateDestroy(blnCreate) {
		document.getElementById("modalImageOverlay").style.display = (blnCreate ? 'block' : 'none');
		if (blnCreate) {
			if (document.getElementById('iMIO').style.display == 'none') {
				imageOverlaysLoad();
			}
		} else {
			if (imageOverlay != null) imageOverlay.setMap(null);
			divShowHide('divTools', false);
		}
		document.getElementById('iMIO').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMIO').className = (blnCreate ? 'liSelected' : '');
	}
	
	function imageOverlaySetButtonsState() {
		document.getElementById("btnImageOverlayDelete").className = 'btn btn-danger' + (document.getElementById('imageOverlay').length > 0 ? '' : ' btn-disabled');
		document.getElementById("trImageOverlayExtent1").style.display = (document.getElementById('imageOverlay').value ? 'table-row' : 'none');
		document.getElementById("trImageOverlayExtent2").style.display = document.getElementById("trImageOverlayExtent1").style.display;
	}
	
	function imageOverlaysLoad() {
		comboClear("imageOverlay");
		$('#imageOverlay').button('loading');
		var cmbImageOverlay = document.getElementById("imageOverlay");
		var opt = document.createElement('option');
		opt.value = '';
		opt.text = '<? echo $_SESSION['strGlobalSelect']; ?>';
		cmbImageOverlay.add(opt);
		var result = $.ajax({
		  url: "ajax.php?chrAction=HIOS&idUser=<? echo $arrUser['idUser']; ?>"
		}).always(function() {
			var arrResult 	= JSON.parse(result.responseText);
			for (var i=0;i<arrResult.length;i++) {
				var opt = document.createElement('option');
				opt.value = arrResult[i]['idUserImageOverlay'];
				opt.text = arrResult[i]['strName'];
				cmbImageOverlay.add(opt);
			}
			$('#imageOverlay').button('reset');
			cmbImageOverlay.selectedIndex = 0;
			imageOverlaySetButtonsState();
		});

	}

	function imageOverlayLoad(){
		imageOverlaySetButtonsState();
		var cmbImageOverlay = document.getElementById("imageOverlay");
		var result = $.ajax({
			url: 'ajax.php?chrAction=HIOS&idUserImageOverlay=' + cmbImageOverlay.value
		}).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			document.getElementById("txtImageOverlayLatSW").value = arrResult[0]['dblLatSW'];
			document.getElementById("txtImageOverlayLongSW").value = arrResult[0]['dblLongSW'];
			document.getElementById("txtImageOverlayLatNE").value = arrResult[0]['dblLatNE'];
			document.getElementById("txtImageOverlayLongNE").value = arrResult[0]['dblLongNE'];
			document.getElementById("hidImageOverlayFileNameFullPath").value = arrResult[0]['strFileNameFullPath'];
			imageOverlayCreateGround(arrResult[0]['dblLatSW'], arrResult[0]['dblLongSW'], arrResult[0]['dblLatNE'], arrResult[0]['dblLongNE'], arrResult[0]['strFileNameFullPath']);
		});
	}
	
	function imageOverlayCreateGround(dblLatSW, dblLongSW, dblLatNE, dblLongNE, strFileNameFullPath) {
		if (imageOverlay != null) imageOverlay.setMap(null);
		var imageOverlayBounds = new google.maps.LatLngBounds(
			new google.maps.LatLng(dblLatSW, dblLongSW),
			new google.maps.LatLng(dblLatNE, dblLongNE)
		);
		imageOverlay = new google.maps.GroundOverlay(strFileNameFullPath,imageOverlayBounds,{opacity:0.7});
		imageOverlay.setMap(map);
		map.fitBounds(imageOverlayBounds);
	}

	// Manipulating Files Upload
	$(function () {
		var url = 'js/fileupload/index.php';
		$('#fuImageOverlayFile').fileupload({
			url: url,
			dataType: 'json',
			done: function (e, data) {
				$.each(data.result.files, function (index, file) {
					if (! blnIsImage(file.name)) { 
						showInfoAlert('<? echo $_SESSION['strErrorInvalidFormat']; ?> JPG, PNG, GIF, BMP');
						return;
					}
					imageOverlayUpload(file.name);
				});
				document.getElementById('divImageOverlayProgressBar').style.display='none';
			},
			start: function(e) {
				$('#bar').css('width','0%');
				document.getElementById('divImageOverlayProgressBar').style.display='inline-block';
			},
			progressall: function (e, data) {
				var progress = parseInt(data.loaded / data.total * 100, 10);
				$('#bar').css('width', progress + '%');
			}
		}).prop('disabled', !$.support.fileInput)
			.parent().addClass($.support.fileInput ? undefined : 'disabled');
	});

	function imageOverlayUpload(strFileName) {
		var cmbImageOverlay = document.getElementById("imageOverlay");		
		var mapBoundsNE = map.getBounds().getNorthEast();
		var mapBoundsSW = map.getBounds().getSouthWest();
		var result = $.ajax({
			url: "ajax.php?chrAction=HIOFU" +
					"&idProject=<? echo $arrProject['idProject']; ?>" +
					"&idUser=<? echo $arrUser['idUser']; ?>" +
					"&strFileName=" + strFileName +
					"&dblLatSW=" + mapBoundsSW.lat().toFixed(7) + 
					"&dblLongSW=" + mapBoundsSW.lng().toFixed(7) + 
					"&dblLatNE=" + mapBoundsNE.lat().toFixed(7) + 
					"&dblLongNE=" + mapBoundsNE.lng().toFixed(7)
		}).done(function() {
			var arrResult 	= JSON.parse(result.responseText);
			var opt = document.createElement('option');
			opt.value = arrResult['idUserImageOverlay'];
			opt.text = arrResult['strName'];
			cmbImageOverlay.add(opt);
			imageOverlayLoad();
		});
	}
		
	function imageOverlayUpdate(){
		$('#btnImageOverlayUpload').button('loading');
		var cmbImageOverlay = document.getElementById("imageOverlay");
		var mapBoundsNE = map.getBounds().getNorthEast();
		var mapBoundsSW = map.getBounds().getSouthWest();
		var result = $.ajax({
			url: 'ajax.php?chrAction=HIOU' +
				'&idUserImageOverlay=' + cmbImageOverlay.value +
				'&dblLatSW=' + document.getElementById("txtImageOverlayLatSW").value + 
				'&dblLongSW=' + document.getElementById("txtImageOverlayLongSW").value + 
				'&dblLatNE=' + document.getElementById("txtImageOverlayLatNE").value + 
				'&dblLongNE=' + document.getElementById("txtImageOverlayLongNE").value
		}).always(function() {
			$('#btnImageOverlayUpload').button('reset');
			imageOverlayCreateGround(document.getElementById("txtImageOverlayLatSW").value, document.getElementById("txtImageOverlayLongSW").value, document.getElementById("txtImageOverlayLatNE").value, document.getElementById("txtImageOverlayLongNE").value, document.getElementById("hidImageOverlayFileNameFullPath").value);
			showSuccessAlert();
		});
	}

	function imageOverlayDelete() {
		var blnDelete = confirm('<? echo $_SESSION['strHomeToolsItemImageOverlayDeleteConfirm']; ?>');
		if (! blnDelete) return;
		$('#btnImageOverlayDelete').button('loading');
		var cmbImageOverlay = document.getElementById("imageOverlay");
		var result = $.ajax({
			url: 'ajax.php?chrAction=HIOD&idUserImageOverlay=' + cmbImageOverlay.value
		}).always(function() {
			$('#btnImageOverlayDelete').button('reset');
			if (result.responseText > 0) {
				cmbImageOverlay.remove(cmbImageOverlay.selectedIndex);
				imageOverlay.setMap(null);
			}
			imageOverlaySetButtonsState();
		});
	}
	
	function toolFlushMapCreateDestroy(blnCreate) {
		document.getElementById("modalFlushMap").style.display = (blnCreate ? 'block' : 'none');
		if (blnCreate) {
			if (document.getElementById('iMFM').style.display == 'none') {
				flushMapFormFieldsLoad();
			}
		} else {
			divShowHide('divTools', false);
		}
		document.getElementById('iMFM').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMFM').className = (blnCreate ? 'liSelected' : '');
	}
	
	function flushMapFormFieldsLoad(){
		var cmbFormFieldsID = document.getElementById('flushMapFormFieldID');
		var cmbFormFieldsIDTo = document.getElementById('flushMapFormFieldIDTo');
   		$('#btnFlushMapDraw').button('loading');
		var result = $.ajax({
			url: 'ajax.php?chrAction=FFS&idForm=' + document.getElementById("flushMapForm").value
		}).always(function() {
			// Clear Form Combo Items
			for (var i=cmbFormFieldsID.options.length-1;i>=0;i--) { cmbFormFieldsID.remove(i); }
			var opt = document.createElement('option');
			opt.value = '';
			opt.text = '<? echo $_SESSION['strHomeToolsItemFlushMapFieldID']; ?>...';
			cmbFormFieldsID.add(opt);
			for (var i=cmbFormFieldsIDTo.options.length-1;i>=0;i--) { cmbFormFieldsIDTo.remove(i); }
			var opt = document.createElement('option');
			opt.value = '';
			opt.text = '<? echo $_SESSION['strHomeToolsItemFlushMapFieldIDTo']; ?>...';
			cmbFormFieldsIDTo.add(opt);
            var arrResult 	= JSON.parse(result.responseText);
            for (var i=0;i<arrResult['arrFields'].length;i++) {
				// Just Numeric Fields (= 2)
				if (arrResult['arrFields'][i]['idFormFieldType'] != 2) continue;
				var opt = document.createElement('option');
				opt.value = arrResult['arrFields'][i]['idFormField'];
				opt.text = arrResult['arrFields'][i]['strName'];
				cmbFormFieldsID.add(opt);
				var opt = document.createElement('option');
				opt.value = arrResult['arrFields'][i]['idFormField'];
				opt.text = arrResult['arrFields'][i]['strName'];
				cmbFormFieldsIDTo.add(opt);
            }
			$('#btnFlushMapDraw').button('reset');
		});
	}
	
	function flushMapDraw(){
		mapShowLoading(true);
		mapClearAllObjects();
		var cmbFormFieldsID = document.getElementById('flushMapFormFieldID');
		var cmbFormFieldsIDTo = document.getElementById('flushMapFormFieldIDTo');
		$('#btnFlushMapDraw').button('loading');
		var result = $.ajax({
			url: 'ajax.php?chrAction=HFMS' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>' +
				'&idFormFieldID=' + cmbFormFieldsID.value + 
				'&idFormFieldIDTo=' + cmbFormFieldsIDTo.value
		}).always(function() {
			$('#btnFlushMapDraw').button('reset');
			var arrResult 	= JSON.parse(result.responseText);
			for (var i=0;i<arrResult.length;i++) {
				if ((arrResult[i]['dblLatitudeFrom']) && (arrResult[i]['dblLatitudeTo'])) {
					var lineCoordinates = [
						new google.maps.LatLng(arrResult[i]['dblLatitudeFrom'], arrResult[i]['dblLongitudeFrom']), 
						new google.maps.LatLng(arrResult[i]['dblLatitudeTo'], arrResult[i]['dblLongitudeTo'])
					];
					var lineFlow = new google.maps.Polyline({strokeWeight : 1, strokeOpacity : 0.7, path: lineCoordinates, geodesic:true, icons: [{icon: {path: google.maps.SymbolPath.FORWARD_OPEN_ARROW}, offset: '100%'}], map: map});
					arrMarkers.push(lineFlow);
				}
			}
			mapShowLoading(false);
		});
	}
	
	function toolBufferCreateDestroy(blnCreate) {
		document.getElementById("modalBuffer").style.display = (blnCreate ? 'block' : 'none');
		if (blnCreate) {
			$('#btnBufferDraw').button('reset');
	   		$("#intBufferRadius").tooltip({placement:'bottom', trigger:'hover focus'});
			bufferDraw();
		} else {
			mapClearAllBuffers();
			divShowHide('divTools', false);
		}
		document.getElementById('iMBF').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liMBF').className = (blnCreate ? 'liSelected' : '');
	}
	
	function bufferRadiusUpdate(){
		var buffer;
		//$('#btnBufferDraw').button('loading');
		mapShowLoading(true);
		var intRadius = parseFloat(document.getElementById('intBufferRadius').value);
		for (var i=0;i<arrBuffers.length;i++) {
			buffer = arrBuffers[i];
			buffer.setRadius(intRadius);
		}
		//$('#btnBufferDraw').button('reset');
		mapShowLoading(false);
		bufferDraw();
	}
	
	function bufferDraw() {
		mapShowLoading(true);
		//$('#btnBufferDraw').button('loading');
		var circleBuffer;
		var idForm = document.getElementById('cmbBufferForm').value;
		mapClearAllBuffers();
		var intRadius = parseFloat(document.getElementById('intBufferRadius').value);
		if (isNaN(intRadius)) {
			document.getElementById('intBufferRadius').value = 300;
			intRadius = document.getElementById('intBufferRadius').value;
		}
		for (var i=0; i<arrMarkers.length; i++) {
			if ((arrMarkers[i].idForm == idForm)) { // Just for points
				circleBuffer = new google.maps.Circle({fillOpacity: document.getElementById('intMapPolygonsOpacity').value/100, clickable:false, center: new google.maps.LatLng(arrMarkers[i].dblLatitude, arrMarkers[i].dblLongitude), strokeWeight: 2, strokeColor: '<? echo $strings->strSiteBaseColor; ?>', editable: false, zIndex: 9999, map: map, radius: intRadius});
				circleBuffer.idForm = arrMarkers[i].idForm;
				circleBuffer.idFormRecord = arrMarkers[i].idFormRecord;
				arrBuffers.push(circleBuffer);
			}
		}
		mapShowLoading(false);
		//$('#btnBufferDraw').button('reset');
	}
	
	function bufferGenerateCoverAreaReport() {
		var idFormCoverBy = document.getElementById('cmbBufferCoverAreaByForm').value;
		if ((! blnEmailCheck()) || (! idFormCoverBy > 0)) {
			document.getElementById('cmbBufferCoverAreaByForm').selectedIndex = 0;
			return;
		}
		showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 1);
		//$('#btnBufferDraw').button('loading');
		mapShowLoading(true);
		var idForm = document.getElementById('cmbBufferForm').value;
		var intRadiusMts = document.getElementById('intBufferRadius').value;
		var result = $.ajax({
			url: 'ajax.php?chrAction=HBCA' + 
				'&idProject=<? echo $arrProject['idProject']; ?>' +
				'&strJSONScope=<? echo $strJSONScope; ?>' +
				'&idForm=' + idForm + 
				'&intRadiusMts=' + intRadiusMts + 
				'&idFormCoverBy=' + idFormCoverBy +
				'&strEmail=' + strReportEmail
		}).always(function() {
			//$('#btnBufferDraw').button('reset');
			mapShowLoading(false);
			showInfoAlert("<? echo $_SESSION['strReportTipSentMail']; ?><BR>" + strReportEmail, 2);
			document.getElementById('cmbBufferCoverAreaByForm').selectedIndex = 0;
			var arrResult 	= JSON.parse(result.responseText);
			window.location='output.php?strName=' + arrResult['strFilePath'].toLowerCase() + '&strFileName=' + arrResult['strFilePathTMP'];
		});
	}
	
	function toolIBGECreateDestroy(blnCreate) {
		if (IBGEFusionLayer != null) {
			IBGEFusionLayer.setMap(null);
		}
		if (blnCreate) {
			$("#divIBGE").draggable({handle:"#divIBGETitle"});
			IBGEFusionLayer = new google.maps.FusionTablesLayer({
				query: {
				  select: '<?=$censo->strGoogleFusionTablesFieldPolys;?>',
				  from: '<?=$censo->strGoogleFusionTablesTableID;?>'
				},
				options : {suppressInfoWindows:true},
				styles: [{
				  polygonOptions: {
					fillColor: '<?=$censo->strGoogleFusionTablesPolyFillColor;?>',
					fillOpacity: <?=$censo->dblGoogleFusionTablesPolyFillOpacity;?>,
					strokeColor: '<?=$censo->strGoogleFusionTablesPolyStrokeColor;?>',
					strokeOpacity: <?=$censo->dblGoogleFusionTablesPolyStrokeOpacity;?>,
					strokeWeight: <?=$censo->intGoogleFusionTablesPolyStrokeWeight;?>
				  }
				}]
			});
			IBGEFusionLayer.setMap(map);
			google.maps.event.addListener(IBGEFusionLayer, 'click', function(e) {
				document.getElementById("ifrIBGE").src ='http://www.censo2010.ibge.gov.br/agsn/tooltip/dashboard.html?USO=4&CurPESQ=1003&SITEag=' + e.row['CD_GEOCODI'].value;
				document.getElementById("divIBGE").style.display = 'block';
			});			
		} else {
			document.getElementById("divIBGE").style.display = 'none';
		}
		divShowHide('divTools', false);
		document.getElementById('iIBGE').style.display = (blnCreate ? 'inline' : 'none');
		document.getElementById('liIBGE').className = (blnCreate ? 'liSelected' : '');
	}
	
	function toolsAction(chrAction) {
		switch(chrAction) {
		case 'RZE': 		// Zoom to Extent
			if (mkCurrent == null) break;
			map.panTo(new google.maps.LatLng(mkCurrent.dblLatitude, mkCurrent.dblLongitude));
			map.setZoom(17);
			break;
		case 'RP': 		// Record Print
			window.open('record-print-' + mkCurrent.idFormRecord);
			break;
		case 'RE':		// Record Edit
			if (document.getElementById('liRE').style.display == "none") break;
			window.open('record-edit--' + mkCurrent.idFormRecord);
			break;
		case 'RFA':		// Record Filter by Area
			if (mkCurrent.idShapeType != 3) {
				showInfoAlert("<? echo $_SESSION['strHomeToolsRecordFilterAreaOnlyPolygon']; ?>");
				return;
			}
			toolFilterByAreaCreateDestroy(true, mkCurrent);
			break;
		case 'RCC': 	// Record Change Color
			if (document.getElementById('liRCC').style.display == "none") break;
			if (mkCurrent.idShapeType > 1) {
				var strRGB = mkCurrent.strokeColor;
				strRGB = replaceAll(strRGB,'#','');
				document.getElementById('strRGB').value = strRGB;
				document.getElementById('strRGB').color.showPicker();
			}
			break;
		case 'RD':		// Record Delete
			if (document.getElementById('liRD').style.display == "none") break;
			if (mkCurrent == null)  {
				showInfoAlert("<? echo $_SESSION['strHomeToolsNoRecordSelected']; ?>");
				return;
			}
	        var blnDelete = confirm('<? echo $_SESSION['strHomeToolsRecordDeleteConfirm']; ?>');
    	    if (! blnDelete) return;
			var result = $.ajax({
				url: 'ajax.php?chrAction=HRD&idFormRecord=' + mkCurrent.idFormRecord
			}).always(function() {				
			});
			mkCurrent.setMap(null);
			// Delete from TreeView
			treeDeleteItem(mkCurrent);
			// Delete from array
			arrMarkersDelete(mkCurrent.idKind, mkCurrent.id);
			// Decreasing number of records
			document.getElementById("spanTreeFormRecordsCount").innerHTML = document.getElementById("spanTreeFormRecordsCount").innerHTML - 1;
			showSuccessAlert("<? echo $_SESSION['strHomeToolsRecordDeleteSuccess']; ?>");
			mkCurrent = null;
			break;
		case 'MCC':		// Map Center Coordinates
			searchSetType(3);
			document.getElementById('strSearch').select();
			break;
		case 'UR':		// Users Routes
			toolUserPositionsCreateDestroy(document.getElementById('iUR').style.display == 'none' ? true : false);
			break;
		case 'MTI':		// Map Toponymy Insert
			toponymyInsertUpdate(null, <? echo $arrUser['idUser']; ?>, -1, map.getCenter().lat(), map.getCenter().lng(), '', true);
			break;
		case 'MPA':		// Map Pan All Records
			mapPanAllRecords();
			break;
		case 'MMD':		// Map Measure Distances
			toolFilterByAreaCreateDestroy(false);
			toolFilterByRadiusCreateDestroy(false);
			toolFilterFormRecordsCreateDestroy(false, false);
			toolMeasureCreateDestroy(true);
			break;
		case 'MSP':		// Map Search by Polygon
			mapClearAllObjects();
			toolMeasureCreateDestroy(false);
			toolFilterByRadiusCreateDestroy(false);
			toolFilterFormRecordsCreateDestroy(false, false);
			toolFilterByAreaCreateDestroy(true);
			break;
		case 'MSR':		// Map Search By Radius
			mapClearAllObjects();
			toolMeasureCreateDestroy(false);
			toolFilterByAreaCreateDestroy(false);
			toolFilterFormRecordsCreateDestroy(false, false);
			toolFilterByRadiusCreateDestroy(true);
			break;
		case 'MFR':		// Map Filter Records
			mapClearAllObjects();
			toolMeasureCreateDestroy(false);
			toolFilterByAreaCreateDestroy(false);
			toolFilterByRadiusCreateDestroy(false);
			toolFilterFormRecordsCreateDestroy(true);
			break;
		case 'MIO':		// Map Overlay Image
			toolImageOverlayCreateDestroy(true);
			break;
		case 'MHM':		// Map Heat Map
			toolHeatmapCreateDestroy(true);
			break;
		case 'MFM':		// Map Flush Map
			toolFlushMapCreateDestroy(true);
			break;
		case 'MBF':		// Map Buffers
			toolBufferCreateDestroy(true);
			break;
		case 'MCS':		// Map Charts & Stats
			break;
		case 'MIBGE':	// Map IBGE Census Data Layer
			toolIBGECreateDestroy(true);
			break;
		case 'ERS2':	// Export to Raster/SAGA
			mapExportShowModal('RS2');
			break;
		case 'EKML':	// Export to KML for ArcGIS
			mapExportShowModal('KML');
			break;
		case 'ESHP':	// Export to ESRI ArcGIS Shapefile
			mapExportShowModal('SHP');
			break;
		case 'EPNG':	// Export to PNG Image
			mapExportShowModal('PNG');
			break;
		case 'RXLS':	// Genetare Report XLSX
			reportProcess('XLS');
			break;
		case 'RDT':		// Generate Report Distances Table
			reportProcess('DISTANCES');
			break;
		case 'RKML':	// Generate Report KML
			reportProcess('KML');
			break;
		case 'RHTML':	// Generate Report HTML
			reportProcess('HTML');
			break;
		case 'RXML': 	// Generate Report XML
			reportProcess('XML');
			break;
		}
		if (chrAction == 'MHM') { // Keep Opened for Heatmap
			divShowHide('divTools', true);
		} else {
			divShowHide('divTools', false);
		}
	}
	
	function divShowHide(idDiv, blnShow) {
		if (blnShow) {
			$("#" + idDiv).fadeIn();
		} else {
			$("#" + idDiv).fadeOut();
		}
	}
	
	function showInfoUpdate() {
		var btn = document.getElementById("btnShowInfo");
		var blnShowInfo = (document.getElementById('btnShowInfo').className == 'btn' ? false : true);
		/*
		if (IBGEFusionLayer) {
			IBGEFusionLayer.setOptions({suppressInfoWindows:!blnShowInfo});
		}
		*/
	}    
	
	$(window).resize(function() {
		mapResize();
	});
	
	$(document).ready( function () {		
		<? if ($_COOKIE['blnFullscreen'] == 1) { ?>
			mapFullscreen();
		<? } ?>
		$('[rel="tooltip"],[data-rel="tooltip"]').tooltip({"html":"true", "placement":"bottom", delay: { show: 100, hide: 400 }});
		infoInitialize();
		filterInitialize();
		mapInitialize();
		mapShortcutKeysInitialize(true);
		treeInitialize();
		markerSetToolButtonsVisibility();
		<? if ($_COOKIE['blnTrafficLayer'] == 1) { ?>
			mapTrafficLayer();
		<? } ?>
		<? if ($_COOKIE['blnToponymyShow'] == 1) { ?>
			toponymysLoad();
		<? } ?>
		$("#modalImageOverlay").draggable();
		$("#modalMapExport").draggable();
		$("#modalFlushMap").draggable();
		$("#modalBuffer").draggable();
		document.getElementById("mapcanvas").focus();
	});
</script>
<? } else { ?>
<p style="text-align:center"><i class="icon-lock"></i> <? echo $_SESSION['strHomeJustUsersMessage']; ?></p>
<? } ?>