<?php
class Coordinate{
	private $database = null;
	private $intDecimals = 2;

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		session_start();
	}

	// Converting Coordinates to format DD MM,MM E DD MM SS,SS
	public function strConvertCoordinatesFormat($intFormat, $dblCoordinate, $intDecimals) {
		$dblCoordinate = number_format ($dblCoordinate, 8);
		$dblDegrees = floor(abs($dblCoordinate));
		if ($dblCoordinate < 0) $dblDegrees = - $dblDegrees;
		$strMinutesDecimal = number_format((abs($dblCoordinate) - abs(floor(abs($dblCoordinate))))*60,$intDecimals);
		$dblMinutes = floor($strMinutesDecimal);
		$dblSeconds = number_format(($strMinutesDecimal - $dblMinutes) * 60, $intDecimals);
		if ($intFormat == 1) {
			$strResult = $dblDegrees . '� ' . $strMinutesDecimal . '&#8217;';
		} else if ($intFormat == 2) {
			$strResult = $dblDegrees . '� ' . $dblMinutes . '&#8217; ' . $dblSeconds . '&#8221;';
		}
		return $strResult;
	}

	public function strBatchConvertCoordinates($txtInput, $idType, $idDatumIn, $idDatumOut, $blnDownload = false) {
		//$txtInput = utf8_decode($txtInput);
		$txtInput = str_replace(",", ".", $txtInput);
		$txtInput = str_replace("\n", "|", $txtInput);
		$arrDatumIn = $this->database->selectDatum($idDatumIn);
		$arrDatumOut = $this->database->selectDatum($idDatumOut);
		$pt1 = new gPoint($this->database, $idDatumIn);
		$pt2 = new gPoint($this->database, $idDatumOut);
		$strResult = '
		<table id="tblResult" name="tblResult" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="margin-top:10px;">
		<thead>
			<tr style="font-weight:bold;text-align:center;" class="btn-primary">
				<td colspan="5" style="text-align:center;line-height:16px;">
					DATUM ' . $arrDatumIn[0]['strName'] . ' � ' . $arrDatumOut[0]['strName'] . '
					<a id="btnCopyResult" data-rel="tooltip" title="' . $_SESSION['strToolButtonCopyTip'] . '" style="float:right" class="btn btn-success" onClick="datumConvert(true);"/><i class="icon-download icon-white"></i></a>
				</td>
			</tr>
			<tr style="font-weight:bold;" class="btn-primary">
				<td width="20%" style="text-align:center;line-height:14px;">Latitude</td>
				<td width="20%" style="text-align:center;line-height:14px;">Longitude</td>
				<td width="25%" style="text-align:center;line-height:14px;">Northing (Y)</td>
				<td width="25%" style="text-align:center;line-height:14px;">Easting (X)</td>
				<td width="10%" style="text-align:center;line-height:14px;">Zone</td>
			</tr>
		</thead>';
		if ($blnDownload) {
			require_once ('js/excel/Classes/PHPExcel.php');
			$workbook = new PHPExcel();	
			$objWorksheet = $workbook->getActiveSheet();
			$workbook->setActiveSheetIndex(0);
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, 1, 'Latitude');
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(1, 1, 'Longitude');
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(2, 1, 'Northing (Y)');
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(3, 1, 'Easting (X)');
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(4, 1, 'Zone');
		}
		$arrCoordinates = explode('|', $txtInput);
		$i=2;
		foreach($arrCoordinates as $dblCoordinates) {
			if (strpos($dblCoordinates,';') === FALSE) continue;
			if ($idType == 1) { // GEO->UTM
				$par = split(';', $dblCoordinates);
				if ((! is_numeric($par[0])) || (! is_numeric($par[1]))) continue;
				$pt1->setLongLat($par[1], $par[0]);
				$pt1->convertLLtoTM();
				$pt2->setUTM($pt1->E(), $pt1->N(), $pt1->Z());
				$pt2->convertTMtoLL();
				$lat = $pt2->Lat();
				$lng = $pt2->Long();
				$pt2->setLongLat($par[1], $par[0]);
				$pt2->convertLLtoTM();
				$strResult .= '<tr>
							   <td style="text-align:center;line-height:12px;">' . number_format($lat, 7, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:12px;">' . number_format($lng, 7, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:12px;">' . number_format($pt2->N(), 2, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:12px;">' . number_format($pt2->E(), 2, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:12px;">' . $pt2->Z() . '</td>
							   </tr>';
				if ($blnDownload) {
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, $i, number_format($lat, 7, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(1, $i, number_format($lng, 7, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(2, $i, number_format($pt2->N(), 2, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(3, $i, number_format($pt2->E(), 2, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $pt2->Z());
				}
			} else { // UTM -> GEO
				$par = split(';', $dblCoordinates);
				if ((! is_numeric($par[0])) || (! is_numeric($par[1]))) continue;
				$pt1->setUTM($par[1], $par[0], $par[2]);
				$pt1->convertTMtoLL();
				$pt2->setLongLat($pt1->Long(),$pt1->Lat());
				$pt2->convertLLtoTM();
				$lat = $pt2->N();
				$lng = $pt2->E();
				$intZone = $pt2->Z();
				$pt2->setUTM($par[1], $par[0], $par[2]);
				$pt2->convertTMtoLL();
				$strResult .= '<tr>
							   <td style="text-align:center;line-height:14px;padding:4px;">' . number_format($pt2->Lat(), 7, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:14px;padding:4px;">' . number_format($pt2->Long(), 7, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:14px;padding:4px;">' . number_format($lat, 2, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:14px;padding:4px;">' . number_format($lng, 2, $_SESSION['strDecimal'], '') . '</td>
							   <td style="text-align:center;line-height:14px;padding:4px;">' . $intZone . '</td>
							 </tr>';
				if ($blnDownload) {
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, $i, number_format($pt2->Lat(), 7, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(1, $i, number_format($pt2->Long(), 7, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(2, $i, number_format($lat, 2, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(3, $i, number_format($lng, 2, $_SESSION['strDecimal'], ''));
					$workbook->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $intZone);
				}
			}
			$i++;
		}
		$strResult .= "</table>";
		$arrResult = array();
		$arrResult['strFilename'] = '';
		if ($blnDownload) {
			$arrResult['strFilename'] = $this->strings->strSiteTmpFileFolder . '/' . $this->strings->generateRandomString(5) . '.xlsx';
			$workbook->setActiveSheetIndex(0);
			$objworkbook = PHPExcel_IOFactory::createWriter($workbook, 'Excel2007');
			$objworkbook->save($arrResult['strFilename']);
		}
		$arrResult['strResult'] = $strResult;
		return $arrResult;
	}
}
?>