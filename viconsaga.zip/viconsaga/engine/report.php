<?php
class Report {
	public $intSizeThumb 			= 70;
	public $intGoogleStaticLimit	= 200;
	public $intTableDistanceLimit	= 10000;
	public $intKMLFieldsLimit		= 20;
	
	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;

		include_once 'project.php';
		$project = new Project($database);
		$this->project = $project;
		
		include_once 'form.php';
		$form = new Form($database);
		$this->form = $form;
		
		include_once 'formrecord.php';
		$formrecord = new Formrecord($database);
		$this->formrecord = $formrecord;

		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		@include_once('js/excel/Classes/PHPExcel.php');

		session_start();
	}

	public function generateReport($idProject, $strExtension, $strJSONFormRecords, $blnAllRecords = false, $blnLiveKML = false, $blnKMLObjNameIsIdFormRecord = false, $dblLatC = 0, $dblLngC = 0, $intMapPolygonsOpacity = 100, $strMapType = '', $strPathPrefix = '', $strJSONScope = '', $strEmail = '', $blnEcho = true) {
		set_time_limit(1200); // Increasing Timeout to Garantee Enough Time
		$arrProject = $this->project->selectProjects($idProject);
		$arrProject = $arrProject[0];
		$arrOutput = array();
		$strOutputFileName = $this->strings->removeInvalidChars($this->strings->changeCharAccent($arrProject['strName']));
		$strOutputFileName = str_replace('.', '', $strOutputFileName);
		$strOutputTmpFileName = $this->strings->strSiteTmpFileFolder . '/' . $idProject . '-' . date('d-m-y-H-i-s');
		$arrOutput['strFilePathTMP'] = $strPathPrefix . $strOutputTmpFileName . '.' . strtolower($strExtension);
		$arrOutput['strFilePath'] = $strOutputFileName . '.' . $strExtension;
		// Getting all records, considering scope
		if ($blnAllRecords) {
			$arrFormRecordsReport = array();
			$arrForms = $this->form->selectForms($idProject, 0, '', 1);
			$i=0;
			foreach($arrForms as $arrForm) { 
				$arrFormRecords = $this->formrecord->selectFormRecords(0, 0, $arrForm['idForm'], 0, $strJSONScope);
				foreach ($arrFormRecords as $arrFormRecord) {
					$arrFormRecordsReport[$i]['idForm'] = $arrForm['idForm'];
					$arrFormRecordsReport[$i]['idFormRecord'] = $arrFormRecord['idFormRecord'];
					$arrFormRecordsReport[$i]['dblDistanceFromCenterMts'] = $arrFormRecord['dblDistanceFromCenterMts'];
					$arrFormRecordsReport[$i]['dblLatitude'] = $arrFormRecord['dblLatitude'];
					$arrFormRecordsReport[$i]['dblLongitude'] = $arrFormRecord['dblLongitude'];
					$i++;
				}
			}
		} else {
			$arrFormRecordsReport = json_decode($strJSONFormRecords, true);
			// Order FormRecords By Form
			/*
			$arr = array();
			foreach ($arrFormRecordsReport as $key => $row) {
				$arr[$key] = $row['idForm'];
			}
			array_multisort($arr, SORT_ASC, $arrFormRecordsReport);
			*/
		}
		$i=0;		
		$idForm = 0;
		switch (strtoupper($strExtension)) {
		case "DISTANCES":		
			$strOutputFileName = 'distances-' . date('d-m-Y h-i');
			$strOutputTmpFileName = $this->strings->strSiteTmpFileFolder . '/' . $idProject . '-' . date('d-m-Y h-i');
			$arrOutput['strFilePathTMP'] = $strOutputTmpFileName . '.xlsx';
			$arrOutput['strFilePath'] = $strOutputFileName . '.xlsx';
			$workbook = new PHPExcel();	
			$worksheet = $workbook->getActiveSheet();
			$workbook->setActiveSheetIndex(0);
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(0,1, $this->strings->changeCharAccent($_SESSION['strGlobalDistance'])); // Title Distance
			for($x=0; $x<count($arrFormRecordsReport);$x++) {
				if ($x >= $this->intTableDistanceLimit) break;
				$dblShortestDist = 99999999;
				$dblGreatestDist = 0;
				$workbook->getActiveSheet()->setCellValueByColumnAndRow($x+1, 1, $arrFormRecordsReport[$x]['idFormRecord']);
				$workbook->getActiveSheet()->getStyle(PHPExcel_Cell::stringFromColumnIndex($x+1) . '1')->applyFromArray(array('alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER))); 
				$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, $x+2, $arrFormRecordsReport[$x]['idFormRecord']);
				$workbook->getActiveSheet()->getStyle('A' . ($x+2))->applyFromArray(array('alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER))); 
				for($y=0; $y<count($arrFormRecordsReport);$y++) {
					if ($y >= $this->intTableDistanceLimit) break;
					$chrCol = PHPExcel_Cell::stringFromColumnIndex($x+1);
					if ($x == $y) {
						$dblDistanceMts = '0'; 
						$workbook->getActiveSheet()->getStyle($chrCol . ($y+2))->applyFromArray(
							array('fill' => array('type' => PHPExcel_Style_Fill::FILL_SOLID, 'color' => array('rgb' => '000000')))
						);
					} else {
						$this->gPoint->setLongLat($arrFormRecordsReport[$x]['dblLongitude'], $arrFormRecordsReport[$x]['dblLatitude']);
						$dblDistanceMts = $this->gPoint->distanceFrom($arrFormRecordsReport[$y]['dblLongitude'], $arrFormRecordsReport[$y]['dblLatitude']);
						if ($dblDistanceMts < $dblShortestDist) {
							$intShortestRow = $y;
							$dblShortestDist = $dblDistanceMts;
						}
						if ($dblDistanceMts > $dblGreatestDist) {
							$intGreatestRow = $y;
							$dblGreatestDist = $dblDistanceMts;
						}
					}
					$workbook->getActiveSheet()->setCellValueByColumnAndRow($x+1,$y+2, $dblDistanceMts);
				}
				// Fill as Red Gratest Distance
				$workbook->getActiveSheet()->getStyle($chrCol . ($intGreatestRow+2))->applyFromArray(array('font' => array('bold'  => true, 'color' => array('rgb' => 'FF0000')))); 
				// Fill as Green Shortest Distance
				$workbook->getActiveSheet()->getStyle($chrCol . ($intShortestRow+2))->applyFromArray(array('font' => array('bold'  => true, 'color' => array('rgb' => '008000')))); 
				if ($blnEcho) {
					echo ',' . ($x+1) . '/' . count($arrFormRecordsReport);
				}
			}
			$workbook->getActiveSheet()->getStyle('B2:' . PHPExcel_Cell::stringFromColumnIndex($x+1) . ($y+2))->getNumberFormat()->setFormatCode('#,##0.00');
			$workbook->setActiveSheetIndex(0);
			$objworkbook = PHPExcel_IOFactory::createWriter($workbook, 'Excel2007');
			$objworkbook->save($arrOutput['strFilePathTMP']);
		break;
		case "XLS":
			require_once "js/excelwriter/class.writeexcel_workbookbig.inc.php";
			require_once "js/excelwriter/class.writeexcel_worksheet.inc.php";
			$workbook = new writeexcel_workbookbig($arrOutput['strFilePathTMP']);
			foreach ($arrFormRecordsReport as $idLineFormRecord => $arrFormRecordReport) {
				if ((! $arrFormRecordReport['idForm']) || (! $arrFormRecordReport['idFormRecord'])) continue;
				if ($idForm != $arrFormRecordReport['idForm']) {
					$idForm = $arrFormRecordReport['idForm'];
					$arrForms = $this->form->selectForms(0, $arrFormRecordReport['idForm']);
					$strTabTitle = substr($arrForms[0]['strName'], 0, 24) . ' (' . $this->intNumberRecordsArrayForm($arrFormRecordsReport, $arrFormRecordReport['idForm']) . ')';
					$strTabTitle = strtr($strTabTitle, array("_" => " ", "/" => " "));
					$worksheet = $workbook->addworksheet($strTabTitle);
					$arrFormFields = $this->form->selectFormFields($arrFormRecordReport['idForm']);
					// Table Header
					$worksheet->write(0,0, 'ID');
					$worksheet->write(0,1, 'Latitude');
					$worksheet->write(0,2, 'Longitude');
					$worksheet->write(0,3, 'UTM Latitude');
					$worksheet->write(0,4, 'UTM Longitude');
					$worksheet->write(0,5, 'UTM Zone');
					$worksheet->write(0,6, $_SESSION['strGlobalShapeType']);
					$worksheet->write(0,7, $_SESSION['strGlobalPerimeter'] . '(m)');
					$worksheet->write(0,8, $_SESSION['strGlobalArea'] . ' (m2)');
					$worksheet->write(0,9, $_SESSION['stradmManageUsersEmail']);
					$worksheet->write(0,10, $_SESSION['strGlobalCreated']);
					$worksheet->write(0,11, $_SESSION['strGlobalUpdated']);
					$worksheet->write(0,12, $_SESSION['strGlobalDistance'] . ' (m)');
					$worksheet->write(0,13, $_SESSION['strGlobalFiles']);
					$worksheet->write(0,14, $_SESSION['strGlobalFiles']);
					$intCol = 15;
					// Fields Name
					foreach($arrFormFields as $arrFormField) {
						$worksheet->write(0, $intCol, $arrFormField['strName']);
						$intCol++;
					}
					$intRow = 1;
				}
				//$this->strings->log($strTabTitle . " - " .  $intRow . ' - ' . $arrFormRecordReport['idFormRecord'], null, true);
				// For each FormRecord...
				$arrFormRecord = $this->formrecord->selectFormRecords(0, 0, 0, $arrFormRecordReport['idFormRecord']);
				$arrFormRecord = $arrFormRecord[0];
				$arrFormRecordLastUpdateEvent = $this->formrecord->arrFormRecordLastUpdateEvent($arrFormRecordReport['idFormRecord']);
				$worksheet->write($intRow, 0, $arrFormRecordReport['idFormRecord']);
				$worksheet->write($intRow, 1, $arrFormRecord['dblLatitude']);
				$worksheet->write($intRow, 2, $arrFormRecord['dblLongitude']);
				$worksheet->write($intRow, 3, $arrFormRecord['dblLatitudeUTM']);
				$worksheet->write($intRow, 4, $arrFormRecord['dblLongitudeUTM']);
				$worksheet->write($intRow, 5, $arrFormRecord['intZoneUTM']);
				$worksheet->write($intRow, 6, $arrFormRecord['idShapeType']);
				$worksheet->write($intRow, 7, ($arrFormRecord['idShapeType'] > 1 ? number_format($arrFormRecord['dblPerimeterMts'], 2, $_SESSION['strDecimal'], '') : 0));
				$worksheet->write($intRow, 8, ($arrFormRecord['idShapeType'] == 3 ? number_format($arrFormRecord['dblAreaMts2'], 2, $_SESSION['strDecimal'], '') : 0));
				$worksheet->write($intRow, 9, $arrFormRecord['strEmail']);
				$worksheet->write($intRow, 10, $arrFormRecord['strCreation']);
				$worksheet->write($intRow, 11, ($arrFormRecordLastUpdateEvent ? $arrFormRecord['strLastUpdate'] . ' - ' . $arrFormRecordLastUpdateEvent['strEmail'] : '-'));
				$worksheet->write($intRow, 12, $arrFormRecordReport['dblDistanceFromCenterMts'] > 0 ? $arrFormRecordReport['dblDistanceFromCenterMts'] : '-');
				$worksheet->write($intRow, 13, count($arrFormRecord['arrFiles']));
				$strFiles = '';
				foreach($arrFormRecord['arrFiles'] as $idLine => $arrFile) {
					$strFiles .= ($idLine > 0 ? ',' : '') . $arrFile['strFileNameFullURL'];
				}
				$worksheet->write($intRow, 14, $strFiles);
				$intCol = 15;
				$arrFormRecordDatas = $this->formrecord->selectFormRecordData($arrFormRecordReport['idFormRecord']);
				foreach($arrFormRecordDatas as $arrFormRecordData) {
					$strValue = $arrFormRecordData['strValue'];
					// Reformat Time Series Record
					if ($arrFormRecordData['idFormFieldType'] == 7) $strValue = str_replace('<:>',", ", $strValue);
					$worksheet->write($intRow, $intCol, $strValue);
					$intCol++;
				} // Col iteration end (formfield)
				$intRow++;
				if ($blnEcho) {
					echo ',' . ($idLineFormRecord+1) . '/' . count($arrFormRecordsReport);
				}
				// Row iteration end (Formrecord)
			}
			$workbook->close();
		break;
	
		case "KML": 
			$strPlaces = '';
			$strStyles = '';
			$intNTotal = 0;
			foreach ($arrFormRecordsReport as $idLineFormRecord => $arrFormRecordReport) {
				if ((! $arrFormRecordReport['idForm']) || (! $arrFormRecordReport['idFormRecord'])) continue;
				if ($idForm != $arrFormRecordReport['idForm']) {
					if ($idForm != 0) $strPlaces .= '</Folder>';
					$idForm = $arrFormRecordReport['idForm'];
					$arrForm = $this->form->selectForms(0, $arrFormRecordReport['idForm']);
					$arrForm = $arrForm[0];
					$intNForms = 0;
					$intFormFields = $this->form->intCountFormFields($arrForm['idForm']);
					$intNRecordsForm = $this->intNumberRecordsArrayForm($arrFormRecordsReport, $arrFormRecordReport['idForm']);
					$strPlaces .= '
					<Folder>
						<name>' . $arrForm['strName'] . ' (' . $intNRecordsForm . ')</name>
						<open>0</open>
						<description></description>
						<Style>
							<ListStyle>
								<listItemType>check</listItemType>
								<bgColor>00ffffff</bgColor>
								<maxSnippetLines>2</maxSnippetLines>
							</ListStyle>
						</Style>
						<gx:balloonVisibility>1</gx:balloonVisibility>
					';
				}
				$intNForms++;
				$intNTotal++;
				$arrFormRecord = $this->formrecord->selectFormRecords(0, 0, 0, $arrFormRecordReport['idFormRecord']);
				$arrFormRecord = $arrFormRecord[0];
				// Inserting Record Data
				$strDescription = '';
				if (! $blnKMLObjNameIsIdFormRecord) {
					// Header Information
					$strDescription .= '<b>URL: </b> ' . '<a href="' . $this->strings->strSiteURL . '/' . $arrFormRecord['idFormRecord'] . '" target="_blank">' . $this->strings->strSiteURL . '/' . $arrFormRecord['idFormRecord'] . '</a><br>';
					// Geographic Coords
					$strDescription .= '<b>Geo Coords: </b> ' . $arrFormRecord['dblLatitude'] . ':' . $arrFormRecord['dblLongitude'] .  '<br>';
					// UTM Coords
					$strDescription .= '<b>UTM Coords:</b> ' . $arrFormRecord['dblLatitudeUTM'] . ':' . $arrFormRecord['dblLongitudeUTM'] . ' ' . $arrFormRecord['intZoneUTM'] .  '<br>';
					// Info Criacao
					$strDescription .= '<b>' . ($blnLiveKML ? 'Created' : $_SESSION['strGlobalCreated']) . ':</b> ' . $arrFormRecord['strCreation'] . ' (' . $arrFormRecord['strEmail'] .  ') <br>';
					// Info Data Ultima Atualizacao
					$strDescription .= '<b>' . ($blnLiveKML ? 'Last Update' : $_SESSION['strGlobalUpdated']) . ':</b> ' .  $arrFormRecord['strLastUpdate'] . '</b><br>'; 
					// Distance m
					$strDescription .= ($arrFormRecordReport['dblDistanceFromCenterMts'] > 0 ? '<b>' . ($blnLiveKML ? 'Distance' : $_SESSION['strGlobalDistance']) . ' (m):</b> ' . number_format($arrFormRecordReport['dblDistanceFromCenterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . '</b><br>' : '');
					// Perimeter for Polylines and Polygons
					if ($arrFormRecord['idShapeType'] > 1) {
						$strDescription .= '<b>' . $_SESSION['strGlobalPerimeter'] . ':</b> ' . number_format($arrFormRecord['dblPerimeterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' mts<br>'; 
					}
					// Area for Polygons
					if ($arrFormRecord['idShapeType'] == 3) {
						$strDescription .= '<b>' . $_SESSION['strGlobalArea'] . ':</b> ' . number_format($arrFormRecord['dblAreaMts2'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' m�<br>'; 
					}
					if ($intFormFields < $this->intKMLFieldsLimit) { // Avoid it to take so long
						$i = 0;
						$arrFormRecordDatas = $this->formrecord->selectFormRecordData($arrFormRecordReport['idFormRecord']);
						foreach($arrFormRecordDatas as $arrFormRecordData) {
							//$strValue = $this->formrecord->returnInfoCampoFormulario($arrFormRecordData, $arrFormField['idPergunta'], $arrFormField['idTipoPergunta']);	
							$strValue = $arrFormRecordData['strValue'];
							// Reformat Time Series
							if ($arrFormRecordData['idFormFieldType'] == 7) $strValue = str_replace('<:>',", ",$strValue);
							$strDescription .= '<b>' . $arrFormRecordData['strName'] . ': </b> ' . $strValue . '<br>';
							$i++;
						}
					}
					// Attached Files
					foreach($arrFormRecord['arrFiles'] as $arrFile) {
						$strTitle = utf8_decode($arrFile['strFileOriginalName'] . ' - ' . $arrFile['strDescription'] . ' ' . number_format(@filesize($arrFile['strFileNameFullPath'])/1000000, 2, '.','') . ' Mb');
						$strDescription .= '<span style="cursor:pointer;margin:5px;float:left"><a href="' . $arrFile['strFileNameFullURL'] . '"><img src="' . $arrFile['strFileThumbURL'] . '" style="width:' . $this->strings->intThumbSize . 'px;height:' . $this->strings->intThumbSize . 'px" align="absmiddle" title="' . $strTitle. '"></a></span>';
					}				
				}
								
				// Inserting Vertexes
				$strVertexs = '';
				foreach($arrFormRecord['arrVertex'] as $arrVerte) {
					$strVertexs .= $arrVerte['dblLongitude'] . ',' . $arrVerte['dblLatitude'] . ",0 ";
				}
				if ($arrFormRecord['idShapeType'] == 3) {
					$strVertexs .= $arrFormRecord['arrVertex'][0]['dblLongitude'] . ',' . $arrFormRecord['arrVertex'][0]['dblLatitude'] . ",0 ";
				}
				
				$strRGB = $arrFormRecord['strCustomMarkerRGBColor'];
				$strRGB = str_replace('#','', $strRGB);
				$strRGB = $this->strings->strSwapRGBToBGR($strRGB);
				$intMapPolygonsOpacity255 = round($intMapPolygonsOpacity*255/100);
				if (($intMapPolygonsOpacity255 > 0) && ($intMapPolygonsOpacity255 < 40)) $intMapPolygonsOpacity255 = 127; // Force to darker
				$strOpacityHex = dechex($intMapPolygonsOpacity255); // Opacity - [00..FF]
				$strRGBStroke = 'FF' . $strRGB;
				$strRGB = $strOpacityHex . $strRGB;
				$strPlaces .= '
		<Placemark>
			<name>' . ($blnKMLObjNameIsIdFormRecord ? $arrFormRecord['idFormRecord'] : $arrForm['strName'] . ' - ' . $arrFormRecord['idFormRecord'] . (count($arrFormRecord['arrFiles']) > 0 ?  ' ('  . count($arrFormRecord['arrFiles']) .  ')' : '')) . '</name>
			<description><![CDATA[' . $strDescription . ']]></description>';
				$strPlaceType = 'Point';
				if ($arrFormRecord['idShapeType'] == 1) {
					$strStyles .= '
					<Style id="style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><IconStyle><scale>1.2</scale><Icon><href>' . $arrFormRecord['strMarkerFullURL'] . '</href></Icon><hotSpot x="32" y="1" xunits="pixels" yunits="pixels"/></IconStyle></Style>
					<Style id="hstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><IconStyle><scale>1.4</scale><Icon><href>' . $arrFormRecord['strMarkerFullURL'] . '</href></Icon><hotSpot x="32" y="1" xunits="pixels" yunits="pixels"/></IconStyle></Style>
					<StyleMap id="mstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><Pair><key>normal</key><styleUrl>#style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair><Pair><key>highlight</key><styleUrl>#hstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair></StyleMap>
					';
				} else if ($arrFormRecord['idShapeType'] == 2) {
					$strPlaceType = 'LineString';
					$strStyles .= '				
					<Style id="style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><LineStyle><width>3.5</width><color>' . $strRGB . '</color></LineStyle><PolyStyle><color>' . $strRGB . '</color></PolyStyle></Style>
					<StyleMap id="mstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><Pair><key>normal</key><styleUrl>#style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair><Pair><key>highlight</key><styleUrl>#style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair></StyleMap>
					';
				} else if ($arrFormRecord['idShapeType'] == 3) {
					$strPlaceType = 'Polygon';
					$strVertexs .= $arrFormRecord['arrVertex'][count($arrFormRecord['arrVertex'])-1]['dblLongitude'] . ',' . $arrFormRecord['arrVertex'][count($arrFormRecord['arrVertex'])-1]['dblLatitude'] . ",0 ";
					$strStyles .= '
					<Style id="style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><LineStyle><width>3.5</width><color>' . $strRGBStroke . '</color></LineStyle><PolyStyle><color>' . $strRGB . '</color></PolyStyle></Style>
					<StyleMap id="mstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '"><Pair><key>normal</key><styleUrl>#style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair><Pair><key>highlight</key><styleUrl>#style-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl></Pair></StyleMap>
					';
				}
				$strPlaces .= '	
			<styleUrl>#mstyle-' . $arrFormRecord['idForm'] . '-' . $arrFormRecord['idFormRecord'] . '</styleUrl>
			<' . $strPlaceType . '>';
				if ($strPlaceType != 'Point')   {
					$strPlaces .= '
				<tessellate>1</tessellate>';
				}
				if ($strPlaceType == 'Polygon') {
					$strPlaces .= '
				<outerBoundaryIs><LinearRing>';
				}
				$strPlaces .= '
				<coordinates>' . $strVertexs . '</coordinates>';
				if ($strPlaceType == 'Polygon') {
					$strPlaces .= '
				</LinearRing></outerBoundaryIs>';
				}	
				$strPlaces .= '
			</' . $strPlaceType . '>';
				$strPlaces .= '
		</Placemark>';
				if ($blnEcho) {
					echo ',' . ($idLineFormRecord+1) . '/' . count($arrFormRecordsReport);
				}
			} // End of FormRecords
			$strPlaces .= '</Folder>';
			$strOut = '<?xml version="1.0" encoding="UTF-8"?>
	<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2" xmlns:kml="http://www.opengis.net/kml/2.2" xmlns:atom="http://www.w3.org/2005/Atom">
		<Document>
			<open>1</open>
			<name>' . strip_tags($arrProject['strName']) . ' (' . $intNTotal . ')</name>' . $strStyles . $strPlaces . '
		</Document>
	</kml>';
			if ($blnLiveKML) {
				$arrOutput['strReport'] = $strOut;
			} else {
				$fh = fopen($arrOutput['strFilePathTMP'], 'w');
				fwrite($fh, $strOut);
				fclose($fh);
			}
		break;
	
		case "HTML":
			// Radius search ...Sort records by distance
			if ($dblLatC <> 0) { 
				// Bubble sort
				$nowData = null;
				for ($i=0; $i<count($arrFormRecordsReport); $i++) {
					for ($j=0; $j<count($arrFormRecordsReport); $j++) {
						if($arrFormRecordsReport[$i]['dblDistanceFromCenterMts'] < $arrFormRecordsReport[$j]['dblDistanceFromCenterMts']){
							$nowData = $arrFormRecordsReport[$i];
							$arrFormRecordsReport[$i] = $arrFormRecordsReport[$j];
							$arrFormRecordsReport[$j] = $nowData;
						}
					}
				}
			}
			$strPageTitle = $arrProject['strName'] . ' - ' . date('d/m/Y H:i');
			$strHTML = '<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<title>'  . $strPageTitle . '</title>
			<link href="' . $this->strings->strSiteURL . '/css/bootstrap-' . $arrProject['strThemeName'] . '.css" rel="stylesheet">
			<link href="' . $this->strings->strSiteURL . '/css/bootstrap-responsive.css" rel="stylesheet">
			<link href="' . $this->strings->strSiteURL . '/css/main.css" rel="stylesheet">
			<link href="' . $this->strings->strSiteURL . '/css/charisma.css" rel="stylesheet">
			<link rel="shortcut icon" href="' . $this->strings->strSiteURL . '/img/logofav.png">
		</head>
		<style>
			body {font-family:Calibri;}
			td {padding-left:5px;}
			tr {border: solid 1px;}
			tr:nth-child(even) {background: ' . $this->strings->strSiteBaseColorLighter . ';}
			tr:nth-child(odd) {background: ' . $this->strings->strSiteBaseColorLight . ';}
			.tables {border: solid 1px; ' . $this->strings->strSiteBaseColorLighter . ';}
			.title {font-weight:bold;color:#000000;font-size:20px;}
			.rounded {-moz-border-radius: 4px;-webkit-border-radius: 4px;border-radius: 4px;opacity: 1!important;}
			.shine {box-shadow: 0 0 25px rgba(255, 255, 255, 1);-webkit-box-shadow: 0 0 25px rgba(255, 255, 255, 1);-moz-box-shadow: 0 0 25px rgba(255, 255, 255, 1);}
			.break {page-break-before: always;}
		</style>
		<body style="margin:10px;background-color:#FFFFFF">
			<img src="' . $this->strings->strSiteURL . '/' . $this->strings->strSiteLogoPath . '" style="float:left;padding-top:5px;padding:5px;height:30px;"  class="rounded">
			<img src="' . $this->strings->strSiteURL . '/' . $arrProject['strLogoFileFullPath'] . '" style="float:right;padding-top:5px;padding:5px;height:30px;"  class="rounded">
			<div style="text-align:center">
				<i class="icon-print" style="cursor:pointer;" onClick="window.print();"></i> 
				<span class="title"> ' . $strPageTitle . '</span>
			</div>
			<div id="chkForms" style="text-align:center;color:#000000;padding:10px">';
			// Inserting Checkboxes
			$arrFormsCheckbox = array();
			foreach ($arrFormRecordsReport as $arrFormRecordReport) {
				if (array_search($arrFormRecordReport['idForm'], $arrFormsCheckbox) !== FALSE) continue;
				$arrFormsCheckbox[] = $arrFormRecordReport['idForm'];
				$arrForms = $this->form->selectForms(0, $arrFormRecordReport['idForm']);
				$strHTML .= '
				<input type="checkbox" checked="true" id="ckb-' . $arrFormRecordReport['idForm'] . '" onClick="
					var tbls = document.getElementsByClassName(\'tbl-' . $arrFormRecordReport['idForm'] . '\');
					for (i=0;i<tbls.length;i++) {
						tbls[i].style.visibility = this.checked ? \'visible\' : \'hidden\';
						tbls[i].style.display = this.checked ? \'block\' : \'none\';
					}
				">
				<label for="ckb-' . $arrFormRecordReport['idForm'] . '" style="cursor:pointer;padding-right:15px;display:inline">
					<img style="max-height:24px;" src="' . $this->strings->strSiteURL . '/' . $arrForms[0]['strMarkerFullPath'] . '" align="absmiddle"> '
					. $arrForms[0]['strName'] . 
					' (' . $this->intNumberRecordsArrayForm($arrFormRecordsReport, $arrFormRecordReport['idForm']) . ')
				</label>';
			}
			$strHTML .= '</div>';
			$strHTML .= '<style> p {font-weight:normal;color:#000000;font-size:12px;margin:4px}</style>';
			$idForm = 0;
			$blnEhPrimeiro = true;
			$i = 1;
			foreach ($arrFormRecordsReport as $idLineFormRecord => $arrFormRecordReport) {
				if ((! $arrFormRecordReport['idForm']) || (! $arrFormRecordReport['idFormRecord'])) continue;
				if ($idForm != $arrFormRecordReport['idForm']) {
					if ($idForm != 0) $strHTML .= '</span>';
					$idForm = $arrFormRecordReport['idForm'];
					$arrForms = $this->form->selectForms(0, $arrFormRecordReport['idForm']);
					$arrFormFields = $this->form->selectFormFields($arrFormRecordReport['idForm']);
				}
				//($blnEhPrimeiro ? ' break' : '') // For 1 record per page, uncomment
				$strHTML .= '<table width="100%" style="margin-top:10px;" id="tbl-' . $arrFormRecordReport['idForm'] . '-' . $arrFormRecordReport['idFormRecord'] . '" class="tbl-' . $arrFormRecordReport['idForm'] . ' tables rounded shine' . ($blnEhPrimeiro ? '' : '') . '"><tr><td width="100%" style="background-color:#FFFFFF;line-height:14px;">';
				// Header Information
				$arrFormRecord = $this->formrecord->selectFormRecords(0, 0, 0, $arrFormRecordReport['idFormRecord']);
				$arrFormRecord = $arrFormRecord[0];
				// If Number of Records is too big, disable static image due to Google Static API's quota limitation
				$stStatictGoogleMapsThumbURL = '';
				if ($i < $this->intGoogleStaticLimit) { 
					$stStatictGoogleMapsThumbURL = $this->strings->strGenerateStaticMapsURL($arrFormRecord['idShapeType'], $arrFormRecord['strCustomMarkerRGBColor'], $arrFormRecord['strFormName'], $arrFormRecord['arrVertex'], $dblLatC, $dblLngC, $strMapType);
					//$strHTML .= '<tr><td>&nbsp;</td><td align="center" valign="top" rowspan="100" style="width:400px;"><img class="rounded" src="' . $stStatictGoogleMapsThumbURL . '" style="width:100%"></td></tr>';
				}
				$blnEhPrimeiro = false;
				$strHTML .= ($stStatictGoogleMapsThumbURL ? '<img class="rounded" src="' . $stStatictGoogleMapsThumbURL . '" style="width:300px;float:right;">' : '') . '
				<p><b>URL:</b> <a href="' . $this->strings->strSiteURL . '/' . $arrFormRecord['idFormRecord'] . '" target="_blank">' . $this->strings->strSiteURL . '/' . $arrFormRecord['idFormRecord'] . '</a></p>
				<p><b>' . $_SESSION['strGlobalForm'] . ':</b> <img style="max-height:18px;" src="' . $arrFormRecord['strMarkerFullURL'] . '" align="absmiddle" style="float:right"> ' . $arrForms[0]['strName'] . '</p>
				<p><b>ID: ' . $arrFormRecordReport['idFormRecord'] . '</p>
				<p><b>' . $_SESSION['strGlobalCreated'] . ':</b> ' . $arrFormRecord['strCreation'] . ' - ' . $arrFormRecord['strEmail'] . ' <img src="' . $this->strings->strSiteURL . '/' .  $arrFormRecord['strDeviceFilePath']. '" style="height:16px;" align="absmiddle"></p>
				<p><b>' . $_SESSION['strGlobalUpdated'] . ':</b> ' . $arrFormRecord['strLastUpdate'] . '</p>
				<p><b>' . $_SESSION['strGlobalCoordinates'] . ':</b> <img src="' . $this->strings->strSiteURL . '/' . $this->strings->strImgFilePathByidShapeType($arrFormRecord['idShapeType']) . '" style="height:16px;"> ' . number_format($arrFormRecord['dblLatitude'], 7, '.', '') . ' : ' . number_format($arrFormRecord['dblLongitude'], 7, '.', '') . '</p>' .
				($arrFormRecordReport['dblDistanceFromCenterMts'] > 0 ? '<p><b>' . $_SESSION['strGlobalDistance'] . ' (m):</b> ' . number_format($arrFormRecordReport['dblDistanceFromCenterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . '</p>' : '') . 
				($arrFormRecord['idShapeType'] > 1 ? '<p><b>' . $_SESSION['strGlobalPerimeter'] . ':</b> ' . number_format($arrFormRecord['dblPerimeterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' mts</p>' : '') . 
				($arrFormRecord['idShapeType'] == 3 ? '<p><b>' . $_SESSION['strGlobalArea'] . ':</b> ' . number_format($arrFormRecord['dblAreaMts2'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' m�</p>' : '');
				$arrFormRecordDatas = $this->formrecord->selectFormRecordData($arrFormRecordReport['idFormRecord']);
				foreach($arrFormRecordDatas as $arrFormRecordData) {
					//$strValue = $this->formrecord->returnInfoCampoFormulario($arrFormRecordData, $arrFormField['idPergunta'], $arrFormField['idTipoPergunta']);	
					$strValue = $arrFormRecordData['strValue'];
					// Format for time series
					if ($arrFormRecordData['idFormFieldType'] == 7) $strValue = str_replace('<:>',", ", $strValue);
					$strHTML .= '<p><b>' . $arrFormRecordData['strName'] . ':</b> ' . $strValue . '</p>';
				}
				
				// Attached Files
				if (count($arrFormRecord['arrFiles'])) {
					foreach($arrFormRecord['arrFiles'] as $arrFile) {
						$strTitle = utf8_decode($arrFile['strFileOriginalName'] . ' - ' . $arrFile['strDescription'] . ' ' . number_format(@filesize($arrFile['strFileNameFullPath'])/1000000, 2, '.','') . ' Mb');
						$strHTML .= '<span style="cursor:pointer;margin:5px;float:left"><a href="' . $arrFile['strFileNameFullURL'] . '"><img src="' . $arrFile['strFileThumbURL'] . '" style="width:' . $this->strings->intThumbSize . 'px;height:' . $this->strings->intThumbSize . 'px" align="absmiddle" title="' . $strTitle. '"></a></span>';
					}
				}
				$strHTML .= '</td></tr></table>';
				$i++;
				if ($blnEcho) {
					echo ',' . ($idLineFormRecord+1) . '/' . count($arrFormRecordsReport);
				}
			} // End FormRecord Iteration
			$strHTML .= '</body></html>';	
			$fh = fopen($arrOutput['strFilePathTMP'], 'w');
			fwrite($fh, $strHTML);
			fclose($fh);
		break;
		
		case "XML":
			$arrXML = array();
			$arrXML['title'] = $arrProject['strName'];
			$arrXML['description'] = $arrProject['strDescription'];
			$arrXML['link'] = $this->strings->strSiteURL . '/' . $arrProject['strAlias'];
			$arrXML['pubDate'] = date('D, d M Y H:i:s') . ' GMT';
			$k = 0;
			foreach ($arrFormRecordsReport as $idLineFormRecord => $arrFormRecordReport) {
				if ((! $arrFormRecordReport['idForm']) || (! $arrFormRecordReport['idFormRecord'])) continue;
				if ($idForm != $arrFormRecordReport['idForm']) {
					$idForm = $arrFormRecordReport['idForm'];
					$arrForms = $this->form->selectForms(0, $arrFormRecordReport['idForm']);
					$arrFormFields = $this->form->selectFormFields($arrFormRecordReport['idForm']);
				}
				$arrFormRecord = $this->formrecord->selectFormRecords(0, 0, 0, $arrFormRecordReport['idFormRecord']);
				$arrFormRecord = $arrFormRecord[0];
				$arrXML['records'][$k]['URL'] = $this->strings->strSiteURL . '/' . $arrFormRecord['idFormRecord'];				
				$arrXML['records'][$k]['formName'] = $arrForms[0]['strName'];
				$arrXML['records'][$k]['recordID'] = $arrFormRecord['idFormRecord'];
				$arrXML['records'][$k]['shapeType'] = $arrFormRecord['idShapeType'];
				$arrXML['records'][$k]['creationDate'] = $arrFormRecord['strCreation'];
				$arrXML['records'][$k]['creationEmail'] = $arrFormRecord['strEmail'];
				$arrXML['records'][$k]['lastUpdateDate'] = $arrFormRecord['strLastUpdate'];
				$arrXML['records'][$k]['sourceDevice'] = $arrFormRecord['idDevice'];
				$arrXML['records'][$k]['shapeColor'] = $arrFormRecord['strCustomMarkerRGBColor'];
				$arrXML['records'][$k]['markerImage'] = $arrFormRecord['strMarkerFullURL'];
				if ($arrFormRecordReport['dblDistanceFromCenterMts'] > 0) {
					 $arrXML['records'][$k]['distanceMts'] = number_format($arrFormRecordReport['dblDistanceFromCenterMts'], 2, '.', '');
				}				
				// Perimeter for Polylines and Polygons
				if ($arrFormRecord['idShapeType'] > 1) {
					$arrXML['records'][$k]['perimeterMts'] = number_format($arrFormRecord['dblPerimeterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']); 
				}
				// Area for Polygons
				if ($arrFormRecord['idShapeType'] == 3) {
					$arrXML['records'][$k]['AreaM2'] = number_format($arrFormRecord['dblAreaMts2'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']); 
				}
				$arrXML['records'][$k]['attachedFiles'] = count($arrFormRecord['arrFiles']);
				// Coordinates
				foreach($arrFormRecord['arrVertex'] as $index => $arrVerte) {
					$arrXML['records'][$k]['coordinates'][$index]['latitude'] = $arrVerte['dblLatitude'];
					$arrXML['records'][$k]['coordinates'][$index]['longitude'] = $arrVerte['dblLongitude'];
				}
				
				$arrFormRecordDatas = $this->formrecord->selectFormRecordData($arrFormRecordReport['idFormRecord']);
				foreach($arrFormRecordDatas as $index => $arrFormRecordData) {
					//$strValue = $this->formrecord->returnInfoCampoFormulario($arrFormRecordData, $arrFormField['idPergunta'], $arrFormField['idTipoPergunta']);	
					$strValue = $arrFormRecordData['strValue'];
					// Format for time series
					if ($arrFormRecordData['idFormFieldType'] == 7) $strValue = str_replace('<:>',", ", $strValue);
					$arrXML['records'][$k]['fields'][$index]['name'] = utf8_encode($arrFormRecordData['strName']);
					$arrXML['records'][$k]['fields'][$index]['description'] = utf8_encode($arrFormRecordData['strTip']);
					$arrXML['records'][$k]['fields'][$index]['dataType'] = $arrFormRecordData['idFormFieldType'];
					$arrXML['records'][$k]['fields'][$index]['value'] = utf8_encode($strValue);
				}
				
				// Attached Files
				foreach($arrFormRecord['arrFiles'] as $index => $arrFile) {
					$arrXML['records'][$k]['files'][$index]['name'] = $arrFile['strFileOriginalName'];
					$arrXML['records'][$k]['files'][$index]['description'] = $arrFile['strDescription'];
					$arrXML['records'][$k]['files'][$index]['sizeMb'] = number_format(@filesize($arrFile['strFileNameFullPath'])/1000000, 2, '.','');
					$arrXML['records'][$k]['files'][$index]['url'] = $arrFile['strFileNameFullURL'];
					$arrXML['records'][$k]['files'][$index]['urlThumb'] = $arrFile['strFileThumbURL'];
				}
				if ($blnEcho) {
					echo ',' . ($idLineFormRecord+1) . '/' . count($arrFormRecordsReport);
				}
				$k++;
			} // End of FormRecord
			// Convert Array to XML
			//$strXML = $this->strings->strArrayToXML($arrXML, 'records');
			$xml = new SimpleXMLElement("<?xml version=\"1.0\"?><result></result>");
			$this->strings->array_to_xml($arrXML,$xml);
			$strXML = $xml->asXML();

			$fh = fopen($arrOutput['strFilePathTMP'], 'w');
			fwrite($fh, $strXML);
			fclose($fh);
		break;
		}

		if (strpos($strEmail, '@') !== FALSE) {
			$strURL = $this->strings->strSiteURL . '/' . $arrOutput['strFilePathTMP'];
			$arrSessions = array();
			$arrSessions[0]['strTitle'] = $_SESSION['strReportTitle'];
			$arrSessions[0]['strContent'] = $_SESSION['strGlobalProject'] . ': ' . $arrProject['strName'] . '<BR>' . $_SESSION['strReportFormat'] . ': ' . $_GET['strExtension'] . '<BR>' . $_SESSION['strReportURL'] . ': <a href="' . $strURL . '" target="_blank">' . $strURL . '</a>';
			$strBody = $this->strings->mailFormatContent(2, $_SESSION['strReportTitle'], '<span style="font-weight:bold;color:#FF0000">' . $_SESSION['strReportWarning'] . '</span>', '', $arrSessions);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strReportTitle']);
			$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $strEmail);
		}
		
		if ($blnEcho) {
			echo '|' . json_encode($this->strings->encodeArray($arrOutput));	
		}
		return $arrOutput;
	}
	
	public function intNumberRecordsArrayForm($arrFormRecordsReport, $idForm) {
		$intNumber = 0;
		for ($i=0;$i<count($arrFormRecordsReport); $i++) {
			if ($arrFormRecordsReport[$i]['idForm'] == $idForm) {
				$intNumber++;
			}
		}
		return $intNumber;
	}
	
	public function liveGoogleEarthKML($idProject) {
		$arrProject = $this->project->selectProjects($idProject);
		$arrProject = $arrProject[0];
		$arrOutput = array();
		$arrOutput['strFilePathTMP'] = $this->strings->strSiteTmpFileFolder . '/live-' . $idProject . '-' . date('d-m-y-H-i-s') . '.kml';
		$strProjectName = $this->strings->removeInvalidChars($this->strings->changeCharAccent($arrProject['strName']));
		$arrOutput['strFilePath'] =  $strProjectName . '.kml';
		$strOut = '<?xml version="1.0" encoding="UTF-8"?>
	<kml xmlns="http://www.opengis.net/kml/2.2">
	<NetworkLink>
		<name>' . $this->strings->strSiteName . ' - ' . strip_tags($arrProject['strName']) . '</name>
		<open>1</open>
		<Link>
			<href>' . $this->strings->strSiteURL . '/earth.php?idProject=' . $idProject . '</href>
			<refreshMode>onInterval</refreshMode>
			<refreshInterval>1800</refreshInterval>
		</Link>
	</NetworkLink>
	</kml>
		';
		$fh = fopen($arrOutput['strFilePathTMP'], 'w');
		fwrite($fh, $strOut);
		fclose($fh);
		return $arrOutput;
	}
	
	public function bufferCoverArea($idProject, $strJSONScope, $idForm, $intRadiusMts, $idFormCoverBy, $strEmail = '') {
		set_time_limit(1800); // Increasing Timeout to Garantee Enough Time
		ob_implicit_flush(true);
		ob_end_flush();
		$arrProject = $this->project->selectProjects($idProject);
		$arrProject = $arrProject[0];
		$arrOutput = array();
		$arrOutput['strFilePathTMP'] = $this->strings->strSiteTmpFileFolder . '/buffer-' . $idProject . '-' . date('d-m-y-H-i-s') . '.xlsx';
		$strProjectName = $this->strings->removeInvalidChars($this->strings->changeCharAccent($arrProject['strName']));
		$arrOutput['strFilePath'] =  $strProjectName . '.xlsx';
		$workbook = new PHPExcel();	
		$worksheet = $workbook->getActiveSheet();
		$workbook->setActiveSheetIndex(0);
		$arrFormBuffer = $this->form->selectForms(0, $idForm);
		$arrFormBuffer = $arrFormBuffer[0];
		$arrFormPolygons = $this->form->selectForms(0, $idFormCoverBy);
		$arrFormPolygons = $arrFormPolygons[0];
		$arrFormRecordsPolygons = $this->formrecord->selectFormRecords(0, 0, $idFormCoverBy, 0, $strJSONScope);
		$arrFormRecordFieldsValues = $this->formrecord->selectFormRecordsFirstFieldTextValue($idFormCoverBy);
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, 1, $this->strings->changeCharAccent($arrFormPolygons['strName']));
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(1, 1, $this->strings->changeCharAccent($_SESSION['strGlobalArea'] . ' ' . $arrFormPolygons['strName'] . ' (km2)'));
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(2, 1, '# ' . $arrFormBuffer['strName']);
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(3, 1, $this->strings->changeCharAccent($_SESSION['strHomeToolsItemBufferCoverAreaCovered'] . ' ' . $_SESSION['strGlobalBy'] . ' ' . $arrFormBuffer['strName']));
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(4, 1, $this->strings->changeCharAccent($_SESSION['strHomeToolsItemBufferCoverAreaUncovered'] . ' ' . $_SESSION['strGlobalBy'] . ' ' . $arrFormBuffer['strName']));
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(5, 1, $this->strings->changeCharAccent('% ' . $_SESSION['strHomeToolsItemBufferCoverAreaCovered']));
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(6, 1, $this->strings->changeCharAccent('% ' . $_SESSION['strHomeToolsItemBufferCoverAreaUncovered']));
		$intRow = 2;
		foreach ($arrFormRecordsPolygons as $arrFormRecordPolygon) {
			if ($arrFormRecordPolygon['idShapeType'] != 3) continue;
			$arrObjects = array();
			$arrObjects[0]['arrVertex'] = $arrFormRecordPolygon['arrVertex'];
			// Get Polygon BB
			$arrBBox = array();
			$arrLat = array();
			$arrLng = array();
			$arrBBox['dblLatSW'] = 90; $arrBBox['dblLngSW'] = 180; $arrBBox['dblLatNE'] = -90; $arrBBox['dblLngNE'] = -180;
			foreach($arrFormRecordPolygon['arrVertex'] as $arrVertex) {
				$arrLat[] = $arrVertex['dblLatitude'];
				$arrLng[] = $arrVertex['dblLongitude'];
				if ($arrVertex['dblLatitude']   < $arrBBox['dblLatSW']) $arrBBox['dblLatSW'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  < $arrBBox['dblLngSW']) $arrBBox['dblLngSW'] = $arrVertex['dblLongitude'];
				if ($arrVertex['dblLatitude']   > $arrBBox['dblLatNE']) $arrBBox['dblLatNE'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  > $arrBBox['dblLngNE']) $arrBBox['dblLngNE'] = $arrVertex['dblLongitude'];
			}
			// End Polygon BB
			$arrFormRecordsBuffers = $this->formrecord->selectFormRecordBufferReport($idForm, $arrBBox['dblLatSW'], $arrBBox['dblLatNE'], $arrBBox['dblLngSW'], $arrBBox['dblLngNE']);
			foreach ($arrFormRecordsBuffers as $arrFormRecordBuffer) {
				if (! $this->strings->blnIsInPolygon($arrLat, $arrLng, $arrFormRecordBuffer['dblLatitude'], $arrFormRecordBuffer['dblLongitude'])) continue;
				$arrObjects[] = array('dblLatitude' => $arrFormRecordBuffer['dblLatitude'], 'dblLongitude' => $arrFormRecordBuffer['dblLongitude']);
			}
			$arrShadow = $this->arrRasterCalculateObjectsShadowArea($arrBBox, $arrObjects, $intRadiusMts);
			$dblAreaKm2 = $arrFormRecordPolygon['dblAreaMts2']/1000000;
			$dblCoveredAreaRate = $arrShadow['intCoveredPixels'] / ($arrShadow['intCoveredPixels'] + $arrShadow['intUncoveredPixels']);
			$dblCoveredAreaPct = $dblCoveredAreaRate*100;
			$dblCoveredAreaKm2 = $dblAreaKm2*$dblCoveredAreaRate;
			//$dblCoveredAreaKm2 = $arrShadow['intCoveredPixels']*pow($arrShadow['dblResolutionMts'], 2)/1000000;
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, $intRow, $this->strings->changeCharAccent($this->strFormRecordFieldValue($arrFormRecordPolygon['idFormRecord'], $arrFormRecordFieldsValues)));
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(1, $intRow, number_format($dblAreaKm2, 4, $_SESSION['strDecimal'], ''));
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(2, $intRow, count($arrObjects)-1);
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(3, $intRow, number_format($dblCoveredAreaKm2, 4, $_SESSION['strDecimal'], ''));
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(4, $intRow, number_format(($dblAreaKm2-$dblCoveredAreaKm2), 4, $_SESSION['strDecimal'], ''));
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(5, $intRow, number_format($dblCoveredAreaPct, 2, $_SESSION['strDecimal'], ''));
			$workbook->getActiveSheet()->setCellValueByColumnAndRow(6, $intRow, number_format((100-$dblCoveredAreaPct), 2, $_SESSION['strDecimal'], ''));
			$intRow++;
		}			
		$objworkbook = PHPExcel_IOFactory::createWriter($workbook, 'Excel2007');
		$objworkbook->save($arrOutput['strFilePathTMP']);
		
		if (strpos($strEmail, '@') !== FALSE) {
			$strURL = $this->strings->strSiteURL . '/' . $arrOutput['strFilePathTMP'];
			$arrSessions = array();
			$arrSessions[0]['strTitle'] = $_SESSION['strHomeToolsItemBuffer'];
			$arrSessions[0]['strContent'] = $_SESSION['strGlobalProject'] . ': ' . $arrProject['strName'] . '<BR>' . $_SESSION['strReportFormat'] . ': XLSX<BR>' . $_SESSION['strReportURL'] . ': <a href="' . $strURL . '" target="_blank">' . $strURL . '</a>';
			$strBody = $this->strings->mailFormatContent(2, $_SESSION['strReportTitle'], '<span style="font-weight:bold;color:#FF0000">' . $_SESSION['strReportWarning'] . '</span>', '', $arrSessions);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strHomeToolsItemBuffer']);
			$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $strEmail);
		}
		
		return $arrOutput;
	}
	
	public function strFormRecordFieldValue($idFormRecord, $arrFormRecordFieldsValues) {
		foreach ($arrFormRecordFieldsValues as $arrFormRecordFieldsValue) {
			if ($arrFormRecordFieldsValue['idFormRecord'] == $idFormRecord) {
				return $arrFormRecordFieldsValue['strValue'];
			}
		}
		return $idFormRecord;
	}

	// Create raster image and plots every objcted. Count no color pixels and multiplies per resolution
	public function arrRasterCalculateObjectsShadowArea($arrBBox, $arrObjects, $intRadiusMts) {
		$intMapMaxDimension = 500;
		$arrVertexs = $arrObjects[0]['arrVertex'];
		// Defining Resolution and Dimensions
		$this->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$dblWidthMts	= ceil($this->gPoint->distanceFrom($arrBBox['dblLngNE'], $arrBBox['dblLatSW']));
		$dblHeightMts 	= ceil($this->gPoint->distanceFrom($arrBBox['dblLngSW'], $arrBBox['dblLatNE']));	
		$dblResolution	= max($dblHeightMts, $dblWidthMts) / $intMapMaxDimension;
		$arrBBox['intWidthPixels']	= round($dblWidthMts / $dblResolution);
		$arrBBox['intHeightPixels']= round($dblHeightMts / $dblResolution);
		// Create Image
		$image = imagecreatetruecolor($arrBBox['intWidthPixels'], $arrBBox['intHeightPixels']);
		$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
		$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
		$imgRed		= ImageColorAllocate($image, 255, 0, 0);
		imagefilledrectangle($image, 0, 0, $arrBBox['intWidthPixels'], $arrBBox['intHeightPixels'], $imgWhite);
		// First is Polygon - Matrix		
		$arrPts = array();
		foreach($arrVertexs as $i => $arrVertex) {
			$arrXY = $this->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $dblResolution, $arrBBox);
			array_push($arrPts, $arrXY['X']);
			array_push($arrPts, $arrXY['Y']);
		}
		imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgBlack);
		foreach ($arrObjects as $i => $arrObject) {
			if ($i == 0) continue;
			// Buffers
			$arrXY = $this->convertLatLngToXY($arrObject['dblLatitude'], $arrObject['dblLongitude'], $dblResolution, $arrBBox);
			$intRadiusPixels = round($intRadiusMts/$dblResolution);
			imagefilledellipse ($image, $arrXY['X'], $arrXY['Y'], $intRadiusPixels, $intRadiusPixels, $imgRed);
		}
		// Check for black pixels = covered area
		$intUncoveredPixels = 0;
		$intCoveredPixels = 0;
		for ($y=0;$y<$arrBBox['intHeightPixels'];$y++) {
			for ($x=0;$x<$arrBBox['intWidthPixels'];$x++) {
				$pixelColor = imagecolorat($image, $x, $y);
				if ($pixelColor == $imgBlack) {
					$intUncoveredPixels++;
				} else if ($pixelColor == $imgRed) {
					$intCoveredPixels++;
				}
			}
		}
		//imagepng($image, 'tmp/' . rand(1,100) . '.png');
		imagedestroy($image);
		$arrResult = array('intCoveredPixels' => $intCoveredPixels, 'intUncoveredPixels' => $intUncoveredPixels, 'dblResolutionMts' => $dblResolution);
		return $arrResult;
	}
	
	function convertLatLngToXY($dblLat, $dblLng, $dblResolution, $arrBBox) {
		$arrXY = array();
		$this->gPoint->setLongLat($dblLng, $dblLat);
		if ($dblLng > $arrBBox['dblLngNE']) {
			$arrXY['X'] = $arrBBox['intWidthPixels']-1;
		} else if ($dblLng < $arrBBox['dblLngSW']) {
			$arrXY['X'] = 0;
		} else {
			$dblDistanceFromCornerMts = $this->gPoint->distanceFrom($arrBBox['dblLngSW'], $dblLat);
			$arrXY['X'] = round($dblDistanceFromCornerMts / $dblResolution);		
		}		
		if ($dblLat > $arrBBox['dblLatNE']) {
			$arrXY['Y'] = 0;
		} else if ($dblLat < $arrBBox['dblLatSW']) {
			$arrXY['Y'] = $arrBBox['intHeightPixels']-1;
		} else {
			$dblDistanceFromCornerMts = $this->gPoint->distanceFrom($dblLng, $arrBBox['dblLatNE']);
			$arrXY['Y'] = round($dblDistanceFromCornerMts / $dblResolution);	
		}
		return $arrXY;
	}	
}
?>