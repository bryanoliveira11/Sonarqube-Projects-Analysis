<?php
class Form {
	public $strDefaultIcon		= 'icon-list-alt';

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'formrecord.php';
		$formrecord = new Formrecord($database);
		$this->formrecord = $formrecord;
		
		session_start();
	}

	public function selectForms($idProject = 0, $idForm = 0, $strSearch = '', $blnActives = 0) {
		$query =
		"SELECT
			f.idForm,
			f.idProject,
			f.dtCreation,
			f.dtLastUpdate,
			f.idMarker,
			f.strName,
			f.blnActive
		FROM
			form 	f
		WHERE 1 > 0
			" . (($idProject > 0) ? " AND f.idProject = " . $idProject : "") . "
			" . (($idForm > 0) ? " AND f.idForm = " . $idForm : "") . "
			" . (($blnActives > 0) ? " AND f.blnActive = 1" : "") . "
			" . (is_numeric($strSearch) ? "AND f.idForm = " . $strSearch : " AND f.strName			LIKE '%" . $strSearch . "%'") . "
		ORDER BY f.strName";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strCreation'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtCreation']));
			$result[$idLine]['strLastUpdate'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtLastUpdate']));
			$arrMarkers = $this->selectMarkers($result[$idLine]['idMarker']);
			$result[$idLine]['strMarkerFullPath'] = $arrMarkers[0]['strMarkerFullPath'];
			$result[$idLine]['intRecords'] = $this->formrecord->intCountFormRecords(0, $result[$idLine]['idForm']);
		}
		return $result;
	}
	
	public function insertForm($idUser, $idProject, $strName, $idMarker = 0) {
		$query = "
			INSERT INTO 
				form 
			SET 
				idProject	= '" . $idProject . "',
				dtCreation	= NOW(),
				dtLastUpdate= NOW(),
				idMarker	= '" . ($idMarker > 0 ? $idMarker : $this->strings->idMarkerDefault) . "',
				strName		= '" . $strName . "'
		";
		$result = $this->database->executeQuery($query);
		$arrResult = array();
		$arrResult['idForm'] = $this->database->getLastInsertedID();
		$this->database->insertEvent(3, $idUser, $strName);
		return $arrResult;
	}
	
	public function deleteForm($idUser, $idForm, $blnKeepStructure = false) {
		set_time_limit(300);
		
		$query = "DELETE formrecordfieldtext FROM formrecord, formrecordfield, formrecordfieldtext WHERE formrecordfield.idFormRecordField = formrecordfieldtext.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);

		$query = "DELETE formrecordfieldnumeric FROM formrecord, formrecordfield, formrecordfieldnumeric WHERE formrecordfield.idFormRecordField = formrecordfieldnumeric.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldalternative FROM formrecord, formrecordfield, formrecordfieldalternative WHERE formrecordfield.idFormRecordField = formrecordfieldalternative.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);	
		
		$query = "DELETE formrecordfielddate FROM formrecord, formrecordfield, formrecordfielddate WHERE formrecordfield.idFormRecordField = formrecordfielddate.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldtime FROM formrecord, formrecordfield, formrecordfieldtime WHERE formrecordfield.idFormRecordField = formrecordfieldtime.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);

		$query = "DELETE formrecordfieldtimeserie FROM formrecord, formrecordfield, formrecordfieldtimeserie WHERE formrecordfield.idFormRecordField = formrecordfieldtimeserie.idFormRecordField AND formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordvertex FROM formrecord, formrecordvertex WHERE formrecordvertex.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);

		$query = "DELETE formrecordfield FROM formrecord, formrecordfield WHERE formrecordfield.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;		
		$result = $this->database->executeQuery($query);

		if (! $blnKeepStructure) {
			$query = "DELETE formfieldalternative FROM formfield, formfieldalternative WHERE formfield.idFormField = formfieldalternative.idFormField AND formfield.idForm=" . $idForm;
			$result = $this->database->executeQuery($query);
		} 

		$arrForm = $this->selectForms(0, $idForm);
		$strFormName =  $arrForm[0]['strName'];
		include_once 'formrecord.php';
		$formrecord = new Formrecord($this->database);
		$arrFormRecordFiles = $formrecord->selectFormRecordFiles($arrForm[0]['idProject'], 0, 0, $idForm);
		foreach ($arrFormRecordFiles as $arrFormRecordFile) {
			@unlink($arrFormRecordFile['strFileNameFullPath']);
			@unlink($arrFormRecordFile['strFileNameFullPathRed']);
		}
		
		$query = "DELETE formrecordfile FROM formrecordfile, formrecord WHERE formrecordfile.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordlog FROM formrecordlog, formrecord WHERE formrecordlog.idFormRecord = formrecord.idFormRecord AND formrecord.idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE FROM formrecord WHERE idForm=" . $idForm;
		$result = $this->database->executeQuery($query);

		if (! $blnKeepStructure) {		
			$query = "DELETE userfilterclause FROM userfilterclause, formfield WHERE userfilterclause.idFormField = formfield.idFormField AND formfield.idForm = " . $idForm;
			$result = $this->database->executeQuery($query);
	
			$query = "DELETE useralertclause FROM useralertclause, useralert WHERE useralert.idUserAlert = useralertclause.idUserAlert AND useralert.idForm = " . $idForm;
			$result = $this->database->executeQuery($query);
			
			$query = "DELETE FROM useralert WHERE idForm = " . $idForm;
			$result = $this->database->executeQuery($query);
	
			$query = "DELETE FROM formfield WHERE idForm = " . $idForm;
			$result = $this->database->executeQuery($query);
			
			$query = "DELETE FROM form WHERE idForm = " . $idForm;
			$result = $this->database->executeQuery($query);
			
			$this->database->insertEvent(4, $idUser, $strFormName);
		}
		
		return 1;
	}

	public function updateFormProperty($idForm, $strField, $strValue) {
		$query = "UPDATE form SET " . $strField . "='" . $strValue . "' WHERE idForm=" . $idForm;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function intCountForms($idProject) {
		$query = "SELECT COUNT(idForm) as `intNum` FROM form WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}
	
	public function intGetIdFormByName($idProject, $strName){
		$query = "SELECT idForm FROM form WHERE idProject = " . $idProject . " AND strName = '" . $strName . "'";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  (count($result) > 0 ? $result[0]['idForm'] : -1);
	}
	
	// Form Fields
	public function selectFormFields($idForm, $idFormField = 0, $blnActives = 0) {
		if ((! $idForm) && (! $idFormField)) return array();
		$query =
		"SELECT
			ff.idFormField,
			ff.idForm,
			ff.idFormFieldType,
			ff.strName,
			ff.strTip,
			ff.intOrder,
			ff.blnActive
		FROM
			formfield 	ff
		WHERE 
			ff.idForm = " . $idForm  . "
			" . (($idFormField > 0) ? " AND  ff.idFormField = " . $idFormField : "") . "
			" . (($blnActives > 0) ? " AND ff.blnActive = 1" : "") . "
		ORDER BY ff.intOrder, ff.idFormField";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strFormFieldType'] = $_SESSION['strFormFieldType_' . $result[$idLine]['idFormFieldType']];
			$result[$idLine]['blnSummary'] = strpos($result[$idLine]['strTip'], '<m>') !== FALSE;
		}
		return $result;
	}
	
	public function arrFormFieldIDs($idForm, $blnJustTextFields = true) {
		$query = "
			SELECT 
				idFormField 
			FROM 
				formfield 
			WHERE 
				idForm = " . $idForm . " AND 
				idFormFieldType <= " . ($blnJustTextFields ? "1" : "5") . "
			ORDER BY 
				intOrder, idFormField
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		foreach ($result as $idLine => $item) {
			$arrResult[] = $result[$idLine]['idFormField'];
		}
		return $arrResult;
	}
	
	public function insertFormField($idForm, $idFormFieldType = 1, $strName = '', $strTip = '', $intOrder = 999) {
		$query = "
			INSERT INTO
				formfield 
			SET 
				idForm			= " . $idForm . ",
				idFormFieldType	= " . $idFormFieldType . ",
				strName			= '" . $strName . "',
				strTip			= '" . $strTip . "',
				intOrder		= " . $intOrder . ",
				blnActive		= 1
		";
		$result = $this->database->executeQuery($query);
		$idFormField = $this->database->getLastInsertedID();
		$arrResult = $this->selectFormFields($idForm, $idFormField);
		return $arrResult[0];
	}
	
	public function updateFormField($idFormField, $strName, $idFormFieldType, $strTip) {
		$query = "
			UPDATE 
				formfield 
			SET 
				strName			= '" . $strName . "',
				idFormFieldType	= '" . $idFormFieldType . "',
				strTip			= '" . $strTip . "'
			WHERE 
				idFormField=" . $idFormField;
		$result = $this->database->executeQuery($query);
		$this->database->insertEvent(8, $_SESSION['idUser'], $strName, $idFormFieldType);
		return 1;
	}
	
	public function reorderFormFields($strIds) {
		$arrIds = explode(',', $strIds);
		$i=1;
		foreach ($arrIds as $idFormField) {
			if (! is_numeric($idFormField)) continue;
			$query = "UPDATE formfield SET intOrder=" . $i . " WHERE idFormField=" . $idFormField;
			$result = $this->database->executeQuery($query);
			$i++;
		}
		return true;
	}

	public function deleteFormField($idFormField) {
		$query = "DELETE formrecordfieldtext FROM formrecordfield,formrecordfieldtext WHERE formrecordfield.idFormRecordField = formrecordfieldtext.idFormRecordField AND formrecordfield.idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldnumeric FROM formrecordfield,formrecordfieldnumeric WHERE formrecordfield.idFormRecordField = formrecordfieldnumeric.idFormRecordField AND formrecordfield.idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldchoice FROM formfieldalternative,formrecordfieldchoice WHERE formrecordfieldchoice.idFormFieldAlternative = formfieldalternative.idFormFieldAlternative AND formfieldalternative.idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE FROM formrecordfield WHERE idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE FROM formfieldalternative WHERE idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE FROM userfilterclause WHERE idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$query = "DELETE FROM useralertclause WHERE idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);

		$query = "DELETE FROM formfield WHERE idFormField = " . $idFormField;
		$result = $this->database->executeQuery($query);
		
		$this->database->insertEvent(9, $_SESSION['idUser']);
		
		return 1;
	}
	
	public function intCountFormFields($idForm) {
		$query = "SELECT COUNT(idFormField) as `intNum` FROM formfield WHERE idForm = " . $idForm;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}
	
	// Form Field Types
	public function selectFormFieldTypes($idFormFieldType = 0) {
		$query = "
			SELECT
				fft.idFormFieldType,
				fft.strFormFieldType
			FROM
				formfieldtype fft
			" . ($idFormFieldType ? " WHERE fft.idFormFieldType = " . $idFormFieldType : "") . "
			ORDER BY
				fft.idFormFieldType
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strFormFieldType'] = $_SESSION['strFormFieldType_' . $result[$idLine]['idFormFieldType']];
		}
		return  $result;
	}
	
	// Markers
	public function selectMarkers($idMarker = 0, $idProject = 0) {
		$query = "
			SELECT
				m.idMarker,
				m.strMarkerFileName,
				m.idProject
			FROM
				marker m
			WHERE 1 > 0
			" . ($idMarker > 0 ? " AND m.idMarker = " . $idMarker : "") . "
			" . ($idProject > 0 ? " AND (m.idProject IS NULL OR m.idProject = " . $idProject . ")": "") . "
			ORDER BY
				m.idProject DESC,
				m.idMarker
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $result[$idLine]['strMarkerFileName'];
			if ($result[$idLine]['idProject'] > 0) {
				$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/' . $result[$idLine]['strMarkerFileName'];
			}
		}
		return  $result;	
	}
	
	public function deleteMarker($idMarker) {
		$arrMarker = $this->selectMarkers($idMarker);
		@unlink($arrMarker[0]['strMarkerFullPath']);
		$query = "DELETE FROM marker WHERE idMarker=" . $idMarker;
		$result = $this->database->executeQuery($query);
		return true;
	}
	
	public function uploadFileMarker($idProject, $strFileName, $blnFullPath = false) {
		$arrResult = array();
		$arrExt = explode('.', $strFileName);
		$strExt = strtolower(array_pop($arrExt));
		$strExt = (strlen($strExt) > 4 ? 'png' : $strExt);
		$strDestinationFileName = $this->strings->generateRandomString(5) . '.' . $strExt;
		$strDestinationFileFullP�th = $this->strings->strProjectFolder . '/' . $idProject . '/' . $strDestinationFileName;
		$strSourceFileFullPath = ($blnFullPath ? $strFileName : $this->strings->strSiteTmpFileFolder . '/' . $strFileName);
		if (copy($strSourceFileFullPath, $strDestinationFileFullP�th) !== FALSE) {
			$query = "
				INSERT INTO marker SET
					strMarkerFileName	= '" . $strDestinationFileName . "',
					idProject			= " . $idProject
			;
			$result = $this->database->executeQuery($query);
			$arrResult['idMarker'] = $this->database->getLastInsertedID();
			$arrResult['strMarkerFullPath'] = $strDestinationFileFullP�th;
		}
		return $arrResult;
	}
	
	// Form Field Alternatives
	public function selectFieldAlternatives($idFormField = 0, $idFormFieldAlternative = 0) {
		$query = "
			SELECT
				ffa.idFormFieldAlternative,
				ffa.idFormField,
				ffa.strAlternative,
				ffa.blnPublic
			FROM
				formfieldalternative ffa
			WHERE 1 > 0
			" . (($idFormField > 0) ? " AND  ffa.idFormField = " . $idFormField : "") . "
			" . (($idFormFieldAlternative > 0) ? " AND  ffa.idFormFieldAlternative = " . $idFormFieldAlternative : "") . "
			ORDER BY
				ffa.strAlternative
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;	
	}

	public function insertFieldAlternative($idFormField, $strAlternative = '', $blnPublic = 0) {
		$query = "
			INSERT INTO 
				formfieldalternative
			SET
				idFormField		= " . $idFormField . ",
				strAlternative	= '" . $strAlternative . "',
				blnPublic		= " . $blnPublic . "
		";
		$result = $this->database->executeQuery($query);
		$arrResult = array();
		$idFormFieldAlternative = $this->database->getLastInsertedID();
		$arrResult = $this->selectFieldAlternatives(0, $idFormFieldAlternative);
		return $arrResult[0];
	}
	
	public function insertFieldAlternativeBatch($idFormField, $strAlternatives) {
		$strValues = '';
		$strAlternatives = mysql_real_escape_string($strAlternatives);
		$arrAlternatives = explode('<br>', $strAlternatives);
		foreach ($arrAlternatives as $i => $strAlternative) {
			if (! trim($strAlternative)) continue;
			$strValues .= "(" . $idFormField . ", '" . $strAlternative . "', 0)" . ($i < count($arrAlternatives) - 1 ? "," : "");
		}
		$query = "INSERT INTO formfieldalternative (idFormField, strAlternative, blnPublic) VALUES " . $strValues;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function updateFieldAlternative($idFormFieldAlternative, $strAlternative) {
		$query = "
			UPDATE
				formfieldalternative
			SET
				strAlternative	= '" . $strAlternative . "'
			WHERE
				idFormFieldAlternative = " . $idFormFieldAlternative . "
		";
		$result = $this->database->executeQuery($query);
		return true;
	}
	
	public function deleteFieldAlternatives($idFormField = 0, $idFormFieldAlternative = 0) {
		if ((! $idFormField) && (! $idFormFieldAlternative)) return false;
		$query = "
			DELETE formrecordfieldalternative FROM formrecordfieldalternative, formfieldalternative
			WHERE 
				formrecordfieldalternative.idFormFieldAlternative = formfieldalternative.idFormFieldAlternative AND
				" . ($idFormField > 0 ? " formrecordfieldalternative.idFormField = " . $idFormField : "") . "
				" . ($idFormFieldAlternative > 0 ? " formrecordfieldalternative.idFormFieldAlternative = " . $idFormFieldAlternative : "") . "
		";
		$result = $this->database->executeQuery($query);
		$query = "
			DELETE FROM 
				formfieldalternative
			WHERE 
				" . ($idFormField > 0 ? " idFormField = " . $idFormField : "") . "
				" . ($idFormFieldAlternative > 0 ? " idFormFieldAlternative = " . $idFormFieldAlternative : "") . "
		";
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
}
?>