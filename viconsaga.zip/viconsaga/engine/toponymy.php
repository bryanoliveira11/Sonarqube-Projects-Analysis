<?php
class Toponymy {
	public $strDefaultIcon	= 'icon-font';

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		session_start();
	}
	
	public function selectToponymys($idProject = 0, $idUser = 0) {
		if ((! $idProject) && (! $idUser)) return array();
		$query =
		"SELECT
			t.idToponymy,
			t.idUser,
			t.dblLatitude,
			t.dblLongitude,
			t.strToponymy,
			t.strCSS
		FROM
			toponymy t,
			user	u
		WHERE
			u.idUser = t.idUser
			" . ($idProject > 0 ? " AND u.idProject = " . $idProject : "") . "
			" . ($idUser > 0 ? " AND t.idUser = " . $idUser : "") . "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	public function insertToponymy($idUser, $dblLatitude, $dblLongitude, $strToponymy, $strCSS = '') {
		$query = "
			INSERT INTO
				toponymy
			SET
				idUser	= " . $idUser . ",
				dblLatitude	= '" . $dblLatitude . "',
				dblLongitude= '" . $dblLongitude . "',
				strToponymy	= '" . utf8_decode($strToponymy) . "',
				strCSS		= '" . $strCSS . "'
		";
		$result = $this->database->executeQuery($query);
		$arrResult = array();
		$arrResult['idToponymy'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function updateToponymy($idToponymy, $dblLatitude, $dblLongitude, $strToponymy, $strCSS = '') {
		$query = "
			UPDATE
				toponymy
			SET
				dblLatitude	= '" . $dblLatitude . "',
				dblLongitude= '" . $dblLongitude . "',
				strToponymy	= '" . utf8_decode($strToponymy) . "',
				strCSS		= '" . $strCSS . "'
			WHERE
				idToponymy = " . $idToponymy . "
		";
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function deleteToponymy($idUser = 0, $idToponymy = 0) {
		if ((! $idUser) && (! $idToponymy)) return false;
		$query = "DELETE FROM toponymy WHERE " . ($idUser > 0 ? " idUser = " . $idUser : "") . ($idToponymy > 0 ? " idToponymy = " . $idToponymy : "");
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}

	public function intCountToponymys($idProject) {
		$query = "
			SELECT 
				COUNT(idToponymy) as `intNum` 
			FROM 
				toponymy	ml, 
				user		u
			WHERE 
				ml.idUser	= u.idUser AND
				u.idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}

	public function strLoadTreeViewToponymyXML($idProject) {
		$arrToponymys = $this->selectToponymys($idProject);
		if (! count($arrToponymys)) return '';
		$strXML = '<item text="' . $_SESSION['strHomeMapLabels'] . ' (' . count($arrToponymys) . ')" id="T" idKind="2" open="1" checked="1" call="1" select="1" aCol="#000000" sCol="#FFFFFF">' . chr(13);
		foreach ($arrToponymys as $arrToponymy) {
			$strXML .= '	<item text="' . $arrToponymy['strToponymy'] . '" id="2:' . $arrToponymy['idToponymy'] . '" idKind="1" idToponymy="' . $arrToponymy['idToponymy'] . '" dblLatitude="' . $arrToponymy['dblLatitude'] . '" dblLongitude="' . $arrToponymy['dblLongitude'] . '" tooltip="' . $arrToponymy['strToponymy'] . '" checked="1"></item>' . chr(13);
		}
		$strXML .= '</item>' . chr(13);
		return $strXML;
	}
}
?>