<?php
class Alert {
	public $strDefaultIcon	= 'icon-bullhorn';

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		session_start();
	}

	public function selectUserAlerts($idUserAlert = 0, $idUser = 0, $idForm = 0, $blnJustActives = 0, $blnOnRecordCreate = '', $blnOnRecordUpdate = '', $blnOnRecordDelete = '') {
		$query =
		"SELECT
			ua.idUserAlert,
			ua.idUser,
			ua.idForm,
			ua.dtCreation,
			ua.strName,
			ua.blnOnRecordCreate,
			ua.blnOnRecordUpdate,
			ua.blnOnRecordDelete,
			ua.strActionEmailTo,
			ua.intNotifyAfterDaysFromEvent,
			ua.blnActive,
			u.idProject,
			f.strName AS strFormName
		FROM
			useralert	ua,
			user		u,
			form		f
		WHERE
			u.idUser = ua.idUser AND
			f.idForm = ua.idForm
			" . (($idUserAlert > 0) ? " AND ua.idUserAlert = " . $idUserAlert : "") . "
			" . (($idUser > 0) ? " AND ua.idUser = " . $idUser : "") . "
			" . (($idForm > 0) ? " AND ua.idForm = " . $idForm : "") . "
			" . (($blnOnRecordCreate) ? " AND ua.blnOnRecordCreate = " . $blnOnRecordCreate : "") . "
			" . (($blnOnRecordUpdate) ? " AND ua.blnOnRecordUpdate = " . $blnOnRecordUpdate : "") . "
			" . (($blnOnRecordDelete) ? " AND ua.blnOnRecordDelete = " . $blnOnRecordDelete : "") . "
			" . (($blnJustActives > 0) ? " AND ua.blnActive = 1" : "") . "
		ORDER BY
			ua.dtCreation";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strCreation'] = date('d/m/y H:i', strtotime($result[$idLine]['dtCreation']));
			// Alert Clauses
			$result[$idLine]['arrClauses'] = $this->selectUserAlertClauses($result[$idLine]['idUserAlert']);
		}
		return $result;
	}

	public function insertUserAlert($idUser, $idForm, $strName, $blnOnRecordCreate = 0, $blnOnRecordUpdate = 0, $blnOnRecordDelete = 0, $strActionEmailTo = '', $intNotifyAfterDaysFromEvent = 0) {
		$query =
		"INSERT INTO useralert SET
			idUser						= " . $idUser . ",
			idForm						= " . $idForm . ",
			dtCreation					= NOW(),
			strName						= '" . $strName . "',
			blnOnRecordCreate			= " . $blnOnRecordCreate . ",
			blnOnRecordUpdate			= " . $blnOnRecordUpdate . ",
			blnOnRecordDelete			= " . $blnOnRecordDelete . ",
			strActionEmailTo			= '" . $strActionEmailTo . "',
			intNotifyAfterDaysFromEvent = " . $intNotifyAfterDaysFromEvent . ",
			blnActive					= 1
		";
		$result = $this->database->executeQuery($query);
		$arrResult = array();
		$arrResult['idUserAlert'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function updateUserAlert($idUserAlert, $strName, $blnOnRecordCreate, $blnOnRecordUpdate, $blnOnRecordDelete, $strActionEmailTo, $intNotifyAfterDaysFromEvent) {
		$query =
		"UPDATE useralert SET
			strName						= '" . $strName . "',
			blnOnRecordCreate			= " . $blnOnRecordCreate . ",
			blnOnRecordUpdate			= " . $blnOnRecordUpdate . ",
			blnOnRecordDelete			= " . $blnOnRecordDelete . ",
			strActionEmailTo			= '" . $strActionEmailTo . "',
			intNotifyAfterDaysFromEvent = " . $intNotifyAfterDaysFromEvent . "
		WHERE
			idUserAlert			= " . $idUserAlert . "
		";
		$result = $this->database->executeQuery($query);
		return true;
	}

	public function updateUserAlertActive($idUserAlert, $blnActive) {
		$query =
		"UPDATE useralert SET
			blnActive			= " . $blnActive . "
		WHERE
			idUserAlert			= " . $idUserAlert . "
		";
		$result = $this->database->executeQuery($query);
		return true;
	}
	
	public function deleteUserAlert($idUserAlert = 0, $idUser = 0) {
		if ($idUserAlert > 0) {
			$query = "DELETE FROM useralertevent WHERE idUserAlert = " . $idUserAlert;
			$result = $this->database->executeQuery($query);
			$query = "DELETE FROM useralertclause WHERE idUserAlert = " . $idUserAlert;
			$result = $this->database->executeQuery($query);
			$query = "DELETE FROM useralert WHERE idUserAlert = " . $idUserAlert;
			$result = $this->database->executeQuery($query);
			return $this->database->getNumAffectedRows();
		} else if ($idUser > 0) {
			$query = "DELETE useralertevent FROM useralertevent, useralert WHERE useralertevent.idUserAlert = useralert.idUserAlert AND useralert.idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			$query = "DELETE useralertclause FROM useralertclause, useralert WHERE useralertclause.idUserAlert = useralert.idUserAlert AND useralert.idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			$query = "DELETE FROM useralert  WHERE idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			return $this->database->getNumAffectedRows();
		}
	}

	public function intCountUserAlerts($idUser = 0, $blnJustActives = 0) {
		$query = "SELECT COUNT(idUserAlert) as `intNumUserAlerts` FROM useralert WHERE 1 > 0 " . ($idUser ? " AND idUser = " . $idUser : "") . ($blnJustActives == 1 ? " AND blnActive = 1" : "");
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNumUserAlerts'];
	}

	// User Alert Clauses
	public function selectUserAlertClauses($idUserAlert) {
		$query =
		"SELECT
			uac.idUserAlertClause,
			uac.idUserAlert,
			uac.idFormField,
			uac.strOperador,
			uac.strValue,
			f.idForm,
			ff.strName AS strFormField
		FROM
			useralertclause uac,
			form f,
			formfield ff
		WHERE
			uac.idFormField	= ff.idFormField AND
			ff.idForm		= f.idForm AND
			uac.idUserAlert	= " . $idUserAlert . "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}

	public function insertUserAlertClause($idUserAlert, $idFormField, $strOperador, $strValue) {
		$query =
		"INSERT INTO useralertclause SET
			idUserAlert	= " . $idUserAlert . ",
			idFormField	= " . $idFormField . ",
			strOperador	= '" . $strOperador . "',
			strValue	= '" . $strValue . "'
		";
		$result = $this->database->executeQuery($query);
		$arrResult = array();
		$arrResult['idUserAlertClause'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function deleteUserAlertClause($idUserAlertClause = 0, $idUserAlert = 0) {
		$query = "DELETE FROM useralertclause WHERE " . ($idUserAlertClause > 0 ? "idUserAlertClause = " . $idUserAlertClause : "idUserAlert = " . $idUserAlert);
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	// User Alert Event
	public function selectUserAlertEvents($idUser = 0, $intLimit = '', $dtFromDateTime = '', $blnRead = '', $blnNotified = '') {
		$query =
		"SELECT
			uae.idUserAlertEvent,
			uae.idUserAlert,
			uae.idEventType,
			uae.dtDateTime,
			uae.idUser,
			uae.idFormRecord,
			uae.dblLatitude,
			uae.dblLongitude,
			uae.txtDetails,
			uae.blnRead,
			uae.blnNotified,
			ua.strActionEmailTo,
			ua.intNotifyAfterDaysFromEvent,
			u.idProject,
			u.strName AS strUserName,
			u.strEmail AS strUserEmail,
			f.strName AS strFormName
		FROM
			useralertevent	uae,
			useralert		ua,
			user			u,
			form			f
		WHERE
			uae.idUserAlert = ua.idUserAlert AND
			uae.idUser		= u.idUser AND
			ua.idForm		= f.idForm
			" . (($idUser > 0) ? " AND uae.idUser = " . $idUser : "") . "
			" . (($dtFromDateTime <> '') ? " AND uae.dtFromDateTime >= '" . $dtFromDateTime . "'" : "") . "
			" . (($blnRead) ? " AND uae.blnRead = " . $blnRead : "") . "
			" . (($blnNotified) ? " AND uae.blnNotified = " . $blnNotified : "") . "
		ORDER BY 
			uae.dtDateTime DESC
		" . ($intLimit ? " LIMIT " . $intLimit : "") . "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateTime'] = date('d/m H:i', strtotime($result[$idLine]['dtDateTime']));
			$result[$idLine]['strEmailAbbreviated'] = strpos($result[$idLine]['strUserEmail'], '@') ? substr($result[$idLine]['strUserEmail'], 0, strpos($result[$idLine]['strUserEmail'], '@')) : $result[$idLine]['strUserEmail'];
			$result[$idLine]['strEventInfo'] = 
				$result[$idLine]['strDateTime'] . ' - ' . 
				$result[$idLine]['strEmailAbbreviated'] . 
					' <span style="color:' . ($result[$idLine]['idEventType'] == 13 ? '#006600' : ($result[$idLine]['idEventType'] == 14 ? '#0000FF' : '#FF0000')). '">' . 
					$_SESSION['strUserAlertEventType_' . $result[$idLine]['idEventType']] . 
					'</span> ' . 
					$result[$idLine]['strFormName'] . 
					' <a style="display:inline-block;padding:0px;margin:0px;cursor:pointer" title="' . $_SESSION['strGlobalClickForMoreDetails'] . '" onClick="'
				;
				$strOnClick = 'userAlertEventsShowDetails(' . $result[$idLine]['idUserAlertEvent'] . ');';
				if ($intLimit < 40) { // Top
					if (($result[$idLine]['dblLatitude'] <> '') && ($result[$idLine]['dblLatitude'] <> 0)) {
						$strOnClick .= 'map.setCenter(new google.maps.LatLng(' . $result[$idLine]['dblLatitude'] . ', ' . $result[$idLine]['dblLongitude'] . '));';
					}
					if ($result[$idLine]['idEventType'] != 15) {
						$strOnClick .= 'infoLoad(' . $result[$idLine]['idFormRecord'] . ');';
					} else {
						$strOnClick .= 'userAlertEventsShowDetails(' . $result[$idLine]['idUserAlertEvent'] . ');';
					}
				}
				$result[$idLine]['strEventInfo'] .= $strOnClick . '">' . $result[$idLine]['idFormRecord'] . '</a>';

		}
		return $result;
	}

	public function selectUserAlertEventDetails($idUserAlertEvent) {
		$query = "SELECT txtDetails FROM useralertevent WHERE idUserAlertEvent=" . $idUserAlertEvent;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0];
	}
	
	// $idEventType: 13->Insert, 14->Update, 15->Delete (FK from table 'eventtype')
	public function blnCheckAndInsertUserAlertEvent($arrFormRecord, $idEventType) {
		$intAlertEvents = 0;
		$arrUserAlerts = $this->selectUserAlerts(0, 0, $arrFormRecord['idForm'], 1, ($idEventType == 13 ? 1 : ''), ($idEventType == 14 ? 1 : ''), ($idEventType == 15 ? 1 : ''));
		// Insert for each alert which fits to criteria...
		foreach($arrUserAlerts as $arrUserAlert){
			// Check if inserting update again (multiple save button hit on updating)
			if ($idEventType == 14) { // Update
				$arrUserAlertEvents = $this->selectUserAlertEvents(0, 1); // Get last inserted event
				$arrUserAlertEvent = $arrUserAlertEvents[0];
				$intMinutesDontUpdate = 3;
				$dtTimeExpiry = strtotime($arrUserAlertEvent['dtDateTime'] . '+ ' . $intMinutesDontUpdate . ' minute');
				$blnAlreadyUpdated = ($dtTimeExpiry > strtotime(date('Y-m-d H:i:s')));
				// If same idEvent, idFormRecord and Less than 3 minutes, don't insert event. Already inserted
				if ((($arrUserAlertEvent['idEventType'] == 13) || ($arrUserAlertEvent['idEventType'] == 14)) && ($arrUserAlertEvent['idFormRecord'] == $arrFormRecord['idFormRecord']) && ($blnAlreadyUpdated)) {
					continue;
				}
			}
			$blnInsert = true;
			include_once 'formrecord.php';
			$formrecord = new Formrecord($this->database);
			// Filter Conditions for Details
			$strClauses = '';
			foreach ($arrUserAlert['arrClauses'] as $i => $arrClause) {
				$strClauses .= ($i > 0 ? ' ' . $_SESSION['strHomeFilterAnd'] . ' ' : '') . $arrClause['strFormField'] . $arrClause['strOperador'] . $arrClause['strValue'];
			}
			$txtDetails =	'<div style="margin:1%;border:solid 1px #444444;background-color:#CCCCCC;font-weight:bold;padding:3px;">' . $arrUserAlert['strName'] . 
							'<br>' . $_SESSION['stradmManageAlertsForm'] . ': ' . $arrUserAlert['strFormName'] . 
							($strClauses ? '<br>' . $_SESSION['stradmManageAlertsConditions'] . ': ' . $strClauses : '') .
							'</div>';
			if ($idEventType == 15) { // Delete
				$txtDetails .= '<table width="100%">' . $arrFormRecord['strInfo'] . '</table>';
			} else { // Insert or Update
				$arrFormRecord = $formrecord->selectFormRecords(0, 0, 0, $arrFormRecord['idFormRecord']);
				$arrFormRecord = $arrFormRecord[0];
				$arrRecordInfo = $formrecord->arrPrintFormRecordData($arrFormRecord, 2);
				$txtDetails .= '<table width="100%">' . $arrRecordInfo['strInfo'] . '</table>';
			}
			// Verifying if respect clauses for alert
			if (count($arrUserAlert['arrClauses']) > 0) {
				$arrFormRecordDatas = $formrecord->selectFormRecordData($arrFormRecord['idFormRecord']);
			}
			$arrClauseTestResults = array();
			foreach ($arrUserAlert['arrClauses'] as $i => $arrClause) {
				$arrClauseTestResults[$i] = false;
				foreach ($arrFormRecordDatas as $arrFormRecordData) {
					if ($arrFormRecordData['idFormField'] == $arrClause['idFormField']) {
						if ($arrClause['strOperador'] == '=') {
							if (strtoupper($arrClause['strValue']) == strtoupper($arrFormRecordData['strValue'])) {
								$arrClauseTestResults[$i] = true;
							}
						} else if ($arrClause['strOperador'] == '>') {
							if (floatval($arrFormRecordData['strValue']) > floatval($arrClause['strValue'])) {
								$arrClauseTestResults[$i] = true;
							}
						} else if ($arrClause['strOperador'] == '<') {
							if (floatval($arrFormRecordData['strValue']) < floatval($arrClause['strValue'])) {
								$arrClauseTestResults[$i] = true;
							}
						} else if ($arrClause['strOperador'] == '<>') {
							if (strtoupper($arrClause['strValue']) != strtoupper($arrFormRecordData['strValue'])) {
								$arrClauseTestResults[$i] = true;
							}
						}
						break;
					}
				}
			}
			foreach ($arrClauseTestResults as $arrClauseTestResult) {
				if (! $arrClauseTestResult) {
					$blnInsert = false;
					break;
				}
			}
			if (! $blnInsert) continue;
			$query =
			"INSERT INTO useralertevent SET
				idUserAlert		= " . $arrUserAlert['idUserAlert'] . ",
				idEventType		= " . $idEventType . ",
				dblLatitude		= '" . $arrFormRecord['dblLatitude'] . "',
				dblLongitude	= '" . $arrFormRecord['dblLongitude'] . "',
				dtDateTime		= NOW(),
				idUser			= " . $arrFormRecord['idUser'] . ",
				idFormRecord	= " . $arrFormRecord['idFormRecord'] . ",
				txtDetails		= '" . $txtDetails . "'
			";
			$result = $this->database->executeQuery($query);
			$arrUserAlertEvent = array();
			$arrUserAlertEvent['idUserAlertEvent'] = $this->database->getLastInsertedID();
			$arrUserAlertEvent['strActionEmailTo'] = $arrUserAlert['strActionEmailTo'];
			$arrUserAlertEvent['intNotifyAfterDaysFromEvent'] = $arrUserAlert['intNotifyAfterDaysFromEvent'];
			$arrUserAlertEvent['idProject'] = $arrUserAlert['idProject'];
			$arrUserAlertEvent['txtDetails'] = $txtDetails;
			$arrUserAlertEvent['idEventType'] = $idEventType;
			$this->notifyUserAlertEvent($arrUserAlertEvent); // Format Alert Mail
			$intAlertEvents++;
		}
		return $intAlertEvents;
	}
	
	public function notifyUserAlertEvent($arrUserAlertEvent) {
		if (count($arrUserAlertEvent)) {
			$arrUserAlertEvents[] = $arrUserAlertEvent;
		} else {
			$arrUserAlertEvents = $this->selectUserAlertEvents(0, 9999, '', '', 0); // Non Notified Mails
		}
		foreach ($arrUserAlertEvents as $arrUserAlertEvent) {
			// Check if wait to notify just N days after event		
			$dtNotify = strtotime($arrUserAlertEvent['dtDateTime'] . '+ ' . $arrUserAlertEvent['intNotifyAfterDaysFromEvent'] . ' days');
			if (($dtNotify > strtotime(date('Y-m-d H:i:s')))) {
				continue;
			}
			if (strpos($arrUserAlertEvent['strActionEmailTo'],'@') > 0) {
				$arrSessions = array();
				$arrSessions[0]['strTitle'] = $_SESSION['stradmManageAlertsMailRecordInformation'];
				$arrSessions[0]['strContent'] = $arrUserAlertEvent['txtDetails'];
				$strBody = $this->strings->mailFormatContent(2, $_SESSION['stradmManageAlertsMailTitle'], '', '', $arrSessions, '?idProject=' . $arrUserAlertEvent['idProject']);
				$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['stradmManageAlertsMailTitle'] . ' ' . $_SESSION['strEventType_' . $arrUserAlertEvent['idEventType']]);
				$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $arrUserAlertEvent['strActionEmailTo']);
			}
			$query = "UPDATE useralertevent SET blnNotified=1 WHERE idUserAlertEvent = " . $arrUserAlertEvent['idUserAlertEvent'];
			$result = $this->database->executeQuery($query);
		}
	}
		
	public function updateUserAlertEvent($idUser, $blnRead = 0, $blnNotified = 0) {
		if ((! $blnRead) && (! $blnNotified)) return false;
		$query =
		"UPDATE useralertevent, useralert SET
		" . ($blnRead	 	> 0 ? "useralertevent.blnRead	= 1" : "") . "
		" . ($blnNotified	> 0 ? "useralertevent.blnNotified	= 1" : "") . "
		WHERE
			useralertevent.idUserAlert = useralert.idUserAlert AND
			useralert.idUser = " . $idUser . "
		";
		$result = $this->database->executeQuery($query);
		return true;
	}
	
	public function deleteUserAlertEvent($idUser) {
		$query = "DELETE useralertevent FROM useralertevent, useralert WHERE useralert.idUserAlert=useralertevent.idUserAlert AND useralert.idUser=" . $idUser;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function intCountUserAlertEventUnread($idUser) {
		$query = "
			SELECT 
				COUNT(idUserAlertEvent) as `intNumUnreadUserAlertEvents` 
			FROM 
				useralertevent 
			WHERE 
				idUser	= " . $idUser  . " AND 
				blnRead	= 0
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0];
	}
}
?>