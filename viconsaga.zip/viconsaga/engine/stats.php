<?php
class Stats {
	public $strDefaultIcon	= 'icon-signal';

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		session_start();
	}
	
	public function selectProjectSearch($idProject = 0, $intDays=9999) {
		$query =
		"SELECT
			strSearch, COUNT(strSearch) as `intCount` 
		FROM
			projectsearch ps
		WHERE
			ps.idProject = " . $idProject  . " AND 
			ps.dtDateSearch >= CURDATE() - INTERVAL " . $intDays . " DAY
		GROUP BY 
			ps.strSearch
		ORDER BY intCount DESC 
		LIMIT 200
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strSearch'] = strip_tags($result[$idLine]['strSearch']);
		}
		return $result;
	}
	
	public function insertProjectSearch($idProject, $strStrings) {
		if (! $strStrings) return;
		$arrStrings = explode(';', $strStrings);
		$strInsert = '';
		foreach ($arrStrings as $strString) {
			if (! $strString) continue;
			$strStrings = strip_tags($strStrings);
			$strInsert .= ($strInsert ? "," : "") . " (" . $idProject . ", NOW(),'" . $strString . "')";
		}
		if (! $strInsert) return false;
		$query = "REPLACE INTO projectsearch (idProject, dtDateSearch, strSearch) VALUES " . $strInsert;
		$result = $this->database->executeQuery($query);
		return $this->database->getLastInsertedID();
	}
	
	public function deleteProjectSearch($idProject) {
		$query = "DELETE FROM projectsearch WHERE idProject=" . $idProject;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function chartLoadData($idChart, $idProject, $dtDateFrom, $dtDateTo) {
		$arrResult = array();
		//$dtDateFrom = $this->strings->ConvertDateBRToMySQL($dtDateFrom);
		//$dtDateTo = $this->strings->ConvertDateBRToMySQL($dtDateTo);
		// Calc number of days in range to define step
		$diff = abs(strtotime($dtDateTo) - strtotime($dtDateFrom));
		$intDays = floor($diff/(60*60*24));
		$strInterval = ($intDays <= 31 ? 'DAY' : 'MONTH');
		if ($idChart == 1) { // Access X Day
			$query = "
				SELECT 
					CONCAT(DAY(e.dtDateTime),'/',MONTH(e.dtDateTime)) as `X`,
					COUNT(e.idEvent) as `Y1` 
				FROM
					event e,
					user u
				WHERE 
					e.idEventType = 19 AND
					e.idUser = u.idUser AND
					u.idProject = " . $idProject . "
					" . ($dtDateFrom  ? " AND e.dtDateTime >= '" . $dtDateFrom . "  00:00:00'" : "") . "
					" . ($dtDateTo ? " AND e.dtDateTime <= '" . $dtDateTo . "  23:59:59'" : "") . "
				GROUP BY 
					" . $strInterval . "(e.dtDateTime) 
				ORDER BY 
					e.dtDateTime
			";
//$fh = fopen("out.txt", 'w');fwrite($fh, $query);fclose($fh);
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			// Labels
			$arrResult['strType'] = 'line';
			$arrResult['strTitle'] = $_SESSION['stradmStatsTitleVisits'] . ' x ' . $_SESSION['stradmStatsTitleDay'];
			$arrResult['arrLabels'][0] = $_SESSION['stradmStatsTitleVisits'];
			$arrResult['arrLabels'][1] = $_SESSION['stradmStatsTitleDay'];
			foreach ($result as $idLine => $item) {
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['X'];
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['Y1'];
			}
		} else if ($idChart == 2) { // Top 10 Access Record
			$query = "
				SELECT 
					e.strParam1 as `X`,
					COUNT(e.strParam1) as `Y1` 
				FROM
					event e,
					user u
				WHERE 
					e.idEventType = 28 AND
					e.idUser = u.idUser AND
					u.idProject = " . $idProject . "
					" . ($dtDateFrom  ? " AND e.dtDateTime >= '" . $dtDateFrom . "  00:00:00'" : "") . "
					" . ($dtDateTo ? " AND e.dtDateTime <= '" . $dtDateTo . "  23:59:59'" : "") . "
				GROUP BY
					e.strParam1
				ORDER BY 
					`Y1` DESC
				LIMIT 10
			";
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			// Labels
			$arrResult['strType'] = 'bar';
			$arrResult['strTitle'] = 'ID x ' . $_SESSION['stradmStatsTitleViews'];
			$arrResult['arrLabels'][0] = 'ID';
			$arrResult['arrLabels'][1] = $_SESSION['stradmStatsTitleViews'];
			foreach ($result as $idLine => $item) {
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['X'];
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['Y1'];
			}
		} else if ($idChart == 3) { // Top 5 Users X Access X Month
			$query = "
				SELECT 
					u.strEmail as `X`,
					COUNT(e.idUser) as `Y1`
				FROM
					event	e,
					user	u
				WHERE 
					e.idEventType = 19 AND
					e.idUser = u.idUser AND
					u.idProject = " . $idProject . "
					" . ($dtDateFrom  ? " AND e.dtDateTime >= '" . $dtDateFrom . "  00:00:00'" : "") . "
					" . ($dtDateTo ? " AND e.dtDateTime <= '" . $dtDateTo . "  23:59:59'" : "") . "
				GROUP BY
					`X`
				ORDER BY 
					`Y1` DESC
				LIMIT 5
			";
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			// Labels
			$arrResult['strType'] = 'bar';
			$arrResult['strTitle'] = $_SESSION['stradmStatsTitleUsers'] . ' x ' . $_SESSION['stradmStatsTitleAccess'];
			$arrResult['arrLabels'][0] = $_SESSION['stradmStatsTitleUsers'];
			$arrResult['arrLabels'][1] = $_SESSION['stradmStatsTitleAccess'];
			foreach ($result as $idLine => $item) {
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['X'];
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['Y1'];
			}
		} else if ($idChart == 4) { // Top 5 Users X Records Creation
			$query = "
				SELECT 
					u.strEmail as `X`,
					COUNT(fr.idUser) as `Y1`
				FROM
					user	u,
					formrecord fr
				WHERE 
					u.idUser = fr.idUser AND
					u.idProject = " . $idProject . "
					" . ($dtDateFrom  ? " AND fr.dtCreation >= '" . $dtDateFrom . "  00:00:00'" : "") . "
					" . ($dtDateTo ? " AND fr.dtCreation <= '" . $dtDateTo . "  23:59:59'" : "") . "
				GROUP BY
					u.idUser
				ORDER BY 
					`Y1` DESC
				LIMIT 5
			";
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			// Labels
			$arrResult['strType'] = 'bar';
			$arrResult['strTitle'] = $_SESSION['stradmStatsTitleUsers'] . ' x ' . $_SESSION['stradmStatsTitleCreatedRecords'];
			$arrResult['arrLabels'][0] = $_SESSION['stradmStatsTitleUsers'];
			$arrResult['arrLabels'][1] = $_SESSION['stradmStatsTitleCreatedRecords'];
			foreach ($result as $idLine => $item) {
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['X'];
				$arrResult['arrValues'][$idLine][] = $result[$idLine]['Y1'];
			}
		}
		return $arrResult;
	}
	
	public function downloadStats($idProject) {
		$strFileName = $this->strings->strTempFolderPath . '/' . $this->strings->generateRandomString(5) . '.xlsx';
		require_once ('js/excel/Classes/PHPExcel.php');
		$workbook = new PHPExcel();	
		$objWorksheet = $workbook->getActiveSheet();
		// Plan Site
		$strPlanName = $this->strings->changeCharAccent('Records');
		$objWorksheet->setTitle($strPlanName);
		$workbook->setActiveSheetIndex(0);
		// Header
		$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, 1, $this->strings->changeCharAccent($_SESSION['stradmStatsHeaderSession']));
		$i=2;
		// Values from Rows
		foreach ($arrSessions as $strSession) {
			//$workbook->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $_SESSION['strStatsSessions_' . $strSession]);
			$i++;
		}		
		$workbook->setActiveSheetIndex(0);
		$objworkbook = PHPExcel_IOFactory::createWriter($workbook, 'Excel2007');
		$objworkbook->save($strFileName);
		return $strFileName;
	}
}
?>