<?php
class Kml {
	
	public function __construct() {
		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
	}
	
	public function load($strFileName, $blnReadCoords = true, $intPrintLimit = 100){
		$this->openKMLBreakLineTags($strFileName);
		$fh = fopen($strFileName, 'r');
		$arrKML['intNPoints'] = 0; $arrKML['intNLines'] = 0; $arrKML['intNPolygons'] = 0;
		$arrKML['strTable'] = '';
		$arrKML['arrBB'] = array('ymin' => 90, 'ymax' => -90, 'xmin' => 180, 'xmax' => -180);
		$arrObjects = array();
		$i = 0;
		$blnFound = 0;
		while (($strLine = fgets($fh)) !== false) {
			// Replacing chars from "&amp;" to "&" and so on...
			$strLine = $this->strings->strHTMLSpectialCharsToHTML($strLine);
			if (strpos(strtolower($strLine), '<placemark') !== false) {
				$blnFound = 1;
				$idShapeType = 1;
			} else if (($blnFound) && (stripos(strtolower($strLine), '<name>') !== false)) {
				$strName = $this->strings->strTagContent($strLine,'name');
			} else if (($blnFound) && (stripos(strtolower($strLine), '<description>') !== false)) {
				$strDescription = $this->strings->strTagContent($strLine,'description');
				while (stripos(strtolower($strLine), '</description>') === false)  {
					$strLine = fgets($fh);
					$strDescription .= $strLine;
				}
				$strDescription = utf8_decode($strDescription);
				$strDescription = str_replace(chr(13), " ", $strDescription);
				$strDescription = str_replace("\n", " ", $strDescription);
			} else if (($blnFound) && (stripos(strtolower($strLine), '<point>')) !== false) {
				$idShapeType = 1;
				$arrKML['intNPoints']++;
			} else if (($blnFound) && (stripos(strtolower($strLine), '<linestring>')) !== false) {
				$idShapeType = 2;
				$arrKML['intNLines']++;
			} else if (($blnFound) && (stripos(strtolower($strLine), '<polygon>')) !== false) {
				$idShapeType = 3;
				$arrKML['intNPolygons']++;
			} else if (($blnFound) && (stripos(strtolower($strLine), '<coordinates>')) !== false) {
				$arrObjects[$i]['strName'] = mb_strtoupper($strName);
				$arrObjects[$i]['strDescription'] = strip_tags(mb_strtoupper($strDescription), '<BR><BR/><BR />');
				$arrObjects[$i]['idShapeType'] = $idShapeType;
				if ($blnReadCoords) {
					$strCoordinates = $this->strings->strTagContent($strLine,'coordinates');
					while (stripos(strtolower($strLine), '</coordinates>') === false)  {
						$strLine = fgets($fh);
						$strCoordinates .= $strLine;
					}
					$arrstrCoordinates = explode(' ', $strCoordinates);
					$arrCoordinates = array();
					$j=0;
					foreach ($arrstrCoordinates as $strCoords) {
						$arrXYZ = explode(',', trim($strCoords));
						if ((! is_numeric($arrXYZ[0])) || (! is_numeric($arrXYZ[1]))) continue;
						$arrCoordinates[$j]['dblLatitude'] = $arrXYZ[1];
						$arrCoordinates[$j]['dblLongitude'] = $arrXYZ[0];
						if ($arrXYZ[0] < $arrKML['arrBB']['xmin']) $arrKML['arrBB']['xmin'] = $arrXYZ[0];
						if ($arrXYZ[0] > $arrKML['arrBB']['xmax']) $arrKML['arrBB']['xmax'] = $arrXYZ[0];
						if ($arrXYZ[1] < $arrKML['arrBB']['ymin']) $arrKML['arrBB']['ymin'] = $arrXYZ[1];
						if ($arrXYZ[1] > $arrKML['arrBB']['ymax']) $arrKML['arrBB']['ymax'] = $arrXYZ[1];
						$j++;
					}
					$arrObjects[$i]['arrCoordinates'] = $arrCoordinates;
				}
				if (($arrKML['intNPoints'] + $arrKML['intNLines'] + $arrKML['intNPolygons']) < $intPrintLimit) {
					$arrKML['strTable'] .= '
						<tr style="text-align:center;">
							<td style="text-align:center">' . $i . '</td>
							<td>' . $arrObjects[$i]['strName'] . '</td>
							<td style="text-align:justify">' . $arrObjects[$i]['strDescription'] . '</td>
							<td style="text-align:center"><img src="' . $this->strings->strImgFilePathByidShapeType($arrObjects[$i]['idShapeType']) . '"></td>
						</tr>
					';
				}
				$i++;
				$blnFound = 0;
			} else if (stripos(strtolower($strLine), '</placemark>') !== false) {
				$blnFound = 0;
				$strDescription = '';
				$strName = '';
			}
		}
		fclose($fh);
		$arrKML['strTable'] = '
		<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
			<thead>
			<tr class="btn-primary">
				<td width="1%" style="text-align:center">#</td>
				<td width="28%">' . $_SESSION['strToolImporterKMLName'] . '</td>
				<td width="70%">' . $_SESSION['strToolImporterKMLDescription'] . '</td>
				<td width="1%">' . $_SESSION['strGlobalShape'] . '</td>
			</tr>
			</thead>' . $arrKML['strTable'] . 
		'</table>';
		$arrKML['intNObjects'] = $arrKML['intNPoints'] + $arrKML['intNLines'] + $arrKML['intNPolygons'];
		$arrKML['arrObjects'] = $arrObjects;
		return $arrKML;
	}
	
	// Function break tags into lines.  Some app generate kml files with all tags just in one line
	// This is a problem for imprter.  This function will break (solve) and overwrite kml file
	public function openKMLBreakLineTags($strFileName){
		if((filesize($strFileName) > 0) && ($fh = fopen($strFileName, 'r'))){
			$strContent = fread($fh, filesize($strFileName));
			$strContent = str_replace("<![CDATA[","",$strContent);
			$strContent = str_replace("]]>","",$strContent);
			fclose($fh);
			$arrTags = explode('><', $strContent);
			$fp = fopen($strFileName, 'w');
			for ($i=0;$i<count($arrTags);$i++) {
				$strLine = '<' . $arrTags[$i] . '>' . PHP_EOL;
				if ($i == 0) $strLine = $arrTags[$i] . '>' . PHP_EOL;
				if ($i == count($arrTags) - 1) $strLine = '<' . $arrTags[$i];
				fwrite($fp, $strLine);
			}
			fclose($fp);
		}
	}
}
?>