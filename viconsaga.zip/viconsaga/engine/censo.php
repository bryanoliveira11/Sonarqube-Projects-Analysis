<?php
class Censo {
	public $arrUFs;
	public $arrTabelas;
	public $database;
	var $lastErr		= null;
	public $strDataDir	= 'censo';
	public $strCSVDir	= 'censo/CSV';
	public $strSHPDir	= 'censo/SHP';
	public $server 		= 'mysql08.viconsaga.com.br';
	public $mydb		= 'viconsaga2';
	public $username	= 'viconsaga2';
	public $password	= 'ViconS@ga';
	public $strGoogleFusionTablesTableID			= '1QFsEql223BUIPlXzsAbswIrDwDqRBpG7lUbZOgrt';
	public $strGoogleFusionTablesFieldPolys			= 'geometry';
	public $strGoogleFusionTablesPolyFillColor		= '#FFFFFF';
	public $dblGoogleFusionTablesPolyFillOpacity	= 0;
	public $strGoogleFusionTablesPolyStrokeColor	= '#FF0000';
	public $dblGoogleFusionTablesPolyStrokeOpacity	= 1;
	public $intGoogleFusionTablesPolyStrokeWeight	= 1;
	public $headerInfo = array();
	public $arrDBFFields = array();
	private $shpFilePath;
	private $shpFile;
	private $shpData = array();
	private $dbf;

	// Guest is Read Only Privileges
	public function __construct() {
		if (strpos($_SERVER["HTTP_HOST"],'localhost') !== FALSE) { 
			$this->server 		= 'localhost';
			$this->username		= 'root';
			$this->password		= '';
			$this->mydb			= 'ibge';
		}
		$this->database = mysql_connect($this->server, $this->username, $this->password);
		mysql_select_db($this->mydb, $this->database);
		mysql_set_charset ('utf8', $this->database);
		$this->setLastErr();
		$this->arrUFs = $this->selectUFs();
		$this->arrTabelas = $this->selectTabelas();
		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;

		include 'shapefile/reader/dbase.php';

		require_once 'rs2.php';
		$rs2 = new rs2();
		$this->rs2 = $rs2;
		
		session_start();
	}
	
	public function selectTabelas($idTabela = 0) {
		$query =
		"SELECT
			t.idTabela,
			t.strName
		FROM
			tabela t
		" . ($idTabela > 0 ? " WHERE t.idTabela = " . $idTabela : ""). "
		";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result;
	}
	
	public function intCountTabela($strTabela) {
		$query = "SELECT COUNT(*) AS `intCount` FROM " . $strTabela;
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result['intCount'];
	}

	public function selectTabelaVariaveis($idTabela = 0, $strSearch = '') {
		$query =
		"SELECT " . ($strSearch ? "DISTINCT" : ""). "
			tv.idTabelaVariavel,
			tv.idTabela,
			tv.strVarNome,
			tv.txtVarDescricao,
			t.strName AS `strTabela`
		FROM
			tabelavariavel tv,
			tabela			t
		WHERE 
			t.idTabela = tv.idTabela
		" . ($idTabela > 0	? " AND tv.idTabela = " . $idTabela : ""). "
		" . ($strSearch		? " AND (tv.strVarNome LIKE '%" . $strSearch . "%' OR tv.txtVarDescricao LIKE '%" . $strSearch . "%' OR t.strName LIKE '%" . $strSearch . "%')" : ""). "
		";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		if ($strSearch) {
			foreach ($result as $i => $item) {
				$result[$i]['blnNumeric']  = $item['strVarNome'][0] == 'V';
				$result[$i]['value'] = '[' . $item['strTabela'] . '] ' . $item['strVarNome'] . ' - ' . $item['txtVarDescricao'];
				$result[$i]['query'] = $strSearch;
			}
			return array('suggestions' => $result);
		}
		return $result;
	}
	
	public function intCountTabelaUF($strTabela, $intUFCod = 0) {
		$query = "SELECT COUNT(*) AS `intCount` FROM " . $strTabela . ($intUFCod > 0 ? " WHERE Cod_setor LIKE '" . $intUFCod . "%'" : "");
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result[0]['intCount'];
	}
	
	public function arrCountTabelaUFs($strTabela) {
		$query = "SELECT Basico.Cod_UF, COUNT(" . $strTabela . ".Cod_setor) AS `intCount` FROM " . ($strTabela != 'Basico' ? $strTabela . "," : "") .  " Basico WHERE Basico.Cod_setor=" . $strTabela . ".Cod_setor GROUP BY Basico.Cod_UF";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$arrResult = array();
		$arrResult['intTotal'] = 0;
		foreach ($result as $i => $item) {
			$arrResult[$item['Cod_UF']] = $item['intCount'];
			$arrResult['intTotal'] += $item['intCount'];
		}
		return $arrResult;
	}
	
	public function intCountSetorUF($intUFCod) {
		$query = "SELECT COUNT(*) AS `intCount` FROM Basico WHERE Cod_Setor LIKE '" . $intUFCod . "%'";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result[0]['intCount'];
	}
	
	public function arrCountSetorUFs() {
		$query = "SELECT Cod_UF, COUNT(Cod_Setor) AS `intCount` FROM Basico GROUP BY Cod_UF";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$arrResult = array();
		$arrResult['intTotal'] = 0;
		foreach ($result as $i => $item) {
			$arrResult[$item['Cod_UF']] = $item['intCount'];
			$arrResult['intTotal'] += $item['intCount'];
		}
		return $arrResult;
	}
	
	public function selectUFs($strUF = '') {
		$query =
		"SELECT
			uf.intUFCod,
			uf.strUF,
			uf.strUFName
		FROM
			uf uf
		" . ($strUF ? " WHERE uf.strUF = '" . $strUF . "'": ""). "
		ORDER BY
			uf.strUF
		";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result;
	}
	
	public function selectGeocodigosByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE) {
		$query =
		"SELECT DISTINCT 
			sv.CD_GEOCODI
		FROM
			setorvertex	sv
		WHERE 
			sv.dblLatitude	< '" . $dblLatNE . "' AND 
			sv.dblLongitude	< '" . $dblLngNE . "' AND 
			sv.dblLatitude	> '" . $dblLatSW . "' AND
			sv.dblLongitude	> '" . $dblLngSW . "'
		";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$arrResult = array();
		foreach($result as $item) {
			$arrResult[] = $item['CD_GEOCODI'];
		}
		return $arrResult;
	}
	
	public function selectSetoresByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE) {
		$arrGeocodigos = $this->selectGeocodigosByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE);
		$query = "
		SELECT
			sv.CD_GEOCODI,
			sv.dblLatitude, 
			sv.dblLongitude
		FROM
			setorvertex	sv
		WHERE 
			sv.CD_GEOCODI IN (" . implode(',', $arrGeocodigos) . ")
		ORDER BY 
			idSetorVertex
		";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$arrSetores = array();
		$arrVertexs = array();		
		$j=-1;
		$CD_GEOCODI = '';
		foreach($result as $i => $item) {
			if ($arrSetores[$j]['CD_GEOCODI'] != $item['CD_GEOCODI']) {$j++;}
			$arrSetores[$j]['CD_GEOCODI'] = $item['CD_GEOCODI'];
			$arrSetores[$j]['arrVertexs'][] = array(
				'dblLatitude' => $item['dblLatitude'],
				'dblLongitude' => $item['dblLongitude']
			);
		}
		return $arrSetores;
	}
	
	public function selectDadosTabelasOperadores($arrGeocodigos, $intClasses, $strVars){
		$arrTabelas = array();
		$arrTabelaVariavel = json_decode($strVars, true);
		$query = "SELECT " . $arrTabelaVariavel[0]['strTabela'] . ".Cod_setor,";
		$strTitulo = '';
		foreach ($arrTabelaVariavel as $i => $item) {
			if ($item['intOperator'] == 1) {
				$chrOperator = '+';
			} else if ($item['intOperator'] == 2) {
				$chrOperator = '-';
			} else if ($item['intOperator'] == 3) {
				$chrOperator = '*';
			} else if ($item['intOperator'] == 4) {
				$chrOperator = '/';
			} else {
				continue;
			}
			$strVar = $item['strTabela'] . '.' . $item['strVarNome'] . ($i < count($arrTabelaVariavel) - 1 ? $chrOperator : '');
			$strTitulo .= $strVar;
			$query .= $strVar;
			if (array_search($item['strTabela'], $arrTabelas) === FALSE) $arrTabelas[] = $item['strTabela'];
		}
		$strWhere = '';
		if (count($arrTabelas) > 1) {
			for($i=1;$i<count($arrTabelas);$i++) {
				$strWhere = $arrTabelas[$i-1] . ".Cod_setor = " . $arrTabelas[$i] . ".Cod_setor AND ";
			}
		}
		$query .= " AS `Legenda` FROM " . implode(',', $arrTabelas) . " WHERE " . $strWhere . " " . $arrTabelas[0] . ".Cod_setor IN (" . implode(',', $arrGeocodigos) . ")";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$dblMax = -99999;
		$dblMin = 999999;
		foreach ($result as $i => $item) {
			if ($item['Legenda'] > $dblMax) $dblMax = $item['Legenda'];
			if ($item['Legenda'] < $dblMin) $dblMin = $item['Legenda'];
		}
		$dblStep = ($dblMax - $dblMin)/$intClasses;
		$arrClasses = array();
		for ($i=0;$i<$intClasses;$i++){
			$arrClasses[$i]['dblMin'] = $dblMin + $i*$dblStep;
			$arrClasses[$i]['dblMax'] = $arrClasses[$i]['dblMin'] + $dblStep;
			$arrClasses[$i]['strClass'] = $arrClasses[$i]['dblMin'] . '-' . $arrClasses[$i]['dblMax'];
			$arrClasses[$i]['index'] = $i+1;
			$arrClasses[$i]['intColor'] = hexdec(substr($this->strings->strGenerateRandonColor(),1,6));
		}
		$arrLegendas = array();
		foreach ($result as $i => $item) {
			$dblValue = $item['Legenda'];
			foreach($arrClasses as $arrClass) {
				if (($dblValue >= $arrClass['dblMin']) && ($dblValue < $arrClass['dblMax'])) {
					$arrLegendas[$item['Cod_setor']] = $arrClass;
				}
			}
		}
		$arrResult = array();
		$arrResult['strTitulo'] = $strTitulo;
		$arrResult['arrLegendas'] = $arrLegendas;
		return $arrResult;
	}
	
	public function selectDadosTabelas($strExt, $arrGeocodigos, $intMode, $strVars){
		if ($intMode == 1) { // All Data From Table
			$arrTabelas = $this->selectTabelas($strVars);
			$query = "SELECT * FROM `" . $arrTabelas[0]['strName'] . "` WHERE Cod_setor IN (" . implode(',', $arrGeocodigos) . ")";
		} else {
			$arrTabelas = array();
			$arrTabelaVariavel = json_decode($strVars, true);
			$query = "SELECT `" . $arrTabelaVariavel[0]['strTabela'] . "`.`Cod_setor`,";
			$strTitulo = '';
			foreach ($arrTabelaVariavel as $i => $item) {
				//$strFieldName = $strExt == 'DBF' ? $item['strTabela'][0] . '-' . $item['strVarNome'] : '[' . $item['strTabela'] . '][' . $item['strVarNome'] . ']';
				$chrOperator = ',';
				if ($item['intOperator'] == 1) {
					$chrOperator = '+';
				} else if ($item['intOperator'] == 2) {
					$chrOperator = '-';
				} else if ($item['intOperator'] == 3) {
					$chrOperator = '*';
				} else if ($item['intOperator'] == 4) {
					$chrOperator = '/';
				}
				$strVar = '`' . $item['strTabela'] . '`.`' . $item['strVarNome'] . '`' . ($i < count($arrTabelaVariavel) - 1 ? $chrOperator : '');
				$query .= $strVar;
				if (array_search($item['strTabela'], $arrTabelas) === FALSE) $arrTabelas[] = $item['strTabela'];
			}
			$strWhere = '';
			if (count($arrTabelas) > 1) {
				for($i=1;$i<count($arrTabelas);$i++) {
					$strWhere = '`' . $arrTabelas[$i-1] . "`.Cod_setor=`" . $arrTabelas[$i] . "`.Cod_setor AND ";
				}
			}
			$query .= " FROM " . implode(',', $arrTabelas) . " WHERE " . $strWhere . " " . $arrTabelas[0] . ".Cod_setor IN (" . implode(',', $arrGeocodigos) . ")";
		}
		//$fh = fopen("out.txt", 'w');fwrite($fh, $query);fclose($fh);
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result;
	}
	
	public function mapExportClass($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $dblResolution, $intClasses, $strVars) {	
		set_time_limit(500);
		$arrOutput = array();
		$strTmpFilePathNoExt = $this->strings->strSiteTmpFileFolder . '/' . date('d-m-y-H-i-s');
		$arrOutput['strFilePath'] = 'map.' . strtolower('rs2');
		$arrOutput['strFilePathTMP'] = $strTmpFilePathNoExt . '.rs2';
		$arrSetores = $this->selectSetoresByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE);
		$arrGeocodigos = array();
		foreach ($arrSetores as $arrSetor) {
			if (array_search($arrSetor['CD_GEOCODI'],$arrGeocodigos) === FALSE) $arrGeocodigos[] = $arrSetor['CD_GEOCODI'];
		}
		$arrDados = $this->selectDadosTabelasOperadores($arrGeocodigos, $intClasses, $strVars);
		$arrLegendas = $arrDados['arrLegendas'];
		$arrBBox = array();
		$arrBBox['dblLatSW'] = $dblLatSW;
		$arrBBox['dblLngSW'] = $dblLngSW;
		$arrBBox['dblLatNE'] = $dblLatNE;
		$arrBBox['dblLngNE'] = $dblLngNE;
		// Setting BoundingBox in UTM
		$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$this->rs2->gPoint->convertLLtoTM();
		$arrBBox['dblLatSWUTM'] = $this->rs2->gPoint->N();
		$arrBBox['dblLngSWUTM'] = $this->rs2->gPoint->E();
		$arrBBox['intZoneSWUTM'] = $this->rs2->gPoint->Z();
		// Setting Map Width
		$arrDimensions = array();
		$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$arrDimensions['dblWidthMts']	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngNE'], $arrBBox['dblLatSW']));
		$arrDimensions['dblHeightMts'] 	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngSW'], $arrBBox['dblLatNE']));
		$arrDimensions['dblResolution'] = $dblResolution;
		$arrDimensions['intWidthPixels'] = round($arrDimensions['dblWidthMts'] / $arrDimensions['dblResolution']);
		$arrDimensions['intHeightPixels'] 	= round($arrDimensions['dblHeightMts'] / $arrDimensions['dblResolution']);	
		// Creating Image and Ploting
		$image = imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
		$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
		$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
		imagefilledrectangle($image, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgWhite);
		foreach ($arrSetores as $arrSetor) {
			$arrVertexs = $arrSetor['arrVertexs'];
			$strRGB = $this->strings->strColorConvertDecToRGB($arrLegendas[$arrSetor['CD_GEOCODI']]['index']+1); 
			$imgColor = ImageColorAllocate($image, $strRGB['R'], $strRGB['G'], $strRGB['B']);
			$arrPts = array();
			foreach($arrVertexs as $i => $arrVertex) {
				$arrXY = $this->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
				array_push($arrPts, $arrXY['X']);
				array_push($arrPts, $arrXY['Y']);
			}
			imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgColor);
		}
		$fh = fopen($arrOutput['strFilePathTMP'], 'wb');
		// Writing File Header
		// File Format - rst2006 = 16
		$intFileFormat = pack('I',16);
		fwrite($fh, $intFileFormat, 1);
		$this->strings->WriteString($fh, 'Censo IBGE 2010: ' . $arrDados['strTitulo']);				// Title
		$this->strings->WriteString($fh, '');								// Author
		$this->strings->WriteByte($fh, date('d'));							// Day
		$this->strings->WriteByte($fh, date('m'));							// Month
		$this->strings->WriteByte($fh, date('y'));							// Year
		$this->strings->WriteWord($fh, $arrDimensions['dblResolution']);	// Resolution
		$this->strings->WriteWord($fh, $arrBBox['intZoneSWUTM']);			// Zone
		$this->strings->WriteByte($fh, $arrBBox['dblLatSW'] < 0 ? 1 : 0);	// Hemisphere 1 = S, 0 = N
		$dblLatSWUTM = round($imgPNG['arrBBox']['dblLatSWUTM']);
		$dblLngSWUTM = round($imgPNG['arrBBox']['dblLngSWUTM']);
		$dblLatNEUTM = $dblLatSWUTM + $arrDimensions['dblResolution']*$arrDimensions['intHeightPixels'];
		$dblLngNEUTM = $dblLngSWUTM + $arrDimensions['dblResolution']*$arrDimensions['intWidthPixels'];
		$this->strings->WriteInt($fh, $dblLatSWUTM);	// LatSW
		$this->strings->WriteInt($fh, $dblLngSWUTM);	// LngSW
		$this->strings->WriteInt($fh, $dblLatNEUTM);	// LatNE
		$this->strings->WriteInt($fh, $dblLngNEUTM);	// LngNE
		$this->strings->WriteWord($fh, $arrDimensions['intHeightPixels']);	// Map Height
		$this->strings->WriteWord($fh, $arrDimensions['intWidthPixels']);	// Map Width
		$intNClasses = count($arrLegendas);									// Number of Classes
		$this->strings->WriteWord($fh, $intNClasses+1);
		// Write Classes
		// Writing First Background Class
		$this->strings->WriteWord($fh, 0);
		$this->strings->WriteString($fh, 'FUNDO');
		foreach ($arrLegendas as $arrLegenda) {
			$this->strings->WriteWord($fh, $arrLegenda['index']);
			$this->strings->WriteString($fh, $arrLegenda['strClass']);
		}
		// Writing  Map Canvas
		for ($y = 0 ; $y < $arrDimensions['intHeightPixels']; $y++) {
			// Gravando o n�mero da linha
			$this->strings->WriteInt($fh, $y + 1);
			$intCol = 0;
			do {
				$intRep = 0;
				$imgColor = imagecolorat($image, $intCol, $y);
				do {
					$intRep++;
					$intCol++;
				} while (($intCol < $arrDimensions['intWidthPixels']) && ($imgColor == imagecolorat($image, $intCol, $y)));
				$this->strings->WriteWord($fh, $intRep);
				$this->strings->WriteWord($fh, $imgColor);
			} while ($intCol < $arrDimensions['intWidthPixels']);
			$this->strings->WriteByte($fh, 0); // Mark End of Line
		}
		// Writing Set of Colors at End of File
		$this->strings->WriteInt($fh, hexdec("FFFFFF"));
		foreach ($arrLegendas as $arrLegenda) {
			$this->strings->WriteInt($fh, $arrLegenda['intColor']);
		}
		fclose($fh);
		return $arrOutput;
	
	}

	// $intMode = 1 => idTabela ; 2=> idTabelaVariavel:1,idTabelaVariavel:2
	public function dataExport($strExt, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $intMode, $strVars = '') {
		set_time_limit(300);
		$arrOutput = array();
		$arrOutput['strFilePath'] = 'data.' . strtolower($strExt);
		$arrOutput['strFilePathTMP'] = $this->strings->strSiteTmpFileFolder . '/' . date('d-m-y-H-i-s') . '.' . strtolower($strExt);
		$arrGeocodigos = $this->selectGeocodigosByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE);
		$arrLinhas = $this->selectDadosTabelas($strExt, $arrGeocodigos, $intMode, $strVars);
		switch ($strExt) {
		case "XLSX":
			include_once('../js/excel/Classes/PHPExcel.php');
			$workbook = new PHPExcel();	
			$worksheet = $workbook->getActiveSheet();
			$workbook->setActiveSheetIndex(0);
			foreach ($arrLinhas as $intRow => $arrLinha) {
				$intCol = 0;
				foreach ($arrLinha as $strFieldName => $strValor) {
					if ($intRow == 0) {
						$workbook->getActiveSheet()->setCellValueByColumnAndRow($intCol, $intRow+1, $strFieldName);
					}
					$workbook->getActiveSheet()->setCellValueByColumnAndRow($intCol, $intRow+2, $strValor);
					$intCol++;
				}
			}
			$objworkbook = PHPExcel_IOFactory::createWriter($workbook, 'Excel2007');
			$objworkbook->save($arrOutput['strFilePathTMP']);
		break;
		case "DBF":
			// Write to DBF
			require_once "dbf/Column.class.php";
			require_once "dbf/Record.class.php";
			require_once "dbf/Table.class.php";
			require_once "dbf/WritableTable.class.php";
			$arrFields = array();
			foreach ($arrLinhas[0] as $strFieldName => $strValor) {
				$strFieldName = $this->strings->changeCharAccent(utf8_decode($strFieldName));
				if ((is_numeric($strValor)) && (strlen($strValor) < 13)) {
					$arrFields[] = array($strFieldName, DBFFIELD_TYPE_NUMERIC, 13, 0);
				} else {
					$arrFields[] = array($strFieldName, DBFFIELD_TYPE_CHAR, 254);
				}
				//$arrFields[] = array($strFieldName, DBFFIELD_TYPE_CHAR, 254);
			}
			$dbf = XBaseWritableTable::create($arrOutput['strFilePathTMP'], $arrFields);			
			foreach ($arrLinhas as $intRow => $arrLinha) {
				$r =& $dbf->appendRecord();
				$j=0;
				foreach ($arrLinha as $strFieldName => $strValor) {
					$strFieldName = $this->strings->changeCharAccent(utf8_decode($strFieldName));
					$strValor = $this->strings->removeInvalidChars($this->strings->changeCharAccent(utf8_decode($strValor)));
					$r->setObjectByName($strFieldName, $strValor);
					$j++;
				}
				$dbf->writeRecord();
			}
			$dbf->close();
		break;
		case "CSV":
			$arrHeader = array();
			foreach ($arrLinhas[0] as $strFieldName => $strValor) {
				$arrHeader[] = $strFieldName;
			}
			$strCSV = implode(';', $arrHeader) . chr(13);
			foreach ($arrLinhas as $intRow => $arrLinha) {
				$arrValues = array();
				foreach ($arrLinha as $strFieldName => $strValor) {
					$arrValues[] = $strValor;
				}
				$strCSV .= implode(';', $arrValues) . ($intRow < count($arrLinhas) - 1 ? chr(13) : '');
			}
			$fh = fopen($arrOutput['strFilePathTMP'], 'w');
			fwrite($fh, $strCSV);
			fclose($fh);
		break;
		}
		return $arrOutput;
	}
	
	public function mapExport($strExt, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $dblResolution) {
		set_time_limit(300);
		$arrOutput = array();
		$strTmpFilePathNoExt = $this->strings->strSiteTmpFileFolder . '/' . date('d-m-y-H-i-s');
		$arrOutput['strFilePath'] = 'map.' . strtolower($strExt);
		$arrOutput['strFilePathTMP'] = $strTmpFilePathNoExt . '.' . strtolower($strExt);
		$arrSetores = $this->selectSetoresByRect($dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE);
		switch ($strExt) {
		case "SHP":
			require_once "shapefile/writer/Shapefile.php";
			require_once "dbf/Column.class.php";
			require_once "dbf/Record.class.php";
			require_once "dbf/Table.class.php";
			require_once "dbf/WritableTable.class.php";
			$arrFields = array(
				array("FID", DBFFIELD_TYPE_NUMERIC, 8, 0),
				array("CD_GEOCODI" , DBFFIELD_TYPE_CHAR, 254)
			);
			$arrBBox = $this->getBoundingBox($arrSetores);
			$shp = new ShapeFile(5, array("xmin" => $arrBBox['dblLngSW'], "ymin" => $arrBBox['dblLatSW'], "xmax" => $arrBBox['dblLngNE'], "ymax" => $arrBBox['dblLatNE']));
			$dbf = XBaseWritableTable::create($strTmpFilePathNoExt . '.dbf', $arrFields);
			foreach($arrSetores as $arrSetor) {
				$this->shpInsertObject($arrSetor, $shp, $dbf);
			}
			$shp->saveToFile($strTmpFilePathNoExt . '.*');
			$dbf->close();			
			$zip = new ZipArchive();
			$zip->open($strTmpFilePathNoExt . '.zip', ZIPARCHIVE::CREATE);
			$zip->addFile($strTmpFilePathNoExt . '.shp', 'map.shp');
			$zip->addFile($strTmpFilePathNoExt . '.shx', 'map.shx');
			$zip->addFile($strTmpFilePathNoExt . '.dbf', 'map.dbf');
			$zip->close();
			$arrOutput['strFilePathTMP'] = $strTmpFilePathNoExt . '.zip';
			$arrOutput['strFilePath'] = 'map.zip';
		break;
		case "KML":
			$strPlaces = '';
			$strStyles = '';
			foreach ($arrSetores as $arrSetor) {
				// Inserting Vertexes
				$strVertexs = '';
				foreach($arrSetor['arrVertexs'] as $arrVertex) {
					$strVertexs .= $arrVertex['dblLongitude'] . ',' . $arrVertex['dblLatitude'] . ",0 ";
				}
				$strVertexs .= $arrSetor['arrVertexs'][0]['dblLongitude'] . ',' . $arrSetor['arrVertexs'][0]['dblLatitude'] . ",0 ";
				$strRGB = 'AA' . $this->strings->strSwapRGBToBGR($this->strings->strGenerateRandonColor()); // 77 = Opacity - [00..FF]
				$strPlaces .= '<Placemark><name>' . $arrSetor['CD_GEOCODI'] . '</name><description><![CDATA[]]></description>';
				$strStyles .= '
					<Style id="style-' . $arrSetor['CD_GEOCODI'] . '"><LineStyle><width>3.5</width><color>' . $strRGB . '</color></LineStyle><PolyStyle><color>' . $strRGB . '</color></PolyStyle></Style>
					<StyleMap id="mstyle-' . $arrSetor['CD_GEOCODI'] . '"><Pair><key>normal</key><styleUrl>#style-' . $arrSetor['CD_GEOCODI'] . '</styleUrl></Pair><Pair><key>highlight</key><styleUrl>#style-' . $arrSetor['CD_GEOCODI'] . '</styleUrl></Pair></StyleMap>
				';
				$strPlaces .= '	
					<styleUrl>#mstyle-' . $arrSetor['CD_GEOCODI'] . '</styleUrl>
					<Polygon>
						<tessellate>1</tessellate>
						<outerBoundaryIs><LinearRing><coordinates>' . $strVertexs . '</coordinates></LinearRing></outerBoundaryIs>
					</Polygon>
					</Placemark>
				';
			} // End of Setores
			$strOut = '<?xml version="1.0" encoding="UTF-8"?>
				<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2" xmlns:kml="http://www.opengis.net/kml/2.2" xmlns:atom="http://www.w3.org/2005/Atom">
					<Document>
						<open>1</open>
						<name>Setores Censit�rios (' . count($arrSetores) . ')</name>' . $strStyles . $strPlaces . '
					</Document>
				</kml>
			';
			$fh = fopen($arrOutput['strFilePathTMP'], 'w');
			fwrite($fh, $strOut);
			fclose($fh);
		break;
		case "RS2":
			$arrBBox = array();
			$arrBBox['dblLatSW'] = $dblLatSW;
			$arrBBox['dblLngSW'] = $dblLngSW;
			$arrBBox['dblLatNE'] = $dblLatNE;
			$arrBBox['dblLngNE'] = $dblLngNE;
			// Setting BoundingBox in UTM
			$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
			$this->rs2->gPoint->convertLLtoTM();
			$arrBBox['dblLatSWUTM'] = $this->rs2->gPoint->N();
			$arrBBox['dblLngSWUTM'] = $this->rs2->gPoint->E();
			$arrBBox['intZoneSWUTM'] = $this->rs2->gPoint->Z();
			// Setting Map Width
			$arrDimensions = array();
			$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
			$arrDimensions['dblWidthMts']	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngNE'], $arrBBox['dblLatSW']));
			$arrDimensions['dblHeightMts'] 	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngSW'], $arrBBox['dblLatNE']));
			$arrDimensions['dblResolution'] = $dblResolution;
			$arrDimensions['intWidthPixels'] = round($arrDimensions['dblWidthMts'] / $arrDimensions['dblResolution']);
			$arrDimensions['intHeightPixels'] 	= round($arrDimensions['dblHeightMts'] / $arrDimensions['dblResolution']);	
			// Creating Image and Ploting
			$image		= imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
			$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
			$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
			imagefilledrectangle($image, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgWhite);
			$j=0;
			$arrClasses = array();
			foreach ($arrSetores as $j => $arrSetor) {
				$arrVertexs = $arrSetor['arrVertexs'];
				$strRGB = $this->strings->strColorConvertDecToRGB($j+1); 
				$imgColor = ImageColorAllocate($image, $strRGB['R'], $strRGB['G'], $strRGB['B']);
				$arrPts = array();
				foreach($arrVertexs as $i => $arrVertex) {
					$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					array_push($arrPts, $arrXY['X']);
					array_push($arrPts, $arrXY['Y']);
				}
				imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgColor);
				$arrClasses[$j]['strClass'] = $arrSetor['CD_GEOCODI'];
				$strRGB = $this->strings->strGenerateRandonColor();
				$intColor = hexdec(substr($strRGB,1,6));
				$arrClasses[$j]['intColor'] = ($j == 0 ? hexdec("FFFFFF") : $intColor);
			}
			//	imagepng($image, 'tmp/a.png'); // Est� plotando com erro o png
			$this->rs2->create(
				$arrOutput['strFilePathTMP'], 
				'Censo IBGE 2010', 
				'', 
				$arrDimensions['dblResolution'], 
				round($arrBBox['dblLatSWUTM']), 
				round($arrBBox['dblLngSWUTM']), 
				$arrBBox['intZoneSWUTM'], 
				($arrBBox['dblLatSW'] < 0 ? 1 : 0), 
				$arrDimensions['intHeightPixels'], 
				$arrDimensions['intWidthPixels'], 
				$arrClasses, 
				$image
			);
		break;
		}
		return $arrOutput;
	}
			
	public function shpInsertObject($arrSetor, &$shp, &$dbf) {
		// SHP Record
		$shpRecord = new ShapeRecord(5);
		foreach($arrSetor['arrVertexs'] as $arrVertex) {
			$shpRecord->addPoint(array("x" => $arrVertex['dblLongitude'], "y" => $arrVertex['dblLatitude']));
		}
		$shpRecord->addPoint(array("x" => $arrSetor['arrVertexs'][0]['dblLongitude'], "y" => $arrSetor['arrVertexs'][0]['dblLatitude']));
		$intID = $shp->addRecord($shpRecord);
		// DBF Record
		$r =& $dbf->appendRecord();
		$r->setObjectByName("FID", $intID);
		$r->setObjectByName("CD_GEOCODI",$arrSetor['CD_GEOCODI']);
		$dbf->writeRecord();
	}
		
	public function getBoundingBox($arrSetores) {
		$arrBBox = array();
		$arrBBox['dblLatSW'] = 90;
		$arrBBox['dblLngSW'] = 180;
		$arrBBox['dblLatNE'] = -90;
		$arrBBox['dblLngNE'] = -180;
		foreach ($arrSetores as $arrSetor) {
			$arrVertexs = $arrSetor['arrVertexs'];
			foreach($arrVertexs as $arrVertex) {
				if ($arrVertex['dblLatitude']   < $arrBBox['dblLatSW']) $arrBBox['dblLatSW'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  < $arrBBox['dblLngSW']) $arrBBox['dblLngSW'] = $arrVertex['dblLongitude'];
				if ($arrVertex['dblLatitude']   > $arrBBox['dblLatNE']) $arrBBox['dblLatNE'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  > $arrBBox['dblLngNE']) $arrBBox['dblLngNE'] = $arrVertex['dblLongitude'];
			}
		}
		return $arrBBox;
	}
	
	/* Database Procedures */
	public function executeQuery($query) {
		$result = mysql_query($query, $this->database);
		$this->setLastErr();
		return $result;
	}

	public function getLastErr() {
		return $this->lastErr;
	}

	private function setLastErr() {
		$this->lastErr = mysql_error($this->database);
	}
	
	public function getLastInsertedID() {
		return mysql_insert_id($this->database);
	}

	public function getNumAffectedRows() {
		return mysql_affected_rows($this->database);
	}

	public function arrDatabaseTables() {
		$query = "SHOW TABLES FROM `" . $this->mydb . "`";
		$result = $this->executeQuery($query);
		$arrTables = array();
		while(($linha = mysql_fetch_array($result)) != null) {
			$arrTables[] = $linha[0];
		}
		return $arrTables;
	}
	
	public function prepareReturn($resultado) {
		if($this->getLastErr() == null) {
			$retorno = Array();
			while(($linha = mysql_fetch_array($resultado)) != null) {
				$aux = Array();
				foreach($linha as $chave2 => $valor2) {
					if(!is_numeric($chave2)) {
						$aux[$chave2] = $valor2;
					}
				}
				$retorno[] = $aux;
			}
			return $retorno;
		} else {
			return null;
		}
	}	
	
	/* Import Procedures */
	public function importMalhaSetores($strUF) {
		set_time_limit(6000);
		$strSHPFilePathNoExt = $this->strSHPDir . '/' . $strUF;
		$arrResult = $this->arrReadInsertSHP($strSHPFilePathNoExt, false);
		return $arrResult;
	}
		
	public function arrReadInsertSHP($strSHPFilePathNoExt, $blnReadDBF = false){
		$this->load($strSHPFilePathNoExt . '.shp');
		return array ('intRecords' => count($this->getShapeData())-1);
	}

	public function clearMalhaSetores() {
		//$this->executeQuery('CREATE TABLE IF NOT EXISTS `setor` (`CD_GEOCODI` BIGINT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`CD_GEOCODI`))');
		$this->executeQuery('CREATE TABLE IF NOT EXISTS `setorvertex` (`idSetorVertex` INT UNSIGNED NOT NULL AUTO_INCREMENT, `CD_GEOCODI` BIGINT NOT NULL, `dblLatitude` DOUBLE NULL, `dblLongitude` DOUBLE NULL, PRIMARY KEY (`idSetorVertex`))');
		$this->executeQuery('TRUNCATE setorvertex');
		//$this->executeQuery('DELETE FROM setor');
		return array('intDeleted' => $this->getNumAffectedRows());
	}
	
	public function importTabelaCSV($idTabela, $strUF) {
		set_time_limit(6000);
		$intRecords = 0;
		$arrTabelas = $this->selectTabelas($idTabela);
		$strTabela = $arrTabelas[0]['strName'];
		$arrUFs = $this->selectUFs($strUF);
		$intUFCod = $arrUFs[0]['intUFCod'];
		$strCSVFilePath = $this->strCSVDir . '/' . $strTabela . '_' . $strUF . '.csv';
		$arrCSV = $this->arrReadCSV($strCSVFilePath);
		$this->createTabelaFromCSV($strTabela, $arrCSV['arrFields']);
		$this->deleteTabelaUF($strTabela, $intUFCod);
		$arrResult = $this->insertTabelaFromCSV($strTabela, $arrCSV);
		return $arrResult;
	}
	
	public function arrReadCSV($strFile) {
		if (! file_exists($strFile)) { return array(); } 
		$strFileContent = file_get_contents($strFile);
		$arrLines = explode(chr(13), $strFileContent);
		$strLineHeader = $arrLines[0];
		$strLineHeader = $this->strRemoveInvalidCharsSQL($strLineHeader);
		$arrHeader = explode(';', $strLineHeader);
		foreach($arrHeader as $intCol => $strFieldName) {
			if (! $strFieldName) continue;			
			$arrFields[$intCol]['strName'] = trim($strFieldName);
			$arrFields[$intCol]['idType'] = (strpos($strFieldName, 'Nome_') !== FALSE ? 1 : 2);
			$arrFields[$intCol]['strType'] = ($arrFields[$intCol]['idType'] == 1 ? 'VARCHAR(100) NULL' : 'INT');
			if ($intCol == 0) { // PK
				$arrFields[$intCol]['strType'] = 'BIGINT NOT NULL AUTO_INCREMENT';
			}
		}
		$arrRows = array();
		for($intRow=1;$intRow<count($arrLines);$intRow++) {
			$strRow = $this->strRemoveInvalidCharsSQL($arrLines[$intRow]);
			$arrCells = explode(';', $strRow);
			for($intCol=0;$intCol<count($arrFields);$intCol++){
				$strCell = trim($arrCells[$intCol]);
				if (($intCol==0) && (! $strCell)) continue;
				// Replace , by , for Numeric Fields
				if (($intCol > 0) && ($arrFields[$intCol]['idType'] == 2)) {
					$strCell = str_replace(",", '.', $strCell); 
					// Force to INT
					$strCell = round($strCell);
				}
				$arrRows[$intRow-1][$intCol] = $strCell;
			}
		}
		$arrCSV = array();
		$arrCSV['arrFields'] = $arrFields;
		$arrCSV['arrRows'] = $arrRows;
		return $arrCSV;
	}
	
	public function createTabelaFromCSV($strTabela, $arrFields) {
		foreach ($arrFields as $i => $arrField) {
			$strFields .= '`' . $arrField['strName'] . '` ' . $arrField['strType'] . ($i < count($arrFields) - 1 ? ', ' : '');
		}
		if (! $strFields) return;
		$strSQL = 'CREATE TABLE IF NOT EXISTS `' . $strTabela . '` (' . $strFields . ', PRIMARY KEY (`' . $arrFields[0]['strName'] . '`))';
		$this->executeQuery($strSQL);
	}
	
	public function insertTabelaFromCSV($strTabela, $arrCSV) {
		set_time_limit(6000);
		$arrFields = $arrCSV['arrFields'];
		$arrFieldNames = array();
		foreach ($arrFields as $arrField) {
			$arrFieldNames[] = '`' . $arrField['strName'] . '`';
		}
		$arrRows = $arrCSV['arrRows'];
		$arrInserts = array();
		$intInserted = 0;
		foreach ($arrRows as $intRow => $arrRow) {
			if ($arrRow[0]) { // Empty 
				foreach($arrRow as $intCol => $strCell) {
					$arrRow[$intCol] = "'" . $strCell . "'";
				}
				$arrInserts[] = '(' . implode(',', $arrRow) . ')';
				$intInserted++;
			}
			if (($intRow % 500 == 0) || ($intRow == count($arrRows)-1)) {
				$strSQL = "INSERT INTO `" . $strTabela . "` (" . implode(',',  $arrFieldNames) . ") VALUES " . implode(',', $arrInserts);
				$this->executeQuery($strSQL);
				$arrInserts = array();
			}
		}
		return array ('intRecords' => $intInserted);
	}
	
	public function deleteTabelaUF($strTabela, $intUFCod) {
		$strSQL = 'DELETE FROM ' . $strTabela . ' WHERE Cod_setor LIKE "' . $intUFCod . '%"';
		$this->executeQuery($strSQL);
		return array('intDeleted' => $this->getNumAffectedRows());
	}
	
	public function clearTabela($idTabela) {
		$arrTabelas = $this->selectTabelas($idTabela);
		$strSQL = 'TRUNCATE `' . $arrTabelas[0]['strName'] . '`';
		$this->executeQuery($strSQL);
		return array('intDeleted' => $this->getNumAffectedRows());
	}
	
	public function strRemoveInvalidCharsSQL($str) {
		$str = trim($str);
		$str = str_replace('"X"', '0', $str);
		$str = str_replace(';X;', ';0;', $str);
		$str = str_replace('"', '', $str);
		$str = str_replace("'", '', $str);
		$str = str_replace("(todos os setores)", '', $str);
		$str = str_replace("Munic�pios n�o pertencentes a estrutura de RM", '-', $str);
		return $str;
	}	
	
	// Censo SHP Functions
	public function load($path) {
		$this->shpFilePath = $path;
		$this->shpFile = fopen($this->shpFilePath, "rb");
		$this->loadHeaders();
		$arrFileName = explode ('.', $path);
		$this->dbf = new dbf_class($arrFileName[0] . '.dbf');
		for($i=0; $i<$this->dbf->dbf_num_field; $i++){
			$this->arrFields[$i]['strName'] = utf8_decode($this->dbf->dbf_names[$i]['name']);
			$this->arrFields[$i]['idType'] = 1; // Set default as text
			if ($this->dbf->dbf_names[$i]['type'] == 'N') {
				$this->arrFields[$i]['idType'] = 2;
			}
		}
		$shpData = $this->loadRecords();
	}
	
	public function headerInfo() {
		return $this->headerInfo;
	}
	
	public function getShapeData() {
		return $this->shpData;
	}
	
	private function geomTypes() {
		return array(
		  0  => 'Null Shape',
		  1  => 'Point',
		  3  => 'PolyLine',
		  5  => 'Polygon',
		  8  => 'MultiPoint',
		  11 => 'PointZ',
		  13 => 'PolyLineZ',
		  15 => 'PolygonZ',
		  18 => 'MultiPointZ',
		  21 => 'PointM',
		  23 => 'PolyLineM',
		  25 => 'PolygonM',
		  28 => 'MultiPointM',
		  31 => 'MultiPatch',
		);
	}
	
	private function geoTypeFromID($id) {
		$geomTypes = $this->geomTypes();
		
		if (isset($geomTypes[$id])) {
		  return $geomTypes[$id];
		}
		
		return NULL;
	}
	
	private function loadHeaders() {
		fseek($this->shpFile, 24, SEEK_SET);
		$length = $this->loadData("N");
		fseek($this->shpFile, 32, SEEK_SET);
		$shape_type = $this->geoTypeFromID($this->loadData("V"));
		
		$bounding_box = array();
		$bounding_box["xmin"] = $this->loadData("d");
		$bounding_box["ymin"] = $this->loadData("d");
		$bounding_box["xmax"] = $this->loadData("d");
		$bounding_box["ymax"] = $this->loadData("d");
		
		$this->headerInfo = array(
		  'length' => $length,
		  'shapeType' => array(
			'id' => $shape_type,
			'name' => $this->geoTypeFromID($shape_type),
		  ),
		  'boundingBox' => $bounding_box,
		);
	}
	
	private function loadRecords() {
		fseek($this->shpFile, 100);
		while(!feof($this->shpFile)) {
//if (count($this->shpData) >= 5) break;
		  $record = $this->loadRecord();
		  $this->shpData[] = $record;
		}
	}

	private function loadData($type) {
		$type_length = $this->loadDataLength($type);
		if ($type_length) {
		  $fread_return = fread($this->shpFile, $type_length);
		  if ($fread_return != '') {
			$tmp = unpack($type, $fread_return);
			return current($tmp);
		  }
		}
		return NULL;
	}
	
	private function loadDataLength($type) {
		$lengths = array(
		  'd' => 8,
		  'V' => 4,
		  'N' => 4,
		);
		
		if (isset($lengths[$type])) {
		  return $lengths[$type];
		}
		
		return NULL;
	}
	
	// shpRecord functions.
	private function loadRecord() {
		$recordNumber = $this->loadData("N");
		$this->loadData("N"); // unnecessary data.
		$shape_type = $this->loadData("V");
		$record = array('shapeType' => array('id' => $shape_type)); 
		switch($record['shapeType']['id']){
		  case 0:
			$this->loadNullRecord();
			break;
		  case 5:
			$this->loadPolygonMRecord(5, $recordNumber); // For Censo
			break;
		  case 25: // PolygonM
			$this->loadPolygonMRecord(25, $recordNumber); // For Censo
			break;
		  default:
			break;
		}
		return $record;
	}
	
	private function loadPoint() {
		$data = array();
		$data['x'] = $this->loadData("d");
		$data['y'] = $this->loadData("d");
		return $data;
	}
	
	private function loadNullRecord() {
		return array();
	}
	
	private function loadPolygonMRecord($idShapeType, $recordNumber) {
		$return = array(
		  'bbox' => array(
			'xmin' => $this->loadData("d"),
			'ymin' => $this->loadData("d"),
			'xmax' => $this->loadData("d"),
			'ymax' => $this->loadData("d"),
		  ),
		);
		$numParts = $this->loadData("V");
		$numPoints = $this->loadData("V");
		if ($numParts > 50) return;
		if ($numPoints > 10000) return;
		$parts = array();
		for ($i = 0; $i < $numParts; $i++) {
		  $parts[] = $this->loadData("V");
		}
		$parts[] = $numPoints;
		//Mmin
		$Mmin = $this->loadData("d");
		//Mmax - Double * 1
		$Mmax = $this->loadData("d");
		$arrInserts = array();
		$row = $this->dbf->getRow($recordNumber-1);
		$CD_GEOCODI = $row[1];
		//$strSQL = "INSERT INTO `setor` (CD_GEOCODI) VALUES (" . $CD_GEOCODI . ");";
		//$this->executeQuery($strSQL);
		// Marray - Double x NPoints
		for ($i = 0; $i < $numPoints; $i++) {
			$arrVertex = $this->loadPoint();
			$arrVertex['x'] = substr($arrVertex['x'],0,10);
			$arrVertex['y'] = substr($arrVertex['y'],0,10);
			if ((! is_infinite($arrVertex['x'])) && (is_numeric($arrVertex['x'])) && (floatval($arrVertex['x']) != 0)) { // INF
				$arrInserts[] = '(' . $CD_GEOCODI . ',' . $arrVertex['y'] . ',' . $arrVertex['x'] . ')';		
			}
		}
		for ($i = 0; $i < $numPoints; $i++) {
		  $this->loadData("d");
		}
		$strSQL = "INSERT INTO `setorvertex` (CD_GEOCODI, dblLatitude, dblLongitude) VALUES " . implode(',', $arrInserts);
		$this->executeQuery($strSQL);
	}
}
?>