<?php
class Database {
	public $strEventLogDefaultIcon		= 'icon-bell';
	public $strDefaultIcon				= 'icon-globe';
	public $blnSiteAllowProjectCreation	= 0;
	public $database;
	var $lastErr						= null;
	var $server 	= '';
	var $username 	= '';
	var $password 	= '';
	var $mydb		= '';
	var $admPassword;

	public function __construct($strPrefix = '') {
		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		include_once $strPrefix . $this->strings->strConnectionFileName;
		$this->admPassword	= $admPassword;
		$this->server 		= $server;
		$this->username 	= $username;
		$this->password 	= $password;
		$this->mydb			= $database;
		$this->blnSiteAllowProjectCreation = $blnSiteAllowProjectCreation;
		$this->database 	= mysqli_connect($this->server, $this->username, $this->password, $this->database);
		$this->thread_id	= mysqli_thread_id($this->database);
		$this->setLastErr();
	}

	public function install() {
		new Database();
		if (! mysqli_ping($this->database)) return 0; // Could not connect to mysql host
		$link = mysqli_select_db($this->database, $this->mydb);
		if (! $link) {
			if (! $this->executeQuery('CREATE DATABASE IF NOT EXISTS ' . $this->mydb)) return 0;
			$link = mysqli_select_db($this->database, $this->mydb);
			if (! $link) { return 0; }
		}
		$link = new mysqli($this->server, $this->username, $this->password, $this->mydb);
		$query = file_get_contents($this->strings->strSQLDatabaseFile);
		if (mysqli_multi_query($link, $query)) {
			return 1;
		} else {
			return 0;
		}
	}

	public function blnTableExists() {
		new Database();
		$query = "SHOW COLUMNS FROM userprojectworkgroup";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return (count($result) > 0);
	}

	public function executeQuery($query) {
		mysqli_select_db($this->database, $this->mydb);
		$result = mysqli_query($this->database, $query);
		$this->setLastErr();
		return $result;
	}

	public function abortQuery() {
		//$idThread = mysqli_thread_id($this->database);
		/* Kill connection */
		$blnResult = mysqli_kill($this->database, $this->thread_id);
		return $blnResult;
	}

	public function getDatabaseSize() {
		$query =
		"SELECT table_schema \"test\", SUM( data_length + index_length) / 1024 / 1024
			\"Data Base Size in MB\" FROM information_schema.TABLES GROUP BY table_schema";
	}

	public function isConnected() {
		return mysqli_select_db($this->database, $this->mydb);
		//return mysqli_ping($this->database);
	}

	public function getLastErr() {
		return $this->lastErr;
	}

	private function setLastErr() {
		$this->lastErr = mysqli_error($this->database);
	}

	public function getLastInsertedID() {
		return mysqli_insert_id($this->database);
	}

	public function getNumAffectedRows() {
		return mysqli_affected_rows($this->database);
	}

	public function close() {
		mysqli_close($this->database);
		$this->database = null;
	}

	/**
	 * Esta fun��o limpa o resultado retornado pelo mysql_query para ficar num formato mais amig�vel.
	 * @param mysql_result $resultado
	 */
	public function prepareReturn($resultado) {
		if($this->getLastErr() == null) {
			$retorno = Array();
			while(($linha = mysqli_fetch_array($resultado)) != null) {
				$aux = Array();
				foreach($linha as $chave2 => $valor2) {
					if(!is_numeric($chave2)) {
						$aux[$chave2] = $valor2;
					}
				}
				$retorno[] = $aux;
			}
			return $retorno;
		} else {
			return null;
		}
	}

	public function log($string) {
		$fp = fopen('log.txt', 'a');
		fwrite($fp, $string);
		fclose($fp);
	}
	
	public function selectCountry($blnJustFlags = false) {
		$strFlagFolder = 'img/language/';
		$query =
		"SELECT
			c.idCountry,
			c.strName,
			c.strCapital,
			c.strTelAreaCode,
			c.strCurrencySymbol,
			c.strLanguageCode
		FROM
			country c
		ORDER BY
			c.strName";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		if ($blnJustFlags) {		
			for ($idLine=count($result)-1; $idLine >= 0; $idLine--) {
				$strFlagPath = $strFlagFolder . $result[$idLine]['strLanguageCode'] . '.png';
				if (file_exists($strFlagPath)) {
					$result[$idLine]['strFlagPath'] = $strFlagPath;
				} else {
					array_splice($result,$idLine,1);
				}
			}
		}
		return $result;

	}
	
	public function selectDatum($idDatum = 0) {
		$query =
		"SELECT
			idDatum,
			strName,
			dblA,
			dblE2
		FROM
			datum d
		" . ($idDatum > 0 ? " WHERE idDatum = " . $idDatum : "") . "
		ORDER BY
			strName";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		return $result;
	}
	
	public function intSelectNextTableKey($strTable, $strPrimaryKeyField) {
		$query = "SELECT MAX(`" . $strPrimaryKeyField . "`) AS `intMAX` FROM " . $strTable;
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		$result[0]['intMAX'];
		return ($result[0]['intMAX'] ? $result[0]['intMAX'] : 0) + 1;
	}
	
	// User Event
	public function selectUserEvents($idProject = 0, $idUser = 0, $idEventType = 0, $dtDateFrom = '', $dtDateTo = '', $intLimit = 99999) {	
		$query =
		"SELECT
			ue.idEvent,
			ue.idEventType,
			ue.idUser,
			ue.dtDateTime,
			ue.strParam1,
			ue.strParam2,
			ue.strParam3,
			u.strEmail
		FROM
			event	ue,
			user	u
		WHERE
			ue.idUser = u.idUser
		" . ($idProject > 0 ? " AND u.idProject = " . $idProject : "") . "
		" . ($idUser > 0 ? " AND ue.idUser = " . $idUser : "") . "
		" . ($idEventType > 0 ? " AND ue.idEventType = " . $idEventType : "") . "
		" . ($dtDateFrom  ? " AND ue.dtDateTime >= '" . $this->strings->ConvertDateBRToMySQL($dtDateFrom) . "  00:00:00'" : "") . "
		" . ($dtDateTo ? " AND ue.dtDateTime <= '" . $this->strings->ConvertDateBRToMySQL($dtDateTo) . "  23:59:59'" : "") . "
		ORDER BY
			ue.dtDateTime DESC 
		LIMIT " . $intLimit;
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateTime'] = date('d/m/y H:i:s', strtotime($result[$idLine]['dtDateTime']));
			$result[$idLine]['strEventType'] = $_SESSION['strEventType_' . $result[$idLine]['idEventType']];
		}
		return $result;
	}
	
	public function insertEvent($idEventType, $idUser = 0, $strParam1 = '', $strParam2 = '', $strParam3 = '', $strDate = '') {
		$query = "
			INSERT INTO event SET 
				idEventType	=	" . $idEventType . ",
				idUser		=	" . $idUser . ",
				dtDateTime	=	" . ($strDate ? "'" . $strDate . "'" : "NOW()") . 
				($strParam1 ? ", strParam1 =	'" . $strParam1 . "'" : "") .
				($strParam2 ? ", strParam2 =	'" . $strParam2 . "'" : "") .
				($strParam3 ? ", strParam3 =	'" . $strParam3 . "'" : "")
		;
		$result = $this->executeQuery($query);
		return true;
	}
	
	public function deleteEvent($idProject = 0, $idUser = 0, $idEventType = 0) {
		if ($idProject > 0) {
			$query = "DELETE eventuser FROM eventuser, user WHERE eventuser.idUser = user.idUser AND user.idProject = " . $idProject;
		} else {
			$query = "DELETE FROM eventuser WHERE " . ($idUser > 0 ? "idUser = " . $idUser : "") . ($idEventType > 0 ? "idEventType = " . $idEventType : "");
		}
		$resultado = $this->executeQuery($query);
		return true;
	}
	
	public function selectEventTypes($idEventType = 0) {	
		$query =
		"SELECT
			et.idEventType,
			et.strEventType
		FROM
			eventtype	et
		" . (($idEventType > 0) ? " WHERE et.idEventType = " . $idEventType : "") . "
		ORDER BY
			et.idEventType";
		$result = $this->executeQuery($query);
		$result = $this->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strEventType'] = $_SESSION['strEventType_' . $result[$idLine]['idEventType']];
		}
		return $result;
	}
}
?>