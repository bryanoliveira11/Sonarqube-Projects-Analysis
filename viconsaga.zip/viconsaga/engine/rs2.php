<?php
class rs2 {
	public function __construct() {
		include_once 'gPoint.php';
		$gPoint = new gPoint();
		$this->gPoint = $gPoint;
	}
	
	public function create($strOutputFile, $strTitle = '', $strAuthor = '', $intResolution, $intLatSW, $intLngSW, $intZoneSW, $intHemisphere, $intHeight, $intWidth, $arrClasses, $pngCanvas) {
	  $fh = fopen($strOutputFile, 'wb');
	  // Writing File Header
	  fwrite($fh, pack('I',16), 1);				// File Format - rst2006 = 16
	  $this->WriteString($fh, $strTitle);		// Title
	  $this->WriteString($fh, $strAuthor);		// Author
	  $this->WriteByte($fh, date('d'));			// Day
	  $this->WriteByte($fh, date('m'));			// Month
	  $this->WriteByte($fh, date('y'));			// Year
	  $this->WriteWord($fh, $intResolution);	// Resolution
	  $this->WriteWord($fh, $intZoneSW);		// Zone
	  $this->WriteByte($fh, $intHemisphere);	// Hemisphere 1 = S, 0 = N			
	  $intLatNE = $intLatSW + $intResolution*$intHeight;
	  $intLngNE = $intLngSW + $intResolution*$intWidth;
	  $this->WriteInt($fh, $intLatSW);			// LatSW
	  $this->WriteInt($fh, $intLngSW);			// LngSW
	  $this->WriteInt($fh, $intLatNE);			// LatNE
	  $this->WriteInt($fh, $intLngNE);			// LngNE
	  $this->WriteWord($fh, $intHeight);		// Map Height
	  $this->WriteWord($fh, $intWidth);			// Map Width
	  $intNClasses = count($arrClasses);		// Number of Classes
	  $this->WriteWord($fh, $intNClasses+1);
	  // Write Classes
	  // Writing First Background Class
	  $this->WriteWord($fh, 0);
	  $this->WriteString($fh, 'FUNDO');
	  for ($i = 0; $i < $intNClasses; $i++) {
		  $this->WriteWord($fh, $i+1);
		  $this->WriteString($fh, $arrClasses[$i]['strClass']);
	  }
	  // Writing  Map Canvas
	  for ($y=0;$y<$intHeight;$y++) {
		  // Writing line number
		  $this->WriteInt($fh, $y+1);
		  $intCol = 0;
		  do {
			  $intRep = 0;
			  $imgColor = imagecolorat($pngCanvas, $intCol, $y);
			  do {
				  $intRep++;
				  $intCol++;
			  } while (($intCol < $intWidth) && ($imgColor == imagecolorat($pngCanvas, $intCol, $y)));
			  $this->WriteWord($fh, $intRep);
			  $this->WriteWord($fh, $imgColor);
		  } while ($intCol < $intWidth);
		  $this->WriteByte($fh, 0); // Mark End of Line
	  }
	  // Writing Set of Colors at End of File
	  for ($i = 0; $i < $intNClasses; $i++) {
		  $this->WriteInt($fh, $arrClasses[$i]['intColor']);
	  }
	  fclose($fh);
	}
	
	public function WriteString($f, $str) {
		for ($i=0; $i < strlen($str);$i++) {
			$s = $str[$i];
			fwrite($f, $s, 1);
		}
		fwrite($f, chr(0)); // Mark End of Line
	}
	
	public function WriteByte($f, $byte) {
		$byte = pack('I', $byte);
		fwrite($f, $byte, 1); // 1 Byte
	}
	
	public function WriteWord($f, $word) {
		$word = pack('S', $word);
		fwrite($f, $word, 2); // 2 Bytes
	}
	
	public function WriteInt($f, $int) {
		$int = pack('L', $int);
		fwrite($f, $int, 4); // 4 Bytes
	}
	
	public function WriteDouble($f, $double) {
		$double = pack('d', $double); 
		fwrite($f, $double, 8); // 8 Bytes
	}

	public function convertLatLngToXY($dblLat, $dblLng, $intResolution, $arrBBox) {
		$arrXY = array();
		$this->gPoint->setLongLat($dblLng, $dblLat);
		if ($dblLng > $arrBBox['dblLngNE']) {
			$arrXY['X'] = $arrBBox['intWidthPixels']-1;
		} else if ($dblLng < $arrBBox['dblLngSW']) {
			$arrXY['X'] = 0;
		} else {
			$dblDistanceFromCornerMts = $this->gPoint->distanceFrom($arrBBox['dblLngSW'], $dblLat);
			$arrXY['X'] = round($dblDistanceFromCornerMts / $intResolution);
		}
		if ($dblLat > $arrBBox['dblLatNE']) {
			$arrXY['Y'] = 0;
		} else if ($dblLat < $arrBBox['dblLatSW']) {
			$arrXY['Y'] = $arrBBox['intHeightPixels']-1;
		} else {
			$dblDistanceFromCornerMts = $this->gPoint->distanceFrom($dblLng, $arrBBox['dblLatNE']);
			$arrXY['Y'] = round($dblDistanceFromCornerMts / $intResolution);
		}
		return $arrXY;
	}
	
	public function convertLatLngToXYPoly($arrVertexs, $intResolution, $arrBBox) {
		$arrXYs = array();
		$j=0;
		for($i=1;$i<count($arrVertexs);$i++) {
			$dblLat1 = $arrVertexs[$i]['dblLatitude'];
			$dblLng1 = $arrVertexs[$i]['dblLongitude'];
			$dblLat2 = $arrVertexs[$i-1]['dblLatitude'];
			$dblLng2 = $arrVertexs[$i-1]['dblLongitude'];
			// Coordinates X1,Y1
			$this->gPoint->setLongLat($dblLng1, $dblLat1);
			$X1 = $this->gPoint->distanceFrom($arrBBox['dblLngSW'], $dblLat1) / $intResolution;
			if ($dblLng1 < $arrBBox['dblLngSW']) $X1 = - $X1;
			$Y1 = $this->gPoint->distanceFrom($dblLng1, $arrBBox['dblLatNE']) / $intResolution;
			if ($dblLat1 > $arrBBox['dblLatNE']) $Y1 = - $Y1;
			// Coordinates X2,Y2
			$this->gPoint->setLongLat($dblLng2, $dblLat2);
			$X2 = $this->gPoint->distanceFrom($arrBBox['dblLngSW'], $dblLat2) / $intResolution;
			if ($dblLng2 < $arrBBox['dblLngSW']) $X2 = - $X2;
			$Y2 = $this->gPoint->distanceFrom($dblLng2, $arrBBox['dblLatNE']) / $intResolution;
			if ($dblLat2 > $arrBBox['dblLatNE']) $Y2 = - $Y2;
			// Determining Linear Equation parameters y = ax + b
			$a = ($X2 == $X1 ? 0 : ($Y2 - $Y1)/($X2 - $X1));
			$b = $Y1 - $X1*$a;
			// Contraining X1,Y1 to BB
			if ($X1 < 0) {
				$X1 = 0;
				$Y1 = $b;
			} else if ($X1 >= $arrBBox['intWidthPixels']) {
				$X1 = $arrBBox['intWidthPixels']-1;
				$Y1 = $a*$X1+$b;
			}
			if ($Y1 < 0) {
				$Y1 = 0;
				$X1 = -$b/$a;
			} else if ($Y1 >= $arrBBox['intHeightPixels']) {
				$Y1 = $arrBBox['intHeightPixels']-1;
				$X1 = ($Y1-$b)/$a;
			}
			// Contraining X2,Y2 to BB
			if ($X2 < 0) {
				$X2 = 0;
				$Y2 = $b;
			} else if ($X2 >= $arrBBox['intWidthPixels']) {
				$X2 = $arrBBox['intWidthPixels']-1;
				$Y2 = $a*$X2+$b;
			}
			if ($Y2 < 0) {
				$Y2 = 0;
				$X2 = -$b/$a;
			} else if ($Y2 >= $arrBBox['intHeightPixels']) {
				$Y2 = $arrBBox['intHeightPixels']-1;
				$X2 = ($Y2-$b)/$a;
			}
			// If both point current and previous are otside BB, don't print
			if (
				(($X1 < 0) || ($X1 >= $arrBBox['intWidthPixels']) || ($Y1 < 0) || ($Y1 >= $arrBBox['intHeightPixels'])) &&
				(($X2 < 0) || ($X2 >= $arrBBox['intWidthPixels']) || ($Y2 < 0) || ($Y2 >= $arrBBox['intHeightPixels']))
			) {
				continue;
			}
			$arrXYs[$j]['X'] = round($X1);
			$arrXYs[$j]['Y'] = round($Y1);
			$arrXYs[$j+1]['X'] = round($X2);
			$arrXYs[$j+1]['Y'] = round($Y2);
			$j = $j+2;
		}
		return $arrXYs;
	}
}
?>