<?php
class Importer {
	public $strDefaultIcon = 'icon-upload';
	public $IMPORTER_ERROR_LESS_FIELDS = -2;
	
	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'form.php';
		$form = new Form($this->database);
		$this->form = $form;
		
		include_once 'formrecord.php';
		$formrecord = new Formrecord($this->database);
		$this->formrecord = $formrecord;
		
		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		session_start();
	}

	public function importDataFromFile($idProject, $idUser, $idForm, $strFormName, $strFileName, $idLatitude, $idLongitude, $strZone = '', $idDatumIn = '') {
		ob_implicit_flush(true);
		ob_end_flush();
		$arrResult = array();
		$arrInsertRecordVertex = array();
		$arrResult['idStatus'] = 'OK'; // OK
		// Increasing to avoid timeout during long import procedures
		set_time_limit(2000);
		$intProcessed = 0;
		$arrExt = explode('.', $strFileName);
		$strExt = strtolower(array_pop($arrExt));
		$blnNewForm = ($idForm == "N");
		// Get next free idFormRecord to start batch insert
		$idFormRecord = $this->database->intSelectNextTableKey('formrecord', 'idFormRecord');
		// Get next free idFormRecordField to start batch insert
		$idFormRecordField = $this->database->intSelectNextTableKey('formrecordfield', 'idFormRecordField');
		// Sets Input Map Original Datum
		if ($idDatumIn) {
			$ptDatumIn = new gPoint($this->database, $idDatumIn);
			$ptDatumWGS84 = new gPoint($this->database); // Default = 23 - WGS84
		}

		// Reading XLS File
		if (($strExt == 'xls') || ($strExt == 'xlsx') || ($strExt == 'csv') || ($strExt == 'shp')) {
			$arrFields = array();
			// Get Fields
			if ($strExt == 'csv') {
				$strFileContent = file_get_contents($strFileName);
				$arrLines = explode(chr(13), $strFileContent);
				$intNLines = count($arrLines);
				$strLineHeader = $arrLines[0];
				$strLineHeader = $this->strings->removeInvalidCharsSQL($strLineHeader);
				$arrHeader = explode(';', $strLineHeader);
				$strLine1 = $arrLines[1];
				$strLine1 = $this->strings->removeInvalidCharsSQL($strLine1);
				$arrLine1 = explode(';', $strLine1);
				$intCol = 0;
				foreach($arrHeader as $strFieldName) {
					$arrFields[$intCol]['strName'] = $strFieldName;
					$arrFields[$intCol]['idFieldType'] = (is_numeric($arrLine1[$intCol]) ? 2 : 1);
					$intCol++;
				}
			} else if (($strExt == 'xlsx') || ($strExt == 'xls')) {
				require_once 'js/excel/Classes/PHPExcel/IOFactory.php';
				$XLS = PHPExcel_IOFactory::load($strFileName);
				// Plan 1
				$XLS->setActiveSheetIndex(0);
				$Plan = $XLS->getActiveSheet();
				$intNLines = 1;
				while($Plan->getCellByColumnAndRow(0, $intNLines)->getValue() != '') $intNLines++;
				$intNLines = $intNLines - 1; // Step Header
				// Handling line 1 but header
				$intCol = 0;
				while($Plan->getCellByColumnAndRow($intCol, 1)->getValue() != '') {
					$strValue = $Plan->getCellByColumnAndRow($intCol, 2)->getValue();
					if ($strValue[0] == '=') {
						$strValue = $Plan->getCellByColumnAndRow($intCol, 2)->getCalculatedValue();
					}
					$arrFields[$intCol]['strName'] = utf8_decode($Plan->getCellByColumnAndRow($intCol, 1)->getValue());
					$arrFields[$intCol]['idFieldType'] = 1; // Set default as text
					if (is_numeric($strValue)) { // Is a Numeric Field
						$arrFields[$intCol]['idFieldType'] = 2;
					}
					if (strpos($strValue, '/') !== FALSE) {
						$strDateTime = str_replace('/', '-', $strValue);
						if (strtotime($strDateTime) !== FALSE) {
							$arrFields[$intCol]['idFieldType'] = 5; // Is a Date Field
						}
					}
					$intCol++;
				}
			} else if ($strExt == 'shp') {
				require_once 'shapefile/reader/shpParser.php';
				$shp = new shpParser();
				$shp->load($strFileName);
				$objects = $shp->getShapeData();
				$intNLines = count($objects);
				$strBaseFileName = explode('.', $strFileName);
				$strBaseFileName = $strBaseFileName[0];
				$strFileNameDBF = $strBaseFileName . '.dbf';
				if (file_exists($strFileNameDBF)) {
					require_once ('shapefile/reader/dbase.php');
					$dbf = new dbf_class($strFileNameDBF);
					for($i=0; $i<$dbf->dbf_num_field; $i++){
						$arrFields[$i]['strName'] = utf8_decode($dbf->dbf_names[$i]['name']);
						$arrFields[$i]['idFieldType'] = 1; // Set default as text
						if ($dbf->dbf_names[$i]['type'] == 'N') {
							$arrFields[$i]['idFieldType'] = 2;
						}
					}
				}
			}
			$intNCols = count($arrFields);
			// If is new form, create it
			if ($blnNewForm) {
				// Inserting new form.
				$idForm = $this->form->insertForm($idUser, $idProject, $strFormName);
				$idForm = $idForm['idForm'];
				$k = 1;
				$intOrder = 1;
				// Inserting form fields.  Faster directly
				$query = "INSERT INTO formfield (idForm, idFormFieldType, strName, strTip, intOrder, blnActive) VALUES ";
				foreach($arrFields as $arrField) {
					// If is not Lat or Lng field, it will be inserted
					if (! (($idLatitude == $k) || (($idLongitude == $k)))) {
						// idTipoPergunta = 1 - Por padr�o vai ser tudo que vem do CSV ser� tipo Texto
						$strFieldName = trim($arrField['strName']);
						$query .= "('" . $idForm . "', " . $arrField['idFieldType'] . ", '" . $strFieldName . "', '', " . $intOrder . ", 1),";
						$intOrder++;
						$this->database->insertEvent(7, $idUser, $strFormName, $strFieldName, $arrField['idFieldType']);
					}
					$k++;
				}
				$query = substr($query, 0, strlen($query) - 1); // Remove last ,
				$this->database->executeQuery($query);
			} else { // Form already exists. Get its field list
				$arrFormFields = $this->form->selectFormFields($idForm); 
				$arrFormFieldsAlternatives = array();
				foreach ($arrFormFields as $arrFormField) {
					if (($arrFormField['idFormFieldType'] == 3) || ($arrFormField['idFormFieldType'] == 4)) {
						$arrFormFieldsAlternatives[$arrFormField['idFormField']]['arrAlternatives'] = $this->form->selectFieldAlternatives($arrFormField['idFormField']);
					}
				}
				
			}
			// Se for formul�rio existente gerar SQL para criar inst�ncia de tabela e campos no formulario resposta
			$arrFormFieldIDs = $this->form->arrFormFieldIDs($idForm, false); // false to get also numeric fields
			// End of Form Fields Handling
			// Start handle records
			$intRowStart = ($strExt == 'shp' ? 0 : 2);
			$intRowFinish = ($strExt == 'shp' ? $intNLines - 1 : $intNLines);
			for ($i=$intRowStart;$i<=$intRowFinish;$i++) {
				$intCurrentRow++;
				// Creating a CSV format line to handle like it
				if ($strExt == 'csv') {
					if (($arrLines[$i-1] == '') || (strpos($arrLines[$i-1], ';') === FALSE)) { // Do not process
						continue;
					}
					$arrRow = explode(';', $arrLines[$i-1]);
				} else if (($strExt == 'xlsx') || ($strExt == 'xls')) {
					$arrRow = array();
					for ($intCol=0;$intCol<$intNCols;$intCol++) {
						$strValue = utf8_decode($Plan->getCellByColumnAndRow($intCol, $i)->getValue());
						if ($strValue[0] == '=') {
							$strValue = utf8_decode($Plan->getCellByColumnAndRow($intCol, $i)->getCalculatedValue());
						}
						$strValue = str_replace(";","",$strValue);
						$arrRow[] = $strValue;
					}
				} else if ($strExt == 'shp') {
					$arrRow = array();
					if ($dbf) {
						$row = $dbf->getRow($i);
						for($j=0; $j<$dbf->dbf_num_field; $j++){
								$arrRow[] = $row[$j];
						}
					}
				}
				$arrVertexs = array();
				$idShapeType = 1;
				if ($strExt == 'shp') {
					$object = $objects[$i];
					if ($object['shapeType']['id'] == 3) {		// POLYLINE
						$idShapeType = 2;
					} else if (($object['shapeType']['id'] == 5) || ($object['shapeType']['id'] == 25) || ($object['shapeType']['id'] == 15))	{ // POLYGON
						$idShapeType = 3;
					}
					$strVertexs = $object['geom']['wkt'];
					// Polygons type MULTIPOLYLINES or MULTIPOLYGON we store each shape in arrShapes
					$arrShapes = explode(', ', $strVertexs);
					foreach ($arrShapes as $s => $strVertexs) {
						$strVertexs = str_replace('(((', '(', $strVertexs);
						$strVertexs = str_replace('((', '(', $strVertexs);
						$start  = strpos($strVertexs, '(');
						$end    = strpos($strVertexs, ')', $start + 1);
						$length = $end - $start;
						$strVertexs = substr($strVertexs, $start + 1, $length - 1);
						$arrVtcs = explode(',', $strVertexs);
						foreach ($arrVtcs as $v => $strVtc) {
							$arrCoordinates = explode(' ', $strVtc);
							$arrVertexs[$s][$v]['dblLatitude'] = $arrCoordinates[1];
							$arrVertexs[$s][$v]['dblLongitude'] = $arrCoordinates[0];
							$arrVertexs[$s][$v] = $this->arrCheckConvertVertex($arrVertexs[$s][$v], $this->gPoint, $strZone);
						}
					}
				} else {
					// Inserting Vertex
					$lat = $arrRow[$idLatitude - 1];
					$lng = $arrRow[$idLongitude - 1];
					$lat = str_replace(",",".",$lat);
					$lng = str_replace(",",".",$lng);
					if ((!is_numeric($lat)) || ($lat > 90) || ($lat < -90)) $lat = "0";
					if ((!is_numeric($lng)) || ($lng > 180) || ($lng < -180)) $lng = "0";
					$arrVertexs[0][0]['dblLatitude'] = $lat;
					$arrVertexs[0][0]['dblLongitude'] = $lng;
				}
				// If do not find coordinates, do not insert record
				if (count($arrVertexs) == 0) continue;
				
				// Create one record for each polygon for MULTIPOLYLINES or MULTIPOLYGON records
				foreach ($arrVertexs as $arrPartVertexs) {
					// Inserting Event
					$strInsertEvent .= "(17," . $idUser . ",'" . $strFormName . "','" . $idFormRecord . "',1),";
					// Insering record into formrecord table
					$strInsertFormRecord .= "(" . $idFormRecord . "," . $idUser . "," . $idForm . ",1," . $idShapeType . "," . ($idShapeType > 1 ? "'" . $this->strings->strGenerateRandonColor() . "'" : "NULL") . ",NOW(),NOW()),";
					// Inserting shape vertexs
					foreach ($arrPartVertexs as $v => $arrVertex) {
					  // Converting Input Datum to WGS84 (Google Maps)
					  if ($idDatumIn) {
							$ptDatumIn->setLongLat($arrVertex['dblLongitude'], $arrVertex['dblLatitude']);
							$ptDatumIn->convertLLtoTM();
							$ptDatumWGS84->setUTM($ptDatumIn->E(), $ptDatumIn->N(), $ptDatumIn->Z());
							$ptDatumWGS84->convertTMtoLL();
							$arrVertex['dblLatitude'] = $ptDatumWGS84->Lat();
							$arrVertex['dblLongitude'] = $ptDatumWGS84->Long();
					  }
					  $arrInsertRecordVertex[] = "(" . $idFormRecord . ",'" . $arrVertex['dblLatitude'] . "','" . $arrVertex['dblLongitude'] . "', " . ($v+1) .")";
					}
					// Code for inserts
					$k = 0;
					$j = 0;
					while($k < sizeof($arrRow)) {
						//$arrRow[$k] = $this->strings->removeInvalidCharsSQL($arrRow[$k]);
						$arrRow[$k] = mysql_real_escape_string($arrRow[$k]);
						// If Col==Lat || Long do not insert value
						if ($idLatitude == $k+1) { $k++; continue; }
						if ($idLongitude == $k+1) { $k++; continue; }
						// If empty cell do not insert
						/*
						// Comment this block to insert all, even null fields
						if (! $arrRow[$k]) { 
							$k++; 
							$j++; 
							//if (! $blnNewForm) $j++; 
							continue; 
						}
						*/
						// If is not new form, insert based on field types from fields list
						if ($blnNewForm) {
							// If number os cols greater than form fields, stop iteration, go to next line
							if ($j >= sizeof($arrFormFieldIDs)) break;
							if ($arrFields[$k]['idFieldType'] == 1) {			// Text
								$strInsertFormRecordField .= "(" . $idFormRecordField . ",". $arrFormFieldIDs[$j]  . "," . $idFormRecord . "),";
								$strInsertFormRecordFieldText .= "(" . $idFormRecordField . ",'" . mb_strtoupper($arrRow[$k]) . "'),";
								$idFormRecordField++;
							} else if ($arrFields[$k]['idFieldType'] == 2) {	// Numeric
								$strValue = $arrRow[$k];
								if (! is_numeric($strValue)) $strValue = '0';
								$strInsertFormRecordField .= "(" . $idFormRecordField . ",". $arrFormFieldIDs[$j]  . "," . $idFormRecord . "),";
								$strInsertFormRecordFieldNumeric .= "(" . $idFormRecordField . "," .  $strValue . "),";
								$idFormRecordField++;
							} else if ($arrFields[$k]['idFieldType'] == 5) {	// Date
								$strDateTime = str_replace('/', '-', $arrRow[$k]);
								$dtDateTime = strtotime($strDateTime);
								if ($dtDateTime !== FALSE) {
									$strDateTime = date('Y-m-d', $dtDateTime);
									$strInsertFormRecordField .= "(" . $idFormRecordField . ",". $arrFormFieldIDs[$j]  . "," . $idFormRecord . "),";
									$strInsertFormRecordFieldDate .= "(" . $idFormRecordField . ",'" . $strDateTime . "'),";
									$idFormRecordField++;
								}
							}
						} else {
							// Otherwise, if user uploaded CSV containing more fields than the selected form, stop
							if ($j >= count($arrFormFields)) break;
							if ($arrFormFields[$j]['idFormFieldType'] == 1) {			// Text
								$strInsertFormRecordField .= "(" . $idFormRecordField . "," . $arrFormFields[$j]['idFormField']  . "," . $idFormRecord . "),";
								$strInsertFormRecordFieldText .= "(" . $idFormRecordField . ",'" . mb_strtoupper($arrRow[$k]) . "'),";
								$idFormRecordField++;
							} else if ($arrFormFields[$j]['idFormFieldType'] == 2) {	// Numeric
								$arrRow[$k] = str_replace(",",".",$arrRow[$k]);
								if (is_numeric($arrRow[$k])) {
									$strInsertFormRecordField .= "(" . $idFormRecordField . "," . $arrFormFields[$j]['idFormField']  . "," . $idFormRecord . "),";
									$strInsertFormRecordFieldNumeric .= "(" . $idFormRecordField . "," . $arrRow[$k] . "),";
									$idFormRecordField++;
								}
							} else if (($arrFormFields[$j]['idFormFieldType'] == 3) || ($arrFormFields[$j]['idFormFieldType'] == 4)) {	// Unique or Mulple Choice
								$arrAlternatives = $arrFormFieldsAlternatives[$arrFormFields[$j]['idFormField']]['arrAlternatives'];
								foreach ($arrAlternatives as $arrAlternative) {
									if (strtoupper($arrAlternative['strAlternative']) == strtoupper($arrRow[$k])) {
										$idFormFieldAlternative = $arrAlternative['idFormFieldAlternative'];
										$strInsertFormRecordField .= "(" . $idFormRecordField . "," . $arrFormFields[$j]['idFormField']  . "," . $idFormRecord . "),";
										$strInsertFormRecordFieldAlternative .= "(" . $idFormRecordField . "," . $idFormFieldAlternative . "),";
										$idFormRecordField++;
										break;
									}
								}
							} else if ($arrFormFields[$j]['idFormFieldType'] == 5) {	// Date
								$strDateTime = str_replace('/', '-', $arrRow[$k]);
								$dtDateTime = strtotime($strDateTime);
								if ($dtDateTime !== FALSE) {
									$strDateTime = date('Y-m-d', $dtDateTime);
									$strInsertFormRecordField .= "(" . $idFormRecordField . "," . $arrFormFields[$j]['idFormField']  . "," . $idFormRecord . "),";
									$strInsertFormRecordFieldDate .= "(" . $idFormRecordField . ",'" . $strDateTime . "'),";
									$idFormRecordField++;
								}
							}
						}
						$k++;
						$j++;
					}
					$idFormRecord++;
				} // End of record shapes inserting ($arrVertexs as $v => $arrPoints)
				// If mod 100 or is last row, will process and reset strs to generate a new set and avoid a slow processing
				if (($i % 100 == 0) || ($i >= $intNLines-1)) {
					$strInsertFormRecord = substr($strInsertFormRecord, 0, strlen($strInsertFormRecord) - 1);
					if ($strInsertFormRecord) {
						$strInsertFormRecord = "INSERT INTO formrecord (idFormRecord, idUser, idForm, idDevice, idShapeType, strCustomMarkerRGBColor, dtCreation, dtLastUpdate) VALUES " . $strInsertFormRecord;
						$result = $this->database->executeQuery($strInsertFormRecord);
						$strInsertFormRecord = '';        
					}
					
					$strInsertEvent = substr(strInsertEvent, 0, strlen(strInsertEvent) - 1);
					if (strInsertEvent) {
						$strInsertEvent = "INSERT INTO event (idEventType, idUser, dtDateTime, strParm1, strParm2, strParm3) VALUES " . $strInsertEvent;
						$result = $this->database->executeQuery(strInsertEvent);
						$strInsertEvent = '';
					}
			
					if (count($arrInsertRecordVertex)) {
						// Break Inserts into batches of 1000
						$intIndex = 0;
						while ($intIndex < count($arrInsertRecordVertex)) {
							$arrInsert = array_slice($arrInsertRecordVertex, $intIndex, 1000);
							$intIndex += 1000;
							$result = $this->database->executeQuery("INSERT INTO formrecordvertex (idFormRecord, dblLatitude, dblLongitude, intPosition) VALUES " . implode(',', $arrInsert));
						}
						$arrInsertRecordVertex = array();
					}
					
					$strInsertFormRecordField = substr($strInsertFormRecordField, 0, strlen($strInsertFormRecordField) - 1);
					if ($strInsertFormRecordField) {
						$strInsertFormRecordField = "INSERT INTO formrecordfield (idFormRecordField, idFormField, idFormRecord) VALUES " . $strInsertFormRecordField;
						$result = $this->database->executeQuery($strInsertFormRecordField);
						$strInsertFormRecordField = '';
					}

					$strInsertFormRecordFieldText = substr($strInsertFormRecordFieldText, 0, strlen($strInsertFormRecordFieldText) - 1);
					if ($strInsertFormRecordFieldText) {
						$strInsertFormRecordFieldText = "INSERT INTO formrecordfieldtext (idFormRecordField, strValue) VALUES " . $strInsertFormRecordFieldText;
						$result = $this->database->executeQuery($strInsertFormRecordFieldText);
						$strInsertFormRecordFieldText = '';
					}
					
					if ($strInsertFormRecordFieldNumeric) {
						$strInsertFormRecordFieldNumeric = substr($strInsertFormRecordFieldNumeric, 0, strlen($strInsertFormRecordFieldNumeric) - 1);
						$strInsertFormRecordFieldNumeric = "INSERT INTO formrecordfieldnumeric (idFormRecordField, dblValue) VALUES " . $strInsertFormRecordFieldNumeric;
						$result = $this->database->executeQuery($strInsertFormRecordFieldNumeric);
						$strInsertFormRecordFieldNumeric = '';
					}
					
					if ($strInsertFormRecordFieldAlternative) {
						$strInsertFormRecordFieldAlternative = substr($strInsertFormRecordFieldAlternative, 0, strlen($strInsertFormRecordFieldAlternative) - 1);
						$strInsertFormRecordFieldAlternative = "INSERT INTO formrecordfieldalternative (idFormRecordField, idFormFieldAlternative) VALUES " . $strInsertFormRecordFieldAlternative;
						$result = $this->database->executeQuery($strInsertFormRecordFieldAlternative);
						$strInsertFormRecordFieldAlternative = '';
					}
					
					if ($strInsertFormRecordFieldDate) {
						$strInsertFormRecordFieldDate = substr($strInsertFormRecordFieldDate, 0, strlen($strInsertFormRecordFieldDate) - 1);
						$strInsertFormRecordFieldDate = "INSERT INTO formrecordfielddate (idFormRecordField, dtValue) VALUES " . $strInsertFormRecordFieldDate;
						$result = $this->database->executeQuery($strInsertFormRecordFieldDate);
						$strInsertFormRecordFieldDate = '';
					}
					
					echo ',' . $i;
				}
			} // End of line (i) reading
		} else if ($strExt == "kml") {
			$idFormRecord = 1;
			// New form for KML Import
			if ($blnNewForm) {
				// Inserting new form
				$idForm = $this->form->insertForm($idUser, $idProject, $strFormName);
				$idForm = $idForm['idForm'];
				$k = 1;
				$intOrder = 1;
				// Inserting form fields. Faster by coding
				$query = "INSERT INTO formfield (idForm, idFormFieldType, strName, strTip, intOrder, blnActive) VALUES 
					(" . $idForm . ", 1, '" . $_SESSION['strToolImporterKMLName'] . "', '', 1, 1),
					(" . $idForm . ", 1, '" . $_SESSION['strToolImporterKMLDescription'] . "', '', 2, 1)
				";
				$this->database->executeQuery($query);
			}
			// Get text fields list - True returns only text fields
			$arrFormFieldIDs = $this->form->arrFormFieldIDs($idForm, true);
			if (count($arrFormFieldIDs) < 2) { // Less fields than necessary
				$arrResult['idStatus'] = $this->IMPORTER_ERROR_LESS_FIELDS;
				return $arrResult;
			}
			require_once 'kml.php';
			$kml = new Kml();
			$arrKML = $kml->load($strFileName);
			foreach ($arrKML['arrObjects'] as $arrObject) {
			  // Creating record - populating tables
			  $arrFormRecord = $this->formrecord->insertFormRecord($idUser, $idForm, 1, $arrObject['idShapeType'], ($arrObject['idShapeType'] > 1 ? $this->strings->strGenerateRandonColor() : ''), $arrObject['arrCoordinates']);
			  $idFormRecord = $arrFormRecord['idFormRecord'];					
			  // Inserting record content
			  $sql = "INSERT INTO formrecordfield (idFormRecordField, idFormField, idFormRecord) VALUES
				  (" . $idFormRecordField . "," . $arrFormFieldIDs[0]  . "," . $idFormRecord . "),
				  (" . ($idFormRecordField + 1) . "," . $arrFormFieldIDs[1]  . "," . $idFormRecord . ")
			  ";
			  $this->database->executeQuery($sql);
			  $sql = "INSERT INTO formrecordfieldtext (idFormRecordField, strValue) VALUES
				  (" . $idFormRecordField . ",'" . $arrObject['strName'] . "'),
				  (" . ($idFormRecordField + 1) . ",'" . $arrObject['strDescription'] . "')
			  ";
			  $this->database->executeQuery($sql);
			  $idFormRecordField += 2;
			  $intProcessed++;
			  echo ',' . $intProcessed;
			}
		}
		return $arrResult;
	}
	
	public function arrCheckConvertVertex($arrVtc, $gPoint, $strZone) {
		$strCoord = explode('.', $arrVtc['dblLatitude']);
		$strCoord = $strCoord[0];
		if (strlen($strCoord) >= 4) {
			$gPoint->setUTM($arrVtc['dblLongitude'], $arrVtc['dblLatitude'], $strZone);
			$gPoint->convertTMtoLL();
			$arrVtc['dblLongitude'] = $gPoint->Long();
			$arrVtc['dblLatitude'] = $gPoint->Lat();
		}
		return $arrVtc;
	}
}
?>