<?php
class Conversor {
	public function __construct($database) {
		$this->database = $database;
		
		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;

		include_once 'importer.php';
		$importer = new Importer($database);
		$this->importer = $importer;
		
		include_once 'rs2.php';
		$rs2 = new rs2();
		$this->rs2 = $rs2;
		
		include_once 'gPoint.php';
		
		session_start();
	}

	public function XLS2DBF($strFileNameXLS) {
		set_time_limit(2000);
		require_once ('js/excel/Classes/PHPExcel/IOFactory.php');
		require_once "engine/dbf/Column.class.php";
		require_once "engine/dbf/Record.class.php";
		require_once "engine/dbf/Table.class.php";
		require_once "engine/dbf/WritableTable.class.php";
		$strFileNameDBF = $this->strings->strSiteTmpFileFolder . '/' . $this->strings->generateRandomString(5) . '.dbf';
		$XLS = PHPExcel_IOFactory::load($strFileNameXLS);
		$XLS->setActiveSheetIndex(0);
		$Plan = $XLS->getActiveSheet();
		$arrFields = array();
		$intCols=0;
		while($Plan->getCellByColumnAndRow($intCols, 1)->getValue() != '') {
			$strFieldName = $this->strings->changeCharAccent(strtoupper(utf8_decode($Plan->getCellByColumnAndRow($intCols, 1)->getCalculatedValue())));
			$strFieldValue = $Plan->getCellByColumnAndRow($intCols, 2)->getValue();
			/*
			if (is_numeric($strFieldValue)) {
				$arrFields[] = array($strFieldName, DBFFIELD_TYPE_NUMERIC, 12, 2);
			} else {
				$arrFields[] = array($strFieldName, DBFFIELD_TYPE_CHAR, 254);
			}
			*/
			$arrFields[] = array($strFieldName, DBFFIELD_TYPE_CHAR, 254);
			$intCols++;
		};
		$dbf = XBaseWritableTable::create($strFileNameDBF, $arrFields);
		$intRow=2;
		$strLine = '';
		while($Plan->getCellByColumnAndRow(0, $intRow)->getValue() != '') {
			$r = &$dbf->appendRecord();
			for ($intCol=0;$intCol<count($arrFields);$intCol++) {
				$strFieldValue = $this->strings->changeCharAccent(strtoupper(utf8_decode($Plan->getCellByColumnAndRow($intCol, $intRow)->getCalculatedValue())));
				$r->setObjectByIndex($intCol, $strFieldValue);
			}
			$dbf->writeRecord();
			$intRow++;
		}
		$dbf->close();
		return array('strFileName' => $strFileNameDBF);
	}

	public function VEC2RS2($strExt, $strOriginalFileName, $strBaseFileName, $intDBFFieldIndex, $idDatumIn, $intResolution, $dblLatSW, $dblLatNE, $dblLngSW, $dblLngNE, $intUTMZone = '', $chrUTMHemisphere = '') {
		// Increasing to avoid timeout during long import procedures
		set_time_limit(2000);
		$gPoint = new gPoint($this->database, $idDatumIn);
		$strZone = $intUTMZone . $chrUTMHemisphere;
		$strFileName = $this->strings->strSiteTmpFileFolder . '/' . $strBaseFileName;
		$strFileNameRS2 = 'tmp/' . $strOriginalFileName . '.rs2';
		$strFileNamePNG = $strFileName . '.png';
		if ($strExt == 'shp') {
			$strFileNameSHP = $strFileName . '.shp';
			$strFileNameDBF = $strFileName . '.dbf';
			require 'engine/shapefile/reader/shpParser.php';
			$shp = new shpParser();
			$shp->load($strFileNameSHP);
			$shpBB = $this->arrCheckConvertCoordinatesSystem($shp->headerInfo['boundingBox'], $gPoint, $strZone);
			$objects = $shp->getShapeData();
			include_once 'engine/shapefile/reader/dbase.php';
			if (file_exists($strFileNameDBF)) {
				$dbf = new dbf_class($strFileNameDBF);
			}
		} else if ($strExt == 'kml') {
			require_once 'engine/kml.php';
			$kml = new Kml();
			$arrKML = $kml->load($strFileName . '.kml', true, 0);
			$objects = $arrKML['arrObjects'];
		}
		// Plot and Write PNG Base File
		$arrBBox = array();
		$arrBBox['dblLatSW'] = $dblLatSW;
		$arrBBox['dblLngSW'] = $dblLngSW;
		$arrBBox['dblLatNE'] = $dblLatNE;
		$arrBBox['dblLngNE'] = $dblLngNE;
		// Setting BoundingBox in UTM
		$gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$gPoint->convertLLtoTM();
		$arrBBox['dblLatSWUTM'] = $gPoint->N();
		$arrBBox['dblLngSWUTM'] = $gPoint->E();
		$arrBBox['intZoneSWUTM'] = $gPoint->Z();
		/*
		$gPoint->setLongLat($arrBBox['dblLngNE'], $arrBBox['dblLatNE']);
		$gPoint->convertLLtoTM();
		$arrBBox['dblLatNEUTM'] = $gPoint->N();
		$arrBBox['dblLngNEUTM'] = $gPoint->E();
		$arrBBox['intZoneNEUTM'] = $gPoint->Z();
		*/
		// Setting Map Width
		$arrDimensions = array();
		$gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$arrDimensions['dbWidthMts']	= ceil($gPoint->distanceFrom($arrBBox['dblLngNE'], $arrBBox['dblLatSW']));
		$arrDimensions['dblHeightMts'] 	= ceil($gPoint->distanceFrom($arrBBox['dblLngSW'], $arrBBox['dblLatNE']));	
		$arrDimensions['intResolution'] = $intResolution;
		$arrDimensions['intWidthPixels'] = round($arrDimensions['dbWidthMts'] / $arrDimensions['intResolution']);
		$arrDimensions['intHeightPixels']= round($arrDimensions['dblHeightMts'] / $arrDimensions['intResolution']);	
		$arrBBox['intWidthPixels'] = $arrDimensions['intWidthPixels'];
		$arrBBox['intHeightPixels'] = $arrDimensions['intHeightPixels'];
		$arrBBox['dblLatNEUTM'] = $arrBBox['dblLatSWUTM'] + $arrDimensions['intResolution']*$arrDimensions['intHeightPixels'];
		$arrBBox['dblLngNEUTM'] = $arrBBox['dblLngSWUTM'] + $arrDimensions['intResolution']*$arrDimensions['intWidthPixels'];
		$arrBBox['intZoneNEUTM'] = $arrBBox['intZoneSWUTM'];
		// Creating Image and Ploting
		$image = imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
		$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
		$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
		// Background color = black
		$imgColorFill = $imgBlack;
		imagefilledrectangle($image, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgColorFill);	
		$arrClasses = array();
		for ($i=0;$i<=count($objects);$i++) {
			$object = $objects[$i];
			$arrVertexs = array();
			if ($strExt == 'shp') {
				$idShapeType = 3; // POLYGON
				if (($object['shapeType']['id'] == 3) || ($object['shapeType']['id'] == 23)) {	// POLYLINE
					$idShapeType = 2;
				} else if (($object['shapeType']['id'] == 1) || ($object['shapeType']['id'] == 8)  || ($object['shapeType']['id'] == 28)) {	// Point
					$idShapeType = 1;
				}
				$strVertexs = $object['geom']['wkt'];
				$arrShapes = explode(', ', $strVertexs);
				foreach ($arrShapes as $s => $strVertexs) {
					$strVertexs = str_replace('(((', '(', $strVertexs);
					$strVertexs = str_replace('((', '(', $strVertexs);
					$start  = strpos($strVertexs, '(');
					$end    = strpos($strVertexs, ')', $start + 1);
					$length = $end - $start;
					$strVertexs = substr($strVertexs, $start + 1, $length - 1);
					$arrVtcs = explode(',', $strVertexs);
					foreach ($arrVtcs as $v => $strVtc) {
						$arrCoordinates = explode(' ', $strVtc);
						$arrVertexs[$s][$v]['dblLatitude'] = $arrCoordinates[1];
						$arrVertexs[$s][$v]['dblLongitude'] = $arrCoordinates[0];
						$arrVertexs[$s][$v] = $this->importer->arrCheckConvertVertex($arrVertexs[$s][$v], $gPoint, $strZone);
					}
				}
			} else if ($strExt == 'kml') {
				$idShapeType = $object['idShapeType'];
				$arrVertexs[0] = $object['arrCoordinates'];
			}
			// Ploting Shape into RS2 Canvas
			$arrVertexsObject = $arrVertexs;
			foreach ($arrVertexsObject as $arrVertexs) {
				$strRGB = $this->strings->strColorConvertDecToRGB($i+1); 
				$imgColor = ImageColorAllocate($image, $strRGB['R'], $strRGB['G'], $strRGB['B']);
				if ($idShapeType == 1) {
					$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[0]['dblLatitude'], $arrVertexs[0]['dblLongitude'], $arrDimensions['intResolution'], $arrBBox);
					imagesetpixel($image, $arrXY['X'], $arrXY['Y'], $imgColor);
				} else if ($idShapeType == 2) {
					for ($j = 0;$j < count($arrVertexs) - 1;$j++) {
						$arrXY1 = $this->rs2->convertLatLngToXY($arrVertexs[$j]['dblLatitude'], $arrVertexs[$j]['dblLongitude'], $arrDimensions['intResolution'], $arrBBox);
						$arrXY2 = $this->rs2->convertLatLngToXY($arrVertexs[$j+1]['dblLatitude'], $arrVertexs[$j+1]['dblLongitude'], $arrDimensions['intResolution'], $arrBBox);
						imageline($image, $arrXY1['X'], $arrXY1['Y'], $arrXY2['X'], $arrXY2['Y'], $imgColor);
					}			
				} else if ($idShapeType == 3) {
					$arrPts = array();
					foreach($arrVertexs as $j => $arrVertex) {
						$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[$j]['dblLatitude'], $arrVertexs[$j]['dblLongitude'], $arrDimensions['intResolution'], $arrBBox);
						array_push($arrPts, $arrXY['X']);
						array_push($arrPts, $arrXY['Y']);
					}
					imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgColor);
				}
			}
			// Writing RS2 Category Name
			if ($strExt == 'shp') {
				$strCategory = 'C' . ($i+1);
				if ($dbf) {
					$row = $dbf->getRow($i);
					$strFieldValue = trim($row[$intDBFFieldIndex]);
					if ($strFieldValue) {
						$strCategory = $strFieldValue;
					}
				}
			} else if ($strExt == 'kml') {
				$strCategory = $object['strName'] ? $object['strName'] : 'C' . ($i+1);
			}
			$arrClasses[$i]['strClass'] = $strCategory;
			$arrClasses[$i]['intColor'] = $i+1;
			$strRGB = $this->strings->strGenerateRandonColor();
			$intColor = hexdec(substr($strRGB,1,6));
			$arrClasses[$i]['intColor'] = $intColor;
		}
		// Write to File
		imagepng($image, $strFileNamePNG);
		$arrResult = array();
		$arrResult['arrBBox'] = $arrBBox;
		$arrResult['arrDimensions'] = $arrDimensions;
		$arrResult['arrClasses'] = $arrClasses;
		// Write to RS2 File Format
		$image = imagecreatefrompng ($strFileNamePNG);
		$this->rs2->create(
			$strFileNameRS2, 
			$strOriginalFileName, 
			'', 
			$arrDimensions['intResolution'], 
			round($arrBBox['dblLatSWUTM']), 
			round($arrBBox['dblLngSWUTM']), 
			$arrBBox['intZoneSWUTM'], 
			$arrBBox['dblLatSW'] < 0 ? 1 : 0, 
			$arrDimensions['intHeightPixels'], 
			$arrDimensions['intWidthPixels'], 
			$arrClasses, 
			$image
		);
		@unlink($strFileNamePNG);
		return array('strFilePathTMP' => $strFileNameRS2);
	}
	
	public function arrCheckConvertCoordinatesSystem($shpBB, $gPoint, $strZone) {
		$strCoord = explode('.', $shpBB['ymin']);
		$strCoord = $strCoord[0];
		if (strlen($strCoord) >= 4) {
			$gPoint->setUTM($shpBB['xmin'], $shpBB['ymin'], $strZone);
			$gPoint->convertTMtoLL();
			$shpBB['xmin'] = $gPoint->Long();
			$shpBB['ymin'] = $gPoint->Lat();
			$gPoint->setUTM($shpBB['xmax'], $shpBB['ymax'], $strZone);
			$gPoint->convertTMtoLL();
			$shpBB['xmax'] = $gPoint->Long();
			$shpBB['ymax'] = $gPoint->Lat();
		}
		return $shpBB;
	}	
}
?>