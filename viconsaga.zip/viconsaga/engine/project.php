<?php
class Project {
	public $strProjectImageNoLogo		= 'img/logo.png';
	public $strProjectImageNoBackground	= 'img/backgrounds/128.jpg';
	public $strDefaultIcon				= 'icon-map-marker';
	public $strRGBDefaultColor			= 'FF0000';

	public function __construct($database) {
		$this->database = $database;
		
		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		session_start();
	}

	public function selectProjects($idProject = 0, $strSearch = '', $blnActives = 0, $blnCount = false, $blnOrderByEvent = false, $intJustAccessedLastDays = 0) {
		$query =
		"SELECT
			p.idProject,
			p.idUserCreator,
			u.strEmail AS strUserCreator,
			p.blnActive,
			p.dtDateCreation,
			p.strName,
			p.txtDescription,
			p.strAlias,
			p.strAddress,
			p.dblLatitude,
			p.dblLongitude,
			p.idCountry,
			p.idCSSTheme,
			css.strThemeName,
			p.strSiteURL,
			p.strRGBColor,
			p.strGoogleAnalyticsID,
			p.strSkypeID,
			p.strLogoFile,
			p.strBackgroundFile,
			p.idProjectUserViewScope,
			p.blnAllowAllView,
			p.blnAllowJoin,
			p.blnAllowJoinAsLevel3,
			c.strName as strCountryName,
			c.strLanguageCode,
			c.strCurrencySymbol
			" . ($blnOrderByEvent ? ",MAX(e.dtDateTime) AS dtLastAccess" : "") . "
		FROM
			project 	p,
			country		c,
			user		u,
			csstheme	css
			" . ($blnOrderByEvent ? ", event e" : "") . "
		WHERE 
		c.idCountry = 	p.idCountry AND
		p.idProject =	u.idProject AND 
		css.idCSSTheme = p.idCSSTheme
		" . ($blnOrderByEvent ? " AND e.idUser = u.idUser AND e.idEventType = 19" : "") . "
		" . ($idProject > 0 ? " AND p.idProject = " . $idProject : "") . "
		" . ($blnActives > 0 ? " AND p.blnActive = 1" : "") . "
		" . ($intJustAccessedLastDays > 0 ? "AND e.dtDateTime BETWEEN NOW() - INTERVAL " . $intJustAccessedLastDays . " DAY AND NOW()" : "") . "
		" . ($strSearch ? is_numeric($strSearch) ? "AND p.idProject = " . $strSearch : "
			AND (
			p.strName			LIKE '%" . $strSearch . "%' OR
			p.txtDescription	LIKE '%" . $strSearch . "%' OR
			p.strAddress		LIKE '%" . $strSearch . "%' OR
			p.strAlias			LIKE '" . $strSearch . "'
			)
		" : "") . "
		GROUP BY p.idProject
		ORDER BY 
		" . ($blnOrderByEvent ? " dtLastAccess DESC" : " p.idProject") . "
		";
		//$fh = fopen("out.txt", 'w');fwrite($fh, $query);fclose($fh);
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateCreation'] = date('d/m/y', strtotime($result[$idLine]['dtDateCreation']));
			$result[$idLine]['strURL'] = $this->strings->strSiteURL . '/?idProject=' . $result[$idLine]['idProject'];
			$result[$idLine]['strURLExternal'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strAlias'];
			$result[$idLine]['strSiteURL'] = ((($result[$idLine]['strSiteURL']) && (strpos($result[$idLine]['strSiteURL'], 'http') === FALSE)) ? 'http://' . $result[$idLine]['strSiteURL'] : '');
			$result[$idLine]['strRGBColor'] = $result[$idLine]['strRGBColor'] ? $result[$idLine]['strRGBColor'] : substr($this->strings->strSiteBaseColor,1,10);
			$result[$idLine]['strRGBColorDark'] = $this->strings->strRGBDarker($result[$idLine]['strRGBColor'], 70);
			$result[$idLine]['strRGBColorLight'] = $this->strings->strRGBLighter($result[$idLine]['strRGBColor'], 90);
			$result[$idLine]['strDateLastAccess'] = $blnOrderByEvent ? date('d/m/y H:i', strtotime($result[$idLine]['dtLastAccess'])) : '';
			$result[$idLine]['intDaysSinceLastAccess'] = $blnOrderByEvent ? 
				floor((time() - strtotime($result[$idLine]['dtLastAccess']))/(60*60*24))
			 : '';
			// Formating full path for logo image
			$result[$idLine]['strLogoFileFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/'  . $result[$idLine]['strLogoFile'];
			if ((! $result[$idLine]['strLogoFile']) || ((! file_exists($result[$idLine]['strLogoFileFullPath'])) && (! file_exists('../' . $result[$idLine]['strLogoFileFullPath'])))) {
				$result[$idLine]['strLogoFileFullPath'] = $this->strProjectImageNoLogo;
			}
			// Formating full path for background image
			$result[$idLine]['strBackgroundFileFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/' . $result[$idLine]['strBackgroundFile'];
			if ((! $result[$idLine]['strBackgroundFile']) || ((! file_exists($result[$idLine]['strBackgroundFileFullPath'])) && (! file_exists('../' . $result[$idLine]['strBackgroundFileFullPath'])))) {
				$result[$idLine]['strBackgroundFileFullPath'] = $this->strProjectImageNoBackground;
			}
			if ($blnCount) {
				$result[$idLine]['intUsers'] =  $this->intCountUsers($item['idProject']);
				$result[$idLine]['intForms'] =  $this->intCountForms($item['idProject']);
				$result[$idLine]['intRecords'] = $this->intCountRecords($item['idProject']);
			}
			// For Project Search
			$result[$idLine]['text'] = $item['strName'];
			//$result[$idLine]['value'] = '<div style="cursor:pointer;white-space: normal;"><a href="../index.php?idProject=' . $result[$idLine]['idProject'] . '" target="_blank" style="text-decoration:none"><img src="../' . $result[$idLine]['strLogoFileFullPath'] . '" style="height:40px;width:40px;float:left;word-break:break-word" class="rounded" align="absmiddle"> ' . strip_tags($result[$idLine]['strName']) . '</a></div>';
			$result[$idLine]['value'] = '<div style="cursor:pointer;white-space: normal;"><img src="../' . $result[$idLine]['strLogoFileFullPath'] . '" style="height:40px;width:40px;float:left;word-break:break-word;margin-right:5px" class="rounded" align="absmiddle"> ' . strip_tags($result[$idLine]['strName']) . '</div>';
			$result[$idLine]['query'] = $strSearch;
		}		
		return $result;
	}

	public function selectProjects2() {
		$query = "SELECT p.idProject FROM project p ORDER BY p.idProject";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);		
		return $result;
	}


	public function insertProject($strEmail, $strName, $strAlias, $blnSendNotificationMail = true) {
		$arrReturn = array();
		// Create Project
		$query =
		"INSERT INTO project SET
			dtDateCreation			= NOW(),
			strName					= '" . $strName . "',
			strAlias				= '" . $strAlias . "',
			blnAllowAllView			= 1,
			idProjectUserViewScope	= 3,
			idProjectUserEditScope	= 3
		";
		$this->database->executeQuery($query);
		$arrReturn['idProject'] = $this->database->getLastInsertedID();
		
		/*
		$query = "SELECT MAX(idProject) as `idProject` FROM project";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);		
		$arrReturn['idProject'] = $result[0]['idProject'];
		*/
		
		if (! is_numeric($arrReturn['idProject'])) { return false;}
		// Create folder for Project
		$strProjectFolderName = $this->strings->strProjectFolder . '/' . $arrReturn['idProject'] . '/';
		mkdir($strProjectFolderName);
		// Create folder for Support Files
		mkdir($strProjectFolderName . '/' . $this->strings->strSupportFolder);
		// Create User
		$strPassword = $this->strings->generateRandomString(4);
		$query =
		"INSERT INTO user SET
			idProject		= " . $arrReturn['idProject'] . ",
			idUserLevel		= 4,
			dtRegister		= NOW(),
			strEmail		=  '" . $strEmail . "',
			strPassword	 	= '" . md5($strPassword) . "'
		";
		$this->database->executeQuery($query);
		$arrReturn['idUser'] = $this->database->getLastInsertedID();
		
		/*
		$query = "SELECT MAX(idUser) as `idUser` FROM user WHERE idProject = " . $arrReturn['idProject'];
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);		
		$arrReturn['idUser'] = $result[0]['idUser'];
		*/
		// Update Project with idUser
		$query = "UPDATE project SET idUserCreator=" . $arrReturn['idUser'] . " WHERE idProject=" . $arrReturn['idProject'];
		$this->database->executeQuery($query);
		// If created user, send a email with password
		if ($blnSendNotificationMail) {
			$arrSessions = array();
			$arrSessions[0]['strTitle'] = $_SESSION['strJoinMailSectionYourInformation'];
			$arrSessions[0]['strContent'] = 
				$_SESSION['strJoinUserEmail'] . ': ' . $strEmail . '<br>' . 
				$_SESSION['strJoinMailPassword'] . ': ' . $strPassword . '<br>' . 
				$_SESSION['strJoinMailURL'] . ': ' . $this->strings->strSiteURL . '/' . $strAlias
			;
			$strBody = $this->strings->mailFormatContent(2, $_SESSION['strJoinMailTitle'], $_SESSION['strJoinMailWelcome'], $_SESSION['strJoinMailGreetings'], $arrSessions, '?idProject=' . $arrReturn['idProject']);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strJoinMailTitle']);
			$strFrom = $this->strings->strSiteEmail;
			$strTo = $strEmail;
			$this->strings->sendMail($strSubject, $strBody, $strFrom, $strTo, $this->strings->strSiteAuthorEmail);
		}
		return $arrReturn;
	}

	public function updateProject($idProject, $strAlias, $strName, $txtDescription, $strAddress, $dblLatitude, $dblLongitude, $strSiteURL, $strGoogleAnalyticsID, $strSkypeID, $blnAllowAllView, $blnAllowJoin, $blnAllowJoinAsLevel3, $idProjectUserViewScope, $idProjectUserEditScope) {
		$query = "
			UPDATE project
			SET
				strAlias				= '" . $strAlias . "',
				strName					= '" . $strName . "',
				txtDescription			= '" . $txtDescription . "',
				strAddress				= '" . $strAddress . "',
				dblLatitude				= '" . $dblLatitude . "',
				dblLongitude			= '" . $dblLongitude . "',
				strSiteURL				= '" . $strSiteURL . "',
				strGoogleAnalyticsID	= '" . $strGoogleAnalyticsID . "',
				strSkypeID				= '" . $strSkypeID . "',
				blnAllowAllView			= '" . $blnAllowAllView . "',
				blnAllowJoin			= '" . $blnAllowJoin . "',
				blnAllowJoinAsLevel3	= '" . $blnAllowJoinAsLevel3 . "',
				idProjectUserViewScope	= '" . $idProjectUserViewScope . "',
				idProjectUserEditScope	= '" . $idProjectUserEditScope . "'
			WHERE
				idProject	=	" . $idProject;
		$result = $this->database->executeQuery($query);
		return true;
	}

	public function updateProjectInstall($idProject, $strAlias, $strName) {
		$query = "
			UPDATE project
			SET
				strAlias				= '" . $strAlias . "',
				strName					= '" . $strName . "'
			WHERE
				idProject	=	" . $idProject;
		$result = $this->database->executeQuery($query);
		return true;
	}

	public function updateProperty($idProject, $strField, $strValue) {
		$query = "UPDATE project SET " . $strField . " = '" . $strValue . "' WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		return true;
	}
	
	public function updateFile($idProject, $strFileName, $strField, $blnFullFilePassed = false) {
		$chrType = strtoupper($chrType);
		// Deleting current file
		$arrProject = $this->selectProjects($idProject);
		$strFileDelete = $arrProject[0][$strField . 'FullPath'];
		
		if (strpos($strFileDelete,'img/') === false) {
			@unlink($strFileDelete);
		}
		// Now moving file and updating table
		$strSourceFileFullPathName = $this->strings->strSiteTmpFileFolder . '/' . $strFileName;
		if ($blnFullFilePassed) $strSourceFileFullPathName = $strFileName;
		if (strpos($strFileName,'mg/backgrounds') > 0) {
			$strSourceFileFullPathName = $strFileName;
			$strSourceFileFullPathName = str_replace('', '', $strFileName);
		}
	    $strFileExt = explode(".", $strFileName);
	    $strFileExt = strtolower(array_pop($strFileExt));
		$strDestinationFileName =  '00' . $this->strings->generateRandomString(2) . '.' . $strFileExt;
		$strDestinationFileFullPathName = $this->strings->strProjectFolder . '/' . $idProject . '/' . $strDestinationFileName;
		if (! $strFileName) {
			$strDestinationFileName = '';
			$strDestinationFileFullPathName = '';
		}
		$query = "UPDATE project SET " . $strField . " = '" . $strDestinationFileName . "' WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		if ($strFileName) {
			copy($strSourceFileFullPathName, $strDestinationFileFullPathName);
		}
		$arrResult = array();
		$arrResult['strFilePath'] = $strDestinationFileFullPathName;
		return $arrResult;
	}

	public function deleteProject($idProject) {
		$query = "DELETE userprojectworkgroup FROM userprojectworkgroup, projectworkgroup WHERE projectworkgroup.idProjectWorkgroup = projectworkgroup.idProjectWorkgroup AND projectworkgroup.idProject = " . $idProject;
		$this->database->executeQuery($query);
				
		include_once 'user.php';
		$user = new User($this->database);
		$arrUsers = $user->selectUsers($idProject);
		foreach ($arrUsers as $arrUser) {
			$user->deleteUser($arrUser['idUser']);
		}
		
		include_once 'form.php';
		$form = new Form($this->database);
		$arrForms = $form->selectForms($idProject);
		foreach ($arrForms as $arrForm) {
			$form->deleteForm(0, $arrForm['idForm']);
		}
		
		$query = "DELETE FROM marker WHERE idProject = " . $idProject;
		$this->database->executeQuery($query);

		$query = "DELETE FROM projectsearch WHERE idProject = " . $idProject;
		$this->database->executeQuery($query);

		$query = "DELETE FROM projectworkgroup WHERE idProject = " . $idProject;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM project WHERE idProject = " . $idProject;
		$this->database->executeQuery($query);
		
		$strProjectFolder = $this->strings->strProjectFolder . '/' . $idProject . '/' ;
		if (file_exists($strProjectFolder)) {
			$this->strings->sureRemoveDir($strProjectFolder, true);
		}
		
		return $idProject;
	}

	public function intCountProjects() {
		$query = "SELECT COUNT(idProject) as `intNum` FROM project";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['intNum'];
	}
	
	public function intCountUsers($idProject) {
		$query = "SELECT COUNT(u.idUser) as `intNum` FROM user u WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['intNum'];
	}
	
	public function intCountForms($idProject) {
		$query = "SELECT COUNT(f.idForm) as `intNum` FROM form f WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['intNum'];
	}
	
	public function intCountRecords($idProject) {
		$query = "SELECT COUNT(fr.idFormRecord) as `intNum` FROM formrecord fr, form f WHERE fr.idForm = f.idForm AND f.idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['intNum'];
	}
	
	public function selectidProjectByAlias($strAlias) {
		$query = "SELECT idProject FROM project WHERE strAlias='" . $strAlias . "'";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['idProject'];
	}
	
	public function blnCheckAliasExists($strAlias) {
		$arrFolders = $this->strings->returnFolderFoldersList('./');
		if (array_search(strtolower($strAlias), $arrFolders) !== FALSE) {
			return  array(array('int' => 1));
		}
		$query = "SELECT COUNT(idProject) as `int` FROM project WHERE strAlias LIKE '" . $strAlias . "'";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	// Themes
	public function selectThemes($idTheme = 0) {
		$query = "
			SELECT
				ct.idCSSTheme,
				ct.strThemeName
			FROM
				csstheme ct
			" . ($idTheme ? " WHERE ct.idCSSTheme = " . $idTheme : "") . "
			ORDER BY
				ct.strThemeName
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strCSSThemeURL'] = 'css/bootstrap-' . $result[$idLine]['strThemeName'] . '.css';
		}
		return  $result;
	}

	// ProjectUserScopes
	public function selectProjectUserScopes($idProjectUserScope = 0) {
		$query = "
			SELECT
				pus.idProjectUserScope,
				pus.strProjectUserScope
			FROM
				projectuserscope pus
			" . ($idProjectUserScope ? " WHERE pus.idProjectUserScope = " . $idProjectUserScope : "") . "
			ORDER BY
				pus.idProjectUserScope
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strProjectUserScope'] = $_SESSION['strProjectUserScope_' . $result[$idLine]['idProjectUserScope']];
		}
		return $result;
	}	
}
?>