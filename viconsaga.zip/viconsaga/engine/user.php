<?php
class User {
	public $USER_CREATED						= 1;
	public $USER_MAIL_ALREADY_USED				= -1;
	public $USER_DONT_EXISTS					= -2;
	public $USER_COULD_NOT_SEND_MAIL			= -3;
	public $strDefaultIcon						= 'icon-user';
	public $intUserPositionMinDistanceMts		= 20;
	public $intUserPositionSubmitIntervalSecs	= 60;
	public $strUserFilterNoMarkerURL			= 'img/blank.png';

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;

		include_once 'formrecord.php';
		$formrecord = new Formrecord($database);
		$this->formrecord = $formrecord;
		
		include_once 'form.php';
		$form = new Form($database);
		$this->form = $form;
		
		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		session_start();
	}

	public function selectUsers($idProject = 0, $idUser = 0, $strSearch = '', $blnDeleted = 0) {	
		$query =
		"SELECT
			u.idUser,
			u.idProject,
			u.idUserLevel,
			u.blnDeleted,
			u.blnActive,
			u.dtRegister,
			u.strName,
			u.strEmail,
			u.strPassword,
			u.dblLatitude,
			u.dblLongitude,
			u.strProfilePhotoPath,
			u.strSkypeID
		FROM
			user u
		WHERE
			u.blnDeleted = " . $blnDeleted . "
		" . (($idProject > 0) ? " AND u.idProject = " . $idProject : "") . "
		" . (($idUser > 0) ? " AND u.idUser = " . $idUser : "") . "
		" . (is_numeric($strSearch) ? "AND u.idUser = " . $strSearch : "
			AND
			(u.strName		LIKE '%" . $strSearch . "%' OR
			u.strEmail		LIKE '%" . $strSearch . "%' OR
			u.strSkypeID	LIKE '%" . $strSearch . "%')
		") . "
		ORDER BY
			u.dtRegister DESC";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strRegister'] = date('d/m/y', strtotime($result[$idLine]['dtRegister']));
			$result[$idLine]['strDateLastAccess'] = $this->strDateLastAccess($result[$idLine]['idUser']);
			$result[$idLine]['strEmailAbbreviated'] = strpos($result[$idLine]['strEmail'], '@') ? substr($result[$idLine]['strEmail'], 0, strpos($result[$idLine]['strEmail'], '@')) : $result[$idLine]['strEmail'];
			$result[$idLine]['strUserLevel'] = $_SESSION['strUserLevel_' . $result[$idLine]['idUserLevel']];
			$result[$idLine]['intNumRecords'] = $this->formrecord->intCountFormrecords(0, 0, $result[$idLine]['idUser']);
			$arrUserProjectWorkgroups = $this->selectUserProjectWorkgroups($result[$idLine]['idUser']);
			$result[$idLine]['strWorkgroups'] = implode(',', $arrUserProjectWorkgroups['strWorkgroup']);
			$result[$idLine]['idProjectWorkgroups'] = implode(',', $arrUserProjectWorkgroups['idProjectWorkgroup']);
			$result[$idLine]['strSkypeStatus'] = ($result[$idLine]['strSkypeID'] ? $this->strings->strSkypeUserStatus($result[$idLine]['strSkypeID'], 18, false) : '');
		}
		return $result;
	}
	
	public function selectIdUserProjectByMail($idProject, $strEmail) {
		$query = "SELECT idUser FROM user WHERE idProject=" . $idProject . " AND strEmail LIKE '" . $strEmail . "'";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		if (count($result) > 0) return $result[0]['idUser'];
		else return 0;
	}
	
	public function insertUser($idProject, $idUserLevel = 1, $blnActive = 1, $strName, $strEmail, $strPassword, $dblLatitude, $dblLongitude, $strSkypeID, $blnSendNotificationMail = 0, $blnPasswordEncripted = false) {
		$result = array();
		$idUser = $this->selectIdUserProjectByMail($idProject, $strEmail);
		if ($idUser > 0) {
			$result['idUser'] = -1;
			return $result;
		}
		if (! $strPassword) $strPassword = $this->strings->generateRandomString(4);
		$strPasswordEncripted = ($blnPasswordEncripted ? $strPassword : md5($strPassword));
		$query =
		"INSERT INTO user SET
			idProject			= " . $idProject . ",
			dtRegister			= NOW(),
			strName				= '" . $strName . "',
			strSkypeID			= '" . $strSkypeID . "',
			strEmail			= '" . $strEmail . "',
			blnActive 			= " . $blnActive . ",
			idUserLevel 		= " . $idUserLevel . "
			" . ($strPassword ? ", strPassword = '" . $strPasswordEncripted . "'" : "")  . "
			" . ($dblLatitude ? ", dblLatitude = " . $dblLatitude : "")  . "
			" . ($dblLongitude ? ", dblLongitude = " . $dblLongitude : "")
		;
		$resultado = $this->database->executeQuery($query);
		$result['idUser'] = $this->database->getLastInsertedID();
		
		if (($blnSendNotificationMail) && ((strpos($strEmail,'@') > 0))) {
			$arrSessions = array();
			$arrSessions[0]['strTitle'] = $_SESSION['strIndexUserJoinTitle'];
			$arrSessions[0]['strContent'] = $_SESSION['stradmEditProfilePersonalEmail'] . ': ' . $strEmail . '<BR>' . 
											$_SESSION['stradmEditProfilePersonalPassword'] . ': ' . $strPassword;
			$strBody = $this->strings->mailFormatContent(2, $_SESSION['strIndexUserJoinTitle'], $_SESSION['strIndexUserJoinSuccess'], '', $arrSessions, '?idProject=' . $idProject);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strIndexUserJoinTitle']);
			$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $strEmail);
		}
		return $result;
	}
	
	public function updateUser($idUser, $strIdProjectWorkgroups, $idUserLevel, $blnActive, $strName, $strEmail, $strPassword, $dblLatitude = NULL, $dblLongitude = NULL, $strSkypeID, $blnSendNotificationMail = false, $blnPasswordEncripted = false) {
		$this->insertUserProjectWorkgroups($idUser, $strIdProjectWorkgroups);
		$strPasswordNoEncrypt = $strPassword;
		if ($strPassword) {
			$strPassword = ($blnPasswordEncripted ? $strPassword : md5($strPassword));
		}
		$query =
		"UPDATE user SET
			strName				= '" . $strName . "',
			strSkypeID			= '" . $strSkypeID . "',
			strEmail			= '" . $strEmail . "'
			" . ($idUserLevel ? ", idUserLevel = " . $idUserLevel : "")  . "
			" . ($blnActive ? ", blnActive = " . $blnActive : "")  . "
			" . ($strPassword ? ", strPassword = '" . $strPassword . "'" : "")  . "
			" . ($dblLatitude != NULL ? ", dblLatitude = " . $dblLatitude : "")  . "
			" . ($dblLongitude != NULL ? ", dblLongitude = " . $dblLongitude : "")  . "
		WHERE
			idUser = " . $idUser;
		$resultado = $this->database->executeQuery($query);		
		if (($blnSendNotificationMail) && ($strPassword)) {
			$arrUser = $this->selectUsers(0, $idUser);
			$arrUser = $arrUser[0];
			if (strpos($arrUser['strEmail'],'@') > 0) {
				$arrSessions = array();
				$arrSessions[0]['strTitle'] = $_SESSION['stradmManageUsersSendNotificationMailTitle'];
				$arrSessions[0]['strContent'] = $_SESSION['stradmEditProfilePersonalEmail'] . ': ' . $arrUser['strEmail'] . '<BR>' . 
												$_SESSION['stradmEditProfilePersonalPassword'] . ': ' . $strPasswordNoEncrypt;
				$strBody = $this->strings->mailFormatContent(2, $_SESSION['stradmManageUsersSendNotificationMailTitle'], $_SESSION['stradmManageUsersSendNotificationMailTitle'], '', $arrSessions, '?idProject=' . $arrUser['idProject']);
				$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['stradmManageUsersSendNotificationMailTitle']);
				$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $arrUser['strEmail']);
			}
		}
		return true;
	}
	
	public function updateUserLevel($idUser, $idUserLevel) {
		$query = "UPDATE user SET idUserLevel = " . $idUserLevel . " WHERE idUser = " . $idUser;
		$resultado = $this->database->executeQuery($query);		
		return $this->database->getNumAffectedRows();
	}
	
	public function deleteUser($idUser = 0) {
		if (! $idUser) return false;
		
		$query = "DELETE formrecordfieldtext FROM formrecordfield, formrecordfieldtext, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfieldtext.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldnumeric FROM formrecordfield, formrecordfieldnumeric, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfieldnumeric.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldalternative FROM formrecordfield, formrecordfieldalternative, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfieldalternative.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfielddate FROM formrecordfield, formrecordfielddate, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfielddate.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldtime FROM formrecordfield, formrecordfieldtime, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfieldtime.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE formrecordfieldtimeserie FROM formrecordfield, formrecordfieldtimeserie, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formrecordfieldtimeserie.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE formrecordfield FROM formrecordfield, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formfieldalternative FROM formrecordfield, formfieldalternative, formrecord WHERE formrecord.idFormRecord = formrecordfield.idFormRecord AND formrecordfield.idFormRecordField = formfieldalternative.idFormRecordField AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE formrecordvertex FROM formrecordvertex, formrecord WHERE formrecord.idFormRecord = formrecordvertex.idFormRecord AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfile FROM formrecordfile, formrecord WHERE formrecord.idFormRecord = formrecordfile.idFormRecord AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordlog FROM formrecordlog, formrecord WHERE formrecord.idFormRecord = formrecordlog.idFormRecord AND formrecord.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM formrecord WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE userimageoverlayclause FROM userimageoverlayclause, userimageoverlay WHERE userimageoverlay.idUserFilter = userimageoverlayclause.idUserFilter AND userimageoverlay.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE useralertclause FROM useralertclause, useralert WHERE useralert.idUserAlert = useralertclause.idUserAlert AND useralert.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM userimageoverlay WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE userprojectworkgroup FROM userprojectworkgroup, projectworkgroup WHERE projectworkgroup.idProjectWorkgroup = projectworkgroup.idProjectWorkgroup AND projectworkgroup.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE supportresponse FROM supportresponse, support WHERE support.idSupport = supportresponse.idSupport AND support.idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE FROM support WHERE support.idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM toponymy WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);

		$query = "DELETE FROM userposition WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM userapisession WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM event WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		
		$query = "DELETE FROM user WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);

		return $this->database->getNumAffectedRows();
	}
	
	public function updateProperty($idUser, $strField, $strValue) {
		$query = "UPDATE user SET " . $strField . " = '" . $strValue . "' WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		return true;
	}
	
	public function updateUserActive($idUser, $blnActive, $blnSendNotificationMail = false) {
		$query = "UPDATE user SET blnActive = " . $blnActive . " WHERE idUser = " . $idUser;
		$result = $this->database->executeQuery($query);
		if ($blnSendNotificationMail) {
			$arrSessions = array();
			$arrUser = $this->selectUsers(0, $idUser);
			$arrSessions[0]['strTitle'] = $_SESSION['stradmManageUsersEmailTitle'];
			$arrSessions[0]['strContent'] = $_SESSION['strGlobalStatus'] . ": " . ($blnActive > 0 ? $_SESSION['stradmManageUsersActiveHint'] : $_SESSION['stradmManageUsersBlockedHint']);
			$strBody = $this->strings->mailFormatContent(2, '', '', '', $arrSessions, '?idProject=' . $arrUser[0]['idProject']);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . ($blnActive > 0 ? $_SESSION['stradmManageUsersActiveHint'] : $_SESSION['stradmManageUsersBlockedHint']));
			$strFrom = $this->strings->strSiteEmail;
			$strTo = $arrUser[0]['strEmail'];
			$this->strings->sendMail($strSubject, $strBody, $strFrom, $strTo);
		}
		return true;
	}

	public function login($idProject, $strEmail, $strPassword) {
		if (($strEmail == $this->strings->strSiteDefaultAdminEmail) && ($strPassword == md5($this->database->admPassword))) {
			$query = "
				SELECT
					idUser, idUserLevel
				FROM
					user
				WHERE
					idProject = " . $idProject . " AND 
					idUserLevel = 4
				ORDER BY 
					dtRegister
				LIMIT 1
			";
		} else {
			$query = "
				SELECT
					idUser, idUserLevel
				FROM
					user
				WHERE
					idProject = " . $idProject . " AND 
					strEmail = '" . $strEmail . "' AND 
					strPassword = '" . $strPassword . "'
			";
		}
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		if (count($result) > 0) {
			$_SESSION['idUser'] = $result[0]['idUser'];
			$_SESSION['idLevel'] = $result[0]['idUserLevel'];
			$_SESSION['idProject'] = $idProject;
			// Event Log: User Login
			$this->database->insertEvent(1, $result[0]['idUser']);
			return 1;
		} else {
			$this->logout();
			return 0;
		}
	}

	public function logout() {
		// Event Log: User Logout
		$this->database->insertEvent(2, $_SESSION['idUser']);
		$_SESSION['idUser'] = -1;
		$_SESSION['idLevel'] = -1;
		$_SESSION['blnAdmin'] = -1;
	}

	public function forgotPassword($idProject = 0, $strEmail) {
		$query = "SELECT idUser FROM user WHERE strEmail='" . $strEmail . "'" . ($idProject > 0 ? " AND idProject=" . $idProject : "");
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$idUser = $result[0]['idUser'];

		if (! $idUser > 0) {
			return $this->USER_DONT_EXISTS;
		}
		if (! $_SESSION['strLoginPasswordReminderTitle']) {
			$_SESSION['strLoginPasswordReminderTitle'] = 'PASSWORD RESET';
			$_SESSION['strGlobalPassword'] = 'Password';
		}
		// Verifying if user exists
		$arrUser = $this->selectUsers(0, $idUser);
		// Generating new random password
		$strNewPassword = $this->strings->generateRandomString(4);
		// Formating e-mail
		$arrSessions = array();
		$arrSessions[0]['strTitle'] = $_SESSION['strLoginPasswordReminderTitle'];
		$arrSessions[0]['strContent'] = $_SESSION['strGlobalPassword'] . ': ' . $strNewPassword;
		$strBody = $this->strings->mailFormatContent(2, '', '', '', $arrSessions, '?idProject=' . $arrUser[0]['idProject'] . '&strEmail=' . $arrUser[0]['strEmail'] . '&strSession=' . $arrUser[0]['strPassword'] . '&s=admProfile');
		$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strLoginPasswordReminderTitle']);
		$strFrom = $this->strings->strSiteEmail;
		$strTo = $arrUser[0]['strEmail'];
		if ($this->strings->sendMail($strSubject, $strBody, $strFrom, $strTo)) {
			// Updating user table with new password
			$query = "UPDATE user SET strPassword = '" . md5($strNewPassword) . "' WHERE idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			// Success - New password sent to user
			return 1;
		} else {
			// Couldn't send email
			return $this->USER_COULD_NOT_SEND_MAIL;
		}
	}
	
	public function intCountUsers($idProject) {
		$query = "SELECT COUNT(idUser) as `intNum` FROM user WHERE idProject = " . $idProject;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}
	
	public function strDateLastAccess($idUser) {
		$query = "SELECT dtDateTime FROM event WHERE idEventType=1 AND idUser = " . $idUser . " ORDER BY dtDateTime DESC LIMIT 2";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		if (count($result) <= 1) {
			return '-';
		} else {
			return date('d/m/y H:i', strtotime($result[1]['dtDateTime']));
		}
	}

	public function selectUserLevels($idUserLevel = 0) {
		$query = "SELECT ul.idUserLevel, ul.strLevel FROM userlevel ul " . ($idUserLevel > 0 ? " WHERE ul.idUserLevel = " . $idUserLevel : "") . " ORDER BY 1";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strLevel'] = $_SESSION['strUserLevel_' . $result[$idLine]['idUserLevel']];			
		}
		return $result;
	}
	
	// UserPosition
	public function selectUserPositions($idProject = 0, $idUser = 0, $dtDate = '', $intMinDistanceMts = 200, $dtFromDate = '', $intLimit = 20) {
		if ((! $idProject) && (! $idUser)) { return array(); }
		$query =
		"SELECT
			up.idUserPosition,
			up.idUser,
			up.dtDate,
			up.dblLatitude,
			up.dblLongitude,
			u.strEmail
		FROM
			userposition	up,
			user			u,
			project 		p
		WHERE
			up.idUser = u.idUser AND
			u.idProject = p.idProject
		" . (($idProject > 0) ? " AND p.idProject = " . $idProject : "") . "
		" . (($idUser > 0) ? " AND up.idUser = " . $idUser : "") . "
		" . (($dtDate) ? " AND up.dtDate LIKE '" . $dtDate . "%'" : "") . "
		" . (($dtFromDate) ? " AND up.dtDate >= '" . $dtFromDate . "'": "") . "
		ORDER BY
			up.idUser, up.dtDate ";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		foreach ($result as $idLine => $item) {
			if ($idUser != $result[$idLine]['idUser']) {
				$idUser = $result[$idLine]['idUser'];
				$i = 0;
			}
			$i++;
			if ($i > $intLimit) continue;
			$this->gPoint->setLongLat($result[$idLine]['dblLongitude'], $result[$idLine]['dblLatitude']);
			$dblDistance = $this->gPoint->distanceFrom($result[$idLine+1]['dblLongitude'], $result[$idLine+1]['dblLatitude']);
			// Excluding point too close in order to promote a cleaner view
			if (($i < 2) || ($dblDistance > $intMinDistanceMts)) {
				$result[$idLine]['strDate'] = date('d/m/y H:i', strtotime($result[$idLine]['dtDate']));
				$result[$idLine]['strEmailAbbreviated'] = strpos($result[$idLine]['strEmail'], '@') ? substr($result[$idLine]['strEmail'], 0, strpos($result[$idLine]['strEmail'], '@')) : $result[$idLine]['strEmail'];
				$arrResult[] = $result[$idLine];
			}
		}
		return $arrResult;
	}
	
	public function insertUserPosition($idUser, $dblLatitude, $dblLongitude, $dtDate = '') {
		if (! $idUser) return false;
		$query = "
		INSERT INTO 
			userposition
		SET
			idUser			= " . $idUser . ",
			dblLatitude		= '" . $dblLatitude . "',
			dblLongitude	= '" . $dblLongitude . "',
			dtDate			= " . ($dtDate ? "'" . $dtDate . "'" : "NOW()") . "
		";
		$this->database->executeQuery($query);
		return $this->database->getLastInsertedID();
	}
	
	public function deleteUserPositions($idUser = 0, $dtDate = '') {
		if (! $idUser) { return array(); }
		$query = "DELETE FROM userposition WHERE idUser = " . $idUser . " AND dtDate LIKE '" . $dtDate . "%'";
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function intCountUserPosition($idProject = 0, $idUser = 0) {
		if ($idProject > 0) {
			$query = "SELECT COUNT(up.idUserPosition) as `intNum` FROM userposition up, user u WHERE up.idUser = u.idUser AND u.idProject = " . $idProject;
		} else if ($idUser > 0) {
			$query = "SELECT COUNT(idUserPosition) as `intNum` FROM userposition WHERE idUser = " . $idUser;
		} else  {
			return 0;
		}
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}

	public function selectUserPositionsDates($idUser) {
		$query = "
		SELECT
			up.dtDate
		FROM
			userposition	up
		WHERE
			up.idUser = " . $idUser. "
		GROUP BY
			YEAR(up.dtDate), MONTH(up.dtDate), DAY(up.dtDate)
		ORDER BY
			up.dtDate DESC
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDate'] = date('d/m/y', strtotime($result[$idLine]['dtDate']));
			$result[$idLine]['strDateMySQL'] = date('Y-m-d', strtotime($result[$idLine]['dtDate']));
		}
		return $result;
	}

	public function mobileLogin($strEmail, $strPassword, $idProject = 0) {
		$query =
		"SELECT
			u.idUser,
			u.strName,
			u.strEmail,
			u.blnActive,
			u.strPassword,
			u.dblLatitude,
			u.dblLongitude,
			p.idProject,
			p.strName as strProjectName
		FROM
			user u,
			project p
		WHERE
			p.idProject = u.idProject AND
			" . ($idProject > 0 ? " u.idProject = " . $idProject . " AND " : "") . "
			u.strEmail		= '" . $strEmail . "' AND
			u.strPassword	= '" . $strPassword . "'"
		;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	public function selectUserProjects($idUser) {
		$query = 
		"SELECT 
			u.idUserLevel,
			p.idProject,  
			p.strName,
			p.strAlias
		FROM 
			project p,
			user u
		WHERE
			u.idProject = p.idProject AND
		";
		// Select projects matching with email AND password
		//$query .= " u.idUser = " . $idUser;
		// Select projects matching with email
		$query .= " u.strEmail = (SELECT u.strEmail FROM user u WHERE u.idUser= " . $idUser . ")";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		require_once 'project.php';
		$project = new Project($this->database);
		foreach ($result as $item) {
			$arrResult[] = $project->selectProjects($item['idProject']);
		}
		return $arrResult;
	}
	
	// ProjectWorkgroup
	public function selectProjectWorkgroups($idProject) {
		$query = "
			SELECT
				pw.idProjectWorkgroup,
				pw.strWorkgroup
			FROM
				projectworkgroup pw
			WHERE
				pw.idProject = " . $idProject . "
			ORDER BY
				pw.idProjectWorkgroup
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrWorkgroups = array();
		$arrWorkgroups[0]['idProjectWorkgroup'] = 0;
		$arrWorkgroups[0]['strWorkgroup'] = $_SESSION['strProjectWorkgroup_0'];
		$i=1;
		foreach ($result as $idLine => $item) {
			$arrWorkgroups[$i]['idProjectWorkgroup'] = $item['idProjectWorkgroup'];
			$arrWorkgroups[$i]['strWorkgroup'] = $item['strWorkgroup'];
			$i++;
		}
		return $arrWorkgroups;
	}
	
	public function insertProjectWorkgroup($idProject, $strWorkgroup) {
		$query =
		"INSERT INTO projectworkgroup SET
			idProject			= " . $idProject . ",
			strWorkgroup		= '" . $strWorkgroup . "'"
		;
		$resultado = $this->database->executeQuery($query);
		$result = array();
		$result['idProjectWorkgroup'] = $this->database->getLastInsertedID();
		return $result;
	}
	
	public function updateProjectWorkgroup($idProjectWorkgroup, $strWorkgroup) {
		$query =
		"UPDATE projectworkgroup SET
			strWorkgroup		= '" . $strWorkgroup . "'
		WHERE
			idProjectWorkgroup	=	" . $idProjectWorkgroup;
		$resultado = $this->database->executeQuery($query);
		return true;
	}
	
	public function deleteProjectWorkgroup($idProject = 0, $idProjectWorkgroup = 0) {
		if ($idProject > 0) {
			$query = "DELETE userprojectworkgroup FROM userprojectworkgroup upw, projectworkgroup pw WHERE upw.idProjectWorkgroup = pw.idProjectWorkgroup AND  pw.idProject = " . $idProjectWorkgroup;
			$resultado = $this->database->executeQuery($query);
			
			$query = "DELETE FROM projectworkgroup WHERE idProject = " . $idProject;
			$resultado = $this->database->executeQuery($query);		
		}
		if ($idProjectWorkgroup) {
			$query = "DELETE FROM userprojectworkgroup WHERE idProjectWorkgroup = " . $idProjectWorkgroup;
			$resultado = $this->database->executeQuery($query);
			
			$query = "DELETE FROM projectworkgroup WHERE idProjectWorkgroup = " . $idProjectWorkgroup;
			$resultado = $this->database->executeQuery($query);
		}
		return true;
	}
	
	// userprojectworkgroup
	public function selectUserProjectWorkgroups($idUser) {
		$query = "
			SELECT
				upw.idProjectWorkgroup,
				pw.strWorkgroup
			FROM
				userprojectworkgroup	upw,
				projectworkgroup		pw
			WHERE
				upw.idProjectWorkgroup	= pw.idProjectWorkgroup AND
				upw.idUser				= " . $idUser . "
			ORDER BY
				pw.idProjectWorkgroup
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		if (count($result)) {
			$arr = array();
			foreach ($result as $item) {
				$arr['strWorkgroup'][] = $item['strWorkgroup'];
				$arr['idProjectWorkgroup'][] = $item['idProjectWorkgroup'];
			}
			return $arr;
		} else {
			$arrWorkgroups = array();
			$arrWorkgroups['idProjectWorkgroup'][] = 0;
			$arrWorkgroups['strWorkgroup'][] = $_SESSION['strProjectWorkgroup_0'];
			return $arrWorkgroups;
		}
	}
	
	public function insertUserProjectWorkgroups($idUser, $strIdProjectWorkgroups) {
		$query = "DELETE FROM userprojectworkgroup WHERE idUser = " . $idUser;
		$this->database->executeQuery($query);
		$arrIds = explode(',', $strIdProjectWorkgroups);
		foreach ($arrIds as $idProjectWorkgroup) {
			if (! is_numeric($idProjectWorkgroup)) continue;
			$query = "INSERT INTO userprojectworkgroup SET idUser = " . $idUser . ", idProjectWorkgroup = " . $idProjectWorkgroup;
			$this->database->executeQuery($query);
		}
	}
	
	public function arrUserViewScope($arrUser, $idProjectUserViewScope){
		$arrUserViewScope = array();
		if ($arrUser['idUserLevel'] < 4) {
			if ($idProjectUserViewScope == 1) {
				$arrUserViewScope['strFrom'] = '';
				$arrUserViewScope['strWhere'] = ' AND fr.idUser = ' . $arrUser['idUser'];
			} else if ($idProjectUserViewScope == 2) {
				$arrUserProjectWorkgroups = $this->selectUserProjectWorkgroups($arrUser['idUser']);
				if (count($arrUserProjectWorkgroups['idProjectWorkgroup']) > 0) {
					$arrUserViewScope['strFrom'] = ', userprojectworkgroup upw';
					foreach ($arrUserProjectWorkgroups['idProjectWorkgroup'] as $i => $idUserProjectWorkgroup) {
						$arrUserViewScope['strWhere'] .= ($i > 0 ? ' OR ' : '') . 'upw.idProjectWorkgroup = ' . $idUserProjectWorkgroup;
					}
					$arrUserViewScope['strWhere'] = ' AND upw.idUser = fr.idUser AND (' . $arrUserViewScope['strWhere'] . ')';
				}
			}
		}
		return $arrUserViewScope;
	}
	
	// UserFilters
	public function selectUserFilters($idUserFilter = '', $idUser = '') {
		$query =
		"SELECT
			uf.idUserFilter,
			uf.idUser,
			uf.idMarker,
			uf.strName
		FROM
			userfilter	uf
		WHERE 
			" . ($idUserFilter	? "uf.idUserFilter	= " . $idUserFilter : ""). "
			" . ($idUser		? "uf.idUser		= " . $idUser : ""). "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strMarkerFullPath'] = $this->strUserFilterNoMarkerURL;
			if ($result[$idLine]['idMarker']) {
				$arrMarkers = $this->form->selectMarkers($result[$idLine]['idMarker']);
				$result[$idLine]['strMarkerFullPath'] = $arrMarkers[0]['strMarkerFullPath'];
			}
		}
		return $result;
	}
	
	public function insertUserFilter($idUser, $strName) {
		$query = "
		INSERT INTO 
			userfilter
		SET 
			idUser	= " . $idUser . ",
			strName	= '" . $strName . "'";
		$this->database->executeQuery($query);
		$result = array();
		$result['idUserFilter'] = $this->database->getLastInsertedID();
		$result['strName'] = $strName;
		return $result;
	}
	
	public function updateUserFilter($idUserFilter, $strName) {
		$query = "
		UPDATE 
			userfilter
		SET 
			strName	= '" . $strName . "'
		WHERE
			idUserFilter	= " . $idUserFilter;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function updateUserFilterMarker($idUserFilter, $idMarker = 'NULL') {
		$query = "
		UPDATE 
			userfilter
		SET 
			idMarker		= " . $idMarker . "
		WHERE
			idUserFilter	= " . $idUserFilter;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function updateUserFilterSetDefaultMarker($idUserFilter) {
		$arrForms = array();
		$arrUserFilterClauses = $this->selectUserFilterClauses($idUserFilter);
		foreach($arrUserFilterClauses as $arrUserFilterClause) {
			if (array_search($arrUserFilterClause['idForm'], $arrForms) === FALSE) {
				$arrForms[] = $arrUserFilterClause['idForm'];
			}
		}
		foreach ($arrForms as $i => $idForm) {
			$query = "UPDATE formrecord SET strCustomMarkerRGBColor=NULL WHERE idForm=" . $idForm;
			$this->database->executeQuery($query);
		}
		$this->updateUserFilterMarker($idUserFilter);
		return $arrForms;
	}
	
	public function deleteUserFilter($idUserFilter) {
		$this->deleteUserFilterClauses($idUserFilter);
		$query = "DELETE FROM userfilter WHERE idUserFilter = " . $idUserFilter;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function selectUserFilterClauses($idUserFilter) {
		$query =
		"SELECT
			ufc.idUserFilterClause,
			ufc.idUserFilter,
			ufc.idFormField,
			ufc.intOperator,
			ufc.strValue,
			ff.strName AS `strFormField`,
			ff.idFormFieldType,
			ff.idForm,
			f.strName AS `strForm`
		FROM
			userfilterclause	ufc,
			formfield			ff,
			form				f
		WHERE 
			ufc.idFormField		= ff.idFormField AND
			ff.idForm			= f.idForm AND
			ufc.idUserFilter	= " . $idUserFilter;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			if ($item['intOperator'] == 1) {
				$result[$idLine]['strOperator'] = '&equals;';
				$result[$idLine]['chrOperator'] = '=';
			} else if ($item['intOperator'] == 2) {
				$result[$idLine]['strOperator'] = '&gt;';
				$result[$idLine]['chrOperator'] = '>';
			}  else if ($item['intOperator'] == 3) {
				$result[$idLine]['strOperator'] = '&ge;';
				$result[$idLine]['chrOperator'] = '>=';
			} else if ($item['intOperator'] == 4) {
				$result[$idLine]['strOperator'] = '&lt;';
				$result[$idLine]['chrOperator'] = '<';
			}  else if ($item['intOperator'] == 5) {
				$result[$idLine]['strOperator'] = '&le;';
				$result[$idLine]['chrOperator'] = '<=';
			} else if ($item['intOperator'] == 6) {
				$result[$idLine]['strOperator'] = '&ne;';
				$result[$idLine]['chrOperator'] = '<>';
			}
		}
		return $result;
	}
	
	public function insertUserFilterClause($idUserFilter, $idFormField, $intOperador, $strValue) {
		$strValue = str_replace(',', '.', $strValue);
		$query = "
		INSERT INTO 
			userfilterclause
		SET 
			idUserFilter	= " . $idUserFilter . ",
			idFormField		= " . $idFormField . ",
			intOperator		= " . $intOperador . ",
			strValue		= '" . $strValue . "'";
		$this->database->executeQuery($query);
		$result = array();
		$result['idUserFilterClause'] = $this->database->getLastInsertedID();
		return $result;
	}
	
	public function deleteUserFilterClauses($idUserFilter = 0, $idUserFilterClause = 0) {
		if ((! $idUserFilter) && (! $idUserFilterClause)) return false;
		$query = "
			DELETE FROM 
				userfilterclause
			WHERE 
				" . ($idUserFilter > 0 ? " idUserFilter = " . $idUserFilter : "") . "
				" . ($idUserFilterClause > 0 ? " idUserFilterClause = " . $idUserFilterClause : "") . "
		";
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	// UserImageOverlays
	public function selectUserImageOverlays($idUserImageOverlay = '', $idUser = '') {
		$query =
		"SELECT
			uio.idUserImageOverlay,
			uio.idUser,
			uio.dblLatSW,
			uio.dblLongSW,
			uio.dblLatNE,
			uio.dblLongNE,
			uio.strName,
			uio.strFileName,
			u.idProject
		FROM
			userimageoverlay	uio,
			user				u
		WHERE 
			u.idUser = uio.idUser AND
			" . ($idUserImageOverlay	? " uio.idUserImageOverlay	= " . $idUserImageOverlay : ""). "
			" . ($idUser				? " uio.idUser		= " . $idUser : ""). "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strFileNameFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/' . $result[$idLine]['strFileName'];
		}
		return $result;
	}
	
	public function insertUserImageOverlay($idProject, $idUser, $dblLatSW, $dblLongSW, $dblLatNE, $dblLongNE, $strFileName) {
		$ext = explode(".", $strFileName);
		$ext = strtolower(array_pop($ext));
		$strSourceFileFullPath = $this->strings->strSiteTmpFileFolder . '/' . $strFileName;
		$strDestinationFileFullPath = $this->strings->strProjectFolder . '/' . $idProject . '/' . $this->strings->generateRandomString(10) . "." . $ext;
		$strName = strtolower($strFileName);
		if (copy($strSourceFileFullPath, $strDestinationFileFullPath)) {
			$query = "
			INSERT INTO 
				userimageoverlay
			SET 
				idUser		= " . $idUser . ",
				dblLatSW	= '" . $dblLatSW . "',
				dblLongSW	= '" . $dblLongSW . "',
				dblLatNE	= '" . $dblLatNE . "',
				dblLongNE	= '" . $dblLongNE . "',
				strName		= '" .  $strName . "',
				strFileName	= '" .  basename($strDestinationFileFullPath) . "'
			";
			$this->database->executeQuery($query);
			$result = array();
			$result['idUserImageOverlay'] = $this->database->getLastInsertedID();
			$result['strName'] = $strName;
			return $result;
		}
	}
	public function updateUserImageOverlay($idUserImageOverlay, $dblLatSW, $dblLongSW, $dblLatNE, $dblLongNE) {
		$query = "
		UPDATE 
			userimageoverlay
		SET 
			dblLatSW	= '" . $dblLatSW . "',
			dblLongSW	= '" . $dblLongSW . "',
			dblLatNE	= '" . $dblLatNE . "',
			dblLongNE	= '" . $dblLongNE . "'
		WHERE
			idUserImageOverlay	= " . $idUserImageOverlay
		;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function deleteUserImageOverlay($idUserImageOverlay) {
		// Delete Image File
		$arrUserImageOverlay = $this->selectUserImageOverlays($idUserImageOverlay);
		$arrUserImageOverlay = $arrUserImageOverlay[0];
		if (file_exists($arrUserImageOverlay['strFileNameFullPath'])) {
			@unlink($arrUserImageOverlay['strFileNameFullPath']);
		}
		$query = "DELETE FROM userimageoverlay WHERE idUserImageOverlay = " . $idUserImageOverlay;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
}
?>