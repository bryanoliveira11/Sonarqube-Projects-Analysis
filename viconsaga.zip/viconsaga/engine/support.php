<?php
class Support {
	public $strDefaultIcon	= 'icon-question-sign';
	public $intMinutesAllowDelete = 30;

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'user.php';
		$user = new User($this->database);
		$this->user = $user;

		session_start();
	}

	public function selectSupports($idSupport = 0, $strSearch = '') {
		$query =
		"SELECT
			s.idSupport,
			s.idUser,
			s.dtDateTime,
			s.strSubject,
			s.txtMessage,
			s.strFileName,
			u.strName,
			u.idProject,
			p.strName as strProjectName
		FROM
			support	s,
			user	u,
			project p
		WHERE
			u.idUser = s.idUser AND
			p.idProject = u.idProject
			" . (($idSupport > 0) ? " AND s.idSupport = " . $idSupport : "") . "
			" . (is_numeric($strSearch) ? "AND s.idSupport = " . $strSearch : "
			AND (s.strSubject LIKE '%" . $strSearch . "%' OR s.txtMessage LIKE '%" . $strSearch . "%')
		") . "
		ORDER BY
			s.dtDateTime DESC";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateTime'] = date('d/m/y H:i', strtotime($result[$idLine]['dtDateTime']));
			// Attached File
			if ($result[$idLine]['strFileName']) {
				$result[$idLine]['strFileNameFull'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/' . $this->strings->strSupportFolder . '/' . $result[$idLine]['strFileName'];
			}
			// Interactions = Responses
			$result[$idLine]['arrResponses'] = $this->selectSupportResponses($result[$idLine]['idSupport']);
			$result[$idLine]['intInteractions'] = count($result[$idLine]['arrResponses']);
			$result[$idLine]['strDateTimeLastInteraction'] = '-';
			if ($result[$idLine]['intInteractions'] > 0) {
				$result[$idLine]['strDateTimeLastInteraction'] = date('d/m/y H:i', strtotime($result[$idLine]['arrResponses'][0]['dtDateTime']));
			}
			// Check if has unread message for User
			$result[$idLine]['intUserUnreadInteractions'] = $this->intCountUnreadResponses(0, $result[$idLine]['idSupport'], 1);
			// Check if has unread message for Administrator
			$result[$idLine]['intAdminUnreadInteractions'] = $this->intCountUnreadResponses(0, $result[$idLine]['idSupport'], 0);
			// Setting show remove button visibility (just few minutes after available) then no more
			$result[$idLine]['blnShowDelete'] = 1;
			$dtTimeExpiry = strtotime($result[$idLine]['dtDateTime'] . '+ ' . $this->intMinutesAllowDelete . ' minute');
			// Problema com Timezone - est� do brasil no php
			if ($dtTimeExpiry < strtotime(date('Y-m-d H:i:s'))) {
				$result[$idLine]['blnShowDelete'] = 0;
			}
		}
		return $result;
	}

	public function insertSupport($idUser, $strSubject, $txtMessage, $strFileName) {
		$query =
		"INSERT INTO support SET
			idUser			= " . $idUser . ",
			dtDateTime		= NOW(),
			strSubject		= '" . $strSubject . "',
			txtMessage		= '" . $txtMessage . "',
			strFileName		= '" . $strFileName . "'
		";
		$result = $this->database->executeQuery($query);
		// Notification Mail for Support
		$arrUser = $this->user->selectUsers(0, $idUser);
		$arrSessions = array();
		$arrSessions[0]['strTitle'] = $_SESSION['stradmSupportMailSessionTitle'];
		$arrSessions[0]['strContent'] = 
			$_SESSION['strMailSupportClient'] . ': ' . $arrUser[0]['strName'] . '<br>' . 
			$_SESSION['strMailSupportEmail'] . ': ' . $arrUser[0]['strEmail'] . '<br>' . 
			$_SESSION['strMailSupportDate'] . ': ' . date('d/m/Y H:i:s') . '<br>' . 
			$_SESSION['strMailSupportSubject'] . ': ' . $strSubject . '<br>' . 
			$_SESSION['strMailSupportMessage'] . ': ' . $txtMessage . '<br>'
		;
		$strBody = $this->strings->mailFormatContent(2, $_SESSION['strMailSupportOpen'], '', '', $arrSessions, 'install.php');
		$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strMailSupportOpen']);
		$strFrom = $arrUser[0]['strEmail'];
		$strTo = $this->strings->strSiteEmail;
		$this->strings->sendMail($strSubject, $strBody, $strFrom, $strTo);
		return $this->database->getLastInsertedID();
	}

	public function deleteSupport($idSupport, $idUser = 0) {
		if ($idUser > 0) {
			$query = "DELETE supportresponse FROM supportresponse, support WHERE supportresponse.idSupport = support.idSupport AND support.idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			$query = "DELETE FROM support WHERE idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			// Clear Support Folder
			$query = "SELECT idProject FROM user WHERE idUser = " . $idUser;
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			$this->strings->sureRemoveDir($this->strings->strProjectFolder . '/' . $result[0]['idProject'] . '/' . $this->strings->strSupportFolder . '/', false);
			return $this->database->getNumAffectedRows();
		}
		
		// Removing related file (if exists)
		$arrSupport = $this->selectSupports($idSupport);
		@unlink($arrSupport[0]['strFileNameFull']);

		// Finaly removing Support Response
		$query = "DELETE FROM supportresponse WHERE idSupport = " . $idSupport;
		$result = $this->database->executeQuery($query);

		// Finaly removing Support
		$query = "DELETE FROM support WHERE idSupport = " . $idSupport;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}

	public function intCountSupports($idUser = 0) {
		$query = "SELECT COUNT(idSupport) as `intNumSupports` FROM support" . ($idUser ? " WHERE idUser = " . $idUser : "");
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNumSupports'];
	}

	// Support Responses
	public function selectSupportResponses($idSupport) {
		$query =
		"SELECT
			sr.idSupportResponse,
			sr.idSupport,
			sr.dtDateTime,
			sr.txtMessage,
			sr.blnFromSupport
		FROM
			supportresponse sr
		WHERE
			sr.idSupport = " . $idSupport . "
		ORDER BY
			sr.dtDateTime DESC";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateTime'] = date('d/m/y H:i', strtotime($result[$idLine]['dtDateTime']));
		}
		return $result;
	}

	public function insertSupportResponse($idSupport, $txtMessage, $blnFromSupport = 0) {
		$query =
		"INSERT INTO supportresponse SET
			idSupport	= " . $idSupport . ",
			dtDateTime		= NOW(),
			txtMessage		= '" . $txtMessage . "',
			blnFromSupport	= " . ($blnFromSupport ? $blnFromSupport : "0") . "
		";
		$result = $this->database->executeQuery($query);
		// Notification Mail for Support
		$arrSupport = $this->selectSupports($idSupport);
		$arrUser = $this->user->selectUsers($arrSupport[0]['idUser']);
		$arrSessions = array();
		$arrSessions[0]['strTitle'] = $_SESSION['stradmSupportMailSessionTitle'];
		$arrSessions[0]['strContent'] = 
			$_SESSION['strMailSupportClient'] . ': ' . $arrUser[0]['strName'] . '<br>' . 
			$_SESSION['strMailSupportEmail'] . ': ' . $arrUser[0]['strEmail'] . '<br>' . 
			$_SESSION['strMailSupportDate'] . ': ' . date('d/m/Y H:i:s') . '<br>' . 
			$_SESSION['strMailSupportSubject'] . ': ' . $arrSupport[0]['strSubject'] . '<br>' . 
			$_SESSION['strMailSupportMessage'] . ': ' . $txtMessage . 
			($arrSupport[0]['strFileName'] ? '<br>' . $_SESSION['strMailSupportAttachedFile'] . ': <a href="' . $this->strings->strSiteURL . '/' . $arrSupport[0]['strFileNameFull'] . '" target="_blank">' . $_SESSION['strMailSupportAttachedFileOpen'] . ' ' . $arrSupport[0]['strFileName'] . '</a>' : '')
		;
		$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strMailSupportInteraction']);
		if ($blnFromSupport) {
			$strURL = '?idProject=' . $arrUser[0]['idProject'];
			$strFrom = $this->strings->strSiteEmail;
			$strTo = $arrUser[0]['strEmail'];
		} else {
			$strURL = 'site/?s=admUsers';
			$strFrom = $arrUser[0]['strEmail'];
			$strTo = $this->strings->strSiteEmail;
		}
		$strBody = $this->strings->mailFormatContent(2, $_SESSION['strMailSupportInteraction'], '', '', $arrSessions, $strURL);
		$this->strings->sendMail($strSubject, $strBody, $strFrom, $strTo);
		return $this->database->getLastInsertedID();
	}


	public function markSupportResponseRead($idSupport, $blnFromSupport = 0) {
		$query = "UPDATE supportresponse SET blnRead = 1 WHERE idSupport = " . $idSupport . " AND blnFromSupport = " . $blnFromSupport;
		$result = $this->database->executeQuery($query);
		return $this->database->getLastInsertedID();
	}

	public function intCountUnreadResponses($idUser = 0, $idSupport = 0, $blnFromSupport = 0) {
		$query = "SELECT COUNT(sr.idSupport) as `intNumUnread` FROM supportresponse sr, support s WHERE s.idSupport = sr.idSupport " . ($idUser > 0 ? " AND s.idUser = " . $idUser : "") . ($idSupport > 0 ? " AND s.idSupport = " . $idSupport : "") . " AND sr.blnRead = 0 AND blnFromSupport = " . $blnFromSupport;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNumUnread'];
	}
}
?>