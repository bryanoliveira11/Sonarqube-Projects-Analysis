<?php
class Map {
	public $intMapMaxDimension = 5000;
	public $intRS2MaxClasses = 32768;

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'report.php';
		$report = new Report($database);
		$this->report = $report;
		
		include_once 'project.php';
		$project = new Project($database);
		$this->project = $project;

		include_once 'formrecord.php';
		$formrecord = new Formrecord($database);
		$this->formrecord = $formrecord;
		
		include_once 'form.php';
		$form = new Form($database);
		$this->form = $form;

		include_once 'rs2.php';
		$rs2 = new rs2();
		$this->rs2 = $rs2;

		session_start();
	}

	public function generateMap($idProject, $strExtension, $strJSONFormRecords, $intResolution, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $blnFinishingGoogleMaps = true, $blnFinishingLegends = true, $blnFinishingGrid = true, $idFinishingMaskFormRecord = 0, $blnRS2LegendID = true, $intMapPolygonsOpacity = 100, $intBufferRadius = 0, $idBufferForm = 0, $strMapType = '', $strJSONScope = '', $strEmail = '') {
		set_time_limit(600); // Increasing Timeout to Garantee Enough Time
		$arrProject = $this->project->selectProjects($idProject);
		$arrProject = $arrProject[0];
		$arrOutput = array();
		//$strOutputFileName = 'map-' . $idProject . '-' . date('d-m-y-H-i-s');
		$strOutputFileName = $this->strings->removeInvalidChars($this->strings->changeCharAccent($arrProject['strName']));
		$strOutputFileName = str_replace('.', '', $strOutputFileName);
		$strOutputTmpFileName = $this->strings->strSiteTmpFileFolder . '/' . $idProject . '-' . date('d-m-y-H-i-s');		
		$blnAllRecords = ($strJSONFormRecords == 'ALL');
		if ($blnAllRecords) {
			$arrFormRecords = $this->formrecord->selectFormRecords($idProject, 0, 0, 0, $strJSONScope);
			// Getting Records Extent
			$dblLatSW = 90;
			$dblLngSW = 180;
			$dblLatNE = -90;
			$dblLngNE = -180;
			for ($i=count($arrFormRecords)-1;$i>=0;$i--) {
				foreach ($arrFormRecords[$i]['arrVertex'] as $arrVertex) {
					if (($arrVertex['dblLatitude'] == 0) || ($arrVertex['dblLongitude'] == 0)) {
						array_splice($arrFormRecords, $i, 1);
						break;
					}
					if ($arrVertex['dblLatitude']   < $dblLatSW) $dblLatSW = $arrVertex['dblLatitude'];
					if ($arrVertex['dblLongitude']  < $dblLngSW) $dblLngSW = $arrVertex['dblLongitude'];
					if ($arrVertex['dblLatitude']   > $dblLatNE) $dblLatNE = $arrVertex['dblLatitude'];
					if ($arrVertex['dblLongitude']  > $dblLngNE) $dblLngNE = $arrVertex['dblLongitude'];	
				}
			}
		} else {
			$arrFormRecords = json_decode($strJSONFormRecords, true);
		}
		switch ($strExtension) {
		case "SHP":
			// Write to Shapefile
			require_once('shapefile/writer/Shapefile.php');
			// Write to DBF
			require_once "dbf/Column.class.php";
			require_once "dbf/Record.class.php";
			require_once "dbf/Table.class.php";
			require_once "dbf/WritableTable.class.php";
			$arrFields = array(
				array("FID", DBFFIELD_TYPE_NUMERIC, 8, 0),
				array("ShapeType" , DBFFIELD_TYPE_NUMERIC, 3, 0),
				array("Created" , DBFFIELD_TYPE_DATE),
				array("Updated" , DBFFIELD_TYPE_DATE),
				array("Form" , DBFFIELD_TYPE_CHAR, 254),
				array("ID", DBFFIELD_TYPE_CHAR, 30),
				array("Creator" , DBFFIELD_TYPE_CHAR, 50)
			);
			$arrRecordsPoints = array();
			$arrRecordsPolylines = array();
			$arrRecordsPolygons = array();
			for ($i=0; $i<count($arrFormRecords); $i++) {
				if ($arrFormRecords[$i]['idShapeType'] == 1) {
					$arrRecordsPoints[] = $arrFormRecords[$i];
				} else if ($arrFormRecords[$i]['idShapeType'] == 2) {
					$arrRecordsPolylines[] = $arrFormRecords[$i];
				} else if ($arrFormRecords[$i]['idShapeType'] == 3) {
					$arrRecordsPolygons[] = $arrFormRecords[$i];
				}
			}
			
			if (count($arrRecordsPoints)) {
				// Bounding Box
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_points.shp', 'strName' => 'points.shp');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_points.shx', 'strName' => 'points.shx');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_points.dbf', 'strName' => 'points.dbf');
				$arrBBox = $this->getBoundingBox($arrRecordsPoints);
				$shp = new ShapeFile(1, array("xmin" => $arrBBox['dblLngSW'], "ymin" => $arrBBox['dblLatSW'], "xmax" => $arrBBox['dblLngNE'], "ymax" => $arrBBox['dblLatNE']));
				$dbf = XBaseWritableTable::create($strOutputTmpFileName . '_points.dbf', $arrFields);
				for ($i=0; $i<count($arrRecordsPoints); $i++) {
					$this->shpInsertObject($arrRecordsPoints[$i]['idFormRecord'], $shp, $dbf);
				}
				$shp->saveToFile($strOutputTmpFileName . '_points.*');
				$dbf->close();
			}
			
			if (count($arrRecordsPolylines)) {
				// Bounding Box
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polylines.shp', 'strName' => 'polylines.shp');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polylines.shx', 'strName' => 'polylines.shx');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polylines.dbf', 'strName' => 'polylines.dbf');
				$arrBBox = $this->getBoundingBox($arrRecordsPolylines);
				$shp = new ShapeFile(3, array("xmin" => $arrBBox['dblLngSW'], "ymin" => $arrBBox['dblLatSW'], "xmax" => $arrBBox['dblLngNE'], "ymax" => $arrBBox['dblLatNE']));
				$dbf = XBaseWritableTable::create($strOutputTmpFileName . '_polylines.dbf', $arrFields);
				for ($i=0; $i<count($arrRecordsPolylines); $i++) {
					$this->shpInsertObject($arrRecordsPolylines[$i]['idFormRecord'], $shp, $dbf);
				}
				$shp->saveToFile($strOutputTmpFileName . '_polylines.*');
				$dbf->close();
			}
			
			if (count($arrRecordsPolygons)) {
				// Bounding Box
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polygons.shp', 'strName' => 'polygons.shp');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polygons.shx', 'strName' => 'polygons.shx');
				$arrFiles[] = array('strTemp' => $strOutputTmpFileName . '_polygons.dbf', 'strName' => 'polygons.dbf');
				$arrBBox = $this->getBoundingBox($arrRecordsPolygons);
				$shp = new ShapeFile(5, array("xmin" => $arrBBox['dblLngSW'], "ymin" => $arrBBox['dblLatSW'], "xmax" => $arrBBox['dblLngNE'], "ymax" => $arrBBox['dblLatNE']));
				$dbf = XBaseWritableTable::create($strOutputTmpFileName . '_polygons.dbf', $arrFields);
				for ($i=0; $i<count($arrRecordsPolygons); $i++) {
					$this->shpInsertObject($arrRecordsPolygons[$i]['idFormRecord'], $shp, $dbf);
				}
				$shp->saveToFile($strOutputTmpFileName . '_polygons.*');
				$dbf->close();
			}
			
			// Create ZIP File to Compile All
			$arrOutput[0]['strFilePathTMP'] = $strOutputTmpFileName . '.zip';
			$arrOutput[0]['strFilePath'] = $strOutputFileName . '.zip';
			$zip = new ZipArchive();
			$zip->open($arrOutput[0]['strFilePathTMP'], ZIPARCHIVE::CREATE);
			foreach ($arrFiles as $arrFile) {
				$zip->addFile($arrFile['strTemp'],$arrFile['strName']);
			}
			$zip->close();
		break;
		case "KML":
			// Generating KML File
			$arrResult = $this->report->generateReport($idProject, 'KML', $strJSONFormRecords, $blnAllRecords, false, true, 0, 0, $intMapPolygonsOpacity, '', '', '', $strEmail, false);
			$arrOutput[0] = $arrResult;
			// Writing to Excel File
			$arrResult = $this->report->generateReport($idProject, 'XLS', $strJSONFormRecords, $blnAllRecords, false, false, 0, 0, $intMapPolygonsOpacity, '', '', '', $strEmail, false);
			$arrOutput[1] = $arrResult;
		break;
		case "PNG":
			// Print Grid, Classes, Title Text
			$arrOutput[0]['strFilePathTMP'] = $strOutputTmpFileName . '.png';
			$arrOutput[0]['strFilePath'] = $strOutputFileName . '.png';
			$imgPNG = $this->PNGPlotBase($intResolution, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $arrOutput[0]['strFilePathTMP'], $arrFormRecords, false, $blnRS2LegendID, $blnFinishingGoogleMaps);
			// Printing Map Finishing
			$this->PNGPlotFinishing($imgPNG, $arrOutput[0]['strFilePathTMP'], $arrFormRecords, $blnFinishingGoogleMaps, $blnFinishingLegends, $blnFinishingGrid, $idFinishingMaskFormRecord, $intMapPolygonsOpacity, $intBufferRadius, $idBufferForm, $strMapType, $arrProject);
			// File World PNGW (Text)
			$arrOutput[1]['strFilePathTMP'] = $strOutputTmpFileName . '.pngw';
			$arrOutput[1]['strFilePath'] = $strOutputFileName . '.pngw';
			$strFileContent = $imgPNG['arrDimensions']['dblResolution'] . chr(13);
			$strFileContent .= '0.00000000000000' . chr(13); // Rotation X = 0
			$strFileContent .= '0.00000000000000' . chr(13); // Rotation Y = 0
			$strFileContent .= '-' . $imgPNG['arrDimensions']['dblResolution'] . chr(13);
			$strFileContent .= $imgPNG['arrBBox']['dblLngSWUTM'] . chr(13);
			$strFileContent .= $imgPNG['arrBBox']['dblLatNEUTM'] . chr(13);
			$fh = fopen($arrOutput[1]['strFilePathTMP'], 'w');
			fwrite($fh, $strFileContent);
			fclose($fh);
		break;
		
		case "RS2":
			// Mapa RS2
			$arrOutput[0]['strFilePathTMP'] = $strOutputTmpFileName . '.rs2';
			$arrOutput[0]['strFilePath'] = $strOutputFileName . '.rs2';
			$strPNGTmpFileName = $strOutputTmpFileName . '.png';
			$imgPNG = $this->PNGPlotBase($intResolution, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $strPNGTmpFileName, $arrFormRecords, true, $blnRS2LegendID, false);
			// Error generating PNG  - Exit
			if (! file_exists($strPNGTmpFileName)) { break; }
			// If generated base PNG, continue generating RS2...
			$image = imagecreatefrompng($strPNGTmpFileName);
			$this->rs2->create(
				$arrOutput[0]['strFilePathTMP'], 
				strip_tags($arrProject['strName']), 
				'', 
				$imgPNG['arrDimensions']['dblResolution'], 
				round($imgPNG['arrBBox']['dblLatSWUTM']), 
				round($imgPNG['arrBBox']['dblLngSWUTM']), 
				$imgPNG['arrBBox']['intZoneSWUTM'], 
				($imgPNG['arrBBox']['dblLatSW'] < 0 ? 1 : 0), 
				$imgPNG['arrDimensions']['intHeightPixels'], 
				$imgPNG['arrDimensions']['intWidthPixels'], 
				$imgPNG['arrClasses'], 
				$image
			);
			@unlink($strPNGTmpFileName);
		break;
		}
		
		if (strpos($strEmail, '@') !== FALSE) {
			$arrSessions = array();
			$arrSessions[0]['strTitle'] = $_SESSION['strMapTitle'];
			$arrSessions[0]['strContent'] = $_SESSION['strGlobalProject'] . ': ' . $arrProject['strName'] . '<BR>' . $_SESSION['strReportFormat'] . ': ' . $strExtension . '<BR>' . $_SESSION['strReportURL'] . ': ';
			foreach($arrOutput as $item) {
				$strURL = $this->strings->strSiteURL . '/' . $item['strFilePathTMP'];
				$arrSessions[0]['strContent'] .= '<a href="' . $strURL . '" target="_blank">' . $strURL . '</a><br>';
			}
			$strBody = $this->strings->mailFormatContent(2, $_SESSION['strReportTitle'], '<span style="font-weight:bold;color:#FF0000">' . $_SESSION['strReportWarning'] . '</span>', '', $arrSessions);
			$strSubject = $this->strings->strUpperAccents($this->strings->strSiteName . ': ' . $_SESSION['strMapTitle']);
			$this->strings->sendMail($strSubject, $strBody, $this->strings->strSiteEmail, $strEmail);
		}

		return $arrOutput;
	}
	
	public function PNGPlotBase($intResolution, $dblLatSW, $dblLngSW, $dblLatNE, $dblLngNE, $strFileName, $arrFormRecords, $blnRS2 = false, $blnRS2LegendID = true, $blnFinishingGoogleMaps = false) {
		$arrBBox = array();
		$arrBBox['dblLatSW'] = $dblLatSW;
		$arrBBox['dblLngSW'] = $dblLngSW;
		$arrBBox['dblLatNE'] = $dblLatNE;
		$arrBBox['dblLngNE'] = $dblLngNE;
		// Setting BoundingBox in UTM
		$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$this->rs2->gPoint->convertLLtoTM();
		$arrBBox['dblLatSWUTM'] = $this->rs2->gPoint->N();
		$arrBBox['dblLngSWUTM'] = $this->rs2->gPoint->E();
		$arrBBox['intZoneSWUTM'] = $this->rs2->gPoint->Z();
		$this->rs2->gPoint->setLongLat($arrBBox['dblLngNE'], $arrBBox['dblLatNE']);
		$this->rs2->gPoint->convertLLtoTM();
		$arrBBox['dblLatNEUTM'] = $this->rs2->gPoint->N();
		$arrBBox['dblLngNEUTM'] = $this->rs2->gPoint->E();
		$arrBBox['intZoneNEUTM'] = $this->rs2->gPoint->Z();
		// Setting Map Width
		$arrDimensions = array();
		$this->rs2->gPoint->setLongLat($arrBBox['dblLngSW'], $arrBBox['dblLatSW']);
		$arrDimensions['dblWidthMts']	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngNE'], $arrBBox['dblLatSW']));
		$arrDimensions['dblHeightMts'] 	= ceil($this->rs2->gPoint->distanceFrom($arrBBox['dblLngSW'], $arrBBox['dblLatNE']));	
		$blnIsWider = true;
		if ($arrDimensions['dblWidthMts'] < $arrDimensions['dblHeightMts']) $blnIsWider = false;
		//$arrDimensions['dblResolution'] = max($arrDimensions['dblHeightMts'], $arrDimensions['dblWidthMts']) / $this->intMapMaxDimension;
		$arrDimensions['dblResolution'] = $intResolution;
		if (! $blnFinishingGoogleMaps) { // Force to Int >= 1
			$arrDimensions['dblResolution'] = ceil($arrDimensions['dblResolution']);
		}
		$arrDimensions['intWidthPixels'] = round($arrDimensions['dblWidthMts'] / $arrDimensions['dblResolution']);
		$arrDimensions['intHeightPixels'] 	= round($arrDimensions['dblHeightMts'] / $arrDimensions['dblResolution']);	
		$arrBBox['intWidthPixels'] = $arrDimensions['intWidthPixels'];
		$arrBBox['intHeightPixels'] = $arrDimensions['intHeightPixels'];
		// Reorder Array to Plot First Polygons then Points and Avoid Overlpaping Hidden Problems
		$arrAux = array();
		for ($i=0; $i<count($arrFormRecords); $i++) {
			if ($arrFormRecords[$i]['idShapeType'] != 1) {
				$arrAux[] = $arrFormRecords[$i];
			}
		}
		for ($i=0; $i<count($arrFormRecords); $i++) {
			if ($arrFormRecords[$i]['idShapeType'] == 1) {
				$arrAux[] = $arrFormRecords[$i];
			}
		}
		$arrFormRecords = $arrAux;
		$arrResult = array();
		$arrResult['arrBBox'] = $arrBBox;
		$arrResult['arrDimensions'] = $arrDimensions;
		// if Plot Map With Google Maps Finishing don't plot base image
		if ($blnFinishingGoogleMaps) {
			return $arrResult;
		}
		// Creating Image and Ploting
		$image = imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
		$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
		$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
		$imgColorFill = $imgWhite;
		// If is RS2, background color has to be Black
		if ($blnRS2) { 
			$imgColorFill = $imgBlack;
		}
		imagefilledrectangle($image, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgColorFill);
		$arrClasses = array();
		$j=0;
		foreach ($arrFormRecords as $arrFormRecord) {
			$arrVertexs = $this->formrecord->selectFormRecordVertexs($arrFormRecord['idFormRecord']);
			$strRGB = $this->strings->strColorConvertDecToRGB($j+1); 
			$imgColor = ImageColorAllocate($image, $strRGB['R'], $strRGB['G'], $strRGB['B']);
			if ($arrFormRecord['idShapeType'] == 1) {
				$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[0]['dblLatitude'], $arrVertexs[0]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
				imagesetpixel($image, $arrXY['X'], $arrXY['Y'], $imgColor);
				//for ($i=0;$i<10;$i++) imagesetpixel($image, $arrXY['X']+$i, $arrXY['Y']+$i, $red);
			} else if ($arrFormRecord['idShapeType'] == 2) {
				/*
				$arrXYs = $this->rs2->convertLatLngToXYPoly($arrVertexs, $arrDimensions['dblResolution'], $arrBBox);
				for ($i = 1;$i<count($arrXYs)-1;$i++) {
					imageline($image, $arrXYs[$i-1]['X'], $arrXYs[$i-1]['Y'], $arrXYs[$i]['X'], $arrXYs[$i]['Y'], $imgColor);
				}
				*/
				for ($i = 0;$i < count($arrVertexs) - 1;$i++) {
					$arrXY1 = $this->rs2->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					$arrXY2 = $this->rs2->convertLatLngToXY($arrVertexs[$i+1]['dblLatitude'], $arrVertexs[$i+1]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					imageline($image, $arrXY1['X'], $arrXY1['Y'], $arrXY2['X'], $arrXY2['Y'], $imgColor);
				}
			} else if ($arrFormRecord['idShapeType'] == 3) {
				$arrPts = array();
				foreach($arrVertexs as $i => $arrVertex) {
					$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					array_push($arrPts, $arrXY['X']);
					array_push($arrPts, $arrXY['Y']);
				}
				imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgColor);
				/*
				$arrPts = array();
				$arrXYs = $this->rs2->convertLatLngToXYPoly($arrVertexs, $arrDimensions['dblResolution'], $arrBBox);
				//$this->strings->log(json_encode($arrXYs), 'tmp/out.txt', true);
				foreach($arrXYs as $arrXY) {
					array_push($arrPts, $arrXY['X']);
					array_push($arrPts, $arrXY['Y']);
				}
				imagefilledpolygon($image, $arrPts, count($arrVertexs), $imgColor);
				*/
			}
			if ($blnRS2LegendID) {
				$arrClasses[$j]['strClass'] = $arrFormRecord['idFormRecord'];
			} else {
				$arrClasses[$j]['strClass'] = $this->formrecord->strGetFirstFieldRecordValue($arrFormRecord['idFormRecord']);
			}
			$arrClasses[$j]['intColor'] = $j+1;
			if ($blnRS2) {
				$strRGB = $this->strings->strGenerateRandonColor();
				if ($arrFormRecord['strCustomMarkerRGBColor']) {
					$strRGB = '#' . $arrFormRecord['strCustomMarkerRGBColor'];
				}
				$arrClasses[$j]['intColor'] = hexdec(substr($strRGB,1,6));
			}
			$j++;
		}
		// Write to File
		imagepng($image, $strFileName);
		$arrResult['arrClasses'] = $arrClasses;
		return $arrResult;
	}

	public function PNGPlotFinishing($imgPNG, $strFileName, $arrFormRecords, $blnFinishingGoogleMaps, $blnFinishingLegends, $blnFinishingGrid, $idFinishingMaskFormRecord, $intMapPolygonsOpacity, $intBufferRadius, $idBufferForm, $strMapType, $arrProject) {
		$arrForms = $this->form->selectForms($arrProject['idProject'], 0, '', 1);
		foreach ($arrFormRecords as $i => $arrFormRecord) {
			$arrVertexs = $this->formrecord->selectFormRecordVertexs($arrFormRecord['idFormRecord']);
			$arrFormRecords[$i]['arrVertexs'] = $arrVertexs;
		}
		$strShotBaseName = $this->strings->generateRandomString(3);
		$arrDimensions = $imgPNG['arrDimensions'];
		$arrBBox = $imgPNG['arrBBox'];
		$blnFinishingGrid = ($blnFinishingGrid) && ($arrBBox['intZoneSWUTM'] == $arrBBox['intZoneNEUTM']);
		$strMapType = $strMapType ? strtolower($strMapType) : strtolower($this->strings->strGoogleMapsDefaultTypeMap);
		$blnHybrid = strpos($strMapType, 'brid') !== FALSE;
		$imageBase = imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
		$imgWhite	= ImageColorAllocate($imageBase, 255, 255, 255);
		$imgBlack	= ImageColorAllocate($imageBase, 0, 0, 0);
		$strFontName = 'fonts/OpenSans-Regular.ttf';
		$intFontSize = min(30, round($arrDimensions['intHeightPixels']*0.018));
		$intFontSize = max(7, $intFontSize);
		$intGridStepMts = 500;
		if ($arrDimensions['dblWidthMts'] > 2000)	{ $intGridStepMts = 1000; }
		if ($arrDimensions['dblWidthMts'] > 10000)	{ $intGridStepMts = 2000; }
		if ($arrDimensions['dblWidthMts'] > 20000)	{ $intGridStepMts = 4000; }
		if ($arrDimensions['dblWidthMts'] > 50000)	{ $intGridStepMts = 5000; }
		if ($arrDimensions['dblWidthMts'] > 100000)	{ $intGridStepMts = 10000; }
		if ($arrDimensions['dblWidthMts'] > 200000)	{ $intGridStepMts = 20000; }
		if ($arrDimensions['dblWidthMts'] > 300000)	{ $intGridStepMts = 30000; }
		if ($arrDimensions['dblWidthMts'] > 500000)	{ $intGridStepMts = 50000; }
		if ($arrDimensions['dblWidthMts'] > 1000000){ $intGridStepMts = 100000; }
		imagefilledrectangle($imageBase, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgWhite);
		// Plot Google Maps Base
		$intMaxShots = 10;
		$intShotSizePixels = 640; 
		if ($blnFinishingGoogleMaps) {
			$intMarginGoogleFooterPixels = 25; // To Hide Footer
			$dblResolution = sqrt(($arrDimensions['dblWidthMts']*$arrDimensions['dblHeightMts'])/($intMaxShots*$intShotSizePixels*$intShotSizePixels));
			$intZoom = $this->intGoogleMapsBestZoom($dblResolution, $arrBBox['dblLatNE']); 
 			$dblGoogleMapsResolution = $this->dblGoogleMapsResolution($intZoom, $arrBBox['dblLatNE']);
			$intStepMts = $dblGoogleMapsResolution*$intShotSizePixels;
			$intGooglePixelsW = ceil($arrDimensions['dblWidthMts']/$dblGoogleMapsResolution) + $intShotSizePixels;
			$intGooglePixelsH = ceil($arrDimensions['dblHeightMts']/$dblGoogleMapsResolution) + $intShotSizePixels;
			$intTotalShots = ceil($intGooglePixelsW/$intShotSizePixels) * ceil($intGooglePixelsH/$intShotSizePixels);
			$imageGoogle = imagecreatetruecolor($intGooglePixelsW, $intGooglePixelsH);
			$imgWhite	= ImageColorAllocate($imageGoogle, 255, 255, 255);
			imagefilledrectangle($imageGoogle, 0, 0, $intGooglePixelsW, $intGooglePixelsH, $imgWhite);
			// Set Center of First Shot
			$dblLatitude = $arrBBox['dblLatNE'];
			$dblLongitude = $arrBBox['dblLngSW'];
			$x = 0;
			$y = 0;
			while($y*($intShotSizePixels-$intMarginGoogleFooterPixels) < $intGooglePixelsH) {
				if ($y > $intMaxShots) break;
				while($x*$intShotSizePixels < $intGooglePixelsW) {
					if ($x > $intMaxShots) break;
					// Quota = 25000 requests/day
					$strStaticGoogleMapsURL = 'http://maps.google.com/maps/api/staticmap?size=' . $intShotSizePixels . 'x' . $intShotSizePixels . '&format=png&zoom=' . $intZoom . '&sensor=false&center=' . $dblLatitude . ',' . $dblLongitude . '&maptype=' . $strMapType . '&key=' . $this->strings->GoogleAPIKey;
					$strStaticGoogleMapsFileFullPath = $this->strings->strSiteTmpFileFolder . '/' .  $strShotBaseName . '-' . $y . 'x' . $x . '.png';
					@copy($strStaticGoogleMapsURL, $strStaticGoogleMapsFileFullPath);
					$imageShot = imagecreatefrompng ($strStaticGoogleMapsFileFullPath);
					list($imgShotSizeW, $imgShotSizeH) = getimagesize($strStaticGoogleMapsFileFullPath);
					imagecopy($imageGoogle, $imageShot, $x*$intShotSizePixels, $y*($intShotSizePixels-$intMarginGoogleFooterPixels), 0, 0, $imgShotSizeW, $imgShotSizeH);
					@unlink($strStaticGoogleMapsFileFullPath);
					$this->rs2->gPoint->setLongLat($dblLongitude, $dblLatitude);
					$this->rs2->gPoint->convertLLtoTM();
					$this->rs2->gPoint->setUTM($this->rs2->gPoint->E() + $intStepMts, $this->rs2->gPoint->N(), $this->rs2->gPoint->Z());
					$this->rs2->gPoint->convertTMtoLL();
					$dblLongitude = $this->rs2->gPoint->Long();
					$x++;
				}
				$x = 0;
				$dblLongitude = $arrBBox['dblLngSW'];
				$this->rs2->gPoint->setLongLat($dblLongitude, $dblLatitude);
				$this->rs2->gPoint->convertLLtoTM();
				$this->rs2->gPoint->setUTM($this->rs2->gPoint->E(), $this->rs2->gPoint->N() - $intStepMts + $intMarginGoogleFooterPixels*$dblGoogleMapsResolution, $this->rs2->gPoint->Z());
				$this->rs2->gPoint->convertTMtoLL();
				$dblLatitude = $this->rs2->gPoint->Lat();
				$y++;

			}
			//imagepng($imageGoogle, 'tmp/1.png');
			// Crop Maps to Image - Paste Resizing
			imagecopyresized($imageBase, $imageGoogle, 0, 0, round($intShotSizePixels/2), round($intShotSizePixels/2), $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], ceil($arrDimensions['dblWidthMts']/$dblGoogleMapsResolution), ceil($arrDimensions['dblHeightMts']/$dblGoogleMapsResolution));
		}		
		// Creating Image and Ploting Overlay Icons
		$j = 0;
		imagesetthickness($imageBase, 2); // Line width = 3 pixels
		$intMapPolygonsOpacity = abs(127 - round($intMapPolygonsOpacity*127/100)); // Transparency - 0..127
		//$imgColorBuffer	= imagecolorallocatealpha($imageBase, 0, 0, 0, 110); // Black with Opacity 70%
		$imgColorBuffer	= imagecolorallocatealpha($imageBase, 0, 0, 0, $intMapPolygonsOpacity);
		foreach ($arrFormRecords as $arrFormRecord) {
			$arrVertexs = $arrFormRecord['arrVertexs'];
			$imgColor		= imagecolorallocatealpha($imageBase, hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],0,2)), hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],2,2)), hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],4,2)), $intMapPolygonsOpacity);
			$imgColorOpaque = ImageColorAllocate($imageBase, hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],0,2)), hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],2,2)), hexdec(substr($arrFormRecord['strCustomMarkerRGBColor'],4,2)));
			if ($arrFormRecord['idShapeType'] == 1) {
				$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[0]['dblLatitude'], $arrVertexs[0]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
				// If Buffer, draw circle
				if (($arrFormRecord['idForm'] == $idBufferForm) && ($intBufferRadius)) {
					imagefilledellipse ($imageBase, $arrXY['X'], $arrXY['Y'], round($intBufferRadius/$dblResolution), round($intBufferRadius/$dblResolution), $imgColorBuffer);
					imageellipse ($imageBase, $arrXY['X'], $arrXY['Y'], round($intBufferRadius/$dblResolution), round($intBufferRadius/$dblResolution), $imgColorOpaque);
				}
				$imgMarker = imagecreatefrompng ($arrFormRecord['strMarkerFullPath']);
				list($imgMarkerSizeW, $imgMarkerSizeH) = getimagesize($arrFormRecord['strMarkerFullPath']);
				$intDestMarkerW = round($arrDimensions['intWidthPixels']*0.01);
				$intDestMarkerH = round($intDestMarkerW * $imgMarkerSizeH/$imgMarkerSizeW);
				imagecopyresized($imageBase, $imgMarker, $arrXY['X'] - round($intDestMarkerW/2), $arrXY['Y'] - round($intDestMarkerH/2), 0, 0, $intDestMarkerW, $intDestMarkerH, $imgMarkerSizeW, $imgMarkerSizeH);

			} else if ($arrFormRecord['idShapeType'] == 2) {
				for ($i = 0;$i < count($arrVertexs) - 1;$i++) {
					$arrXY1 = $this->rs2->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					$arrXY2 = $this->rs2->convertLatLngToXY($arrVertexs[$i+1]['dblLatitude'], $arrVertexs[$i+1]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					imageline($imageBase, $arrXY1['X'], $arrXY1['Y'], $arrXY2['X'], $arrXY2['Y'], $imgColor);
				}
			} else if ($arrFormRecord['idShapeType'] == 3) {
				$arrPts = array();
				foreach($arrVertexs as $i => $arrVertex) {
					$arrXY = $this->rs2->convertLatLngToXY($arrVertexs[$i]['dblLatitude'], $arrVertexs[$i]['dblLongitude'], $arrDimensions['dblResolution'], $arrBBox);
					array_push($arrPts, $arrXY['X']);
					array_push($arrPts, $arrXY['Y']);
				}
				imagefilledpolygon($imageBase, $arrPts, count($arrVertexs), $imgColor);
				imagepolygon($imageBase, $arrPts, count($arrVertexs), $imgColorOpaque);
				// Plot Image Mask
				if ($idFinishingMaskFormRecord == $arrFormRecord['idFormRecord']) {
					imagealphablending($imageBase, true);
					$imageMask = imagecreatetruecolor($arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
					$imgMaskWhite = imagecolorallocate($imageMask, 255, 255, 255);
					$imgMaskBlack = imagecolorallocate($imageMask, 0, 0, 0);
					imagefilledrectangle($imageMask, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'], $imgMaskWhite);
					imagecolortransparent($imageMask, $imgMaskBlack);
					imagefilledpolygon($imageMask, $arrPts, count($arrVertexs), $imgMaskBlack);
				}
			}
			$j++;
		}		
		if ($idFinishingMaskFormRecord > 0) {
			imagecopymerge($imageBase, $imageMask, 0, 0, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels'],100);
			imagesavealpha($imageBase, true); 
			imagedestroy($imageMask);
		}
		$image = $imageBase;
		$arrDim = $this->arrTextDimensions('1234567', $intFontSize, $strFontName);
		$intMarginPixelsH = ($blnFinishingGrid ? round($arrDim['h']*1.4) : 0);
		$intMarginPixelsW = ($blnFinishingGrid ? round($arrDim['w']*1.4) : 0);
		if ($blnFinishingGrid) {
			// Draw Image Border
			$image = imagecreatetruecolor($arrDimensions['intWidthPixels'] + $intMarginPixelsW*2, $arrDimensions['intHeightPixels'] + $intMarginPixelsH*2);
			$imgWhite	= ImageColorAllocate($image, 255, 255, 255);
			$imgBlack	= ImageColorAllocate($image, 0, 0, 0);
			imagefilledrectangle($image, 0, 0, $arrDimensions['intWidthPixels'] + $intMarginPixelsW*2, $arrDimensions['intHeightPixels']+ $intMarginPixelsH*2, $imgWhite);
			imagecopy($image, $imageBase, $intMarginPixelsW, $intMarginPixelsH, 0, 0, $arrDimensions['intWidthPixels'], $arrDimensions['intHeightPixels']);
			imagerectangle ($image, $intMarginPixelsW, $intMarginPixelsH, $arrDimensions['intWidthPixels'] + $intMarginPixelsW, $arrDimensions['intHeightPixels'] + $intMarginPixelsH, $imgBlack);
			// Draw Grid Lines
			$arrDim = $this->arrTextDimensions('0', $intFontSize, $strFontName);
			$intMarginTextPixels = round($arrDim['w']*0.25);
			// Vert Lines
			$intModStepMts = $intGridStepMts - (floor($arrBBox['dblLngSWUTM']) % $intGridStepMts);
			$x = round($intModStepMts/$arrDimensions['dblResolution']);
			$i = 0;
			while ($x < $arrDimensions['intWidthPixels']-1) {
				// Coordinates on Top and Bottom
				$strLongitude = number_format(floor($arrBBox['dblLngSWUTM']) + $intModStepMts + $intGridStepMts*$i, 0, '', '.');
				// Top
				$arrDim = $this->arrTextDimensions($strLongitude, $intFontSize, $strFontName);
				$x1 = $intMarginPixelsW + $x - round($arrDim['w']/2);
				imagefttext($image, $intFontSize, 0, $x1, $intMarginPixelsH - $intMarginTextPixels, $imgBlack, $strFontName, $strLongitude);
				// Bottom
				imagefttext($image, $intFontSize, 0, $x1, $arrDimensions['intHeightPixels'] + $intMarginPixelsH + $intFontSize + $intMarginTextPixels, $imgBlack, $strFontName, $strLongitude);
				// Line
				imageline($image, $x + $intMarginPixelsW, $intMarginPixelsH, $x + $intMarginPixelsW, $arrDimensions['intHeightPixels'] + $intMarginPixelsH, $imgBlack);
				$this->rs2->gPoint->setUTM($arrBBox['dblLngSWUTM'] + $x*$arrDimensions['dblResolution'] + $intGridStepMts, $arrBBox['dblLatNEUTM'], $arrBBox['intZoneSWUTM']);
				$this->rs2->gPoint->convertTMtoLL();
				$arrXY	= $this->rs2->convertLatLngToXY($this->rs2->gPoint->Lat(), $this->rs2->gPoint->Long(), $arrDimensions['dblResolution'], $arrBBox);
				$x = $arrXY['X'];
				$i++;
			}
			// Horiz Lines
			$intModStepMts = $intGridStepMts - (floor($arrBBox['dblLatNEUTM']) % $intGridStepMts);
			$y = round($intModStepMts/$arrDimensions['dblResolution']);
			$i = 0;
			while ($y < $arrDimensions['intHeightPixels']-1) {
				$strLatitude = number_format(floor($arrBBox['dblLatNEUTM']) + $intModStepMts - $intGridStepMts*$i, 0, '', '.');
				$y1 = $y + $intMarginPixelsH + round($arrDim['h']/2);
				// Left
				imagefttext($image, $intFontSize, 0, $intMarginPixelsW - round($intFontSize*0.9*strlen($strLongitude)) - $intMarginTextPixels, $y1, $imgBlack, $strFontName, $strLatitude);
				// Right
				imagefttext($image, $intFontSize, 0, $arrDimensions['intWidthPixels'] + $intMarginPixelsW + $intMarginTextPixels, $y1, $imgBlack, $strFontName, $strLatitude);
				// Line
				imageline($image, $intMarginPixelsW, $y + $intMarginPixelsH, $arrDimensions['intWidthPixels'] + $intMarginPixelsW, $y + $intMarginPixelsH, $imgBlack);
				$this->rs2->gPoint->setUTM($arrBBox['dblLngSWUTM'], $arrBBox['dblLatNEUTM'] - $y*$arrDimensions['dblResolution'] - $intGridStepMts, $arrBBox['intZoneSWUTM']);
				$this->rs2->gPoint->convertTMtoLL();
				$arrXY	= $this->rs2->convertLatLngToXY($this->rs2->gPoint->Lat(), $this->rs2->gPoint->Long(), $arrDimensions['dblResolution'], $arrBBox);
				$y = $arrXY['Y'];
				$i++;
			}
		}
		
		if ($blnFinishingLegends) {
			// Draw Legends
			$intMarkerSize = round($arrDimensions['intWidthPixels']*0.015);
			$intMarkerMargin = round($intMarkerSize*0.2);
			$intLegendBoxMargin = $intMarkerMargin;
			$intWidthPixels = 2000;
			$intHeightPixels = 2000;
			$intHeightPixelsFinal = $intLegendBoxMargin;
			$imageLegends = imagecreatetruecolor($intWidthPixels, $intHeightPixels);
			$clGray = ImageColorAllocate($imageLegends, 100, 100, 100);
			$clBlack = ImageColorAllocate($imageLegends, 0, 0, 0);
			$clLegendBackground = imagecolorallocatealpha($imageLegends, 233, 233, 233, 5);
			imagefilledrectangle(
				$imageLegends, 
				0, 
				0, 
				$intWidthPixels, 
				$intHeightPixels, 
				$clLegendBackground
			);
			// Project and Vicon Logo/Name
			$imgLogo = imagecreatefrompng ($arrProject['strLogoFileFullPath']);
			list($imgLogoW, $imgLogoH) = getimagesize($arrProject['strLogoFileFullPath']);
			$intWidthPixelsFinal = 0;
			// Project Logo
			imagecopyresized($imageLegends, $imgLogo, $intLegendBoxMargin, $intLegendBoxMargin, 0, 0, $intMarkerSize, $intMarkerSize, $imgLogoW, $imgLogoH);
			// Project Name
			$arrProjectName = explode(' ', $arrProject['strName']);
			$strProjectName = $arrProjectName[0];
			$arrDim = $this->arrTextDimensions($strProjectName, $intFontSize, $strFontName);
			imagefttext($imageLegends, $intFontSize, 0, $intLegendBoxMargin + $intMarkerSize + round($arrDim['h']/2), $intLegendBoxMargin + round(($intMarkerSize + $arrDim['h'])/2), $imgBlack, $strFontName, $strProjectName);
			$intHeightPixelsFinal = $intHeightPixelsFinal + $intLegendBoxMargin + $intMarkerSize;
			// Horiz Line
			$intClassesBaseY = $intHeightPixelsFinal;
			imageline($imageLegends, 0, $intClassesBaseY, $intWidthPixels, $intClassesBaseY, $imgBlack);
			$y=0;
			foreach ($arrForms as $i => $arrForm) {
				$intFormRecords = $this->intCountFormRecords($arrForm['idForm'], $arrFormRecords);
				if ($intFormRecords == 0) continue;
				$imgMarker = imagecreatefrompng ($arrForm['strMarkerFullPath']);
				list($imgMarkerW, $imgMarkerH) = getimagesize($arrForm['strMarkerFullPath']);
				$y1 = $intClassesBaseY + round($y*$intMarkerSize);
				imagecopyresized($imageLegends, $imgMarker, $intLegendBoxMargin, $y1, 0, 0, $intMarkerSize, $intMarkerSize, $imgMarkerW, $imgMarkerH);
				$strLegend = $arrForm['strName'] . ($idFinishingMaskFormRecord > 0 ? '' : ' (' . $intFormRecords . ')');
				$arrDim = $this->arrTextDimensions($strLegend, $intFontSize, $strFontName);
				imagefttext($imageLegends, $intFontSize, 0, $intLegendBoxMargin + $intMarkerSize + $intMarkerMargin, $y1 + round($intFontSize/2) + round($intMarkerSize/2), $imgBlack, $strFontName, $strLegend);
				$intHeightPixelsFinal += $intMarkerSize;
				$intWidthPixelsFinal = max($intWidthPixelsFinal, $intMarkerSize + $intMarkerMargin + $arrDim['w']);
				$y++;
			}
			if ($intBufferRadius) {
				$y1 = $intClassesBaseY + round($y*$intMarkerSize);
				imagefilledellipse ($imageLegends, $intLegendBoxMargin + round($intMarkerSize/2), $y1 + round($intMarkerSize/2) , $intMarkerSize, $intMarkerSize, $imgBlack);
				$arrDim = $this->arrTextDimensions($_SESSION['strHomeToolsItemBuffer'], $intFontSize, $strFontName);
				imagefttext($imageLegends, $intFontSize, 0, $intLegendBoxMargin + $intMarkerSize, $y1 + round($intFontSize/2) + round($intMarkerSize/2), $imgBlack, $strFontName, $_SESSION['strHomeToolsItemBuffer']);
				$intHeightPixelsFinal += $intMarkerSize;
				$intWidthPixelsFinal = max($intWidthPixelsFinal, $intMarkerSize + $intMarkerMargin*2 + $arrDim['w']);
			}
			// Horiz Line
			$intHeightPixelsFinal += $intMarkerMargin;
			imageline($imageLegends, 0, $intHeightPixelsFinal, $intWidthPixels, $intHeightPixelsFinal, $imgBlack);
			$intHeightPixelsFinal += $intMarkerMargin + $arrDim['h'];
			// Current Date
			imagefttext($imageLegends, $intFontSize, 0, round($intFontSize/2), $intHeightPixelsFinal, $imgBlack, $strFontName, $_SESSION['strGlobalDate'] . ': ' . date('d/m/Y'));
			$intHeightPixelsFinal += round($intMarkerMargin*0.4) + $arrDim['h'];
			// Datum
			imagefttext($imageLegends, $intFontSize, 0, round($intFontSize/2), $intHeightPixelsFinal, $imgBlack, $strFontName, 'Datum: WGS84');
			$intHeightPixelsFinal += round($intMarkerMargin*0.4) + $arrDim['h'];
			// UTM Zone
			imagefttext($imageLegends, $intFontSize, 0, round($intFontSize/2), $intHeightPixelsFinal, $imgBlack, $strFontName, $_SESSION['strGlobalUTMZone'] . ' (SW): ' . $arrBBox['intZoneSWUTM']);
			$intHeightPixelsFinal += $intLegendBoxMargin;
			$intWidthPixelsFinal += $intLegendBoxMargin*2;
			imagerectangle(
				$imageLegends, 
				0, 
				0, 
				$intWidthPixelsFinal-1, 
				$intHeightPixelsFinal-1,
				$imgBlack
			);
			// Paste into image
			$intLegendBoxMarginTopLeft = round($arrDimensions['intWidthPixels']*0.015);
			imagecopy($image, $imageLegends, $intMarginPixelsW + $intLegendBoxMarginTopLeft, $intMarginPixelsH + $intLegendBoxMarginTopLeft, 0, 0, $intWidthPixelsFinal, $intHeightPixelsFinal);
		}

		// Draw Noth Q
		$imgNorth = imagecreatefrompng ('img/north.png');
		list($imgNorthW, $imgNorthH) = getimagesize('img/north.png');
		$intNothSize = round($arrDimensions['intWidthPixels']*0.025);
		$intMarginNorthScale = $intNothSize*0.4;
		imagecopyresized($image, $imgNorth, $intMarginPixelsW  + $arrDimensions['intWidthPixels'] - $intNothSize - $intMarginNorthScale, $intMarginPixelsH + $intMarginNorthScale, 0, 0, $intNothSize, $intNothSize * $imgNorthH/$imgNorthW, $imgNorthW, $imgNorthH);
		
		// Draw Map Scale
		$intScaleSizeMts = round($intGridStepMts*0.2);
		$intScaleSizePixels = round($intScaleSizeMts/$arrDimensions['dblResolution']);
		$x1 = $intMarginPixelsW  + $arrDimensions['intWidthPixels'] - $intScaleSizePixels - $intMarginNorthScale;
		$x2 = $intMarginPixelsW  + $arrDimensions['intWidthPixels'] - $intMarginNorthScale;
		$y = $intMarginPixelsH  + $arrDimensions['intHeightPixels'] - $intMarginNorthScale*2;
		// ______________
		imageline($image, $x1, $y, $x2, $y, $imgBlack);
		// |
		imageline($image, $x1, $y-round($intFontSize/2), $x1, $y, $imgBlack);
		// |
		imageline($image, $x2, $y-round($intFontSize/2), $x2, $y, $imgBlack);
		// Scale Text
		$strScaleText = $intScaleSizeMts . ' m';
		$xText = $x1; // round(($x1+$x2)/2 - strlen($strScaleText)*$intFontSize/2);
		$dims = imagettfbbox($intFontSize, 0, $strFontName, $strScaleText);
		$intFooterTextMargin = 5;
		$intTextW = $dims[4] - $dims[6];
		imagefttext($image, $intFontSize, 0, $x2 - $intTextW, $y + $intFontSize + round($intFontSize*0.5), $imgBlack, $strFontName, $strScaleText);

		// Draw Vicon and Google Maps Footer WaterMark
		$clGray = ImageColorAllocate($image, 240, 240, 240);
		$x1 = $intMarginPixelsW + 1;
		$y1 = $intMarginPixelsH + $arrDimensions['intHeightPixels'] - 1;
		$strFootText = $_SESSION['strGlobalGeneratedBy'] . ' ' . $this->strings->strSiteName . ($blnFinishingGoogleMaps ? ' | ' . $_SESSION['strGlobalCartographicData'] . ': Google Maps' : '');
		$intFontSizeFooter = round($intFontSize*0.5);
		$dims = imagettfbbox($intFontSizeFooter, 0, $strFontName, $strFootText);
		$intFooterTextMargin = 5;
		$intTextW = $dims[4] - $dims[6] + $intFooterTextMargin*2;
		$intTextH = $dims[3] - $dims[5] + round($intFontSizeFooter/2);
		imagefilledrectangle($image, $x1, $y1 - $intFontSizeFooter - round($intFontSizeFooter/2), $x1 + $intTextW, $y1, $clGray);
		imagefttext($image, $intFontSizeFooter, 0, $x1 + $intFooterTextMargin, $y1 - ($intFontSizeFooter*0.2), $imgBlack, $strFontName, $strFootText);
		// Write to File
		imagepng($image, $strFileName);
		return $imgPNG;
	}
	
	public function intGoogleMapsBestZoom($dblResolution, $dblLatitude) {
		$arrGoogleMapsResolutions = array();
		for ($i=0;$i<=20;$i++) {
			$arrGoogleMapsResolutions[$i] = $this->dblGoogleMapsResolution($i, $dblLatitude);
		}
		//0 (far) to 20 (close) 
		$intZoom = 0;
		$intZoomMax = count($arrGoogleMapsResolutions)-1; 
		for ($i=0;$i<$intZoomMax;$i++) {
			if (($dblResolution < $arrGoogleMapsResolutions[$i]) && ($dblResolution > $arrGoogleMapsResolutions[$i+1])) {
				$intZoom = $i;
			}
		}
		if ($dblResolution < $arrGoogleMapsResolutions[$intZoomMax]) $intZoom = $intZoomMax;
		return $intZoom;
	}
		
	public function dblGoogleMapsResolution($intZoom, $dblLatitude) {
		return 156543.03392*cos($dblLatitude*pi()/180)/pow(2, $intZoom);
	}

	public function intCountFormRecords($idForm, $arrFormRecords) {
		$intFormRecords = 0;
		foreach ($arrFormRecords as $arrFormRecord) {
			if ($arrFormRecord['idForm'] == $idForm) {
				$intFormRecords++;
			}
		}
		return $intFormRecords;
	}
	
	public function getBoundingBox($arrFormRecords) {
		$arrBBox = array();
		$arrBBox['dblLatSW'] = 90;
		$arrBBox['dblLngSW'] = 180;
		$arrBBox['dblLatNE'] = -90;
		$arrBBox['dblLngNE'] = -180;
		foreach ($arrFormRecords as $arrFormRecord) {
			$arrVertexs = $this->formrecord->selectFormRecordVertexs($arrFormRecord['idFormRecord']);
			foreach($arrVertexs as $arrVertex) {
				if ($arrVertex['dblLatitude']   < $arrBBox['dblLatSW']) $arrBBox['dblLatSW'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  < $arrBBox['dblLngSW']) $arrBBox['dblLngSW'] = $arrVertex['dblLongitude'];
				if ($arrVertex['dblLatitude']   > $arrBBox['dblLatNE']) $arrBBox['dblLatNE'] = $arrVertex['dblLatitude'];
				if ($arrVertex['dblLongitude']  > $arrBBox['dblLngNE']) $arrBBox['dblLngNE'] = $arrVertex['dblLongitude'];
			}
		}
		return $arrBBox;
	}
	
	public function shpInsertObject($idFormRecord, &$shp, &$dbf) {
		$arrFormRecord = $this->formrecord->selectFormRecords(0, 0, 0, $idFormRecord);
		$arrFormRecord = $arrFormRecord[0];
		// SHP Record
		$shpRecord = new ShapeRecord(($arrFormRecord['idShapeType'] == 1 ? 1 : ($arrFormRecord['idShapeType'] == 2 ? 3 : 5)));
		foreach($arrFormRecord['arrVertex'] as $arrVertex) {
			$shpRecord->addPoint(array("x" => $arrVertex['dblLongitude'], "y" => $arrVertex['dblLatitude']));
		}
		if ($arrFormRecord['idShapeType'] == 3) {
			$shpRecord->addPoint(array("x" => $arrFormRecord['arrVertex'][0]['dblLongitude'], "y" => $arrFormRecord['arrVertex'][0]['dblLatitude']));
		}
		$intID = $shp->addRecord($shpRecord);
		// DBF Record
		$r =& $dbf->appendRecord();
		$r->setObjectByName("FID", $intID);
		$r->setObjectByName("ShapeType", $arrFormRecord['idShapeType']);
		$r->setObjectByName("Created", strtotime($arrFormRecord['dtCreation']));
		$r->setObjectByName("Updated", strtotime($arrFormRecord['dtLastUpdate']));
		$r->setObjectByName("Form", $arrFormRecord['strFormName']);
		$r->setObjectByName("ID", $idFormRecord);
		$r->setObjectByName("Creator", $arrFormRecord['strEmail']);
		$dbf->writeRecord();
	}
	
	private function arrTextDimensions($strText, $intFontSize, $strFontName) {
	  $arrTextDim = imagettfbbox ($intFontSize, 0, $strFontName, $strText);
	  $intW = abs($arrTextDim[4] - $arrTextDim[0]);
	  $intH = abs($arrTextDim[5] - $arrTextDim[1]);	
	  return array('w' => $intW, 'h' => $intH);
	}
}
?>