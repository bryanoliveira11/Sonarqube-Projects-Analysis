<?php
class Formrecord {
	public $strDefaultIcon			= 'icon-map-marker';
	public $intNeighborsDistanceMts = 200;
	public $intInsidePolygonRate	= 10; // x% inside search polygon to be inserted into the results

	public function __construct($database) {
		$this->database = $database;

		include_once 'strings.php';
		$strings = new Strings();
		$this->strings = $strings;
		
		include_once 'gPoint.php';
		$gPoint = new gPoint($database);
		$this->gPoint = $gPoint;
		
		include_once 'alert.php';
		$alert = new Alert($database);
		$this->alert = $alert;

		session_start();
	}

	public function selectFormRecords($idProject = 0, $idUser = 0, $idForm = 0, $idFormRecord = 0, $strJSONScope = '', $strOrderBy = 'idFormRecord', $intLimit = 0) {
		$arrScope = json_decode($strJSONScope, true);
		$query =
		"SELECT
			fr.idFormRecord,
			fr.idUser,
			fr.idForm,
			fr.idDevice,
			fr.idShapeType,
			fr.strCustomMarkerRGBColor,
			fr.dtCreation,
			fr.dtLastUpdate,
			f.idProject,
			f.strName AS strFormName,
			f.idMarker,
			f.blnActive,
			m.strMarkerFileName,
			m.idProject AS idProjectMarker,
			u.strName,
			u.strEmail
		FROM
			formrecord			fr,
			form				f,
			marker				m,
			user				u
			" . $arrScope['strFrom'] . "
		WHERE 
			fr.idForm		= f.idForm
			AND f.idMarker	= m.idMarker
			AND fr.idUser	= u.idUser
			" . $arrScope['strWhere'] . "
			" . (
				(is_array($idFormRecord) === TRUE) ? " AND fr.idFormRecord IN (" . implode(',', $idFormRecord) . ")" : 
				(($idFormRecord > 0) ? " AND fr.idFormRecord = " . $idFormRecord : "")
			) . "
			" . (($idProject > 0) ? " AND f.idProject = " . $idProject : "") . "
			" . (($idUser > 0) ? " AND fr.idUser = " . $idUser : "") . "
			" . (($idForm > 0) ? " AND fr.idForm = " . $idForm : "") . "
		ORDER BY fr.idForm, fr." . $strOrderBy . "
		" . ($intLimit > 0 ? " LIMIT " . $intLimit : "") . "
		";
		//$fh = fopen("out.txt", 'w');fwrite($fh, $query);fclose($fh);
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strCreation'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtCreation']));
			$result[$idLine]['strLastUpdate'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtLastUpdate']));
			$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $result[$idLine]['strMarkerFileName'];
			if ($result[$idLine]['idProjectMarker'] > 0) {
				$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProjectMarker'] . '/' . $result[$idLine]['strMarkerFileName'];
			}
			$result[$idLine]['strFormMarkerFullPath'] = $result[$idLine]['strMarkerFullPath'];
			$result[$idLine]['strMarkerFullURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strMarkerFullPath'];
			// Custom Marker
			if (($result[$idLine]['idShapeType'] == 1) && ($result[$idLine]['strCustomMarkerRGBColor'])) {
				$result[$idLine]['strMarkerFullPath'] = $result[$idLine]['strCustomMarkerRGBColor'];
				$result[$idLine]['strMarkerFullURL'] = $result[$idLine]['strMarkerFullPath'];
			}
			if ($result[$idLine]['idShapeType'] > 1) {
				$result[$idLine]['strCustomMarkerRGBColor'] = str_replace('#','', $result[$idLine]['strCustomMarkerRGBColor']);
				if ($result[$idLine]['strCustomMarkerRGBColor']) {
					$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $result[$idLine]['strCustomMarkerRGBColor'];
				} else {
					$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $this->strings->strGenerateRandonColor();
				}
			}
			$result[$idLine]['arrVertex'] = $this->selectFormRecordVertexs($result[$idLine]['idFormRecord']);
			$result[$idLine]['arrFiles'] = $this->selectFormRecordFiles($result[$idLine]['idProject'], $result[$idLine]['idFormRecord']);
			$result[$idLine]['strDevice'] = $_SESSION['strDevice_' . $result[$idLine]['idDevice']];
			$result[$idLine]['strDeviceFilePath'] = $this->strings->strDevicesFolder . '/' . $result[$idLine]['idDevice'] . '.png';
			$result[$idLine]['dblLatitude'] = $result[$idLine]['arrVertex'][0]['dblLatitude'];
			$result[$idLine]['dblLongitude'] = $result[$idLine]['arrVertex'][0]['dblLongitude'];
			if ($result[$idLine]['idShapeType'] != 1) {
				$arrCentroid = $this->strings->arrVertexsCentroid($result[$idLine]['arrVertex']);
				$result[$idLine]['dblLatitude'] = $arrCentroid['dblLatitude'];
				$result[$idLine]['dblLongitude'] = $arrCentroid['dblLongitude'];
				$arrPolyDimensions = $this->arrVertexsDimensions($result[$idLine]['arrVertex'], $arrCentroid, $result[$idLine]['idShapeType']);
				$result[$idLine]['dblPerimeterMts'] = $arrPolyDimensions['dblPerimeterMts'];
				$result[$idLine]['dblAreaMts2'] = $arrPolyDimensions['dblAreaMts2'];
			}
			$result[$idLine]['dblDistanceFromCenterMts'] = -1;
			$this->gPoint->setLongLat($result[$idLine]['dblLongitude'], $result[$idLine]['dblLatitude']);
			$this->gPoint->convertLLtoTM();
			$result[$idLine]['dblLatitudeUTM'] = number_format($this->gPoint->N(), 2, $_SESSION['strDecimal'], '');
			$result[$idLine]['dblLongitudeUTM'] = number_format($this->gPoint->E(), 2, $_SESSION['strDecimal'], '');
			$result[$idLine]['intZoneUTM'] = $this->gPoint->Z();
		}
		return $result;
	}

	public function selectFormRecordsTimeline($idProject = 0, $idUser = 0, $strIDForms = '', $strSearch = '', $dblLat = '', $dblLng = '', $strJSONScope = '', $intFrom = 0, $intLimit = 10) {
		// View Scope
		$arrScope = json_decode($strJSONScope, true);
		// Form order
		$strFilterForms = "AND 0 > 1";
		if ($strIDForms == 'ALL') {
			$strFilterForms = "";
		} else if ($strIDForms) {
			$strFilterForms = "";
			$arrIdForms = explode(',', $strIDForms);
			foreach ($arrIdForms as $idForm) {
				if (! is_numeric($idForm)) continue;
				$strFilterForms .= ($strFilterForms ? ' OR ': '') . ' f.idForm = ' . $idForm;
			}
			$strFilterForms = " AND (" . $strFilterForms . ")";
		}
		
		$query =
		"SELECT
			fr.idFormRecord,
			fr.idUser,
			fr.idForm,
			fr.idDevice,
			fr.idShapeType,
			fr.strCustomMarkerRGBColor,
			fr.dtCreation,
			fr.dtLastUpdate,
			f.idProject,
			f.strName AS strFormName,
			f.idMarker,
			f.blnActive,
			m.strMarkerFileName,
			m.idProject AS idProjectMarker,
			u.strName,
			u.strEmail
			" . ($dblLat ? ", SQRT(POWER(ABS(ABS(frv.dblLatitude) - ABS(" . $dblLat . ")), 2) + POWER(ABS(ABS(frv.dblLongitude) - ABS(" . $dblLng . ")), 2)) as dblDistance" : "") . "
		FROM
			formrecord			fr,
			form				f,
			marker				m,
			user				u
			" . ($strSearch ? ", formrecordfield frf, formrecordfieldtext frft" : ""). "
			" . ($dblLat ? ",formrecordvertex	frv" : "") . "
			" . $arrScope['strFrom'] . "
		WHERE 
			fr.idForm		= f.idForm
			AND f.idMarker	= m.idMarker
			AND fr.idUser	= u.idUser
			" . $arrScope['strWhere'] . "
			" . ($dblLat ? " AND frv.idFormRecord	= fr.idFormRecord" : ""). "
			" . (($idFormRecord > 0) ? " AND fr.idFormRecord = " . $idFormRecord : "") . "
			" . (($idProject > 0) ? " AND f.idProject = " . $idProject : "") . "
			" . (($idUser > 0) ? " AND fr.idUser = " . $idUser : "") . "
			" . ($strSearch ? " AND frf.idFormRecord = fr.idFormRecord AND frft.idFormRecordField = frf.idFormRecordField AND (frft.strValue LIKE '%" . utf8_decode($strSearch) . "%' OR fr.idFormRecord LIKE '%" . $strSearch . "%')" : "") . "
			" . $strFilterForms . "
		GROUP BY fr.idFormRecord
		ORDER BY " . ($dblLat ? "dblDistance" : " fr.dtLastUpdate DESC, fr.idFormRecord DESC ") . "
		LIMIT " . $intFrom . ',' . $intLimit . "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strCreation'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtCreation']));
			$result[$idLine]['strLastUpdate'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtLastUpdate']));
			$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $result[$idLine]['strMarkerFileName'];
			if ($result[$idLine]['idProjectMarker'] > 0) {
				$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProjectMarker'] . '/' . $result[$idLine]['strMarkerFileName'];
			}
			$result[$idLine]['strMarkerFullURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strMarkerFullPath'];
			// Custom Marker
			if (($result[$idLine]['idShapeType'] == 1) && ($result[$idLine]['strCustomMarkerRGBColor'])) {
				$result[$idLine]['strMarkerFullPath'] = $result[$idLine]['strCustomMarkerRGBColor'];
				$result[$idLine]['strMarkerFullURL'] = $result[$idLine]['strMarkerFullPath'];
			}
			if (! $result[$idLine]['strCustomMarkerRGBColor']) {
				$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $this->strings->strGenerateRandonColor();
			}
			$result[$idLine]['arrVertex'] = $this->selectFormRecordVertexs($result[$idLine]['idFormRecord']);
			$result[$idLine]['arrFiles'] = $this->selectFormRecordFiles($result[$idLine]['idProject'], $result[$idLine]['idFormRecord']);
			$result[$idLine]['strDevice'] = $_SESSION['strDevice_' . $result[$idLine]['idDevice']];
			$result[$idLine]['strDeviceFilePath'] = $this->strings->strDevicesFolder . '/' . $result[$idLine]['idDevice'] . '.png';
			$result[$idLine]['dblLatitude'] = $result[$idLine]['arrVertex'][0]['dblLatitude'];
			$result[$idLine]['dblLongitude'] = $result[$idLine]['arrVertex'][0]['dblLongitude'];
			if ($result[$idLine]['idShapeType'] != 1) {
				$arrCentroid = $this->strings->arrVertexsCentroid($result[$idLine]['arrVertex']);
				$result[$idLine]['dblLatitude'] = $arrCentroid['dblLatitude'];
				$result[$idLine]['dblLongitude'] = $arrCentroid['dblLongitude'];
				$arrPolyDimensions = $this->arrVertexsDimensions($result[$idLine]['arrVertex'], $arrCentroid, $result[$idLine]['idShapeType']);
				$result[$idLine]['dblPerimeterMts'] = $arrPolyDimensions['dblPerimeterMts'];
				$result[$idLine]['dblAreaMts2'] = $arrPolyDimensions['dblAreaMts2'];
			}
			
			$result[$idLine]['dblDistanceFromCenterMts'] = -1;
			if ($dblLat) {
				$this->gPoint->setLongLat($dblLng, $dblLat);
				$result[$idLine]['dblDistanceFromCenterMts'] = $this->gPoint->distanceFrom($result[$idLine]['dblLongitude'], $result[$idLine]['dblLatitude']);
			}
			$this->gPoint->setLongLat($result[$idLine]['dblLongitude'], $result[$idLine]['dblLatitude']);
			$this->gPoint->convertLLtoTM();
			$result[$idLine]['dblLatitudeUTM'] = number_format($this->gPoint->N(), 2, $_SESSION['strDecimal'], '');
			$result[$idLine]['dblLongitudeUTM'] = number_format($this->gPoint->E(), 2, $_SESSION['strDecimal'], '');
			$result[$idLine]['intZoneUTM'] = $this->gPoint->Z();
		}
		return $result;
	}

	public function selectFormRecordsByUserFilter($idUserFilter, $strModeANDOR, $strJSONScope) {
		$arrScope = json_decode($strJSONScope, true);
		$arrFormRecords = array();
		include_once 'user.php';
		$user = new User($this->database);
		$arrUserFilterClauses = $user->selectUserFilterClauses($idUserFilter);
		if (count($arrUserFilterClauses) == 0) { return $arrFormRecords;}
		$arrResults = array();
		foreach ($arrUserFilterClauses as $i => $arrUserFilterClause) {
			if ($arrUserFilterClause['idFormFieldType'] == 1) {
				$query =
				"SELECT DISTINCT
					fr.idFormRecord
				FROM
					formrecord			fr,
					formrecordfield		frf,
					formrecordfieldtext	frft
					" . $arrScope['strFrom'] . "
				WHERE 
					fr.idFormRecord		= frf.idFormRecord AND
					frf.idFormField		= " . $arrUserFilterClause['idFormField'] . " AND
					frf.idFormRecordField	= frft.idFormRecordField AND
					frft.strValue		LIKE '%" . $arrUserFilterClause['strValue'] . "%'
					" . $arrScope['strWhere'] . "
				";
			} else if ($arrUserFilterClause['idFormFieldType'] == 2) {
				$query =
				"SELECT DISTINCT
					fr.idFormRecord
				FROM
					formrecord				fr,
					formrecordfield			frf,
					formrecordfieldnumeric	frfn
					" . $arrScope['strFrom'] . "
				WHERE 
					fr.idFormRecord			= frf.idFormRecord AND
					frf.idFormField			= " . $arrUserFilterClause['idFormField'] . " AND
					frf.idFormRecordField	= frfn.idFormRecordField AND
					frfn.dblValue	" . $arrUserFilterClause['chrOperator'] . "'" . $arrUserFilterClause['strValue'] . "'
					" . $arrScope['strWhere'] . "
				";
			} else if (($arrUserFilterClause['idFormFieldType'] == 3) || ($arrUserFilterClause['idFormFieldType'] == 4)) {
				$query =
				"SELECT DISTINCT
					fr.idFormRecord
				FROM
					formrecord					fr,
					formrecordfield				frf,
					formrecordfieldalternative	frfa,
					formfieldalternative		ffa
					" . $arrScope['strFrom'] . "
				WHERE 
					fr.idFormRecord				= frf.idFormRecord AND
					frf.idFormField				= " . $arrUserFilterClause['idFormField'] . " AND
					frf.idFormRecordField		= frfa.idFormRecordField AND
					frfa.idFormFieldAlternative	= ffa.idFormFieldAlternative AND
					ffa.strAlternative	" . $arrUserFilterClause['chrOperator'] . "'" . $arrUserFilterClause['strValue'] . "'
					" . $arrScope['strWhere'] . "
				";
			} else if ($arrUserFilterClause['idFormFieldType'] == 5) {
				$strValue = $this->strings->ConvertDateBRToMySQL($arrUserFilterClause['strValue']);
				$query =
				"SELECT DISTINCT
					fr.idFormRecord
				FROM
					formrecord			fr,
					formrecordfield		frf,
					formrecordfielddate	frfd
					" . $arrScope['strFrom'] . "
				WHERE 
					fr.idFormRecord			= frf.idFormRecord AND
					frf.idFormField			= " . $arrUserFilterClause['idFormField'] . " AND
					frf.idFormRecordField	= frfd.idFormRecordField AND
					frfd.dtValue	" . $arrUserFilterClause['chrOperator'] . "'" . $strValue . "'
					" . $arrScope['strWhere'] . "
				";
			} else if ($arrUserFilterClause['idFormFieldType'] == 6) {
				$strValue = $arrUserFilterClause['strValue'] . ':00';
				$query =
				"SELECT DISTINCT
					fr.idFormRecord
				FROM
					formrecord			fr,
					formrecordfield		frf,
					formrecordfieldtime	frft
					" . $arrScope['strFrom'] . "
				WHERE 
					fr.idFormRecord			= frf.idFormRecord AND
					frf.idFormField			= " . $arrUserFilterClause['idFormField'] . " AND
					frf.idFormRecordField	= frft.idFormRecordField AND
					frft.tmValue	" . $arrUserFilterClause['chrOperator'] . "'" . $strValue . "'
					" . $arrScope['strWhere'] . "
				";
			}
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			foreach ($result as $item) {
				$arrResults[$i][] = $item['idFormRecord'];
			}
		}
		$result = array();
		if ($strModeANDOR == 'AND') {
			if (count($arrResults) == 1) {
				$result = $arrResults[0];
			} else if (count($arrResults) == 2) {
				$result = array_intersect($arrResults[0], $arrResults[1]);
			} else if (count($arrResults) == 3) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2]);
			} else if (count($arrResults) == 4) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3]);
			} else if (count($arrResults) == 5) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4]);
			} else if (count($arrResults) == 6) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5]);
			} else if (count($arrResults) == 7) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6]);
			} else if (count($arrResults) == 8) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7]);
			} else if (count($arrResults) == 9) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7], $arrResults[8]);
			} else if (count($arrResults) == 10) {
				$result = array_intersect($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7], $arrResults[8], $arrResults[9]);
			}
		} else {
			if (count($arrResults) == 1) {
				$result = $arrResults[0];
			} else if (count($arrResults) == 2) {
				$result = array_merge($arrResults[0], $arrResults[1]);
			} else if (count($arrResults) == 3) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2]);
			} else if (count($arrResults) == 4) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3]);
			} else if (count($arrResults) == 5) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4]);
			} else if (count($arrResults) == 6) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5]);
			} else if (count($arrResults) == 7) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6]);
			} else if (count($arrResults) == 8) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7]);
			} else if (count($arrResults) == 9) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7], $arrResults[8]);
			} else if (count($arrResults) == 10) {
				$result = array_merge($arrResults[0], $arrResults[1], $arrResults[2], $arrResults[3], $arrResults[4], $arrResults[5], $arrResults[6], $arrResults[7], $arrResults[8], $arrResults[9]);
			}
		}
		//$this->strings->log(count($result) . json_encode($result), 'tmp/out.txt', true);
		$result = array_unique($result);
		$arrFormRecords = array();
		if (count ($result)) {
			$arrFormRecords = $this->selectFormRecords(0, 0, 0, $result);
		}
		return $arrFormRecords;
	}
	
	public function selectFormRecordsByPolygon($chrType, $idProject, $arrCoordinates, $strJSONScope, $strParam = '', $intLimit = 0, $strOrderBy = 'fr.idForm, fr.idFormRecord', $idForm = 0, $dtDateFrom = '', $dtDateTo = '') {
		set_time_limit(60);
		$arrScope = json_decode($strJSONScope, true);
		if ($chrType == 'C') {
			$dblRadiusDegrees = $strParam/110000;
			$gDistance =& new gPoint($this->database);
			$gDistance->setLongLat($arrCoordinates[0]['dblLng'], $arrCoordinates[0]['dblLat']);
		} else if ($chrType == 'P') {
			// Find Bounding Box
			$arrLat = array();
			$arrLng = array();
			$dblLatNE = -90; $dblLatSW = 90; $dblLngNE = -180; $dblLngSW = 180;
			foreach ($arrCoordinates as $arrCoordinate) {
				$arrLat[] = $arrCoordinate['dblLat'];
				$arrLng[] = $arrCoordinate['dblLng'];
				if ($arrCoordinate['dblLat'] > $dblLatNE) $dblLatNE = $arrCoordinate['dblLat'];
				if ($arrCoordinate['dblLat'] < $dblLatSW) $dblLatSW = $arrCoordinate['dblLat'];
				if ($arrCoordinate['dblLng'] > $dblLngNE) $dblLngNE = $arrCoordinate['dblLng'];
				if ($arrCoordinate['dblLng'] < $dblLngSW) $dblLngSW = $arrCoordinate['dblLng'];
			}
		}
		$query =
		"SELECT
			fr.idFormRecord,
			fr.idUser,
			fr.idForm,
			fr.idDevice,
			fr.idShapeType,
			fr.strCustomMarkerRGBColor,
			f.idProject,
			f.strName,
			f.idMarker,
			f.blnActive,
			m.strMarkerFileName,
			m.idProject AS idProjectMarker
		FROM
			formrecord			fr,
			form				f,
			marker				m,
			formrecordvertex	frv
			" . $arrScope['strFrom'] . "
		WHERE 
			fr.idForm				= f.idForm
			AND frv.idFormRecord	= fr.idFormRecord
			AND f.idMarker			= m.idMarker
			AND f.blnActive			= 1
			AND f.idProject			= " . $idProject . "
			" . ($idForm ?  "AND fr.idForm = " . $idForm : "") . "
			" . ($dtDateFrom ?  "AND fr.dtLastUpdate >= '" . $dtDateFrom . "'" : "") . "
			" . ($dtDateTo ?  "AND fr.dtLastUpdate <= '" . $dtDateTo . "'" : "") . "
			" . $arrScope['strWhere'] . "
		" . ($chrType == "R" ? "
			AND frv.dblLatitude		< '" . $arrCoordinates[0]['dblLat'] . "'
			AND frv.dblLongitude	< '" . $arrCoordinates[0]['dblLng'] . "'
			AND frv.dblLatitude		> '" . $arrCoordinates[1]['dblLat'] . "'
			AND frv.dblLongitude	> '" . $arrCoordinates[1]['dblLng'] . "'
		" : ($chrType == "C" ? "
			AND frv.dblLatitude		> '" . ($arrCoordinates[0]['dblLat'] - $dblRadiusDegrees) . "'
			AND frv.dblLatitude		< '" . ($arrCoordinates[0]['dblLat'] + $dblRadiusDegrees) . "'
			AND frv.dblLongitude	> '" . ($arrCoordinates[0]['dblLng'] - $dblRadiusDegrees) . "'
			AND frv.dblLongitude	< '" . ($arrCoordinates[0]['dblLng'] + $dblRadiusDegrees) . "'
		" : ($chrType == "P" ? "
			AND frv.dblLatitude		< '" . $dblLatNE . "'
			AND frv.dblLongitude	< '" . $dblLngNE . "'
			AND frv.dblLatitude		> '" . $dblLatSW . "'
			AND frv.dblLongitude	> '" . $dblLngSW . "'
		" : ""))) . "
		GROUP BY
			fr.idFormRecord
		ORDER BY 
		" . $strOrderBy . "
		" . ($intLimit > 0 ? "LIMIT " . $intLimit : "");
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);		
		for ($idLine=count($result)-1; $idLine >= 0; $idLine--) {
			$result[$idLine]['arrVertex'] = $this->selectFormRecordVertexs($result[$idLine]['idFormRecord']);
			$result[$idLine]['dblLatitude'] = $result[$idLine]['arrVertex'][0]['dblLatitude'];
			$result[$idLine]['dblLongitude'] = $result[$idLine]['arrVertex'][0]['dblLongitude'];
			if ($result[$idLine]['idShapeType'] != 1) {
				$arrCentroid = $this->strings->arrVertexsCentroid($result[$idLine]['arrVertex']);
				$result[$idLine]['dblLatitude'] = $arrCentroid['dblLatitude'];
				$result[$idLine]['dblLongitude'] = $arrCentroid['dblLongitude'];
			}
			$result[$idLine]['dblDistanceFromCenterMts'] = ($chrType == 'C' ? $gDistance->distanceFrom($result[$idLine]['dblLongitude'], $result[$idLine]['dblLatitude']) : -1);
			$blnSkip = false;
			// If Selecting by radius, filter by distance
			if ($chrType == 'C') {
				$blnSkip = true;
				foreach ($result[$idLine]['arrVertex'] as $arrVertex) {
					$dblDistance = $gDistance->distanceFrom($arrVertex['dblLongitude'],$arrVertex['dblLatitude']);
					if ($dblDistance <= $strParam) {
						$blnSkip = false;
						break;
					} 
				}
				if ($blnSkip) {
					// Remove item from array
					array_splice($result, $idLine, 1);
				}
			} else if ($chrType == 'P') {
				$blnSkip = true;
				$intVertexesInsidePolygon = 0;
				foreach ($result[$idLine]['arrVertex'] as $arrVertex) {
					$blnIsInsidePolygon = $this->strings->blnIsInPolygon($arrLat, $arrLng, $arrVertex['dblLatitude'], $arrVertex['dblLongitude']);
					if ($blnIsInsidePolygon) $intVertexesInsidePolygon++;
					$intInsidePolygonRate = $intVertexesInsidePolygon/count($result[$idLine]['arrVertex'])*100;
					if ($intInsidePolygonRate > $this->intInsidePolygonRate) {
						$blnSkip = false;
						break;
					}
				}
				if ($blnSkip) {
					// Remove item from array
					array_splice($result, $idLine, 1);
				}
			}
			if ($blnSkip) continue;
			$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $result[$idLine]['strMarkerFileName'];
			if ($result[$idLine]['idProjectMarker'] > 0) {
				$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProjectMarker'] . '/' . $result[$idLine]['strMarkerFileName'];
			}
			$result[$idLine]['strFormMarkerFullPath'] = $result[$idLine]['strMarkerFullPath'];
			if (($result[$idLine]['idShapeType'] == 1) && ($result[$idLine]['strCustomMarkerRGBColor'])) {
				$result[$idLine]['strMarkerFullPath'] = $result[$idLine]['strCustomMarkerRGBColor'];
			}
			if ($result[$idLine]['idShapeType'] > 1) {
				$result[$idLine]['strCustomMarkerRGBColor'] = str_replace('#','', $result[$idLine]['strCustomMarkerRGBColor']);
				if ($result[$idLine]['strCustomMarkerRGBColor']) {
					$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $result[$idLine]['strCustomMarkerRGBColor'];
				} else {
					$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $this->strings->strGenerateRandonColor();
				}
			}
		}
		return $result;
	}

	public function selectFormRecordData($idFormRecord) {
		if (! $idFormRecord) return array();
		$query =
		"SELECT 
				f.idForm,
				frf.idFormField,
				frf.idFormRecordField,
				ff.strName,
				frft.strValue AS `strValue`,
				ff.idFormFieldType,
				ff.strTip,
				ff.intOrder
		FROM 
				formrecordfieldtext	frft,
				formrecordfield		frf,
				formrecord			fr,
				formfield			ff,
				form				f,
				marker 				m
		WHERE
				frft.idFormRecordField	= frf.idFormRecordField AND
				frf.idFormRecord	 	= fr.idFormRecord AND
				frf.idFormField			= ff.idFormField AND
				fr.idForm				= f.idForm AND
				f.idMarker				= m.idMarker AND
				fr.idFormRecord			= " . $idFormRecord . "
		
		UNION 
		
		SELECT 
				f.idForm,
				frf.idFormField,
				frf.idFormRecordField,
				ff.strName,
				frfn.dblValue AS `strValue`,
				ff.idFormFieldType,
				ff.strTip,
				ff.intOrder
		FROM 
				formrecordfieldnumeric frfn,
				formrecordfield		frf,
				formrecord			fr,
				formfield			ff,
				form				f,
				marker 				m
		WHERE
				frfn.idFormRecordField	= frf.idFormRecordField AND
				frf.idFormRecord 		= fr.idFormRecord AND
				frf.idFormField			= ff.idFormField AND
				fr.idForm				= f.idForm AND
				f.idMarker				= m.idMarker AND
				fr.idFormRecord			= " . $idFormRecord . "
		
		UNION 
		
		SELECT 
				f.idForm,
				frf.idFormField,
				frf.idFormRecordField,
				ff.strName,
				frfd.dtValue AS `strValue`,
				ff.idFormFieldType,
				ff.strTip,
				ff.intOrder
		FROM 
				formrecordfielddate frfd,
				formrecordfield		frf,
				formrecord			fr,
				formfield			ff,
				form				f,
				marker 				m
		WHERE
				frfd.idFormRecordField	= frf.idFormRecordField AND
				frf.idFormRecord 		= fr.idFormRecord AND
				frf.idFormField			= ff.idFormField AND
				fr.idForm				= f.idForm AND
				f.idMarker				= m.idMarker AND
				fr.idFormRecord			= " . $idFormRecord . "
		
		UNION 
		
		SELECT 
				f.idForm,
				frf.idFormField,
				frf.idFormRecordField,
				ff.strName,
				frft.tmValue AS `strValue`,
				ff.idFormFieldType,
				ff.strTip,
				ff.intOrder
		FROM 
				formrecordfieldtime frft,
				formrecordfield		frf,
				formrecord			fr,
				formfield			ff,
				form				f,
				marker 				m
		WHERE
				frft.idFormRecordField	= frf.idFormRecordField AND
				frf.idFormRecord 		= fr.idFormRecord AND
				frf.idFormField			= ff.idFormField AND
				fr.idForm				= f.idForm AND
				f.idMarker				= m.idMarker AND
				fr.idFormRecord			= " . $idFormRecord . "
		
		ORDER BY
				intOrder
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		include_once 'form.php';
		$form = new Form($this->database);
		$arrFormFields = $form->selectFormFields($result[0]['idForm']);
		$arrResult = array();
		foreach ($arrFormFields as $idLine => $arrFormField) {
			$arrResult[$idLine]['blnSummary'] = $arrFormField['blnSummary'];
			$arrResult[$idLine]['idFormField'] = $arrFormField['idFormField'];
			$arrResult[$idLine]['strName'] = $arrFormField['strName'];
			$arrResult[$idLine]['idFormFieldType'] = $arrFormField['idFormFieldType'];
			$arrResult[$idLine]['strTip'] = $arrFormField['strTip'];
			$arrResult[$idLine]['intOrder'] = $arrFormField['intOrder'];
			if (($arrResult[$idLine]['idFormFieldType'] == 3) || ($arrResult[$idLine]['idFormFieldType'] == 4)) {
				$arrAlternatives = $this->arrFormRecordFieldAlternatives($idFormRecord, $arrFormField['idFormField']);
				$arrResult[$idLine]['strValue'] = count($arrAlternatives) ? implode(', ', $arrAlternatives['arrAlternatives']) : '';
				$arrResult[$idLine]['idValue'] = count($arrAlternatives) ? implode(', ', $arrAlternatives['arridFormFieldAlternative']) : '';
			} else if ($arrResult[$idLine]['idFormFieldType'] == 5) {
				$arrResult[$idLine]['strValue'] = $this->strFindValueArray($arrFormField['idFormField'], $result);
				if ($arrResult[$idLine]['strValue']) {
					$arrResult[$idLine]['strValue'] = date('d/m/Y', strtotime($arrResult[$idLine]['strValue']));
				}
			} else if ($arrResult[$idLine]['idFormFieldType'] == 7) {
				$strValues = $this->arrFormRecordFieldTimeSeriesValues($idFormRecord, $arrFormField['idFormField']);
				$strValues = implode('; ', $strValues);
				$strValues = str_replace('\t','-', $strValues);
				$arrResult[$idLine]['strValue'] = $strValues;
			} else {
				$arrResult[$idLine]['strValue'] = $this->strFindValueArray($arrFormField['idFormField'], $result);
			} 
		}
		return $arrResult;
	}
	
	public function selectFormRecordsHeatmap($idProject, $strJSONScope) {
		$arrScope = json_decode($strJSONScope, true);
		$query =
		"SELECT 
			fr.idFormRecord,
			frv.dblLatitude,
			frv.dblLongitude
		FROM 
			formrecordvertex	frv,
			formrecord			fr,
			form				f
			" . $arrScope['strFrom'] . "
		WHERE
			frv.idFormRecord		= fr.idFormRecord AND
			fr.idForm				= f.idForm AND
			fr.idShapeType			= 1 AND
			f.idProject				= " . $idProject . "
			" . $arrScope['strWhere'] . "
		ORDER BY
			fr.idFormRecord
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	public function selectFormRecordFlushMap($idProject, $strJSONScope, $idFormFieldID, $idFormFieldIDTo) {
		$arrScope = json_decode($strJSONScope, true);
		$query =
		"SELECT 
			frv.idFormRecord,
			frv.dblLatitude,
			frv.dblLongitude,
			frfn.dblValue AS intID,
			frfn2.dblValue AS intIDTo
		FROM 
			" . $arrScope['strFrom'] . "
			formrecordfield			frf,
			formrecordvertex		frv,
			formrecordfieldnumeric	frfn,
			formrecordfield 		frf2
		RIGHT JOIN  
			formrecordfieldnumeric frfn2
		ON
			frfn2.idFormRecordField = frf2.idFormRecordField AND 
			frf2.idFormField = " . $idFormFieldIDTo . "
		WHERE
			frf.idFormRecord		= frv.idFormRecord AND
			frf.idFormRecord		= frf2.idFormRecord AND
			frfn.idFormRecordField 	= frf.idFormRecordField AND frf.idFormField			= " . $idFormFieldID . "
			" . $arrScope['strWhere'] . "
		ORDER BY
			intID
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrToIndex = array();
		foreach ($result as $idLine => $item) {
			$arrToIndex[$item['intID']] = $item['intIDTo'];
		}
		$i=0;
		$arrResult = array();
		foreach ($result as $idLine => $item) {
			if ($result[$arrToIndex[$item['intIDTo']]]['dblLatitude']) {
				$arrResult[$i]['dblLatitudeFrom'] = $item['dblLatitude'];
				$arrResult[$i]['dblLongitudeFrom'] = $item['dblLongitude'];
				$arrResult[$i]['dblLatitudeTo'] = $result[$arrToIndex[$item['intID']]]['dblLatitude'];
				$arrResult[$i]['dblLongitudeTo'] = $result[$arrToIndex[$item['intID']]]['dblLongitude'];
				$i++;
			}
		}
		return $arrResult;
	}
	
	public function selectFormRecordBuffer($idProject, $strJSONScope, $idForm, $idFormField = '') {
		$arrScope = json_decode($strJSONScope, true);
		$query =
		"SELECT 
			frv.dblLatitude,
			frv.dblLongitude
		FROM 
			formrecordvertex	frv,
			formrecord			fr,
			form				f
			" . $arrScope['strFrom'] . "
		WHERE
			frv.idFormRecord		= fr.idFormRecord AND
			fr.idForm				= f.idForm AND
			fr.idShapeType			= 1 AND
			f.idForm				= " . $idForm . " AND
			f.idProject				= " . $idProject . "
			" . $arrScope['strWhere'] . "
		GROUP BY
			frv.idFormRecord
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	public function selectFormRecordBufferReport($idForm, $dblLatSW, $dblLatNE, $dblLngSW, $dblLngNE) {
		$query =
		"SELECT 
			fr.idFormRecord,
			fr.idShapeType,
			frv.dblLatitude,
			frv.dblLongitude
		FROM 
			formrecordvertex	frv,
			formrecord			fr
		WHERE
			frv.idFormRecord		= fr.idFormRecord
			AND fr.idForm			= " . $idForm . "
			AND fr.idShapeType		= 1 
			AND frv.dblLatitude		< '" . $dblLatNE . "'
			AND frv.dblLongitude	< '" . $dblLngNE . "'
			AND frv.dblLatitude		> '" . $dblLatSW . "'
			AND frv.dblLongitude	> '" . $dblLngSW . "'
		GROUP BY
			frv.idFormRecord
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}
	
	public function arrFormRecordFieldAlternatives($idFormRecord, $idFormField) {
		$query = "
		SELECT 
			ffa.strAlternative,
			ffa.idFormFieldAlternative
		FROM 
			formrecordfield 			frf,
			formrecordfieldalternative	frfa,
			formfieldalternative		ffa
		WHERE
			frf.idFormRecordField 		= frfa.idFormRecordField AND
			frfa.idFormFieldAlternative	= ffa.idFormFieldAlternative AND
			frf.idFormRecord 			= " . $idFormRecord . " AND 
			frf.idFormField				= " . $idFormField . "
		ORDER BY 
			ffa.strAlternative
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		$i=0;
		foreach ($result as $arrAlternative) {
			$arrResult['arridFormFieldAlternative'][$i] = $arrAlternative['idFormFieldAlternative'];
			$arrResult['arrAlternatives'][$i] = $arrAlternative['strAlternative'];
			$i++;
		}
		return $arrResult;
	}
	
	public function arrFormRecordFieldTimeSeriesValues($idFormRecord, $idFormField) {
		$query = "
		SELECT 
			frfts.dtDateTime,
			frfts.strValue
		FROM 
			formrecordfield 			frf,
			formrecordfieldtimeserie	frfts
		WHERE
			frf.idFormRecordField 		= frfts.idFormRecordField AND
			frf.idFormRecord 			= " . $idFormRecord . " AND 
			frf.idFormField				= " . $idFormField . "
		ORDER BY 
			frfts.dtDateTime
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		foreach ($result as $arr) {
			$arrResult[] = $arr['dtDateTime'] . '\t' . trim($arr['strValue']);
		}
		return $arrResult;
	}
	
	public function strFindValueArray($idFormField, $arrDatas) {
		foreach ($arrDatas as $arrData) {
			if ($arrData['idFormField'] == $idFormField) {
				return $arrData['strValue'];
			}
		}
	}
	
	// $intMediaType: 1 = home.php Information Window | 2 = recordPrint.php | 3 = timeline.php
	public function arrPrintFormRecordData($arrFormRecord, $intMediaType = 1) {
		$strFormRecordURL = $this->strings->strSiteURL . '/' .  $arrFormRecord['idFormRecord'];		
		$strInfo = '';
		$strWhatsApp = '';
		$arrFormRecordLastUpdateEvent = $this->arrFormRecordLastUpdateEvent($arrFormRecord['idFormRecord']);
		$strStaticMap = $this->strings->strGenerateStaticMapsURL($arrFormRecord['idShapeType'], $arrFormRecord['strCustomMarkerRGBColor'], $arrFormRecord['strFormName'], $arrFormRecord['arrVertex']);
		$strMapLinkURL = 'geo:' . $arrFormRecord['dblLatitude'] . ',' . $arrFormRecord['dblLongitude'] . '?q=' . $arrFormRecord['dblLatitude'] . ',' . $arrFormRecord['dblLongitude'];
		$strBtnShowHeader = '<i id="btnShowHeader" class="icon-plus-sign" style="cursor:pointer;float:right" title="' . $_SESSION['strGlobalShowHeaderInfo'] . '" onClick="
			var blnShow = document.getElementById(\'btnShowHeader\').className == \'icon-plus-sign\';
			var x = document.getElementsByClassName(\'tblInfoHeader\');
			document.getElementById(\'btnShowHeader\').className = \'icon-\' + (blnShow ? \'minus\' : \'plus\') + \'-sign\';
			for (var i=0;i<x.length;i++) {
				x[i].style.display = blnShow ? \'table-row\' : \'none\';
			}
		"></i>';
		$strInfo .= '
		<style>.tblInfoHeader{display:none;}</style>
		<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalForm'] . ':</b> <img style="max-height:18px;" src="' . $arrFormRecord['strMarkerFullURL'] . '" align="absmiddle" style="float:right"> ' . $arrFormRecord['strFormName'] . '</td></tr>
		<tr class="tblInfoHeader"><td><b>ID: ' . $arrFormRecord['idFormRecord'] . '</td></tr>
		<tr class="tblInfoHeader"><td><b>URL: <a href="' . $strFormRecordURL . '" target="_blank">' . $strFormRecordURL . '</a> <i class="icon-qrcode" style="cursor:pointer" data-rel="tooltip" title="' . $_SESSION['strGlobalDownloadQRCode'] . '" onClick="qrCode(\'' . $strFormRecordURL . '\',\'' . $arrFormRecord['idFormRecord'] . '\');"></i>' . '</td></tr>
		<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalCreated'] . ':</b> ' . $arrFormRecord['strCreation'] . ' - ' . $arrFormRecord['strEmail'] . ' <img src="' . $this->strings->strSiteURL . '/' .  $arrFormRecord['strDeviceFilePath']. '" title="' . $_SESSION['strGlobalDeviceCreateFrom'] . ' ' . $_SESSION['strDevice_' . $arrFormRecord['idDevice']] . '" style="height:16px;" align="absmiddle"> </td></tr>
		<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalUpdated'] . ':</b> ' . ($arrFormRecordLastUpdateEvent ? $arrFormRecord['strLastUpdate'] . ' - ' . $arrFormRecordLastUpdateEvent['strEmail'] : '-') . ($intMediaType == 1 && $arrFormRecordLastUpdateEvent ? ' <a id="btnFormRecordLog" data-loading-text="..." class="btn btn-round" style="padding: 0px 3px 1px 3px" data-rel="tooltip" title="' . $_SESSION['strGlobalFormRecordLog'] . '" onClick="formrecordShowLog(' . $arrFormRecord['idFormRecord'] . ');"><i class="icon-time"></i></a>' : '') . '</td></tr>
		<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalCoordinates'] . ':</b> <img src="' . $this->strings->strSiteURL . '/' . $this->strings->strImgFilePathByidShapeType($arrFormRecord['idShapeType']) . '" style="height:16px"> ' . number_format($arrFormRecord['dblLatitude'], 7, '.', '') . ',' . number_format($arrFormRecord['dblLongitude'], 7, '.', '') . ' <a href="' . $strMapLinkURL . '" class="hidden-desktop" style="float:right;"><i class="icon-map-marker"></i>' . $_SESSION['strGlobalOpenMap'] . '</a></td></tr>
		<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalCoordinates'] . ' UTM:</b> <img src="' . $this->strings->strSiteURL . '/' . $this->strings->strImgFilePathByidShapeType($arrFormRecord['idShapeType']) . '" style="height:16px"> ' . $arrFormRecord['dblLatitudeUTM'] . ':' . $arrFormRecord['dblLongitudeUTM'] . ' ' . $arrFormRecord['intZoneUTM'] . '</td></tr>
		' . ($arrFormRecord['dblDistanceFromCenterMts'] > 0 ? '<tr><td><b>' . $_SESSION['strGlobalDistance'] . ' (km):</b> <i class="icon-user"></i><i class="icon-resize-horizontal"></i><i class="icon-map-marker"></i> ' . number_format($arrFormRecord['dblDistanceFromCenterMts']/1000, 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' km</td></tr>' : '') . '
		';
		if ($arrFormRecord['idShapeType'] == 3) {
			$strInfo .= '<tr class="tblInfoHeader"><td><b>' . $_SESSION['strGlobalPerimeter'] . ': </b> ' . number_format($arrFormRecord['dblPerimeterMts'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' mts | <b>' . $_SESSION['strGlobalArea'] . ': </b>' . number_format($arrFormRecord['dblAreaMts2'], 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' m�</td></tr>';
		}
		$strWhatsApp .=
		$_SESSION['strGlobalForm'] . ': ' . $arrFormRecord['strFormName'] . '%0A
		ID: ' . $arrFormRecord['idFormRecord'] . '%0A
		URL: ' . $strFormRecordURL . '%0A
		' . $_SESSION['strGlobalCreated'] . ': ' . $arrFormRecord['strCreation'] . ' - ' . $arrFormRecord['strEmail'] . '%0A
		' . $_SESSION['strGlobalUpdated'] . ': ' . $arrFormRecord['strLastUpdate'] . '%0A
		' . $_SESSION['strGlobalCoordinates'] . ': ' . number_format($arrFormRecord['dblLatitude'], 7, '.', '') . ':' . number_format($arrFormRecord['dblLongitude'], 7, '.', '') . '%0A
		' . $_SESSION['strGlobalCoordinates'] . ' UTM: ' . $arrFormRecord['dblLatitudeUTM'] . ':' . $arrFormRecord['dblLongitudeUTM'] . ' ' . $arrFormRecord['intZoneUTM'] . '%0A
		';
		$strSummary = '';
		$arrFormRecordDatas = $this->selectFormRecordData($arrFormRecord['idFormRecord']);
		foreach($arrFormRecordDatas as $i => $arrFormRecordData) {
			$strFielName = $arrFormRecordData['strName'] . ':';
			if (strlen($strFielName) < 400) { // Var strFieldName char limit
				$arrFieldNamePrev = explode(':', $arrFormRecordDatas[$i-1]['strName']);
				$arrFieldNameCurr = explode(':', $arrFormRecordDatas[$i]['strName']);
				$strFielName  = '';
				for ($l=0;$l<count($arrFieldNameCurr);$l++) {
					if ($arrFieldNameCurr[$l] != $arrFieldNamePrev[$l]) {
						$strFielName .= ($arrFieldNameCurr[$l-1] != $arrFieldNamePrev[$l-1] ? '<br>' : '') . '<span style="margin-left:' . ($l*$this->strings->intFieldLevelIndentPx) . 'px;">' . $arrFieldNameCurr[$l] . ':</span>';
					}
				}
			}
			$strValue = $arrFormRecordData['strValue'];
			$strValue = $this->strings->strAddURL($strValue);
			//$strValue = strip_tags($strValue);
			if ($arrFormRecordData['idFormFieldType'] == 7) $strValue = str_replace('<:>',", ", $strValue);
			$strInfo .= '<tr><td>' . ($i == 0 ? $strBtnShowHeader : '') . '<b>' . $strFielName . '</b> ' . $strValue . '</td></tr>';
			$strWhatsApp .= $arrFormRecordData['strName'] . ': ' . $strValue . '%0A';
			if ($arrFormRecordData['blnSummary']) {
				$strSummary .= '<tr><td><b>' . $strFielName . '</b> ' . $strValue . '</td></tr>';
			}
		}

		// Attached Files
		if (count($arrFormRecord['arrFiles'])) {
			$strWhatsApp .= $_SESSION['strGlobalFiles'] . ': ' . count($arrFormRecord['arrFiles']);
			$strInfo .= '
			<tr>
				<td id="InfoWindowFiles">
					<i class="icon-file"></i><b> ' . $_SESSION['strGlobalFiles'] . ' (' . count($arrFormRecord['arrFiles']) . ')</b></a>
					' . ($intMediaType == 1 ? '<a onClick="document.getElementById(\'divInfoContent\').scrollTop=0;"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a>' : '') . '
				</td>
			</tr>
			<tr><td>
			';
			$strImages  = '';
			$strFiles = '';
			$strPictureURL = '';
			foreach($arrFormRecord['arrFiles'] as $i => $arrFile) {
				$strTitle = ($arrFile['strDescription'] ? $arrFile['strDescription'] : $arrFile['strFileOriginalName']) . (($arrFile['blnYoutube']) || (strpos($arrFile['strFileOriginalName'], '://') !== FALSE) ? '' : ' [' . number_format(@filesize($arrFile['strFileNameFullPath'])/1000000, 2, '.','') . ' Mb]');
				$strWhatsApp .= '%0A['. ($i+1). '/' . count($arrFormRecord['arrFiles']) . '] - ' .  $arrFile['strFileNameFullURL'];
				if ((stripos($arrFile['strFileNameFullPathRed'], '.jpg') !== FALSE) || (stripos($arrFile['strFileNameFullPathRed'], '.jpeg') !== FALSE) || (stripos($arrFile['strFileName'], '.png') !== FALSE) || (stripos($arrFile['strFileName'], '.gif') !== FALSE)) {
					if ($strPictureURL == '') { $strPictureURL = $arrFile['strFileThumbURL'];}
					$strOnClick = "$.fancybox({'href':'" . $arrFile['strFileNameFullPath'] . "', 'title':'" . $arrFile['strDescription'] . "'" . ($arrFile['blnYoutube'] ? ", 'type':'iframe'": ""). "});";
					if ($intMediaType == 1) {
						$strImages .= '<span style="cursor:pointer;margin:5px;float:left"><img class="img-polaroid" src="' . $arrFile['strFileThumbURL'] . '" style="width:' . $this->strings->intThumbSize . 'px;height:' . $this->strings->intThumbSize . 'px" align="absmiddle" title="' . $strTitle. '" onClick="' . $strOnClick . '"></span>';
					} else if ($intMediaType == 2) {
						$strImages .= '<img class="img-polaroid" src="' . $arrFile['strFileThumbURL'] . '" style="margin:5px;width:' . $this->strings->intThumbSize*2 . 'px;height:' . $this->strings->intThumbSize*2 . 'px" align="absmiddle" title="' . $strTitle. '" align="absmiddle">';
					} else {
						$strImages .= '
						<div style="display:inline-block;margin:1%;width:96%;position: relative;">
							<div style="background-color:#ffffff;width:100%;line-height:23px;top:5px;text-align:center;position:absolute;left: 5px;font-weight:bold;opacity:0.9;filter:alpha(opacity=10);">
								' . $strTitle . ($arrFile['blnYoutube'] ? ' (<i class="icon-film"></i> Video Youtube)' : '') . '
							</div>
							' . ($arrFile['blnYoutube'] ? '<a href="' . $arrFile['strFileNameFullURL'] . '" target="_blank">' : '') . '
							<img class="img-polaroid" src="' . $arrFile['strFileThumbURL'] . '" style="width:100%;" align="absmiddle" align="absmiddle">
							' . ($arrFile['blnYoutube'] ? '</a>' : '') . '
						</div>
						';
					}
				} else {
					if (strpos($arrFile['strFileOriginalName'], '://') === FALSE) {
						$strOnClick = "window.location='output.php?strName=" . $arrFile['strFileOriginalName'] . "&strFileName=" . $arrFile['strFileNameFullPath'] . "'";
						$strFiles .= '<img src="' . $arrFile['strFileThumbURL'] . '" style="height:24px" align="absmiddle" title="' . $strTitle. '" align="absmiddle"> <a style="line-height:28px;font-weight:bold;cursor:pointer" onClick="' . $strOnClick . '">' . $strTitle . '</a><BR>';
					} else { // External File URL
						$strFiles .= '<img src="' . $arrFile['strFileThumbURL'] . '" style="height:24px" align="absmiddle" title="' . $arrFile['strFileOriginalName'] . '" align="absmiddle"> <a href="' . $arrFile['strFileOriginalName'] . '" style="line-height:28px;font-weight:bold;" target="_blank">' . $strTitle . '</a><BR>';
					}
				}
			}
			$strInfo .= '
			' . $strImages . '
			<tr><td>' . $strFiles . '</td></tr>
			</td></tr>';
		}
		if (($intMediaType == 1) || ($intMediaType == 3)) {
			include_once 'project.php';
			$project = new Project($this->database);
			$arrProject = $project->selectProjects($arrFormRecord['idProject']);
			$arrProject = $arrProject[0];
			if ($strPictureURL == '') { $strPictureURL = $this->strings->strSiteURL . '/' . $arrProject['strLogoFileFullPath'];}
			$strFacebook = 
				'URL: ' . $strFormRecordURL . '; ' . 
				$_SESSION['strGlobalCoordinates'] . ': ' . number_format($arrFormRecord['dblLatitude'], 7, '.', '') . ':' . number_format($arrFormRecord['dblLongitude'], 7, '.', '') . '; ' . 
				$_SESSION['strGlobalCreated'] . ': ' . $arrFormRecord['strCreation'] . ' - ' . $arrFormRecord['strEmail'] . '; ' . 
				$_SESSION['strGlobalFiles'] . ': ' . count($arrFormRecord['arrFiles']);
			;
			$strWhatsApp = $this->strings->removeInvalidCharsSQL($strWhatsApp);
			$strSocialMedia = '
				<a class="share-button hidden-desktop" style="float:left" href="whatsapp://send?text=' . $_SESSION['strGlobalProject'] . ': ' . $arrProject['strName'] . '%0A' . $strWhatsApp . '" data-action="share/whatsapp/share"><img src="img/share/whatsapp.png" class="share-image"></a>
				<a class="share-button" href="https://www.facebook.com/dialog/feed?app_id=350664978450591&display=popup&link=' . $this->strings->strSiteURL . '/' .  $arrFormRecord['idFormRecord'] . '&redirect_uri=https://www.facebook.com/&picture=' . $strPictureURL . '&name=' . $this->strings->changeCharAccent($arrProject['strName'] . ' %C2%BB ' . $arrFormRecord['strFormName'] . ' %C2%BB ' . $arrFormRecord['idFormRecord'] . '&description=' . $strFacebook) . '" target="_blank"><img src="img/share/facebook.png" class="share-image"></a>
				<a class="share-button" href="https://twitter.com/share?url=' . $this->strings->strSiteURL . '/' .  $arrFormRecord['idFormRecord'] . '&text=' . $arrFormRecord['dblLatitude'] . ':' . $arrFormRecord['dblLongitude']  . ' %C2%BB ' . $this->strings->changeCharAccent($arrProject['strName'] . ' %C2%BB ' . $arrFormRecord['strFormName'] . ' %C2%BB ' . $arrFormRecord['idFormRecord']) . ' %C2%BB ' . '" target="_blank"><img src="img/share/twitter.png" class="share-image"></a>
			';
			if ($intMediaType == 1) {
				$strInfo = '
					<tr class="tblInfoHeader"><td id="InfoWindowTop">
						<b>' . $_SESSION['strGlobalFiles'] . ': </b> <a onClick="document.getElementById(\'divInfoContent\').scrollTop = document.getElementById(\'InfoWindowFiles\').offsetTop;">' . count($arrFormRecord['arrFiles']) . ' <i class="icon-chevron-down" style="cursor:pointer"></i></a>
						<span style="float:right">' . $strSocialMedia . '</span>
					</td></tr>
				' . $strInfo;
			} else if ($intMediaType == 3) {
				$strInfo = '<tr><td>' . $strSocialMedia . '</td></tr>' . $strInfo;
			}
		}
		$arrResult = array();
		if ($strSummary) {
			$strSummary =	'
				<tr><td><b>' . $_SESSION['strGlobalCreated'] . ':</b> ' . $arrFormRecord['strCreation'] . ' - ' . $arrFormRecord['strEmail'] . ' <img src="' . $this->strings->strSiteURL . '/' .  $arrFormRecord['strDeviceFilePath']. '" title="' . $_SESSION['strGlobalDeviceCreateFrom'] . ' ' . $_SESSION['strDevice_' . $arrFormRecord['idDevice']] . '" style="height:16px;" align="absmiddle"> </td></tr>
				<tr><td><b>' . $_SESSION['strGlobalCoordinates'] . ':</b> <img src="' . $this->strings->strSiteURL . '/' . $this->strings->strImgFilePathByidShapeType($arrFormRecord['idShapeType']) . '" style="height:16px"> ' . number_format($arrFormRecord['dblLatitude'], 7, '.', '') . ',' . number_format($arrFormRecord['dblLongitude'], 7, '.', '') . ' <a href="' . $strMapLinkURL . '" class="hidden-desktop" style="float:right;"><i class="icon-map-marker"></i>' . $_SESSION['strGlobalOpenMap'] . '</a></td></tr>
				' . ($arrFormRecord['dblDistanceFromCenterMts'] > 0 ? '<tr><td><b>' . $_SESSION['strGlobalDistance'] . ' (km):</b> <i class="icon-user"></i><i class="icon-resize-horizontal"></i><i class="icon-map-marker"></i> ' . number_format($arrFormRecord['dblDistanceFromCenterMts']/1000, 2, $_SESSION['strDecimal'], $_SESSION['strThousands']) . ' km</td></tr>' : '') . 
				$strSummary
			;
		}
		$arrResult['strInfo'] = $strSummary . $strInfo;
		$arrResult['strStaticMap'] = $strStaticMap;
		$arrResult['strMapLinkURL'] = $strMapLinkURL;
		return $arrResult;
	}
	
	public function selectFormRecordsTreeView($idForm, $strJSONScope, $intLimit = 99999) {
		$arrScope = json_decode($strJSONScope, true);
		$query =
		"SELECT 
			fr.idFormRecord,
			fr.idShapeType,
			fr.idUser,
			fr.strCustomMarkerRGBColor,
			m.strMarkerFileName,
			m.idProject AS idProjectMarker,
			ff.intOrder,
			ff.strName,
			frft.strValue,
			frv.dblLatitude,
			frv.dblLongitude
		FROM 
			formrecordfieldtext	frft,
			formrecordfield		frf,
			formrecordvertex	frv,
			formrecord			fr,
			formfield			ff,
			form				f,
			marker 				m
			" . $arrScope['strFrom'] . "
		WHERE
			frft.idFormRecordField	= frf.idFormRecordField AND
			frf.idFormRecord 		= fr.idFormRecord AND
			frv.idFormRecord		= fr.idFormRecord AND
			frf.idFormField			= ff.idFormField AND
			fr.idForm				= f.idForm AND
			f.idMarker				= m.idMarker AND
			ff.idFormFieldType		= 1 AND
			fr.idForm				= " . $idForm . " AND
			ff.intOrder = (SELECT MIN(intOrder) FROM formfield WHERE idFormFieldType = 1 AND idForm = " . $idForm . ")
			" . $arrScope['strWhere'] . "
		GROUP BY fr.idFormRecord
		ORDER BY
			frft.strValue
		LIMIT " . $intLimit . "
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $result[$idLine]['strMarkerFileName'];
			if ($result[$idLine]['idProjectMarker'] > 0) {
				$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProjectMarker'] . '/' . $result[$idLine]['strMarkerFileName'];
			}
			if (strpos($result[$idLine]['strCustomMarkerRGBColor'], '/') !== FALSE){
				$result[$idLine]['strMarkerFullPath'] = $result[$idLine]['strCustomMarkerRGBColor'];
				$arrFileName = explode('/', $result[$idLine]['strCustomMarkerRGBColor']);
				$strFileName = $arrFileName[count($arrFileName)-1];
				$arrFileName = explode('.', $strFileName);
				if (is_numeric($arrFileName[0])) {
					$result[$idLine]['strMarkerFullPath'] = $this->strings->strMarkerFolder . '/' . $strFileName;
				} else {
					$result[$idLine]['strMarkerFullPath'] = $this->strings->strProjectFolder . '/' . $result[$idLine]['idProjectMarker'] . '/' . $strFileName;
				}
			}
			$result[$idLine]['strCustomMarkerRGBColor'] = '#' . $this->strings->strGenerateRandonColor();
		}
		return $result;
	}
	
	public function selectFormRecordsFirstFieldTextValue($idForm) {
		$query =
		"SELECT 
			fr.idFormRecord,
			frft.strValue
		FROM 
			formrecordfieldtext	frft,
			formrecordfield		frf,
			formrecord			fr,
			formfield			ff,
			form				f
		WHERE
			frft.idFormRecordField	= frf.idFormRecordField AND
			frf.idFormRecord 		= fr.idFormRecord AND
			frf.idFormField			= ff.idFormField AND
			ff.idFormFieldType		= 1 AND
			fr.idForm				= " . $idForm . " AND
			ff.intOrder = (SELECT MIN(intOrder) FROM formfield WHERE idFormFieldType = 1 AND idForm = " . $idForm . ")
		GROUP BY fr.idFormRecord
		ORDER BY
			frft.strValue
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result;
	}

	public function insertFormRecord($idUser, $idForm, $idDevice = 1, $idShapeType = 1, $strCustomMarkerRGBColor = '', $arrCoordinates, $dtCreation = '') {
		$query = "
			INSERT INTO 
				formrecord
			SET 
				idUser		= " . $idUser . ",
				idForm		= " . $idForm . ",
				idDevice	= " . $idDevice . ",
				idShapeType	= " . $idShapeType . ",
				" . ($strCustomMarkerRGBColor ? "strCustomMarkerRGBColor = '" . $strCustomMarkerRGBColor . "'," : "") . "
				dtCreation	= " . ($dtCreation ? "'" . $dtCreation . "'" : "NOW()") . ",
				dtLastUpdate	= " . ($dtCreation ? "'" . $dtCreation . "'" : "NOW()") . "
		";
		$arrResult = array();
		$this->database->executeQuery($query);
		$arrResult['idFormRecord'] = $this->database->getLastInsertedID();
		$this->database->insertEvent(17, $idUser, $idForm, $idDevice, $idShapeType);
		// Inserting Coordinates into formrecordvertex
		$this->insertFormRecordVertexs($arrResult['idFormRecord'], $idShapeType, $arrCoordinates);
		return $arrResult;
	}
	
	public function insertFormRecordVertexs($idFormRecord, $idShapeType, $arrCoordinates) {
		$query = "DELETE FROM formrecordvertex WHERE idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		$query = '';
		foreach ($arrCoordinates as $i => $arrCoordinate) {
			$query .= "(" . $idFormRecord . ",'" . $arrCoordinate['dblLatitude'] ."','" . $arrCoordinate['dblLongitude'] . "'," . ($i+1) . ")" . ($i < count($arrCoordinates) - 1 ? "," : "");
		}
		if ($query) {
			$this->updateFormRecordProperty($idFormRecord, 'idShapeType', $idShapeType);
			$query = "INSERT INTO formrecordvertex (idFormRecord, dblLatitude, dblLongitude, intPosition) VALUES " . $query;
			$this->database->executeQuery($query);
		}
	}
	
	public function insertUpdateFormRecord($idUser, $idForm, $idFormRecord, $strJSONData) {
		$arrData = json_decode($strJSONData, true);
		$arrData = $arrData[0];
		$arrResult = array();
		$arrResult['idFormRecord'] = $idFormRecord;
		$arrResult['idForm'] = $idForm;
		$arrResult['idUser'] = $idUser;
		$arrResult['dblLatitude'] = $arrData['arrShape'][0]['arrCoordinates'][0]['dblLatitude'];
		$arrResult['dblLongitude'] = $arrData['arrShape'][0]['arrCoordinates'][0]['dblLongitude'];
		$arrResult['blnInsert'] = 0;
		if ($idFormRecord < 0) { // New Record
			$arrFormRecord = $this->insertFormRecord($idUser, $idForm, 1, $arrData['arrShape'][0]['idShapeType'], ($arrData['arrShape'][0]['idShapeType'] > 1 ? $this->strings->strGenerateRandonColor() : ''), $arrData['arrShape'][0]['arrCoordinates']);
			$arrResult['idFormRecord'] = $arrFormRecord['idFormRecord'];
			$arrResult['blnInsert'] = 1;
			// Update Files to New id
			if ($arrResult['idFormRecord'] > 0) {
				$query = "UPDATE formrecordfile SET idFormRecord = " . $arrResult['idFormRecord'] . " WHERE idFormRecord = " . $idFormRecord;
				$this->database->executeQuery($query);	
			}
		} else {
			$query = "UPDATE formrecord SET dtLastUpdate = NOW() WHERE idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);	
			$this->insertFormRecordVertexs($arrResult['idFormRecord'], $arrData['arrShape'][0]['idShapeType'], $arrData['arrShape'][0]['arrCoordinates']);
			$this->database->insertEvent(14, $idUser, $idFormRecord);
		}
		$arrFormFields = $arrData['arrFormFields'];
		// For Log - Before Delete to Check What Had Before Update
		$arrFormRecordDatas = $this->selectFormRecordData($arrResult['idFormRecord']);
		// Delete previous values from db		
		$this->deleteFormRecord($arrResult['idFormRecord'], false);
		$txtLog = '';
		foreach ($arrFormFields as $i => $arrFormField) {
			//if (! $arrFormField['strValue']) continue; // Skip Empty values
			$strFormFieldName = $this->strIsNewFormFieldValue($arrFormRecordDatas[$i], $arrFormField, $idFormRecord < 0);
			// Insert new value
			if ($arrFormField['idFormFieldType'] == 1) {
				$this->insertFormRecordFieldText($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
			} else if ($arrFormField['idFormFieldType'] == 2) {
				$this->insertFormRecordFieldNumeric($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
			} else if (($arrFormField['idFormFieldType'] == 3) || ($arrFormField['idFormFieldType'] == 4)) {
				$this->insertFormRecordFieldAlternative($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
				$arrAlternatives = $this->arrFormRecordFieldAlternatives($arrResult['idFormRecord'], $arrFormField['idFormField']);
				$arrFormField['strValue'] = count($arrAlternatives) ? utf8_encode(implode(', ', $arrAlternatives['arrAlternatives'])) : '';
			} else if ($arrFormField['idFormFieldType'] == 5) {
				$this->insertFormRecordFieldDate($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
			} else if ($arrFormField['idFormFieldType'] == 6) {
				$this->insertFormRecordFieldTime($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
			} else if ($arrFormField['idFormFieldType'] == 7) {
				$this->insertFormRecordFieldTimeSeries($arrResult['idFormRecord'], $arrFormField['idFormField'], $arrFormField['strValue']);
			}
			if ($strFormFieldName) {
				$txtLog .= '<tr><td>' . utf8_decode($strFormFieldName) . ':</td><td>' . utf8_decode($arrFormField['strValue']) . '</td></tr>';
			}
		}
		// Insert Form Record Log
		if ($txtLog) {
			$this->insertFormRecordLog($arrResult['idFormRecord'], $idUser, $this->strings->removeInvalidCharsSQL($txtLog));
		}
		// Check and Insert (if case) User Alert Event
		$this->alert->blnCheckAndInsertUserAlertEvent($arrResult, ($idFormRecord < 0 ? 13 : 14));
		return $arrResult;
	}
	
	public function strIsNewFormFieldValue($arrFormRecordData, $arrFormField, $blnNewRecord){
		// if is FieldType Alternatives
		$arrFormRecordData['strValue'] = utf8_encode($arrFormRecordData['strValue']);
		if ($arrFormRecordData['idValue']) $arrFormRecordData['strValue'] = $arrFormRecordData['idValue'];
		
		if ((($blnNewRecord) && ($arrFormField['strValue'])) || (($arrFormRecordData['idFormField'] == $arrFormField['idFormField']) && ($arrFormRecordData['strValue'] != $arrFormField['strValue']))) {
			return $arrFormField['strFormFieldName'];
		}
		return false;
	}

	public function updateFormRecordProperty($idFormRecord, $strField, $strValue) {
		$query = "UPDATE formrecord SET " . $strField . " = '" . $strValue . "' WHERE idFormRecord = " . $idFormRecord;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function updateFormRecords($strAction, $strJSONFormRecords, $strNewValue){
		$arrFormRecords = json_decode($strJSONFormRecords, true);
		$strOR = '';
		foreach ($arrFormRecords as $i => $arrFormRecord) {
			$strOR .= ($i > 0 ? ' OR ' : '') . ' idFormRecord = ' . $arrFormRecord['idFormRecord'];
		}
		if (! $strOR) return false;
		switch ($strAction) {
			case 'TR': // Change Records Owner
				$query = "UPDATE formrecord SET idUser = " . $strNewValue . " WHERE " . $strOR;
				$result = $this->database->executeQuery($query);
			break;
			case 'CC': // Change Color
				$query = "UPDATE formrecord SET strCustomMarkerRGBColor = '" . $strNewValue . "' WHERE idShapeType != 1 AND (" . $strOR . ")";
				$result = $this->database->executeQuery($query);
			break;
			case 'CI': // Change Icon
				$query = "UPDATE formrecord SET strCustomMarkerRGBColor = '" . $strNewValue . "' WHERE idShapeType = 1 AND (" . $strOR . ")";
				$result = $this->database->executeQuery($query);
			break;
			case 'CI0': // Change Icon to Default
				$query = "UPDATE formrecord SET strCustomMarkerRGBColor = NULL WHERE idShapeType = 1 AND (" . $strOR . ")";
				$result = $this->database->executeQuery($query);
			break;
			case 'DEL': // Delete
				foreach ($arrFormRecords as $arrFormRecord) {
					$this->deleteFormRecord($arrFormRecord['idFormRecord']);
				}
			break;
		}
		return true;
	}
	
	public function updateUserCreator($idUserFrom, $idUserTo) {
		$query = "UPDATE formrecord SET idUser = " . $idUserTo . " WHERE idUser = " . $idUserFrom;
		$result = $this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
		
	public function deleteFormRecord($idFormRecord, $blnDeleteAll = true) {
		// For blnDeleteAll and Alerts, before destroy data
		$arrFormRecord = $this->selectFormRecords(0, 0, 0, $idFormRecord);
		$arrFormRecord = $arrFormRecord[0];
		$arrRecordInfo = $this->arrPrintFormRecordData($arrFormRecord, 2);
		$arrFormRecord['strInfo'] = $arrRecordInfo['strInfo'];

		$query = "DELETE formrecordfieldtext FROM formrecordfield, formrecordfieldtext WHERE formrecordfield.idFormRecordField = formrecordfieldtext.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldnumeric FROM formrecordfield, formrecordfieldnumeric WHERE formrecordfield.idFormRecordField = formrecordfieldnumeric.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldalternative FROM formrecordfield, formrecordfieldalternative WHERE formrecordfield.idFormRecordField = formrecordfieldalternative.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfielddate FROM formrecordfield, formrecordfielddate WHERE formrecordfield.idFormRecordField = formrecordfielddate.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		
		$query = "DELETE formrecordfieldtime FROM formrecordfield, formrecordfieldtime WHERE formrecordfield.idFormRecordField = formrecordfieldtime.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);

		$query = "DELETE formrecordfieldtimeserie FROM formrecordfield, formrecordfieldtimeserie WHERE formrecordfield.idFormRecordField = formrecordfieldtimeserie.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);

		$query = "DELETE formrecordfield FROM formrecordfield WHERE formrecordfield.idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		
		if ($blnDeleteAll) {		
			$query = "DELETE formfieldalternative FROM formrecordfield, formfieldalternative WHERE formrecordfield.idFormRecordField = formfieldalternative.idFormRecordField AND formrecordfield.idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);
	
			$query = "DELETE formrecordvertex FROM formrecordvertex WHERE formrecordvertex.idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);

			$arrFormRecordFiles = $this->selectFormRecordFiles($arrFormRecord['idProject'], $idFormRecord);
			foreach ($arrFormRecordFiles as $arrFormRecordFile) {
				@unlink($arrFormRecordFile['strFileNameFullPath']);
				@unlink($arrFormRecordFile['strFileNameFullPathRed']);
			}
			$query = "DELETE FROM formrecordfile WHERE idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);
			
			$query = "DELETE FROM formrecordlog WHERE idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);
			
			$query = "DELETE FROM formrecord WHERE idFormRecord = " . $idFormRecord;
			$this->database->executeQuery($query);
			
			// Check and Insert (if case) User Alert Event
			$this->alert->blnCheckAndInsertUserAlertEvent($arrFormRecord, 15);
		}
	}
	
	public function intCountFormRecords($idProject = 0, $idForm = 0, $idUser = 0, $strJSONScope = '') {
		$arrScope = json_decode($strJSONScope, true);
		$query = "
			SELECT 
				COUNT(fr.idFormRecord) as `intNum` 
			FROM 
				formrecord	fr,
				form		f
			" . $arrScope['strFrom'] . "
			WHERE 
				fr.idForm = f.idForm 
				" . $arrScope['strWhere'] . "
				" . ($idProject	> 0 ? " AND f.idProject		= " . $idProject : "") . "
				" . ($idForm	> 0 ? " AND fr.idForm		= " . $idForm : "") . "
				" . ($idUser	> 0 ? " AND fr.idUser		= " . $idUser : "")
		;
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0]['intNum'];
	}
	
	// Formrecordvertex
	public function selectFormRecordVertexs($idFormRecord) {
		$query = "
			SELECT 
				frv.idFormRecordVertex,
				frv.idFormRecord,
				frv.dblLatitude,
				frv.dblLongitude,
				frv.intPosition
			FROM 
				formrecordvertex	frv
			WHERE 
				frv.idFormRecord	= " . $idFormRecord . "
			ORDER BY
				frv.intPosition
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		if (! count($result)) {
			$result[0]['dblLatitude'] = 0;
			$result[0]['dblLongitude'] = 0;
		}
		return  $result;
	}
	
	public function selectProjectBoundingBox($idProject, $strJSONScope) {
		$arrScope = json_decode($strJSONScope, true);
		$query = "
			SELECT 
				MAX(frv.dblLatitude) as dblLatNE,
				MIN(frv.dblLatitude) as dblLatSW,
				MAX(frv.dblLongitude) as dblLngNE,
				MIN(frv.dblLongitude) as dblLngSW
			FROM 
				formrecordvertex frv,
				formrecord fr,
				form f
				" . $arrScope['strFrom'] . "
			WHERE 
				" . $arrScope['strWhere'] . "
				f.blnActive 		= true					AND
				frv.idFormRecord	= fr.idFormRecord		AND
				fr.idForm			= f.idForm 				AND
				f.idProject			= " . $idProject . "	AND
				dblLatitude			<> 0 					AND
				dblLongitude		<> 0					AND
				dblLatitude <= 90 AND dblLatitude >= -90 AND dblLongitude <= 180 AND dblLongitude >= -180
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return  $result[0];
	}
	
	public function strLoadTreeViewItemsXML($idProject, $strJSONScope, $intMaxFormRecords = 0) {
		include_once 'form.php';
		$form = new Form($this->database);
		$arrForms = $form->selectForms($idProject, 0, '', true);
		$intRecordsTotal = 0;
		foreach ($arrForms as $arrForm) {
			$intRecords = $this->intCountFormRecords(0, $arrForm['idForm'], 0, $strJSONScope);
			if (! $intRecords) continue;
			$intRecordsTotal += $intRecords;
			$strXML .= '<item text="' . $arrForm['strName'] . ' (' . $intRecords . ')" id="' . $arrForm['idForm'] . '" idKind="1" idForm="' . $arrForm['idForm'] . '" idFormRecord="0" open="1" checked="1" im0="../../../../' . $arrForm['strMarkerFullPath']  . '" im1="../../../../' . $arrForm['strMarkerFullPath'] . '" im2="../../../../' . $arrForm['strMarkerFullPath'] . '" call="1" select="1" aCol="#000000" sCol="#FFFFFF">' . chr(13);
			$arrFormRecords = $this->selectFormRecordsTreeView($arrForm['idForm'], $strJSONScope, $intMaxFormRecords); // limit tree items per form
			if ($intRecords > $intMaxFormRecords) {
				$strXML .= '</item>' . chr(13);
				continue;
			}
			foreach ($arrFormRecords as $i => $arrFormRecord) {
				$strIcon = $arrFormRecord['idShapeType'] == 1 ? $arrFormRecord['strMarkerFullPath'] : $this->strings->strImgFilePathByidShapeType($arrFormRecord['idShapeType']);
				$strRGBColor = $arrFormRecord['idShapeType'] == 1 ? '#000000' : $arrFormRecord['strCustomMarkerRGBColor'];
				$strText = $arrFormRecord['strValue'] ? strip_tags($arrFormRecord['strValue']) : $arrFormRecord['idFormRecord'];
				$strText = strtr($strText, array("&" => " ", "(" => "", ")" => "", "#" => " "));
				$strTextShort = substr($strText,0, 50);
				$strXML .= '	<item text="' . $strTextShort . '" id="1:' . $arrFormRecord['idFormRecord'] . '" idKind="1" idForm="' . $arrForm['idForm'] . '" idFormRecord="' . $arrFormRecord['idFormRecord'] . '" idUser="' . $arrFormRecord['idUser'] . '" idShapeType="' . $arrFormRecord['idShapeType'] . '" dblLatitude="' . $arrFormRecord['dblLatitude'] . '" dblLongitude="' . $arrFormRecord['dblLongitude'] . '" tooltip="' . $strText . '" checked="1" im0="../../../../' . $strIcon . '" im1="../../../../' . $strIcon . '" im2="../../../../' . $strIcon . '" aCol="' .  $strRGBColor . '" sCol="' . $strRGBColor . '" style=""></item>' . chr(13);
			}
			$strXML .= '</item>' . chr(13);
		}
		$arrResult = array();
		$arrResult['strXML'] = $strXML;
		$arrResult['intRecords'] = $intRecordsTotal;
		return $arrResult;
	}
	
	// 1 = Records, 4 = Users
	public function selectSuggestedValues($idProject, $strQuery, $intSearchType) {
		$arrResult = array();
		if ($intSearchType == 1) {
			// Including Numeric Alternatives - VERY SLOW!
			/*
			$query = "
				SELECT
					frf.idFormRecord,
					fr.idShapeType,
					frv.dblLatitude,
					frv.dblLongitude,
					m.idProject,
					m.strMarkerFileName,
					frft.strValue
				FROM 
					formrecordvertex	frv,
					formrecord			fr,
					form				f,
					marker			m,
					formrecordfield		frf
				LEFT OUTER JOIN formrecordfieldtext frft ON frft.idFormRecordField	= frf.idFormRecordField
				LEFT OUTER JOIN formrecordfieldnumeric frfn ON frfn.idFormRecordField	= frf.idFormRecordField
				WHERE 
					frf.idFormRecord		= fr.idFormRecord AND
					frv.idFormRecord		= fr.idFormRecord AND
					fr.idForm				= f.idForm AND
					f.idMarker				= m.idMarker AND
					f.idProject				= " . $idProject . " AND
					f.blnActive				= 1	AND
					(
					frfn.dblValue			LIKE '%" . $strQuery . "%' OR
					frft.strValue			LIKE '%" . utf8_decode($strQuery) . "%'
					" . (is_numeric($strQuery) ? " OR fr.idFormRecord LIKE '%" . $strQuery . "%'" : "") . "
					)
				GROUP BY 
					fr.idFormRecord
				ORDER BY
					strValue
				";
			*/
			// Including Field Alternatives - SLOW!
			/*
			$query = "
				SELECT
					frf.idFormRecord,
					fr.idShapeType,
					frv.dblLatitude,
					frv.dblLongitude,
					m.idProject,
					m.strMarkerFileName,
					frft.strValue AS strValue
				FROM 
					formrecordvertex	frv,
					formrecord			fr,
					form				f,
					marker			m,
					formrecordfield		frf,
					formrecordfieldtext frft
				WHERE 
					frf.idFormRecord		= fr.idFormRecord AND
					frv.idFormRecord		= fr.idFormRecord AND
					fr.idForm				= f.idForm AND
					f.idMarker				= m.idMarker AND
					f.idProject				= " . $idProject . " AND
					f.blnActive				= 1	AND
					frft.idFormRecordField = frf.idFormRecordField AND 
					" . (is_numeric($strQuery) ? "fr.idFormRecord LIKE '%" . $strQuery . "%'" : "frft.strValue LIKE '%" . utf8_decode($strQuery) . "%'") . "
				
				UNION
				
				SELECT
					frf.idFormRecord,
					fr.idShapeType,
					frv.dblLatitude,
					frv.dblLongitude,
					m.idProject,
					m.strMarkerFileName,
					ffa.strAlternative AS strValue
				FROM 
					formrecordvertex	frv,
					formrecord			fr,
					form				f,
					marker			m,
					formrecordfield		frf,
					formfieldalternative ffa,
					formrecordfieldalternative frfa
				WHERE 
					frf.idFormRecord		= fr.idFormRecord AND
					frv.idFormRecord		= fr.idFormRecord AND
					fr.idForm				= f.idForm AND
					f.idMarker				= m.idMarker AND
					f.idProject				= " . $idProject . " AND
					f.blnActive				= 1	AND
					frfa.idFormRecordField = frf.idFormRecordField AND 
					frfa.idFormFieldAlternative = ffa.idFormFieldAlternative AND
					" . (is_numeric($strQuery) ? "fr.idFormRecord LIKE '%" . $strQuery . "%'" : "ffa.strAlternative LIKE '%" . utf8_decode($strQuery) . "%'") . "
				GROUP BY 
					fr.idFormRecord
				ORDER BY
					strValue
			*/
			// NOT Including Numeric Alternatives - Faster
			$query = "
				SELECT
					frf.idFormRecord,
					fr.idShapeType,
					frv.dblLatitude,
					frv.dblLongitude,
					m.idProject,
					m.strMarkerFileName,
					frft.strValue
				FROM 
					formrecordvertex	frv,
					formrecord			fr,
					form				f,
					marker			m,
					formrecordfield		frf
				LEFT OUTER JOIN formrecordfieldtext frft ON frft.idFormRecordField	= frf.idFormRecordField
				WHERE 
					frf.idFormRecord		= fr.idFormRecord AND
					frv.idFormRecord		= fr.idFormRecord AND
					fr.idForm				= f.idForm AND
					f.idMarker				= m.idMarker AND
					f.idProject				= " . $idProject . " AND
					f.blnActive				= 1	AND
					" . (is_numeric($strQuery) ? "fr.idFormRecord LIKE '%" . $strQuery . "%'" : "frft.strValue LIKE '%" . utf8_decode($strQuery) . "%'") . "
				GROUP BY 
					fr.idFormRecord
				ORDER BY
					strValue
				";
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			foreach ($result as $idLine => $item) {
				$result[$idLine]['strMarkerFullPath'] = ($result[$idLine]['idProject'] > 0 ? $this->strings->strProjectFolder . '/' . $result[$idLine]['idProject'] . '/' : $this->strings->strMarkerFolder . '/') . $result[$idLine]['strMarkerFileName'];
				$strValue = strip_tags($item['strValue']);
				$intPos = strpos(strtolower($strValue), strtolower($strQuery));
				$i = $intPos;
				while (($i > 0) && ($strValue[$i] != ' ')) $i--;
				$strWord = substr($strValue, $i, 40);
				$arrResult[$idLine]['value'] = '<img src=' . $this->strings->strImgFilePathByidShapeType($item['idShapeType']) . ' style="height:16px;"> <img src=' . $result[$idLine]['strMarkerFullPath'] . ' style="height:16px;"> [' . $item['idFormRecord'] . '] ' . $strWord;
				$arrResult[$idLine]['data'] = '1:' . $item['idFormRecord'] . ':' . $item['dblLatitude'] . ':' . $item['dblLongitude'];
				$arrResult[$idLine]['text'] = $strWord;
			}
		} else {
			/*
			// All Users
			$query = "
			SELECT
				u.idUser,
				u.strName,
				u.strEmail,
				u.idUserLevel,
				u.strSkypeID
			FROM 
				user			u
			WHERE 
				u.blnActive = 1	AND
				u.idProject = " . $idProject . " AND
				(u.strName LIKE '%" . utf8_decode($strQuery) . "%' OR u.strEmail LIKE '%" . utf8_decode($strQuery) . "%')
			GROUP BY 
				idUser
			ORDER BY
				u.dtRegister
			";
			$result = $this->database->executeQuery($query);
			$result = $this->database->prepareReturn($result);
			*/
			include_once 'user.php';
			$user = new User($this->database);
			$arrUsers = $user->selectUsers($idProject, 0, utf8_decode($strQuery));
			foreach ($arrUsers as $idLine => $arrUser) {
				$arrResult[$idLine]['value'] = '<span style="width:100%;white-space: normal;">';
				$arrResult[$idLine]['value'] .= '<i class="icon-user"></i> ' . ($arrUser['strName'] ? $arrUser['strName'] : $arrUser['strEmailAbbreviated']) . ' | <i class="icon-lock"></i> ' . $arrUser['idUserLevel'] . '/4 | <i class="icon-list-alt"></i> ' . $arrUser['intNumRecords'] . ($arrUser['strSkypeID'] ? ' | ' . $arrUser['strSkypeStatus'] . $arrUser['strSkypeID'] : '');
				$arrUserPositionsDates = $user->selectUserPositionsDates($arrUser['idUser']);
				if (count ($arrUserPositionsDates) > 0) {
					$arrResult[$idLine]['value'] .= '
						<br><img src="img/userRoute.png" style="width:16px;height:16px"> ' . $_SESSION['strHomeToolsItemUserRoutes'] . ':<br>
						<span class="input-prepend" id="spanUserRouteDate_' . $arrUser['idUser'] . '_' . $arrUserPositionsDate['strDateMySQL'] . '" style="margin-right:6px;margin-bottom:4px">
							' . ($arrUser['idUser'] == $_SESSION['idUser'] ? '
							<span class="add-on btn-danger" style="cursor:pointer;" onClick="userPositionsDelete(' . $arrUser['idUser'] . ');">
								<i class="icon-trash icon-white"></i>
							</span>
							' : ''). '
							<span class="add-on btn" style="font-size:12px;color:#000000;width:150px" onClick="userPositionsLoad(' . $arrUser['idUser'] . ');" title="' . $_SESSION['strHomeToolsItemUserRoutesClickToView'] . '">
								' . $_SESSION['strGlobalAll'] . ' (' . count($arrUserPositionsDates) . ')
							</span>
						</span>
					';
					foreach ($arrUserPositionsDates as $i => $arrUserPositionsDate) {
						$arrResult[$idLine]['value'] .= '' . 
							'<span class="input-prepend" id="spanUserRouteDate_' . $arrUser['idUser'] . '_' . $arrUserPositionsDate['strDateMySQL'] . '" style="margin-right:6px;margin-bottom:4px">
								' . ($arrUser['idUser'] == $_SESSION['idUser'] ? '
								<span class="add-on btn-danger" style="cursor:pointer;" onClick="userPositionsDelete(' . $arrUser['idUser'] . ', \'' . $arrUserPositionsDate['strDateMySQL'] . '\');">
									<i class="icon-trash icon-white"></i>
								</span>
								' : ''). '
								<span class="add-on btn" style="font-size:12px;color:#000000" onClick="userPositionsLoad(' . $arrUser['idUser'] . ', \'' . $arrUserPositionsDate['strDateMySQL'] . '\');" title="' . $_SESSION['strHomeToolsItemUserRoutesClickToView'] . '">
									' . $arrUserPositionsDate['strDate'] . '
								</span>
							</span> ';
							//($arrUser['idUser'] == $_SESSION['idUser'] ? '<span id="spanUserRouteDate_' . $arrUser['idUser'] . '_' . $arrUserPositionsDate['strDateMySQL'] . '"><i class="icon-trash" style="cursor:pointer" onClick="userPositionsDelete(' . $arrUser['idUser'] . ', \'' . $arrUserPositionsDate['strDateMySQL'] . '\');"></i> ' : '') . 
							//'<span style="text-decoration:underline;cursor:pointer" onClick="userPositionsLoad(' . $arrUser['idUser'] . ', \'' . $arrUserPositionsDate['strDateMySQL'] . '\');" title="' . $_SESSION['strHomeToolsItemUserRoutesClickToView'] . '">' . $arrUserPositionsDate['strDate'] . '</span></span>';
					}
				}
				$arrResult[$idLine]['value'] .= '</span>';
				$arrResult[$idLine]['data'] = '4:' . $arrUser['idUser'];
				$arrResult[$idLine]['text'] = $arrUser['strEmail'];
			}
		}
		return  $arrResult;
	}
	
	public function selectSuggestedFormFieldValues($idFormField, $strQuery) {
		$query = "
			SELECT DISTINCT
				frf.idFormRecordField,
				frft.strValue
			FROM 
				formrecordfieldtext	frft,
				formrecordfield		frf
			WHERE 
				frft.idFormRecordField	= frf.idFormRecordField AND
				frf.idFormField			= " . $idFormField . " AND
				(
				frft.strValue			LIKE '%" . utf8_decode($strQuery) . "%'
				" . (is_numeric($strQuery) ? " OR fr.idFormRecord = " . $strQuery : "") . "
				)
			GROUP BY 
				strValue
			
			UNION 
			
			SELECT DISTINCT
				frf.idFormRecordField,
				ffa.strAlternative AS `strValue`
			FROM 
				formrecordfieldalternative	frfa,
				formfieldalternative		ffa,
				formrecordfield				frf
			WHERE 
				frfa.idFormRecordField		= frf.idFormRecordField AND
				frfa.idFormFieldAlternative	= ffa.idFormFieldAlternative AND
				frf.idFormField				= " . $idFormField . " AND
				ffa.strAlternative			LIKE '%" . utf8_decode($strQuery) . "%'
			GROUP BY 
				strValue
			ORDER BY
				strValue
		";
		$result = $this->database->executeQuery($query);		
		$result = $this->database->prepareReturn($result);
		$arrResult = array();
		foreach ($result as $idLine => $item) {
			$strValue = $item['strValue'];
			$intPos = strpos(strtolower($strValue), strtolower($strQuery));
			$i = $intPos;
			while (($i > 0) && ($strValue[$i] != ' ')) $i--;
			$strWord = substr($strValue, $i, 40);
			$arrResult[$idLine]['value'] = $strWord;
			$arrResult[$idLine]['data'] = $item['idFormField'];
			$arrResult[$idLine]['text'] = $strWord;
		}
		return  $arrResult;
	}

	public function strGetFirstFieldRecordValue($idFormRecord) {
		$query =
		"SELECT
			frft.strValue
		FROM 
			formrecordfieldtext	frft,
			formrecordfield		frf,
			formfield			ff
		WHERE
			frft.idFormRecordField	= frf.idFormRecordField AND
			frf.idFormField 		= ff.idFormField AND
			frf.idFormRecord 		= " . $idFormRecord . "
		ORDER BY
			ff.intOrder
		LIMIT 1
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0]['strValue'] ? $result[0]['strValue'] : $idFormRecord;
	}
	
	// Form Record Files
	public function selectFormRecordFiles($idProject, $idFormRecord = 0, $idFormRecordFile = 0, $idForm = 0) {
		$query =
		"SELECT
			frf.idFormRecordFile,
			frf.idFormRecord,
			frf.strFileName,
			frf.strFileOriginalName,
			frf.strDescription,
			frf.intPosition
		FROM
			formrecordfile		frf
			" . ($idForm > 0 ? ", formrecord fr, form f" : "") . "
		WHERE 1 > 0 
			" . ($idForm > 0 ? "AND frf.idFormRecord = fr.idFormRecord AND fr.idForm = f.idForm AND f.idForm = " . $idForm : "") . "
			" . ($idFormRecord != 0 ? " AND frf.idFormRecord = " . $idFormRecord : "") . "
			" . ($idFormRecordFile > 0 ? " AND frf.idFormRecordFile = " . $idFormRecordFile : "") . "
		ORDER BY frf.intPosition
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strFileNameFullPath'] = $this->strings->strProjectFolder . '/' . $idProject . '/' . $result[$idLine]['strFileName'];
			$arrFileName = explode('.', $result[$idLine]['strFileName']);
			$strExt = array_pop($arrFileName);
			$result[$idLine]['strFileNameFullPathRed'] = $this->strings->strProjectFolder . '/' . $idProject . '/' . $arrFileName[0] . 'red.' . $strExt;
			$result[$idLine]['strFileNameFullURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strFileNameFullPath'];
			if (file_exists($result[$idLine]['strFileNameFullPathRed'])) {
				$result[$idLine]['strFileThumb'] = $result[$idLine]['strFileNameFullPathRed'];
				$result[$idLine]['strFileThumbURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strFileNameFullPathRed'];
			} else if ((stripos($result[$idLine]['strFileName'], '.jpg') !== FALSE) || (stripos($result[$idLine]['strFileName'], '.jpeg') !== FALSE) || (stripos($result[$idLine]['strFileName'], '.png') !== FALSE) || (stripos($result[$idLine]['strFileName'], '.gif') !== FALSE)) {
				$result[$idLine]['strFileThumb'] = $result[$idLine]['strFileNameFullPath'];
				$result[$idLine]['strFileThumbURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strFileNameFullPath'];
			} else if (strpos($result[$idLine]['strFileOriginalName'], '://') !== FALSE) {
				$result[$idLine]['strFileThumb'] = 'img/file-cloud.png';
				$result[$idLine]['strFileThumbURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strFileThumb'];
			} else {
				// Thumb Icon
				$arrExt = explode('.', $result[$idLine]['strFileName']);
				$strExt = array_pop($arrExt);
				if (strtolower($strExt) == 'jpg') {
					$result[$idLine]['strFileThumb'] = $result[$idLine]['strFileNameFullPath'];
				} else {
					$result[$idLine]['strFileThumb'] = $this->strings->strIconFileExtension($strExt);
				}
				$result[$idLine]['strFileThumbURL'] = $this->strings->strSiteURL . '/' . $result[$idLine]['strFileThumb'];
			}
			$result[$idLine]['blnYoutube'] = false;
			if (strpos($result[$idLine]['strFileOriginalName'], 'youtube.com') !== FALSE) {
				$result[$idLine]['blnYoutube'] = true;
				$result[$idLine]['strFileNameFullURL'] = $result[$idLine]['strFileOriginalName'];
				$arr = explode('=', $result[$idLine]['strFileOriginalName']);
				$result[$idLine]['strFileNameFullPath'] = 'http://www.youtube.com/embed/' . $arr[1];
				if (! file_exists($result[$idLine]['strFileThumb'])) {
					$result[$idLine]['strFileThumb'] = 'http://img.youtube.com/vi/' . $arr[1] . '/hqdefault.jpg';
					$result[$idLine]['strFileThumbURL'] = $result[$idLine]['strFileThumb'];
				}
			}
		}
		return $result;
	}
	
	public function insertFormRecordFile($idProject, $idFormRecord, $strOriginalFileFullPath, $strOriginalFileName, $strDescription = '', $intPosition = 999, $strPrefixFolder = '') {
		$arrResult = array();
		$ext = explode(".", $strOriginalFileFullPath);
		$ext = strtolower(array_pop($ext));
		$strFileName = $this->strings->generateRandomString(10) . "." . $ext;
		$strDestinationFileFullPath = $strPrefixFolder . $this->strings->strProjectFolder . '/' . $idProject . '/' . $strFileName;
		if (copy($strOriginalFileFullPath, $strDestinationFileFullPath)) {
			$query = "
			INSERT INTO 
				formrecordfile
			SET
				idFormRecord			= " . $idFormRecord . ",
				strFileName				= '" . $strFileName . "',
				strFileOriginalName		= '" . $strOriginalFileName . "',
				strDescription			= '" . $strDescription . "',
				intPosition				= " . $intPosition . "
			";
			$this->database->executeQuery($query);
			$arrResult['idFormRecordFile'] = $this->database->getLastInsertedID();
			// if JPEG, create thumbnail
			if ($ext == 'jpg') {
				list($width, $height, $type, $attr) = getimagesize($strDestinationFileFullPath);
				$this->strings->createThumbnail($strDestinationFileFullPath, 'red', $this->strings->intThumbRedSize, round($this->strings->intThumbRedSize * $height / $width), 80);
			}
		}
		return $arrResult;
	}
	
	public function insertFormRecordFileStreetView($idProject, $idFormRecord, $strURL) {
		$strFileName = $this->strings->generateRandomString(10) . '.jpg';
		$strDestinationFileFullPath = $this->strings->strProjectFolder . '/' . $idProject . '/' . $strFileName;
		@copy($strURL, $strDestinationFileFullPath);
		$arrResult = array();
		$query = "
		INSERT INTO 
			formrecordfile
		SET
			idFormRecord			= " . $idFormRecord . ",
			strFileName				= '" . $strFileName . "',
			strFileOriginalName		= '" . basename($strFileName) . "',
			strDescription			= 'Google Maps capture',
			intPosition				= 9999
		";
		$this->database->executeQuery($query);
		$arrResult['idFormRecordFile'] = $this->database->getLastInsertedID();
		// Create thumbnail
		list($width, $height, $type, $attr) = getimagesize($strDestinationFileFullPath);
		$this->strings->createThumbnail($strDestinationFileFullPath, 'red', $this->strings->intThumbRedSize, round($this->strings->intThumbRedSize * $height / $width), 80);
		return $arrResult;
	}

	public function insertFormRecordFileURL($idProject, $idFormRecord, $strURL, $strDescription = '', $intPosition = 999) {
		$strFileName = $this->strings->generateRandomString(10);
		$strDestinationFileFullPath = $this->strings->strProjectFolder . '/' . $idProject . '/' . $strFileName;
		if (strpos($strURL, 'youtube.com/watch?v=') !== FALSE) { // YouTube
			$strURL = (strpos($strURL, '://') === FALSE ? 'https://' : '') . $strURL;
			$arr = explode('=', $strURL);
			@copy('http://img.youtube.com/vi/' . $arr[1] . '/hqdefault.jpg', $strDestinationFileFullPath . 'red.jpg');
			$strFileName .= '.jpg';
		} else {
			$strFileName = '';
			$strDescription = $strURL;
		}
		$arrResult = array();
		$query = "
		INSERT INTO 
			formrecordfile
		SET
			idFormRecord			= " . $idFormRecord . ",
			strFileName				= '" . $strFileName . "',
			strFileOriginalName		= '" . $strURL . "',
			strDescription			= '" . $strDescription . "',
			intPosition				= " . $intPosition . "
		";
		$this->database->executeQuery($query);
		$arrResult['idFormRecordFile'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function updateIdFormRecordFile($idFormRecordFile, $idUser) {
		$query = "UPDATE formrecordfile	SET idFormRecord=" . $idFormRecordFile . " WHERE idFormRecord=-" . $idUser;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function deleteFormRecordFile($idProject, $idFormRecordFile) {
		// Delete File
		$arrFormRecordFile = $this->selectFormRecordFiles($idProject, 0, $idFormRecordFile);
		@unlink($arrFormRecordFile[0]['strFileNameFullPath']);
		@unlink($arrFormRecordFile[0]['strFileNameFullPathRed']);
		// Delete Record
		$query = "DELETE FROM formrecordfile WHERE idFormRecordFile = " . $idFormRecordFile;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
	
	public function updateDescriptionFormRecordFile($idFormRecordFile, $strDescription) {
		$query = "UPDATE formrecordfile SET strDescription = '" . $strDescription . "' WHERE idFormRecordFile = " . $idFormRecordFile;
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
		
	public function reorderFormRecordFiles($strIds) {
		$arrIds = explode(',', $strIds);
		$i=1;
		foreach ($arrIds as $idFormRecordFile) {
			if (! is_numeric($idFormRecordFile)) continue;
			$query = "UPDATE formrecordfile SET intPosition=" . $i . " WHERE idFormRecordFile=" . $idFormRecordFile;
			$result = $this->database->executeQuery($query);
			$i++;
		}
		return 1;
	}
		
	// Form Record Fields
	public function insertFormRecordField($idFormRecord, $idFormField) {
		$query = "INSERT INTO formrecordfield SET idFormField = " . $idFormField . ", idFormRecord = " . $idFormRecord;
		$this->database->executeQuery($query);
		return $this->database->getLastInsertedID();
	}
	
	public function insertFormRecordFieldText($idFormRecord, $idFormField, $strValue) {
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$query = "INSERT INTO formrecordfieldtext SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", strValue = '" . utf8_decode($strValue) . "'";
		$this->database->executeQuery($query);
		$arrResult['idText'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function insertFormRecordFieldNumeric($idFormRecord, $idFormField, $dblValue) {
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$query = "INSERT INTO formrecordfieldnumeric SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", dblValue = '" . $dblValue . "'";
		$this->database->executeQuery($query);
		$arrResult['idNumeric'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function insertFormRecordFieldAlternative($idFormRecord, $idFormField, $stridFormFieldAlternatives) {
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$arrIdFormFieldAlternatives = explode(',', $stridFormFieldAlternatives);
		foreach ($arrIdFormFieldAlternatives as $idFormFieldAlternative) {
			if (! is_numeric($idFormFieldAlternative)) continue;
			$query = "INSERT INTO formrecordfieldalternative SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", idFormFieldAlternative = " . $idFormFieldAlternative;
			$this->database->executeQuery($query);
		}
		return $arrResult;
	}
	
	public function insertFormRecordFieldDate($idFormRecord, $idFormField, $dtValue) {
		if (! $dtValue) return false;
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$query = "INSERT INTO formrecordfielddate SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", dtValue = '" . $dtValue . "'";
		$this->database->executeQuery($query);
		$arrResult['idDate'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function insertFormRecordFieldTime($idFormRecord, $idFormField, $tmValue) {
		if (! $tmValue) return false;
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$query = "INSERT INTO formrecordfieldtime SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", tmValue = '" . $tmValue . "'";
		$this->database->executeQuery($query);
		$arrResult['idTime'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function insertFormRecordFieldTimeSeries($idFormRecord, $idFormField, $strValues) {
		$arrResult = array();
		$arrResult['idFormRecordField'] = $this->insertFormRecordField($idFormRecord, $idFormField);
		$arrValues = explode('|', $strValues);
		foreach ($arrValues as $strValue) {
			if (! $strValue) continue;
			$arrValue = explode(chr(9), $strValue);
			if (count($arrValue) != 2) continue;
			$dtDateTime = $arrValue[0] . ':00';
			$dtDateTime = str_replace('T',' ', $dtDateTime);
			$strValue = $arrValue[1];
			$query = "INSERT INTO formrecordfieldtimeserie SET idFormRecordField = " . $arrResult['idFormRecordField'] . ", dtDateTime = '" . $dtDateTime . "', strValue = '" . utf8_decode($strValue) . "'";
			$this->database->executeQuery($query);
		}
	}
	
	public function strIdAlternativesFormRecord($idFormField, $strAlternatives) {
		$arrIds = array();
		if (! $strAlternatives) return $arrIds;
		$arrAlternatives = explode(',', $strAlternatives);
		$strAlternativesSQL = '';
		foreach ($arrAlternatives as $i => $strAlternative) {
			$strAlternativesSQL .= "strAlternative = '" . $strAlternative . "'" . ( $i < count($arrAlternatives) - 1 ? " OR " : "");
		}
		$query = "SELECT idFormFieldAlternative FROM idFormField = " . $idFormField . " AND (" . $strAlternativesSQL . ")";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		foreach ($result as $idLine => $item) {
			$arrIds[] = $item['idFormFieldAlternative'];
		}
		return implode(',', $arrIds);
	}
	
	public function arrVertexsDimensions($arrVertexs, $arrCentroid, $idShapeType) {
		$dblPerimeterMts = 0;
		$dblXMax = 0; $dblXMin = 9999; $dblYMax = 0; $dblYMin = 9999;
		foreach ($arrVertexs as $i => $arrVertex) {
			$this->gPoint->setLongLat($arrVertex['dblLongitude'], $arrVertex['dblLatitude']);
			$dblPerimeterMts += $this->gPoint->distanceFrom($arrVertexs[$i < count($arrVertexs) - 1 ? $i + 1 : 0]['dblLongitude'], $arrVertexs[$i < count($arrVertexs) - 1 ? $i + 1 : 0]['dblLatitude']);
			if ($idShapeType == 3) {
				$this->gPoint->setLongLat($arrCentroid['dblLongitude'], $arrCentroid['dblLatitude']);
				$arrVertexs[$i]['X'] = $this->gPoint->distanceFrom($arrVertex['dblLongitude'], $arrCentroid['dblLatitude']);
				if (is_nan($arrVertexs[$i]['X'])) $arrVertexs[$i]['X'] = 0;
				if ($arrVertex['dblLongitude'] < $arrCentroid['dblLongitude']) $arrVertexs[$i]['X'] = -$arrVertexs[$i]['X'];
				$arrVertexs[$i]['Y'] = $this->gPoint->distanceFrom($arrCentroid['dblLongitude'], $arrVertex['dblLatitude']);
				if (is_nan($arrVertexs[$i]['Y'])) $arrVertexs[$i]['Y'] = 0;
				if ($arrVertex['dblLatitude'] < $arrCentroid['dblLatitude']) $arrVertexs[$i]['Y'] = -$arrVertexs[$i]['Y'];
			}
		}
		$dblAreaMts2 = 0;
		if ($idShapeType == 3) {
			$j = count($arrVertexs)-1;
			for ($i=0;$i<count($arrVertexs);$i++) {
				//area = area +  (X[j]+X[i]) * (Y[j]-Y[i]); 
				$dblAreaMts2 += ($arrVertexs[$j]['X'] + $arrVertexs[$i]['X']) * ($arrVertexs[$j]['Y'] - $arrVertexs[$i]['Y']);
				$j = $i;
			}
			$dblAreaMts2 = abs($dblAreaMts2/2);
		}
		return array('dblPerimeterMts' => $dblPerimeterMts, 'dblAreaMts2' => $dblAreaMts2);
	}	
	
	public function arrFormRecordLastUpdateEvent($idFormRecord) {
		$query = "
		SELECT 
			e.dtDateTime,
			u.strEmail
		FROM
			event e, user u
		WHERE
			e.idUser = u.idUser AND
			e.strParam1 = " . $idFormRecord . " AND
			e.idEventType = 14
		ORDER BY e.idEvent DESC
		LIMIT 1
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		return $result[0];
	}
	
	// formrecordlog
	public function selectFormRecordLog($idFormRecord) {
		$query = "
			SELECT 
				frl.idFormRecordLog,
				frl.idFormRecord,
				frl.idUser,
				frl.dtDateTime,
				frl.txtLog,
				u.strName AS strUserName
			FROM 
				formrecordlog	frl,
				user			u
			WHERE 
				frl.idUser 			= u.idUser AND
				frl.idFormRecord	= " . $idFormRecord . "
			ORDER BY
				frl.dtDateTime DESC
		";
		$result = $this->database->executeQuery($query);
		$result = $this->database->prepareReturn($result);
		$strLog = '';
		foreach ($result as $idLine => $item) {
			$result[$idLine]['strDateTime'] = date('d/m/Y H:i', strtotime($result[$idLine]['dtDateTime']));
			$blnCreated = ($idLine == count($result)-1);
			$strLog .= '<div style="width:100%"><b>' . $result[$idLine]['strDateTime'] . ' <span style="color:' . ($blnCreated ? '#006600' : '#0000FF'). '">' .  strtolower($blnCreated ? $_SESSION['strGlobalCreated'] : $_SESSION['strGlobalUpdated']) . '</span> ' . $_SESSION['strGlobalBy'] . ' <i class="icon-user"></i>' . $result[$idLine]['strUserName'] . '</b><table class="tblLog table table-striped table-bordered bootstrap-datatable datatable" style="background-color:#FFFFFF;width:100%">' . $result[$idLine]['txtLog'] . '</table></div>';
		}
		$arrResult = array();
		$arrResult['strLog'] = $strLog;
		return $arrResult;
	}

	public function insertFormRecordLog($idFormRecord, $idUser, $txtLog) {
		$query = "
			INSERT INTO 
				formrecordlog
			SET 
				idFormRecord	= " . $idFormRecord . ",
				idUser			= " . $idUser . ",
				dtDateTime		= NOW(),
				txtLog			= '" . $txtLog . "'
		";
		$this->database->executeQuery($query);
		$arrResult = array();
		$arrResult['idFormRecordLog'] = $this->database->getLastInsertedID();
		return $arrResult;
	}
	
	public function deleteFormRecordLog($idFormRecord = 0, $idUser = 0) {
		$query = "DELETE FROM formrecordlog WHERE " . ($idFormRecord > 0 ? "idFormRecord = " . $idFormRecord : "") . ($idUser > 0 ? "idUser = " . $idUser : "");
		$this->database->executeQuery($query);
		return $this->database->getNumAffectedRows();
	}
}
?>