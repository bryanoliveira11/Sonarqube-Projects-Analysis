<?php
/* String Manipulation Functions Lib */
class Strings {
	public $strSiteURL;
	public $strSiteReleaseVersion		= '2015-09-09';
	public $strSiteReleaseFolder 		= 'releases';
	public $strSiteName 				= 'Vicon SAGA';
	public $strSiteEmail 				= 'contato@viconsaga.com.br';
	public $strSiteLogoPath				= 'img/logo.png';
	public $strSiteDefaultBackgroundFile= 'img/backgrounds/1.jpg';
	public $strSQLDatabaseFile			= 'schema/viconsaga.sql';
	public $strSiteDefaultLanguage 		= 'br';
	public $strConnectionFileName		= 'connection.inc';
	public $strSiteDefaultAdminEmail	= 'admin';
	public $strSiteDefaultAdminPassword	= 'admin';
	public $strSiteAuthorName			= 'LAGEOP/UFRJ';
	public $strSiteAuthorEmail			= 'tiagomarino@hotmail.com';
	public $strSiteBaseColor			= '#d44413';
	public $strSiteBaseColorLight;
	public $strSiteBaseColorDark;
	public $strSiteTmpFileFolder		= 'tmp';
	public $strSiteDefaultHomePage		= 'home';
	public $strLiveKMLFileName			= 'records.kml';
	public $intThumbSize				= 100;
	public $intThumbRedSize				= 200;
	public $intCookieLifeSec			= 31104000; // 1 year
	public $intFieldLevelIndentPx		= 20;
	public $intVertexsLimit				= 30;
	public $intMaxploadFileSizeMB		= 20;
	public $intDefaultDatum				= 23; // WGS 84
	public $strImageWatermarkFont		= 'img/fonts/african.ttf';
	public $GoogleAPIKey 				= 'AIzaSyASJbspnBPxwtj3g0NZzZMmV5hNOVBbHHQ';
	public $strGoogleMapsDefaultTypeMap = 'HYBRID';
	public $strProjectFolder			= 'projects';
	public $strSupportFolder			= 'support';
	public $strMarkerFolder				= 'img/markers';
	public $strDevicesFolder			= 'img/devices';
	public $strIconsFolder				= 'img/filetypes';
	public $idMarkerDefault				= 1;
	public $strSiteSkypeID 				= '';
	public $strSiteFacebookID 			= '';
	public $strSiteTwitterID 			= '';
	public $strSiteYoutubeID 			= '';
	public $strSiteGooglePlusID 		= '';

	public function __construct() {
		// Set INI parameters
		ini_set('short_open_tag', 1); 
		ini_set('display_errors', 0); 
		ini_set('memory_limit', '-1');
		ini_set('allow_url_fopen', 'on');
		ini_set('upload_max_filesize', $this->intMaxploadFileSizeMB . 'M');
		ini_set('post_max_size', $this->intMaxploadFileSizeMB . 'M');
		$this->strSiteURL = 'http://' . $_SERVER["HTTP_HOST"];
		if ((strpos($_SERVER["HTTP_HOST"],'calhost') > 0) || (strpos($_SERVER["HTTP_HOST"],'92.168.') > 0)) { 
			$arrParms = explode('/', $_SERVER["PHP_SELF"]);
			$this->strSiteURL = 'http://' . $_SERVER["HTTP_HOST"] . '/' . $arrParms[1];
		}
		$this->strSiteBaseColorLighter = $this->strRGBLighter($this->strSiteBaseColor, 90);
		$this->strSiteBaseColorLight = $this->strRGBLighter($this->strSiteBaseColor, 80);
		$this->strSiteBaseColorDark = $this->strRGBDarker($this->strSiteBaseColor, 70);
	}

	public function checkCreateFolders($strPrefix = '') {
		// Creating folders if not exists
		if (! file_exists($strPrefix . $this->strProjectFolder)) {
			mkdir($strPrefix . $this->strProjectFolder);
		}
		if (! file_exists($strPrefix . $this->strSiteTmpFileFolder)) {
			mkdir($strPrefix . $this->strSiteTmpFileFolder);
		}
	}
	
	public function log($str, $strFileName = 'tmp/out.txt', $blnAppend = false){
		$fh = @fopen($strFileName, $blnAppend ? 'a' : 'w'); 
		if ($blnAppend) {
			fputs($fh, "[" . date('H:i:s', time()) . "] " .  $str . chr(13));
		} else {
			fwrite($fh, $str);
		}
		fclose($fh);
	}

	public function array_reorder($array, $oldIndex, $newIndex) {
		array_splice(
			$array,
			$newIndex,
			count($array),
			array_merge(
				array_splice($array, $oldIndex, 1),
				array_slice($array, $newIndex, count($array))
			)
		);
		return $array;
	}

	public function strCurrentReleaseDate(){
		$arrResult = array();
		$arr = explode('-', $this->strSiteReleaseVersion);
		$strDateCurrentRelease =  $arr[2] . '/' . $arr[2] . '/' . $arr[0];
		return $strDateCurrentRelease;
	}

	public function convertToDefaultTimeZone($dtDate) {
		$date = new DateTime($dtDate);
		$date->setTimeZone(new DateTimeZone(date_default_timezone_get()));
		return $date;
	}

	public function writeStringToFile($txtInput, $strBreakLine = '<br>', $strExt) {
		$strFileName = $this->strSiteTmpFileFolder . '/' . $this->generateRandomString(10) . '.' . $strExt;
		$txtInput = str_replace($strBreakLine, chr(13), $txtInput);
		$fh = fopen($strFileName, 'w');
		fwrite($fh, $txtInput);
		fclose($fh);
		$arrReturn = array();
		$arrReturn['strFileName'] = $strFileName;
		return $arrReturn;
	}

	public function printPageSession($vtSession, $strIcon){
		echo '
				<div>
					<ul class="breadcrumb" style="font-weight:bold"><i class="' . $strIcon . '"></i>';
		$i = 0;
		foreach($vtSession as $item) {
			echo '				<li>' . $item . '</li>';
			$i++;
			if (($i > 0) && ($i < count($vtSession))) {
			echo '				<span class="divider">/</span>';
			}
		}
		echo '
					</ul>
				</div>
				<!-- Onde mensagens do sistema ser�o notificadas -->
				<div id="divMessage"></div>
				';
	}

	function strSkypeUserStatus($strUserID, $intIconSize = 24, $blnWriteStatus = true, $strPrefixFolder = '') {
		$xml = simplexml_load_string($this->processUrl("http://mystatus.skype.com/" . $strUserID . ".xml"));
		if ($xml) {
			$arr = $this->arrXMLtoArray($xml);
		}
		$idStatusCode = ($arr['Status']['statusCode'] ? $arr['Status']['statusCode'] : 1); // 1 = Offline
		return '<a style="cursor:pointer;margin-right:5px;" href="skype:' . $strUserID . '?call" title="' . $strUserID . ' - ' . $_SESSION["strSkypeStatusTitle"] . ': ' . $_SESSION["strSkypeStatus_" . $idStatusCode] . ($idStatusCode > 1 ? ' - ' . $_SESSION["strSkypeStatusClickTalk"] : ''). '"><img style="width:' . $intIconSize . 'px;height:' . $intIconSize . 'px;" src="' . $strPrefixFolder . 'img/skype/' . $idStatusCode . '.png">' . ($blnWriteStatus ? ' ' . $_SESSION["strSkypeStatusTitle"] . ': ' . $_SESSION["strSkypeStatus_" . $idStatusCode] : '') . '</a>';
	}

	/**************************************************************************************
								SITE LANGUAGES HANDLING
	**************************************************************************************/
	function loadLanguagesList() {
		$strLanguageFile = 'strings.csv';
		if($fh = fopen($strLanguageFile, 'r')){
			$conteudo_arquivo = fread($fh, filesize($strLanguageFile));
			fclose($fh);
		}
		$linhas = explode(chr(13), $conteudo_arquivo);
		$linha_0 = substr($linhas[0],strpos($linhas[0],';')+1,strlen($linhas[0]));
		$linha_1 = substr($linhas[1],strpos($linhas[1],';')+1,strlen($linhas[1]));
		$colunas_0 = explode(';', $linha_0);
		$colunas_1 = explode(';', $linha_1);
		$lista = '';
		$i = 0;
		foreach($colunas_1 as $item) {
			$lista .= $item . ':' . $colunas_0[$i] . ';';
			$i++;
		}
		$lista = substr($lista,0,strlen($lista) - 1);
		$colunas = explode(';', $lista);
		return $colunas;
	}

	function loadLanguage($strLangCode, $strPrefix = '') {
		// If do not find $strLangCode, set default
		$intLanguageCol = 2; // Default 'us'
		$strLanguageFile = $strPrefix . 'strings.csv';
		// Getting first line with lang codes
		if($fh = fopen($strLanguageFile, 'r')){
			$strFileContent = fread($fh, filesize($strLanguageFile));
		}
		$arrLines = explode(chr(13), $strFileContent);
		$arrColsLine0 = explode(';', $arrLines[0]);
		$i = 0;
		foreach ($arrColsLine0 as $strFileLangCode) {
			if (strtolower($strFileLangCode) == strtolower($strLangCode)) {
				$intLanguageCol = $i;
				break;
			}
			$i++;
		}
		// Now getting, for each line, expression from respective language column
		foreach ($arrLines as $strLine) {
		  $arrLineCells = explode(';', $strLine);
		  $_SESSION[trim($arrLineCells[0])] =  trim($arrLineCells[$intLanguageCol]);
		}
		fclose($fh);
		// Setting Currency Region
		//setlocale(LC_MONETARY, $strLangCode);
		// Setting Currency Symbol in function of Broker Region (strLanguageCode)
		$_SESSION['strMoneyCurrency'] = ($strLangCode == 'br' ? 'BRL' :'USD');
	}

	/**************************************************************************************
								STRINGS HANDLING
	**************************************************************************************/
	public function strAddURL($strText) {
			//$strImg = preg_replace('!(http|ftp|scp)(s)?:\/\/[a-zA-Z0-9.?&_/]+!', '<img src="\\0" style="width:100px;height:100px;" class="rounded" onClick="$.fancybox({\'href\':\'\\0\', \'width\' : \'100%\', \'height\': \'100%\'});"> ', $strText) . '<br>';
			//$strText = preg_replace('!(http|ftp|scp)(s)?:\/\/[a-zA-Z0-9.?&_/]+!', '<a href="\\0">\\0</a>',$strText);
			//return $strImg . $strText;
			$strImg = '';
			$intURLStart = strpos($strText, 'http');
			while ($intURLStart !== FALSE) {
				$intURLEnd = strpos(substr($strText, $intURLStart, strlen($strText)), ' ');
				if (! $intURLEnd > 0) $intURLEnd = strlen($strText);
				$strURL = substr($strText, $intURLStart, $intURLEnd);
				$strExt = strtolower(substr($strURL, strlen($strURL) -3, 3));
				if ($strExt == 'jpg') {
					$strImg .= '
						<img src="' . $strURL . '" style="width:100px;height:100px;" class="rounded" onClick="
				            $.fancybox({\'href\':\'' . $strURL . '\', \'width\' : \'100%\', \'height\': \'100%\'});
						">
					';
					/*$strImg .= '
					<a rel="fancy_group" title="" href="' . $strURL . '">
						<img src="' . $strURL . '" style="width:100px;height:100px;" class="rounded">
					</a>';
					*/
				}
				$strText = str_replace($strURL, '<a href="' . $strURL . '" target="_blank">' . $strURL . '</a>', $strText);
				$strText = preg_replace('/http/', 'htt:p', $strText, 2);
				$intURLStart = strpos($strText, 'http');
			}
			$strText = str_replace('htt:p', 'http', $strText);
			return $strImg . $strText;
	}
	
	// Fun��o para retornar o que est� dentro de uma TAG
	public function strTagContent($strText, $strTag) {
		$strResult = str_replace('<' . $strTag . '>', '', $strText);
		$strResult = str_replace('</' . $strTag . '>', '', $strResult);
		return trim(utf8_decode($strResult));
	}

	public function strHTMLSpectialCharsToHTML($str) {
		$strResult = $str;
		$strResult = html_entity_decode($strResult);
		//$strResult = str_replace("&lt;","<",$strResult);
		//$strResult = str_replace("&gt;",">",$strResult);
		//$strResult = str_replace("&amp;","&",$strResult);
		//$strResult = str_replace("&amp;","&",$strResult);
		$strResult = str_replace("<![CDATA[","",$strResult);
		$strResult = str_replace("]]>","",$strResult);
		return $strResult;
	}

	public function br2nl($text) { 
	   $text = strtr($text, array('<br />' => "\r\n", '<br />' => "\r", '<br />' => "\n")); 
	   $text = strtr($text, array('<br>' => "\r\n", '<br>' => "\r", '<br>' => "\n")); 
	   $text = strtr($text, array('<BR />' => "\r\n", '<BR />' => "\r", '<BR />' => "\n")); 
	   $text = strtr($text, array('<BR>' => "\r\n", '<BR>' => "\r", '<BR>' => "\n")); 
	   return $text;
	} 
	
	public function strImgFilePathByidShapeType($idShapeType) {
		$strShapeType = 'point';
		if ($idShapeType == 2) $strShapeType = 'line';
		if ($idShapeType == 3) $strShapeType = 'polygon';
		return "img/shape-" . $strShapeType . ".png";
	}
	
	public function changePageTitle($strSessionTitle) {
		echo '<script>document.title = "' . strip_tags($strSessionTitle . ' - ' . $this->strSiteName) . '"</script>';
    }
          
	public function getUserLanguage() {
		$langs = array();
		if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
			// break up string into pieces (languages and q factors)
			preg_match_all('/([a-z]{1,8}(-[a-z]{1,8})?)\s*(;\s*q\s*=\s*(1|0\.[0-9]+))?/i',
			$_SERVER['HTTP_ACCEPT_LANGUAGE'], $lang_parse);
			if (count($lang_parse[1])) {
				// create a list like �??en�?? => 0.8
				$langs = array_combine($lang_parse[1], $lang_parse[4]);
				// set default to 1 for any without q factor
				foreach ($langs as $lang => $val) {
					if ($val === '') $langs[$lang] = 1;
				}
				// sort list based on value
				arsort($langs, SORT_NUMERIC);
			}
		}
		//extract most important (first)
		foreach ($langs as $lang => $val) { break; }
		//if complex language simplify it
		if (stristr($lang,"-")) {$tmp = explode("-",$lang); $lang = $tmp[0]; }
		return $lang;
	}

	public function ConvertDateMySQLToBR($data) {
	  // 2012-8-08 18:31:00
	  $params = explode('-', $data);
	  $retorno = substr($params[2],0,2) . '/' . $params[1] . '/' . $params[0];
	  if (strlen($params[2]) > 4) {
		$retorno .= ' ' . substr($params[2],3,2000);
	  }
	  if ($params[3]) {
		$retorno .= ' - ' . $params[3];
	  }
	  return $retorno;
	}

	public function ConvertDateBRToMySQL($data) {
	  // 28/8/2012 18:31:00
	  $params = explode('/', $data);
	  $retorno = substr($params[2],0,4) . '-' . $params[1] . '-' . $params[0];
	  if (strlen($params[2]) > 4) {
		$retorno .= substr($params[2],4,2000);
	  }
	  return $retorno;
	}

	public function extractCode($strText, $strPreviousHashtag) {
		$arrWords = explode(' ', $strText);
		for ($i=0;$i<count($arrWords); $i++) {
			if (strtoupper(trim($strPreviousHashtag)) == trim(strtoupper($arrWords[$i]))) {
				break;
			}
		}
		return trim($arrWords[$i+1]);
	}

	public function highlightText($strText, $strExpression) {
	  if (! $strExpression) return $strText;
	  $strResult = '';
	  $strLeft = ' ' . $strText;
	  while (strpos(strtoupper($strLeft),strtoupper($strExpression)) > 0) {
		$intStartPos = strpos(strtoupper($strLeft),strtoupper($strExpression));
		$intEndPos = $intStartPos + strlen($strExpression);
		$strResult .= substr($strLeft,0,$intStartPos) . '<span class="rounded" style="background: #ffff00">' . $strExpression . '</span>';
		$strLeft = substr($strLeft,$intEndPos, 20000);
	  }
	  $strResult .= substr($strLeft,0,20000);
	  return $strResult;
	}


	public function returnFolderFilesList($strFolderPath) {
	  $arrReturn = array();
	  if ($handle = opendir($strFolderPath)) {
		while (false !== ($file = readdir($handle))) {
		  if (($file == '.') || ($file == '..') || (is_dir($strFolderPath .'/' . $file))) { continue; }
		  array_push($arrReturn, $file);
		}
	  }
	  return $arrReturn;
	}
	
	public function returnFolderFoldersList($strFolderPath) {
	  $arrReturn = array();
	  if ($handle = opendir($strFolderPath)) {
		while (false !== ($file = readdir($handle))) {
			if (is_dir($strFolderPath .'/' . $file)) {
				  array_push($arrReturn, strtolower($file));
			}
		}
	  }
	  return $arrReturn;
	}

	public function htmlEntitiesArray($arr) {
		foreach ($arr as $n => $v) {
			if (is_array($v))
				$arr[$n] = $this->encodeArray($v);
			else {
				$arr[$n] = htmlentities($arr[$n]);
			}
		}
		return $arr;
	}

	public function strIconFileExtension($strExt) {
		$strIconFile = $this->strIconsFolder . '/' . $strExt . '.png';
		if (! file_exists($strIconFile)) {
			$strIconFile = $this->strIconsFolder . '/unkown.png';
		}
		return $strIconFile;
	}
	
	public function strStringfyCoordinatesKML($arrVetexs) {
		$strVetexs = '';
		foreach ($arrVetexs as $i => $arrVetex) {
			$strVetexs .= $arrVetex['dblLongitude'] . ',' . $arrVetex['dblLatitude'] . ' ';
		}
		return trim($strVetexs);
	}

	public function encodeArray($arr) {
		foreach ($arr as $n => $v) {
			if (is_array($v))
				$arr[$n] = $this->encodeArray($v);
			else {
				$arr[$n] = utf8_encode($arr[$n]);
			}
		}
		return $arr;
	}

	public function decodeArray($arr) {
		foreach ($arr as $n => $v) {
			if (is_array($v))
				$arr[$n] = $this->decodeArray($v);
			else {
				$arr[$n] = utf8_decode($arr[$n]);
			}
		}
		return $arr;
	}

	public function removeCharAccent($string) {
		$low=array("�" => "A", "�" => "O", "�" => "A", "�" => "C", "�" => "A", "�" => "A", "�" => "E",
		"�" => "I", "�" => "O", "�" => "U", "�" => "U", "�" => "N", "�" => "O", "�" => "o",
		"�" => "a", "�" => "o", "�" => "a", "�" => "c", "�" => "a", "�" => "a", "�" => "e", "�" => "E", "�" => "e",
		"�" => "i", "�" => "o", "�" => "u", "�" => "u");
		return strtr($string,$low);
	}

	public function changeCharAccent($string) {
		$low=array("�" => "A", "�" => "O", "�" => "A", "�" => "C", "�" => "A", "�" => "A", "�" => "E",
		"�" => "I", "�" => "O", "�" => "U", "�" => "U", "�" => "N", "�" => "O", "�" => "o",
		"�" => "a", "�" => "o", "�" => "a", "�" => "c", "�" => "a", "�" => "a", "�" => "e", "�" => "E", "�" => "e",
		"�" => "i", "�" => "o", "�" => "u", "�" => "u");
		return strtr($string,$low);
	}

	public function swapCharToTripleAccent($string) {
		$low=array("�" => "A_CIR", "�" => "O_TIL", "�" => "A_CRAS", "�" => "C_CED", "�" => "A_TIL", "�" => "A_AGU", "�" => "E_AGU",
		"�" => "I_AGU", "�" => "O_AGU", "�" => "U_AGU", "�" => "U_TRE", "�" => "N_TIL", "�" => "O_CIR", "�" => "o_CIR",
		"�" => "a_CIR", "�" => "o_TIL", "�" => "a_CRA", "�" => "c_CED", "�" => "a_TIL", "�" => "a_AGU", "�" => "e_AGU", "�" => "E_CIR", "�" => "e_CIR",
		"�" => "i_AGU", "�" => "o_AGU", "�" => "u_AGU");
		return strtr($string,$low);
	}

	public function swapTripleAccentToChar($string) {
		$low = array("A_CIR" => "�", "O_TIL" => "�", "A_CRAS" => "�", "C_CED" => "�", "A_TIL" => "�", "A_AGU" => "�", "E_AGU" => "�",
		"I_AGU" => "�", "O_AGU" => "�", "U_AGU" => "�", "U_TRE" => "�", "N_TIL" => "�", "O_CIR" => "�", "o_CIR" => "�",
		"a_CIR" => "�", "o_TIL" => "�", "a_CRA" => "�", "c_CED" => "�", "a_TIL" => "�", "a_AGU" => "�", "e_AGU" => "�", "E_CIR" => "�", "e_CIR" => "�",
		"i_AGU" => "�", "o_AGU" => "�", "u_AGU" => "�");
		return strtr($string,$low);
	}

	public function strGenerateRandonColor() {
		$r = dechex(mt_rand(0,255)); // generate the red component
		$g = dechex(mt_rand(0,255)); // generate the green component
		$b = dechex(mt_rand(0,255)); // generate the blue component
		$rgb = $r.$g.$b;
		if($r == $g && $g == $b){
			$rgb = substr($rgb,0,3); // shorter version
		}
		return $rgb;
	}

	public function strColorConvertDecToRGB($i) {
		$strRGB = array();
		$strRGB['R'] = floor($i / (256 * 256));
		$strRGB['G'] = floor($i / 256);
		$strRGB['B'] = $i % 256;
		return $strRGB;
	}

	function strSwapRGBToBGR($strRGB) {
		return substr($strRGB,4,2) . substr($strRGB,2,2) . substr($strRGB,0,2);
	}

	function strRGBDarker($hex, $factor = 30) {
		$new_hex = '';
		$base['R'] = hexdec($hex{0}.$hex{1});
		$base['G'] = hexdec($hex{2}.$hex{3});
		$base['B'] = hexdec($hex{4}.$hex{5});
		foreach ($base as $k => $v) {
			$amount = $v / 100;
			$amount = round($amount * $factor);
			$new_decimal = $v - $amount;
			$new_hex_component = dechex($new_decimal);
			if(strlen($new_hex_component) < 2) {
			  $new_hex_component = "0".$new_hex_component;
			}
			$new_hex .= $new_hex_component;
		}
		return $new_hex;        
	}

	function strRGBLighter($hex, $factor = 30) {
	  $new_hex = '';
	  $base['R'] = hexdec($hex{0}.$hex{1});
	  $base['G'] = hexdec($hex{2}.$hex{3});
	  $base['B'] = hexdec($hex{4}.$hex{5});
	  foreach ($base as $k => $v) {
		$amount = 255 - $v;
		$amount = $amount / 100;
		$amount = round($amount * $factor);
		$new_decimal = $v + $amount;
		$new_hex_component = dechex($new_decimal);
		if(strlen($new_hex_component) < 2) {
		  $new_hex_component = "0".$new_hex_component;
		}
		$new_hex .= $new_hex_component;
	  }
	  return $new_hex;
	}

	public function strUpperAccents($str) {
		return strtoupper(strtr($str,"����������������","����������������"));
	}

	public function money_format($dblNumber, $strCurrencySymbol = ''){
		if (! $strCurrencySymbol) $strCurrencySymbol = $_SESSION["strMoneyCurrency"];
		return $strCurrencySymbol . ' ' . number_format($dblNumber, 2, $_SESSION["strDecimal"], $_SESSION["strThousands"]);
	}
	
	public function strMesExtensoPTBR($MES){ 
		switch ($MES) {  
			case 1 : $MES='Janeiro'; break; 
			case 2 : $MES='Fevereiro';    break; 
			case 3 : $MES='Mar�o';    break; 
			case 4 : $MES='Abril';    break; 
			case 5 : $MES='Maio';    break; 
			case 6 : $MES='Junho';    break; 
			case 7 : $MES='Julho';    break; 
			case 8 : $MES='Agosto';    break; 
			case 9 : $MES='Setembro'; break; 
			case 10 : $MES='Outubro'; break; 
			case 11 : $MES='Novembro';    break; 
			case 12 : $MES='Dezembro'; break; 
		} 
		return $MES; 
	} 

	public function sendMail($strSubject, $strBody, $strFrom, $strTo, $strBcc='') {
		$strAdicional = "From: " . $strFrom . "\r\nMIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\n";
		$blnResult = @mail($strTo, $strSubject, $strBody, $strAdicional, '-r' . $strFrom);
		return $blnResult;
	}

	public function mailFormatContent($intFromDepartment, $strTitle, $strTextTop, $strTextBottom, $arrSessions, $strSiteURLParams = '') {
		// 1 = Dpto Financeiro, 2 = Suporte T�cnico
		$strBaseColor = '#CC0041';
		$strBody = '	
		<!DOCTYPE html>
		<html lang="pt-BR">
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<title>' . $strTitle . '</title>
		</head>
		<body rightmargin="0" leftmargin="0" topmargin="0" bottommargin="0" style="margin: 0px;">
		<style>
			body, p, td { font-family: Tahoma, Verdana, Arial, Helvetica; font-size: 11px; line-height: 15px; color: #666666;}
			h1{ font-family: Arial, Verdana, Tahoma; font-size: 14px; color: #666666; text-decoration: uppercase;}
			.rounded { -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px; opacity: 1!important; }
		</style>
		<link href=\'http://fonts.googleapis.com/css?family=Hammersmith+One\' rel=\'stylesheet\' type=\'text/css\'>
		<table background="' . $this->strSiteURL . '/img/mail_body-bg.gif" cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td bgcolor="' . $strBaseColor . '">
				<table align="center" cellpadding="0" cellspacing="0" width="570px">
				<tr>
					<td valign="middle" height="72px">
						<a title="' . $this->strSiteName . '" href="' . $this->strSiteURL . '" target="_blank" 
							style="text-decoration:none;font-size:40px;font-family: \'Hammersmith One\', sans-serif;color:#FFFFFF;font-weight:bold;	letter-spacing:3px;"
						 >
							<img src="' . $this->strSiteURL . '/' . $this->strSiteLogoPath .'" width="60px" height="60px" border="0" align="absmiddle" style="margin-right:10px;"/>
							<span style="margin-top:30px;position:absolute">' . $this->strSiteName . '</span>
						</a>
					</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table align="center" cellpadding="0" cellspacing="0" style="background-color:#ffffff" width="570px">
				<tr>
					<td colspan="2" style="font-size: 11px; font-family: Tahoma;">
						<table align="center" width="570px" cellpadding="10" cellspacing="0">
						<tr>
							<td>
								<p>' . $strTextTop . '</p>
		';
		foreach($arrSessions as $arrLine) {
			$strBody .= '
									<table width="100%" border="0">
									<tr>
										<td style="padding-left:10px;background-color:' . $strBaseColor . ';" valign="middle"><p style="color:#FFFFFF"><b>' . $arrLine['strTitle'] . '</b></p></td>
									</tr>
									<tr>
										<td bgcolor="#F0F0F0" style="padding:10px;" class="rounded">
										' . $arrLine['strContent'] . '
										</td>
									</tr>
									</table>
									<br />
			';
		}
		if ($strSiteURLParams) {
			$strBody .= '<p style="text-align:center"><a href="' . $this->strSiteURL . '/' .  $strSiteURLParams .'" target="_blank"><input type="button" value="' . $_SESSION['strMailGoToSite'] . '" style="color:#ffffff;font-weight:bold;cursor:pointer;background-color:' . $strBaseColor . '" class="rounded"></a></p>';
		}
		$strBody .= '
									<p>' . $strTextBottom . '</p>
									<p>
										' . $_SESSION['strMailYoursSincerly'] . ',<br />
										' . $_SESSION['strMailDept_' . $intFromDepartment] . ' - ' . $this->strSiteName . '
									</p>
									<p>
										<a href="' . $this->strSiteURL . '" target="_blank">' . $this->strSiteURL . '</a><br />
										<a href="mailto:' . $this->strSiteEmail . '">' . $this->strSiteEmail . '</a>
									</p>
								</p>
							</td>
						</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td width="10" align="left" valign="bottom">&nbsp;</td>
					<td width="10" align="right" valign="bottom">&nbsp;</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td height="20px"></td>
		</tr>
		</table>
		</body>
		</html>
		';
		return $strBody;
	}

	public function extractIntNumber($str) {
		$intStart = -1;
		$intStop = -1;
		for ($i=0;$i<strlen($str);$i++) {
			if (($intStart >= 0) && ($intStop >= 0) && (! is_numeric($str[$i]))) { break; }

			if (($intStart < 0) && (is_numeric($str[$i]))) {
				$intStart = $i;
			}
			if (($intStart >= 0) && (is_numeric($str[$i]))) {
				$intStop = $i;
			}
		}
		$intNumber = substr($str, $intStart, $intStop - $intStart + 1);
		if (is_numeric($intNumber)) {
			return $intNumber;
		} else {
			return -1;
		}
	}
	
	public function strGenerateStaticMapsURL($idShapeType, $strRGB, $strFormName, $arrVtcs, $dblLatC = '', $dblLngC = '', $strMapType = '') {
		$strRGB = str_replace('#','', $strRGB);
		$strPath = '';
		if (count($arrVtcs) > $this->intVertexsLimit) {
			$arrVtcs = $this->arrSimplifyArrayVertexs($arrVtcs, $this->intVertexsLimit);
		}
		foreach($arrVtcs as $n => $arrVtc) {
			$strPath .= $arrVtc['dblLatitude'] . ',' . $arrVtc['dblLongitude'] . (($n < count($arrVtcs) - 1) ? "|" : "");
		}
		if ($idShapeType == 3) {
			$strPath .= "|" . $arrVtcs[0]['dblLatitude'] . ',' . $arrVtcs[0]['dblLongitude'];
		}
		$strStaticGoogleMapsThumbURL = 'http://maps.google.com/maps/api/staticmap?size=480x480&sensor=false&maptype=' . strtolower($strMapType ? $strMapType : $this->strings->strGoogleMapsDefaultTypeMap) . '&key=' . $this->GoogleAPIKey;
		if ($idShapeType == 1) { 			// Point
			$strStaticGoogleMapsThumbURL .= $dblLatC ? '&markers=color:green%7Clabel:C%7C' . $dblLatC . ',' . $dblLngC : ''; // Center Marker
			$strStaticGoogleMapsThumbURL .= '&markers=color:red%7Clabel:' . $strFormName[0] . '%7C' . $strPath;
		} else if ($idShapeType == 2) {	// Polyline
			$strStaticGoogleMapsThumbURL .= '&path=color:0x' . $strRGB . '|weight:2|' . $strPath;
		} else if ($idShapeType == 3) {	// Polygon
			$strStaticGoogleMapsThumbURL .= '&path=fillcolor:0x' . $strRGB . '|color:0x' . $strRGB . '|weight:2|' . $strPath;
		}
		
		return $strStaticGoogleMapsThumbURL;
	}

	public function blnIsDevice($type = NULL) {
       $user_agent = strtolower ( $_SERVER['HTTP_USER_AGENT'] );
        if ( $type == 'bot' ) {
                // matches popular bots
                if ( preg_match ( "/googlebot|adsbot|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/", $user_agent ) ) {
                        return true;
                        // watchmouse|pingdom\.com are "uptime services"
                }
        } else if ( $type == 'browser' ) {
                // matches core browser types
                if ( preg_match ( "/mozilla\/|opera\//", $user_agent ) ) {
                        return true;
                }
        } else if ( $type == 'mobile' ) {
                // matches popular mobile devices that have small screens and/or touch inputs
                // mobile devices have regional trends; some of these will have varying popularity in Europe, Asia, and America
                // detailed demographics are unknown, and South America, the Pacific Islands, and Africa trends might not be represented, here
                if ( preg_match ( "/phone|iphone|itouch|ipod|symbian|android|htc_|htc-|palmos|blackberry|opera mini|iemobile|windows ce|nokia|fennec|hiptop|kindle|mot |mot-|webos\/|samsung|sonyericsson|^sie-|nintendo/", $user_agent ) ) {
                        // these are the most common
                        return true;
                } else if ( preg_match ( "/mobile|pda;|avantgo|eudoraweb|minimo|netfront|brew|teleca|lg;|lge |wap;| wap /", $user_agent ) ) {
                        // these are less common, and might not be worth checking
                        return true;
                }
        }
        return false;
	}

	public function removeInvalidCharsSQL($str) {
		$str = trim($str);
		$str = str_replace('"', '', $str);
		$str = str_replace("'", '', $str);
		return $str;
	}

	public function removeInvalidChars($str) {
		$str = trim($str);
		$low = array("&" => "", "/" => "", "|" => "", "\\" => "", '"' => "", "'" => "", "+" => "", "-" => "", "#" => "");
		$str = strtr($str, $low);
		$str = preg_replace( "/\r|\n/", "", $str);
		return $str;
	}

	// $strMessage = 'This is a message #Longitude=-23.2423; #Latitude=-23.434254; like semantic blog information'
	// $strSearchFieldTag = Latitude;
	public function strSearchTagAndReturnValue($strMessage, $strSearchFieldTag) {
		$strValue = '';
		$strSearchFieldTag = $this->strStructuredBlogSymbolTag . $strSearchFieldTag; // $strSearchFieldTag = '#Latitude'
		$intPosTag = strpos($strMessage, $strSearchFieldTag); // $intPosTag = 39
		if ($intPosTag === false) { return $strValue; }
		$strMessage = substr($strMessage, $intPosTag, strlen($strMessage)); // $strMessage = '#Latitude=-23.434254; like semantic blog information'
		$intPosSeparator = strpos($strMessage, $this->strStructuredBlogSymbolSeparator); // $intPosSeparator = 9
		if ($intPosSeparator === false) { return $strValue; }
		$strMessage = trim(substr($strMessage, $intPosSeparator + 1, strlen($strMessage))); // $strMessage = '-23.434254; like semantic blog information'
		$intPosEndValue = strpos($strMessage, $this->strStructuredBlogSymbolEndValue); // $intPosEndValue = 10
		if ($intPosEndValue === false) {
			$intPosEndValue = strlen($strMessage);
		}
		$strValue = trim(substr($strMessage, 0, $intPosEndValue)); // $strValue = '-23.434254'
		return trim(utf8_decode($strValue));
	}

	public function extractTagsText($strText, $strCharHash) {
		$strTemp = $strText;
		$arrResult = array();
		$strTemp = ' ' . $strTemp;
		while (strpos($strTemp, $strCharHash)) {
			$intStart = strpos($strTemp, $strCharHash);
			$strTemp = substr($strTemp, $intStart+1, strlen($strTemp));
			$strTag = substr($strTemp, 0, strpos($strTemp, ' '));
			$arrResult[] = $strTag;
		}
		$strResult = '';
		for ($i=0;$i<count($arrResult);$i++) {
			if ($i > 0) $strResult .= ';';
			$strResult .= $arrResult[$i];
		}
		return $strResult;
	}

	public function intCalculateDateDifferenceDays($dtStart, $dtEnd) {
		$intDiffSec = $dtEnd - $dtStart;
		return floor($intDiffSec/3600/24);
	}

	public function removeChrsXML($str) {
		$str = trim($str);
		$str = str_replace(chr(13), '', $str);
		return $str;
	}

	public function generateRandomString($intLength) {
		return substr(md5(uniqid(time())),0,$intLength);
	}

	public function sureRemoveDir($dir, $DeleteMe) {
	  if(!$dh = @opendir($dir)) return;
	  while (false !== ($obj = readdir($dh))) {
		if($obj=='.' || $obj=='..') continue;
		if (!@unlink($dir.'/'.$obj)) $this->sureRemoveDir($dir.'/'.$obj, true);
	  }
	  closedir($dh);
	  if ($DeleteMe){
		@rmdir($dir);
	  }
	}

	public function arrReturnListFilesFolder($strFolder, $strExtension = '') {
		$arrFiles = array();
		if (is_dir($strFolder)) {
		  if ($dh = opendir($strFolder)) {
			while (($file = readdir($dh)) !== false) {
			  if (filetype($strFolder . $file) != "dir"){
				$ext = explode(".", $file);
				$ext = '.' . strtolower(array_pop($ext));
				if (! $strExtension) {
					$arrFiles[] = $strFolder . $file;
				} else {
					if ($ext == $strExtension) {
						$arrFiles[] = $strFolder . $file;
					}
				}
			  }
			}
			closedir($dh);
		  }
		}
		return $arrFiles;
	}

	public function arrVertexsCentroid($arrVertexs){
		$x=$y=0;
		$n = count($arrVertexs);
		for($i=0; $i<$n; $i++){
			$x += $arrVertexs[$i]['dblLongitude'];
			$y += $arrVertexs[$i]['dblLatitude'];
		}
		$arrResult = array();
		$arrResult['dblLatitude'] = $y/$n;
		$arrResult['dblLongitude'] = $x/$n;
		return $arrResult;
	}
	
	public function blnIsInPolygon($arrY, $arrX, $dblLat, $dblLng) {
		$intSize = count($arrX);
		$i = $j = $c = 0;
		for ($i = 0, $j = $intSize-1 ; $i < $intSize; $j = $i++) {
			if ( (($arrY[$i] > $dblLat != ($arrY[$j] > $dblLat)) &&
					($dblLng < ($arrX[$j] - $arrX[$i]) * ($dblLat - $arrY[$i]) / ($arrY[$j] - $arrY[$i]) + $arrX[$i]) ) )
				$c = !$c;
		}
		return $c;
	}
	
	public function arrSimplifyArrayVertexs($arrVertexs, $intNewSize) {
		$arrResult = array();
		$intStep = ceil(count($arrVertexs) / $intNewSize);
		foreach ($arrVertexs as $i => $arrVertex) {
			if ($i % $intStep == 0) {
				$arrResult[] = $arrVertex;
			}
		}
		$arrResult[] = $arrVertexs[0];
		return $arrResult;
	}
	
	/** @param string $strUrl Required. API URL to request */
	public function processUrl($strUrl, $arrHeaders = array()) {
		$responseInfo=array();
		$user_agent='';
		$ch = curl_init($strUrl);
		curl_setopt($ch, CURLOPT_URL, $strUrl);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_NOBODY, 0);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION,1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		if (count($arrHeaders) > 0) { // Require additional header
			curl_setopt($ch, CURLOPT_HTTPHEADER, $arrHeaders);
		} else {
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

		}
		$response = curl_exec($ch);
		$responseInfo=curl_getinfo($ch);
		if(intval($responseInfo['http_code']) == 200 )
			return $response;
		else
			return false;
	}

	/**
	 * Function to prepare data for return to client
	 * @access private
	 * @param string $data
	 * $type = json || xml
	 */
	public function objectify($type, $data) {
		if($type ==  'json' )
			return (object) json_decode($data);
		else if($type == 'xml' ) {
			if( function_exists('simplexml_load_string') ) {
				$obj = simplexml_load_string($data);
				$statuses = array();
				foreach($obj->status as $status) {
					$statuses[] = $status;
				}
				return (object) $statuses;
			}
			else {
				return $out;
			}
		}
		else
			return false;
	}
	
	public function strFormatXmlString($str) {
		$xml = new DOMDocument('1.0');
		$xml->loadXML($str);
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		return trim($xml->saveXML());
	}

	public function formatXmlString($xml) {

	  // add marker linefeeds to aid the pretty-tokeniser (adds a linefeed between all tag-end boundaries)
	  $xml = preg_replace('/(>)(<)(\/*)/', "$1\n$2$3", $xml);

	  // now indent the tags
	  $token      = strtok($xml, "\n");
	  $result     = ''; // holds formatted version as it is built
	  $pad        = 0; // initial indent
	  $matches    = array(); // returns from preg_matches()

	  // scan each line and adjust indent based on opening/closing tags
	  while ($token !== false) :

		// test for the various tag states

		// 1. open and closing tags on same line - no change
		if (preg_match('/.+<\/\w[^>]*>$/', $token, $matches)) :
		  $indent=0;
		// 2. closing tag - outdent now
		elseif (preg_match('/^<\/\w/', $token, $matches)) :
		  $pad--;
		// 3. opening tag - don't pad this one, only subsequent tags
		elseif (preg_match('/^<\w[^>]*[^\/]>.*$/', $token, $matches)) :
		  $indent=1;
		// 4. no indentation needed
		else :
		  $indent = 0;
		endif;

		// pad the line with the required number of leading spaces
		$line    = str_pad($token, strlen($token)+$pad, ' ', STR_PAD_LEFT);
		$result .= $line . "\n"; // add to the cumulative result, with linefeed
		$token   = strtok("\n"); // get the next token
		$pad    += $indent; // update the pad size for subsequent lines
	  endwhile;

	  return $result;
	}

	public function arrXMLtoArray(SimpleXMLElement $xml) {
        $array = (array)$xml;

        foreach ( array_slice($array, 0) as $key => $value ) {
            if ( $value instanceof SimpleXMLElement ) {
                $array[$key] = empty($value) ? NULL : $this->arrXMLtoArray($value);
            }
        }
        return $array;
    }
	
	/* createThumbnail variables:image file,image file path,suffix to append to the name before the .jpg,thumbnail width,thumbnail height,thumbnail quality */
	public function createThumbnail($strFileName, $suffix, $newWidth, $newHeight, $quality = 50, $strWatermarkText = '') {
		$strFileExt = explode(".", $strFileName);
		$strFileNameNoExt = $strFileExt[0];
		$strFileExt = strtolower($strFileExt[1]);
		// Open the original image.
		$original = @imagecreatefromjpeg($strFileName) or die("Error");
		list($width, $height, $type, $attr) = getimagesize($strFileName);
		if (! $width > 0) return false;
		// Resample the image.
		$tempImg = @imagecreatetruecolor($newWidth, $newHeight);
		imagecopyresized($tempImg, $original, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
		$newName = $strFileNameNoExt . $suffix . '.' . $strFileExt;
		// Adding Watermark
		$strFontColor = imagecolorallocate($tempImg, 255, 255, 255); // White
		$strFontName = $this->strImageWatermarkFont;
		$intAngle = 0;
		if ($strWatermarkText) {
			$intFontSize = 5;
			// imagefttext($tempImg, $intFontSize, $intAngle, 5, $intFontSize + 5, $strFontColor, $strFontName, $strWatermarkText);
			// Aplly Watermark and save original image
			$intFontSize = round($height*0.03); // 5% from image size
			imagefttext($original, $intFontSize, $intAngle, 5, $intFontSize + 10, $strFontColor, $strFontName, $strWatermarkText);
			@imagejpeg($original, $strFileName, $quality);
		}
		// Save the image.
		imagejpeg($tempImg, $newName, $quality);
		// Clean up.
		imagedestroy($original);
		imagedestroy($tempImg);
		return true;
	}
	
	// Check if image is JPG and if is greater than $intLimitWidth to reduce in order to not consume time for loading
	public function checkAndReduceJpegImage($strFileName, $intLimitWidth) {
		$strFileExt = explode(".", $strFileName);
		$strFileNameNoExt = $strFileExt[0];
		$strFileExt = strtolower($strFileExt[1]);
		if (strtolower($strFileExt) == 'jpg') {
			// Open the original image.
			@list($width, $height, $type, $attr) = getimagesize($strFileName);
			if ($width > $intLimitWidth) {
				$this->createThumbnail($strFileName, '', $intLimitWidth, round($intLimitWidth*$height/$width));
			}
		}
	}
	
	public function blnCheckDomainExists($strDomain, $strExtension) {
		$strURL = 'http://busca.whois.host.uol.com.br/domainAlreadyRegistred.html?name=' . $strDomain . '&extension=' . $strExtension;
		$strResult = $this->processUrl($strURL);
		return (strpos($strResult, 'alse') > 0 ? '0' : '1');
	}
	
	public function strArrayToXML($data, $rootNodeName = 'data', $xml=null) {
		// turn off compatibility mode as simple xml throws a wobbly if you don't.
		if (ini_get('zend.ze1_compatibility_mode') == 1) {
			ini_set ('zend.ze1_compatibility_mode', 0);
		}
 		if ($xml == null) {
			$xml = simplexml_load_string("<?xml version='1.0' encoding='utf-8'?><$rootNodeName />");
		}
 
		// loop through the data passed in.
		foreach($data as $key => $value) {
			// no numeric keys in our xml please!
			if (is_numeric($key)) {
				// make string key...
				//$key = "unknownNode_". (string) $key;
				$key = 'record';
			}
 
			// replace anything not alpha numeric
			//$key = preg_replace('/[^a-z]/i', '', $key);
 
			// if there is another array found recrusively call this function
			if (is_array($value)) {
				$node = $xml->addChild($key);
				// recrusive call.
				$this->strArrayToXML($value, $rootNodeName, $node);
			} else {
				// add single node.
				$value = utf8_encode($value);
				$xml->addChild($key,$value);
			}
		}
		// pass back as string. or simple xml object if you want!
		return $xml->asXML();
	}

	// function defination to convert array to xml
	public function array_to_xml($arrData, &$xmlData) {
	    foreach($arrData as $key => $value) {
	        if(is_array($value)) {
	            if(!is_numeric($key)){
	                $subnode = $xmlData->addChild("$key");
	                $this->array_to_xml($value, $subnode);
       	     } else{
	                $subnode = $xmlData->addChild(substr($xmlData->getName(),0,strlen($xmlData->getName())-1));
			  //$subnode = $xmlData->addChild($xmlData->getName());
	                $this->array_to_xml($value, $subnode);
	            }
	        }
	        else {
	            $xmlData->addChild("$key",htmlspecialchars("$value"));
	        }
	    }
	}
}
?>