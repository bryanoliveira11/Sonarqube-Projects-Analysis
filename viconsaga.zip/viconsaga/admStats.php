<? $strings->changePageTitle($_SESSION['strIndexMenuStats']); ?>
<!-- Charts -->
<script src="js/charts/Lib/js/knockout-3.0.0.js"></script>
<script src="js/charts/Lib/js/globalize.min.js"></script>
<script src="js/charts/Lib/js/dx.chartjs.js"></script>
<style>
	.chart {width:49%;/*overflow-y:hidden;overflow-x:hidden;*/display:inline-block;margin-bottom:30px;}
	.input-date {font-family:'Calibri';text-align:center;font-weight:bold;width:95px;}
	input[type=date]::-webkit-inner-spin-button { -webkit-appearance: none; display: none;}
	::-webkit-clear-button{display: none; -webkit-appearance: none; }
</style>
<div class="sessionTitle">
    <i class="icon-signal"></i><span class="hidden-phone"> <? echo $_SESSION['strIndexMenuStats']; ?></span>
    <span style="float:right;position:relative;top:-4px;display:inline-block">
        <input id="dtDateFrom" name="dtDateFrom" type="date" title="<? echo $_SESSION['stradmStatsProjectCreationDate'] . ': ' . $arrProject['strDateCreation']; ?>" class="input-date" value="<? echo $_COOKIE['dtDateFrom'] ? $_COOKIE['dtDateFrom'] : date("Y-m-d", strtotime("-1 month", time())); ?>"> - 
        <input id="dtDateTo" name="dtDateTo" type="date" class="input-date" value="<? echo $_COOKIE['dtDateTo'] ? $_COOKIE['dtDateTo'] : date('Y-m-d', time()); ?>">
	    <a id="btnChartUpdate" class="btn btn-info" onclick="chartPlot();" data-loading-text="..." style="position:relative;top:-4px"><i class="icon-refresh icon-white"></i></a>
    </span>
    </span>
</div>

<div style="overflow:hidden;text-align:center;margin-bottom:10px;">
    <div class="chart" id="c1"></div>
    <div class="chart" id="c2"></div>
    <div class="chart" id="c3"></div>
    <div class="chart" id="c4"></div>
</div>
<script>    
	function chartPlot() {
		chartLoadData('c1', 1, false);
		chartLoadData('c2', 2, false);
		chartLoadData('c3', 3, false);
		chartLoadData('c4', 4, false);
	}
	
    function chartLoadData(idCanvas, idChart, blnShowLegend) {
        blnShowLegend = (blnShowLegend ? true : false);
		$('#btnChartUpdate').button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=SDL" +
			"&idProject=<? echo $arrProject['idProject']; ?>" + 
			"&idChart=" + idChart + 
			"&dtDateFrom=" + document.getElementById('dtDateFrom').value +
			"&dtDateTo=" + document.getElementById('dtDateTo').value
        }).always(function() {
            chartPlotData(idCanvas, result.responseText, blnShowLegend);
			$('#btnChartUpdate').button('reset');
        });
    }

    function chartPlotData(idCanvas, strData, blnShowLegend) {
        blnShowLegend = (blnShowLegend ? true : false);
        var chart;
        var chartData = new Array();
		var intTotal = 0;
        var arrData = JSON.parse(strData);
        if (! arrData['arrValues']) {
			arrData['arrValues'] = [];
		}
        var strChartType = arrData['strType'];
        if ((strChartType == 'line') || (strChartType == 'bar')) {
            // Series Names
            var arrSeries = new Array();
            for (var i=1;i<arrData['arrLabels'].length;i++)	{
                arrSeries.push({"valueField" : "Y" + i, "name" : arrData['arrLabels'][i]});
            }
            // Series Values
            for (var i=0;i<arrData['arrValues'].length;i++)	{
                var arrKeys = {};
                arrKeys['X'] = arrData['arrValues'][i][0];
                for (var j=1;j<arrData['arrValues'][i].length;j++)	{
                    arrKeys['Y' + j] = parseInt(arrData['arrValues'][i][j]);
					intTotal += arrKeys['Y' + j];
                }
                chartData.push(arrKeys);
            }
        } else if (strChartType == 'pie') {
            for (var i=0;i<arrData['arrValues'].length;i++)	{
                chartData.push ({"X" : arrData['arrValues'][i][0], "Y" : parseInt(arrData['arrValues'][i][1])});
				intTotal += arrData['arrValues'][i][1];
            }
        }	
        if ((arrData['arrValues']) && (arrData['arrValues'].length)) {
			document.getElementById(idCanvas).style.height = "200px";
		}
		arrData['strTitle'] += ' (' + intTotal + ')';
        if (strChartType == 'line') {
            $("#" + idCanvas).dxChart({
                dataSource: chartData,
                commonSeriesSettings: {
                    argumentField: "X"
                },
                series: arrSeries,
                argumentAxis:{
                    grid:{
                        visible: true
                    }
                },
                tooltip:{
                    enabled: true
                },
                title: {
                    text: arrData['strTitle'],
                    font: { color:'#000000', opacity: 1, weight: 700, size: 14 }
                },
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    visible: blnShowLegend
                },
                commonPaneSettings: {
                    border:{
                        visible: true,
                        right: false
                    }       
                }
            });
        } else if (strChartType == 'bar') {
            $("#" + idCanvas).dxChart({
                dataSource: chartData,
                commonSeriesSettings: {
                    argumentField: "X",
                    type: "bar",
                    hoverMode: "allArgumentPoints",
                    selectionMode: "allArgumentPoints",
                    label: {
                        visible: true,
                        format: "fixedPoint",
                        precision: 0
                    }
                },
                series: arrSeries,
                title: {
                    text: arrData['strTitle'],
                    font: { color:'#000000', opacity: 1, weight: 700, size: 14 }
                },
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    visible: blnShowLegend
                },
                pointClick: function (point) {
                    this.select();
                }
            });
        } else if (strChartType == 'pie') {
            $("#" + idCanvas).dxPieChart({
                dataSource: chartData,
                series: [
                    {
                        argumentField: "X",
                        valueField: "Y",
                        label:{
                            visible: true,
                            connector:{
                                visible:true,
                                width: 1
                            }
                        }
                    }
                ],
                title: {
                    text: arrData['strTitle'],
                    font: { size: 14 }
                }
            });
        }
    }
	
	$(document).ready(function () {
		chartPlot();
	});
</script>

<? 
	$arrTags = $stats->selectProjectSearch($arrProject['idProject']);
	if (count($arrTags)) { 
?>
<div class="sessionTitle">
    <i class="icon-search"></i> <? echo $_SESSION['stradmStatsSearchTitle']; ?>
</div>
<style>
	.tags {font:80% Trebuchet MS, Arial, Helvetica, sans-serif; padding:0 2px; line-height:180%; word-wrap: break-word;}
	.tags ul {margin:1em 0;padding:.5em 10px;text-align:center;background:none;color:#030303}
	.tags li {margin:2px;padding:0;list-style:none;display:inline;}
</style>
<div class="tags">
<ul>
<?
	foreach ($arrTags as $arrTag) {
		$intFontSize = min(300, (100 + ($arrTag['intCount']*20)));
		echo '<li style="cursor:help;color:#' . $strings->strGenerateRandonColor() . ';font-weight:bold;font-size:' . $intFontSize . '%;" data-rel="tooltip" title="' . $arrTag['intCount'] . '">' . $arrTag['strSearch'] . ' (' . $arrTag['intCount'] . ')</li>';
	}
?>
</ul>
</div>
<? } ?>