<? $strings->changePageTitle($_SESSION['strIndexMenuManageAlerts']); ?>
<script>
	var arrSessions = new Array ("manage", "alerts");
</script>
<style> .control-label{font-weight:bold;}</style>

<div class="sessionTitle"><i class="<? echo $alert->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuManageAlerts']; ?></div>
<div class="box-content">
    <table width="100%"><tr>
    <!-- Menu -->
    <td valign="top">
        <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF">
            <li id="menu_manage" onClick="showSession(arrSessions, 0);">
                <a><i class="icon-cog"></i><span class="hidden-phone"> <? echo $_SESSION['strIndexMenuManageAlerts']; ?></span></a>
            </li>
            <li id="menu_alerts" onClick="showSession(arrSessions, 1);" >
                <a><i class="<? echo $alert->strDefaultIcon; ?>"></i><span class="hidden-phone"> <? echo $_SESSION['stradmManageAlertsAlertsLog']; ?></span></a>
            </li>
        </ul>
    </td>
    <!-- End Menu -->
    <!-- Body -->
    <td valign="top" width="100%" style="padding-left:20px;background-color:transparent;">
        <div id="div_manage">
            <div class="sessionTitle">
                <i class="icon-cog"></i> <span class="hidden-phone"><? echo $_SESSION['strIndexMenuManageAlerts']; ?></span>
                <a href="#" class="btn btn-success" style="float:right;position:relative;top:-4px" onclick="userAlertLoad(-1);"><i class="icon-plus-sign icon-white"></i> <? echo $_SESSION['stradmManageAlertsCreate']; ?></a>
            </div>
            <table id="tblUserAlerts" name="tblUserAlerts" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
                <thead>
                    <tr style="cursor:pointer;font-weight:bold;" class="btn-primary">
                        <th style="white-space:nowrap;text-align:center" class="hidden-phone" width="1"><? echo $_SESSION['stradmManageAlertsCreation']; ?></th>
                        <th style="text-align:center"><? echo $_SESSION['stradmManageAlertsName']; ?></th>
                        <th style="text-align:center" class="hidden-phone" width="300"><? echo $_SESSION['stradmManageAlertsMailTo']; ?></th>
                        <th style="white-space:nowrap;text-align:center" width="1" class="hidden-phone"><? echo $_SESSION['stradmManageAlertsTriggerAfter']; ?></th>
                        <th style="text-align:center" width="1"><? echo $_SESSION['stradmManageAlertsActive']; ?></th>
                        <th style="text-align:center;white-space:nowrap;" width="1"><? echo $_SESSION['strGlobalActions']; ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <!-- Panel for View/Insert Alert -->
            <div class="modal hide fade hideSelection" id="modalUserAlert">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">�</button>
                    <h4><i class="<? echo $alert->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuManageAlerts']; ?></h4>
                </div>
                <div class="modal-body">
                    <div class="control-group">
                        <input type="hidden" id="idUserAlert" name="idUserAlert" value="">
                        <!-- strName -->
                        <label class="control-label"><? echo $_SESSION['stradmManageAlertsName']; ?>:</label>
                        <div class="controls">
                            <input type="text" class="fullwith" id="strName" name="strName">
                        </div>
                        
                        <!-- Who? Form -->
                        <label class="control-label"><? echo $_SESSION['stradmManageAlertsForm']; ?>:</label>
                        <div class="controls">
                            <select id="idUserAlertForm" name="idUserAlertForm" style="width:100%;margin:0px" onchange="userAlertUserClauseFormFieldsLoad();">
                            <? 
                                $arrForms = $form->selectForms($arrProject['idProject'], 0, '', 1); 
                                foreach ($arrForms as $arrForm) {
                                    echo '<option value="' . $arrForm['idForm'] . '">' . $arrForm['strName'] . '</option>';
                                }
                            ?>
                            </select>
                        </div>
                        
                        <!-- Clauses for Trigger -->
                        <label class="control-label"><? echo $_SESSION['stradmManageAlertsTrigger']; ?>:</label>
                        <div class="controls">
                            <input id="blnOnRecordCreate" type="checkbox" /> <label for="blnOnRecordCreate" style="display:inline-block;margin-right:10px;"><? echo $_SESSION['stradmManageAlertsOnCreate']; ?></label>
                            <input id="blnOnRecordUpdate" type="checkbox" /> <label for="blnOnRecordUpdate" style="display:inline-block;margin-right:10px;"><? echo $_SESSION['stradmManageAlertsOnUpdate']; ?></label>
                            <input id="blnOnRecordDelete" type="checkbox" /> <label for="blnOnRecordDelete" style="display:inline-block"><? echo $_SESSION['stradmManageAlertsOnDelete']; ?></label>
                        </div>
            
                        <!-- Form Field Condition -->
                        <label class="control-label"><? echo $_SESSION['stradmManageAlertsConditions'] . ' (' . $_SESSION['strHomeFilterAnd'] . ')'; ?>:</label>
                        <div class="controls">
                        <table>
                            <tr>
                                <td width="49%">
									<select id="idUserAlertFormField" name="idUserAlertFormField" style="width:100%;margin:0px" onchange="userAlertSuggestionsInitialize();"></select>
                                </td>
                                <td width="1%">
                                    <select id="strUserAlertClauseOperator" name="strUserAlertClauseOperator" style="width:60px;margin:0px;text-align:center">
                                        <option value="=">=</option>
                                        <option value=">">&gt;</option>
                                        <option value="<">&lt;</option>
                                        <option value="<>">&ne;</option>
                                    </select> 
                                </td>
                                <td width="49%" style="text-align:left"><input type="text" id="strUserAlertClauseValue" name="strUserAlertClauseValue" style="width:95%;margin:0px;background-position:right;background-repeat:no-repeat" autocomplete="off" onKeyDown="if(event.keyCode=='13'){userAlertUserClauseInsert();}"/> </td>
                                <td width="1%">
                                    <a id="btnUserAlertUserClauseInsert" data-loading-text="..." class="btn btn-success" onclick="userAlertUserClauseInsert();"><i class="icon-plus-sign icon-white"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" width="99%" style="text-align:center" valign="top">
                                    <select id="userAlertClauses" style="width:100%;height:40px;" size="2"></select>
                                </td>
                                <td width="1%" valign="top">
                                    <a id="btnUserAlertUserClauseDelete" data-loading-text="..." class="btn btn-danger" onclick="userAlertUserClauseDelete();"><i class="icon-minus-sign icon-white"></i></a>
                                </td>
                            </tr>
                            </table>
                        </div>            
                        
                        <!-- strActionEmailTo -->
                        <label class="control-label"><? echo $_SESSION['stradmManageAlertsMailTo']; ?>:</label>
                        <div class="controls">
                            <input type="email" class="fullwith" id="strActionEmailTo" name="strActionEmailTo" placeholder="<? echo $_SESSION['stradmManageAlertsMailToTip']; ?>">
                        </div>
                        <!-- intNotifyAfterDaysFromEvent -->
                        <label class="control-label" style="display:inline-block"><? echo $_SESSION['stradmManageAlertsTriggerAfter']; ?>:</label> <input type="number" style="width:60px;text-align:center" min="0" max="1000" id="intNotifyAfterDaysFromEvent" name="intNotifyAfterDaysFromEvent" value="0" onBlur="this.value=parseInt(this.value);" data-rel="tooltip" title="<? echo $_SESSION['stradmManageAlertsTriggerDaysFromEvent0Tip']; ?>"> <? echo $_SESSION['stradmManageAlertsTriggerDaysFromEvent']; ?>
                        
                        <div style="text-align:right">
                            <a href="#" class="btn btn-primary" id="btnModalUserAlertSave" data-loading-text="..." onclick="userAlertInsertUpdate();"><? echo $_SESSION['strGlobalSave']; ?></a>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
			<script>
				function userAlertLoad(idUserAlert) {
					$('#btnModalUserAlertSave').button('reset');
					document.getElementById('idUserAlertForm').disabled = false;
					document.getElementById('idUserAlert').value = idUserAlert;
					document.getElementById('strName').value = '';
					document.getElementById('blnOnRecordCreate').checked = 0;
					document.getElementById('blnOnRecordUpdate').checked = 0;
					document.getElementById('blnOnRecordDelete').checked = 0;
					var cmbUserAlertClauses = document.getElementById("userAlertClauses");
					for (var i=cmbUserAlertClauses.options.length-1;i>=0;i--) { cmbUserAlertClauses.remove(i); }
					document.getElementById('strActionEmailTo').value = '<? echo (strpos($arrUser['idUser'], '@') !== FALSE ? $arrUser['idUser'] : ""); ?>';
					document.getElementById('intNotifyAfterDaysFromEvent').value = '0';
					if (idUserAlert > 0) {
						var result = $.ajax({
						  url: "ajax.php?chrAction=UAS&idUserAlert=" + idUserAlert
						}).always(function() {
							if (result.responseText) {
								var response 	= result.responseText;
								var retorno 	= JSON.parse(response);
								document.getElementById('idUserAlert').value = idUserAlert;
								document.getElementById('strName').value = retorno[0]['strName'];
								document.getElementById('blnOnRecordCreate').checked = retorno[0]['blnOnRecordCreate'] == 1 ? 1 : 0;
								document.getElementById('blnOnRecordUpdate').checked = retorno[0]['blnOnRecordUpdate'] == 1 ? 1 : 0;
								document.getElementById('blnOnRecordDelete').checked = retorno[0]['blnOnRecordDelete'] == 1 ? 1 : 0;
								document.getElementById('strActionEmailTo').value = retorno[0]['strActionEmailTo'];
								document.getElementById('intNotifyAfterDaysFromEvent').value = retorno[0]['intNotifyAfterDaysFromEvent'];
								var arrClauses	= retorno[0]['arrClauses'];
								for (var i=0;i<arrClauses.length;i++) {
									var opt = document.createElement('option');
									opt.value = arrClauses[i]['idUserAlertClause'];
									opt.text = arrClauses[i]['strFormField'] + arrClauses[i]['strOperador'] + arrClauses[i]['strValue'];
									cmbUserAlertClauses.add(opt);
								}
								if (arrClauses.length > 0) {
									comboSelectByValue(document.getElementById('idUserAlertForm'), retorno[0]['idForm']);
									document.getElementById('idUserAlertForm').disabled = true;
									userAlertUserClauseFormFieldsLoad();
								}
							}
							$('#modalUserAlert').modal('show');
							document.getElementById('strName').focus();
						});
					} else {
						$('#modalUserAlert').modal('show');
						document.getElementById('strName').focus();
					}
				}
			
				function userAlertInsertUpdate() {
					var idUserAlert = document.getElementById('idUserAlert').value;
					$('#btnModalUserAlertSave').button('reset');
					if (! checkidUserAlertFormRequiredFields()) return;
					$('#btnModalUserAlertSave').button('loading');
					chrAction = (idUserAlert >= 0 ? 'U' : 'I');
					var result = $.ajax({
					  url: "ajax.php?chrAction=UA" + chrAction +
							'&idUserAlert=' + idUserAlert +	
							'&idUser=<? echo $arrUser['idUser']; ?>' +
							'&idForm=' + document.getElementById('idUserAlertForm').value + 
							'&strName=' + document.getElementById('strName').value +
							'&strActionEmailTo=' + document.getElementById('strActionEmailTo').value +
							'&intNotifyAfterDaysFromEvent=' + document.getElementById('intNotifyAfterDaysFromEvent').value +
							'&blnOnRecordCreate=' + (document.getElementById('blnOnRecordCreate').checked ? '1' : '0') +
							'&blnOnRecordUpdate=' + (document.getElementById('blnOnRecordUpdate').checked ? '1' : '0') +
							'&blnOnRecordDelete=' + (document.getElementById('blnOnRecordDelete').checked ? '1' : '0')
					}).always(function() {
						var response 	= result.responseText;
						var retorno 	= JSON.parse(response);
						document.getElementById('idUserAlert').value = response['idUserAlert'];
						$('#btnModalUserAlertSave').button('reset');
						$('#modalUserAlert').modal('hide');
						userAlertsLoad('tblUserAlerts');
					});
				}
				
				function checkidUserAlertFormRequiredFields() {
					if (! document.getElementById('strName').value) {
						showInfoAlert('<? echo $_SESSION['strGlobalErrorFill'] . ' ' . strtoupper($_SESSION['stradmManageAlertsName']); ?>');
						document.getElementById('strName').focus();
						return false;
					}
					return true;
				}
				
				function userAlertUpdateActive(idUserAlert, blnActive){
					$.ajax({url: "ajax.php?chrAction=UAUA&idUserAlert=" + idUserAlert + "&blnActive=" + blnActive});
				}
			
				function userAlertDelete(idUserAlert) {
					var blnDelete = confirm('<? echo $_SESSION['stradmManageAlertsConfirmDelete']; ?>');
					if (! blnDelete) return;
					$('#btnUserAlertDelete_' + idUserAlert).button('loading');
					var result = $.ajax({
					  url: "ajax.php?chrAction=UAD&idUserAlert=" + idUserAlert
					}).always(function() {
						if (result.responseText > 0) {
							$('#tblUserAlerts_' + idUserAlert).fadeOut(800, function(){
								$('#tblUserAlerts_' + idUserAlert).remove();
							});
						}
						$('#btnUserAlertDelete_' + idUserAlert).button('reset');
					});
				}
			
				function userAlertsLoad(idTable) {
					var table = document.getElementById(idTable);
					var tbody = table.getElementsByTagName("tbody")[0];
					tbody.innerHTML = '<tr><td colspan="6"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
					var result = $.ajax({
					  url: "ajax.php?chrAction=UAS&idUser=<? echo $arrUser['idUser']; ?>"
					}).always(function() {
						var response 	= result.responseText;
						var arrResult 	= JSON.parse(response);
						tbody.innerHTML = '';
						var rows = tbody.getElementsByTagName("tr").length;
						for (var i=0;i<arrResult.length;i++) {
							var row = tbody.insertRow(i);
							row.id = idTable + '_' + arrResult[i]['idUserAlert'];
							var cell = row.insertCell(0);
							cell.innerHTML = arrResult[i]['strCreation'];
							cell.className = "hidden-phone";
							cell.style.whiteSpace = "nowrap";
							cell.style.textAlign = "center";
							var cell = row.insertCell(1);
							var strClauses = '';
							var arrClauses	= arrResult[i]['arrClauses'];
							for (var j=0;j<arrClauses.length;j++) {
								strClauses += (j > 0 ? ' <? echo $_SESSION['strHomeFilterAnd']; ?> ' : '') + arrClauses[j]['strFormField'] + arrClauses[j]['strOperador'] + arrClauses[j]['strValue'];
							}
							cell.innerHTML = ' <span>' + arrResult[i]['strName'] + ' (' + arrResult[i]['strFormName'] + ') '+ '</span><span style="float:right">' + (arrResult[i]['blnOnRecordCreate'] == 1 ? '<i class="icon-plus-sign" title="<? echo $_SESSION['stradmManageAlertsOnCreate']; ?>"></i> ': '')  + (arrResult[i]['blnOnRecordUpdate'] == 1 ? '<i class="icon-refresh"  title="<? echo $_SESSION['stradmManageAlertsOnUpdate']; ?>"></i> ': '') + (arrResult[i]['blnOnRecordDelete'] == 1 ? '<i class="icon-minus-sign"  title="<? echo $_SESSION['stradmManageAlertsOnDelete']; ?>"></i> ': '') + '</span>' +
												(strClauses != '' ? '<br><span style="font-weight:bold;font-style:italic;font-size:10px;line-height:11px;margin-left:5px;">' + strClauses + '</span>' : '');
							var cell = row.insertCell(2);
							cell.innerHTML = arrResult[i]['strActionEmailTo'];
							cell.style.textAlign = "left";
							cell.className = "hidden-phone";
							var cell = row.insertCell(3);
							cell.innerHTML = arrResult[i]['intNotifyAfterDaysFromEvent'] > 0 ? arrResult[i]['intNotifyAfterDaysFromEvent'] + ' <? echo $_SESSION['strGlobalDays']; ?>' : '<? echo $_SESSION['stradmManageAlertsTriggerDaysImmediately']; ?>';
							cell.style.textAlign = "center";
							cell.className = "hidden-phone";
							cell.style.whiteSpace = "nowrap";
							var cell = row.insertCell(4);
							cell.innerHTML = '<input type="checkbox" onClick="userAlertUpdateActive(' + arrResult[i]['idUserAlert'] + ', this.checked);" ' + (arrResult[i]['blnActive'] == "1" ? "checked" : "") + '>';
							cell.style.textAlign = "center";
							var cell = row.insertCell(5);
							cell.innerHTML =	'<span class="btn btn-success" style="margin-left:3px;" onClick="userAlertLoad(' + arrResult[i]['idUserAlert'] + ');"><i class="icon-edit icon-white"></i></span>' +
												'<span class="btn btn-danger" id="btnUserAlertDelete_' + arrResult[i]['idUserAlert'] + '" data-loading-text="..." style="margin-left:3px;" onClick="userAlertDelete(' + arrResult[i]['idUserAlert'] + ');"><i class="icon-trash icon-white"></i></span>';
							cell.style.textAlign = "center";
							cell.style.whiteSpace = "nowrap";
						}
					});
				}
			
				function userAlertUserClauseInsert() {
					$('#btnUserAlertUserClauseInsert').button('loading');
					var idUserAlert = document.getElementById("idUserAlert").value;
					var result = $.ajax({url: 'ajax.php?chrAction=UACI' +
											'&idUser=<? echo $arrUser['idUser']; ?>' +
											'&strName=' + document.getElementById('strName').value +
											'&idUserAlert=' + document.getElementById("idUserAlert").value +
											'&idForm=' + document.getElementById("idUserAlertForm").value +
											'&idFormField=' + document.getElementById("idUserAlertFormField").value +
											'&strOperador=' + document.getElementById("strUserAlertClauseOperator").value +
											'&strValue=' + document.getElementById("strUserAlertClauseValue").value
					}).always(function() {
						$('#btnUserAlertUserClauseInsert').button('reset');
						var arrResult 	= JSON.parse(result.responseText);
						var cmbUserAlertClauses = document.getElementById("userAlertClauses");
						var opt = document.createElement('option');
						opt.value = arrResult['idUserAlertClause'];
						opt.text = document.getElementById("idUserAlertFormField").options[document.getElementById("idUserAlertFormField").selectedIndex].text + 
							document.getElementById("strUserAlertClauseOperator").options[document.getElementById("strUserAlertClauseOperator").selectedIndex].text + 
							document.getElementById("strUserAlertClauseValue").value;
						cmbUserAlertClauses.add(opt);
						document.getElementById("idUserAlertForm").disabled = (cmbUserAlertClauses.length == 0 ? false : true);
						document.getElementById("idUserAlert").value = arrResult['idUserAlert'];
					});
				}
			
				function userAlertUserClauseDelete() {
					if (document.getElementById('userAlertClauses').length == 0) return;
					$('#btnUserAlertUserClauseDelete').button('loading');
					var idUserAlertClause = document.getElementById("userAlertClauses").value;
					var result = $.ajax({
						url: 'ajax.php?chrAction=UACD&idUserAlertClause=' + idUserAlertClause
					}).always(function() {
						$('#btnUserAlertUserClauseDelete').button('reset');
						if (result.responseText > 0) {
							document.getElementById("userAlertClauses").remove(document.getElementById("userAlertClauses").selectedIndex);
						}
						document.getElementById('idUserAlertForm').disabled = (document.getElementById("userAlertClauses").length == 0 ? false : true);
					});
				}
			
				function userAlertUserClauseFormFieldsLoad(){
					var cmbClauseFormFields = document.getElementById('idUserAlertFormField');
					var result = $.ajax({
						url: 'ajax.php?chrAction=FFS&idForm=' + document.getElementById("idUserAlertForm").value
					}).always(function() {
						var arrResult 	= JSON.parse(result.responseText);
						// Clear Form Combo Items
						for (var i=cmbClauseFormFields.options.length-1;i>=0;i--) { cmbClauseFormFields.remove(i); 	}
						for (var i=0;i<arrResult['arrFields'].length;i++) {
							var opt = document.createElement('option');
							opt.value = arrResult['arrFields'][i]['idFormField'];
							opt.text = arrResult['arrFields'][i]['strName'];
							cmbClauseFormFields.add(opt);
						}
					});
				}
				
				function userAlertSuggestionsInitialize() {
					var objSearch = document.getElementById('strUserAlertClauseValue');
					objSearch.value = '';
					// Suggestions for Clause Values
					$('#strUserAlertClauseValue').autocomplete({
						serviceUrl: 'ajax.php?chrAction=FRFFS&idFormField=' + document.getElementById('idUserAlertFormField').value,
						minChars:3,
						onSearchStart: function (query) {
							objSearch.style.backgroundImage="url(img/loading.gif)";
						},
						onSearchComplete: function (query, suggestions) {
							objSearch.style.backgroundImage = "";
						},
						onSelect: function(suggestion) {
							objSearch.value = suggestion.text;
						}
					});
				}
            </script>
		</div>
        <div id="div_alerts">
            <div class="sessionTitle">
            	<i class="<? echo $alert->strDefaultIcon; ?>"></i> <span class="hidden-phone"><? echo $_SESSION['stradmManageAlertsAlertsLog']; ?></span>
                <a href="#" class="btn btn-danger" style="float:right;position:relative;top:-4px" onclick="userAlertEventsClear();"><i class="icon-trash icon-white"></i> <? echo $_SESSION['stradmManageAlertsClear']; ?></a>
			</div>
            <div id="divAlertEvents" style="width:100%;line-height:20px;font-size:14px;"></div>
			<script>
				function userAlertEventsLoad2(){
					var divAlerts = document.getElementById('divAlertEvents');
					divAlerts.innerHTML = '<div style="text-align:center;width:100%"><img src="img/loading1.gif"></div>';
					var result = $.ajax({
						url: 'ajax.php?chrAction=IUAES&idUser=<? echo $arrUser['idUser']; ?>&intLimit=100'
					}).always(function() {
						var response 	= result.responseText;
						var arrResult 	= JSON.parse(response);
						var strUserAlerts = '';
						if (arrResult.length == 0) {
							strUserAlerts = "<i><? echo $_SESSION['strIndexAlertsNoAlerts']; ?></i>";
						}
						for (var i=0;i<arrResult.length;i++) {
							strUserAlerts += '<div class="width:100%" style="' + (arrResult[i]['blnRead'] == "0" ? 'font-weight:bold' : '') + '">' + arrResult[i]['strEventInfo'] + '</div>';
						}
						divAlerts.innerHTML = strUserAlerts;
					});
				}
				
				function userAlertEventsClear(){
		    	    var blnDelete = confirm('<? echo $_SESSION['strIndexAlertsConfirmDelete']; ?>');
    			    if (! blnDelete) return;
					var divAlerts = document.getElementById('divAlertEvents');
					divAlerts.innerHTML = '<div style="text-align:center;width:100%"><img src="img/loading1.gif"></div>';
					var result = $.ajax({
						url: 'ajax.php?chrAction=UAED&idUser=<? echo $arrUser['idUser']; ?>'
					}).always(function() {
						divAlerts.innerHTML = "<i><? echo $_SESSION['strIndexAlertsNoAlerts']; ?></i>";
						document.getElementById('divAlerts').innerHTML = divAlerts.innerHTML;
					});
				}
            </script>
		</div>
    </td>
    </tr></table>
    <!-- End Body -->
</div>
<script>
	showSession(arrSessions, <? echo ($_GET['ss'] ? $_GET['ss'] : 0);?>);
	$(document).ready( function () {
		// Notification Tooltip
		$("#intNotifyAfterDaysFromEvent").tooltip({placement:'bottom', trigger:'hover focus'});
		userAlertEventsLoad2();
		userAlertsLoad('tblUserAlerts');
		userAlertUserClauseFormFieldsLoad();
	});
</script>