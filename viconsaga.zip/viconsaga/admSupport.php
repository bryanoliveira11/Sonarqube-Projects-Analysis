<?
	$strings->changePageTitle($_SESSION['strIndexMenuProjectManagementSupport']);

	// Insert new support
	if ($_POST['blnInsertSupport']) {
		$strDestinationFileName = '';
		if($_FILES['fuFileName']['name']){
			$strFileExt = explode(".", $_FILES['fuFileName']['name']);
			$strFileExt = strtolower(array_pop($strFileExt));
			$strDestinationFileName =  $strings->generateRandomString(5) . '.' . $strFileExt;
			$strDestinationFileFullPathName = $strings->strProjectFolder . '/' . $arrUser['idProject'] . '/' . $strings->strSupportFolder . '/' . $strDestinationFileName;
			copy($_FILES['fuFileName']['tmp_name'], $strDestinationFileFullPathName);
		}
		$idSupport = $support->insertSupport($arrUser['idUser'], $_POST['strSubject'], nl2br($_POST['txtMessage']), $strDestinationFileName);
		echo '
			<div id="alertSupportCallSuccess" class="alert alert-success alert-dismissable">
				<strong>' . $_SESSION['stradmSupportCreatedSuccessTitle'] . '</strong> ' . $_SESSION['stradmSupportCreatedSuccess'] . '
			</div>
			<script>$(\'#alertSupportCallSuccess\').fadeOut(10000, function(){});</script>
		';
	}
?>
<div class="sessionTitle">
    <i class="<? echo $support->strDefaultIcon; ?>"></i><b> <span class="hidden-phone"><? echo $_SESSION['strIndexMenuProjectManagementSupport']; ?></span></b>
    <a href="#" class="btn btn-success" style="float:right;position:relative;top:-4px" onclick="supportLoad(-1);"><i class="icon-plus-sign icon-white"></i> <? echo $_SESSION['stradmSupportTableHeaderOpenNew']; ?></a>
</div>
<div class="box-content">
    <table id="tblSupports" name="tblSupports" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
      <thead>
          <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF">
              <th width="20"></th>
              <th width="30" class="hidden-phone" style="text-align:center"><i class="icon-file"></i></th>
              <th width="90" style="text-align:center"><? echo $_SESSION['stradmSupportTableHeaderOpen']; ?></th>
              <th width="400"><? echo $_SESSION['stradmSupportTableHeaderSubject']; ?></th>
              <th style="text-align:center" class="hidden-phone"><? echo $_SESSION['stradmSupportTableHeaderInteractions']; ?></th>
              <th style="text-align:center" class="hidden-phone"><? echo $_SESSION['stradmSupportTableHeaderLastAnswer']; ?></th>
              <th width="80" style="text-align:center"><? echo $_SESSION['strGlobalActions']; ?></th>
          </tr>
      </thead>
      <tbody>
      </tbody>
  </table>
</div>

<!-- Panel for Insert Support -->
<div class="modal hide fade hideSelection" id="modalSupport">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">�</button>
        <h4><i class="<? echo $support->strDefaultIcon; ?>"></i> <? echo $_SESSION['stradmSupportModalTitle']; ?></h4>
    </div>
    <div class="modal-body">
		<input type="hidden" id="blnInsertSupport" name="blnInsertSupport" value="">
		<input type="hidden" id="idSupport" name="idSupport" value="">
        <div class="control-group">
			<!-- strSubject -->
            <label class="control-label"><? echo $_SESSION['stradmSupportModalFieldTitleSubject']; ?>:<span class="mandatory-field">*</span></label>
            <div class="controls">
                <input type="text" class="fullwith" id="strSubject" name="strSubject">
            </div>

			<!-- txtMessage -->
            <label class="control-label"><? echo $_SESSION['stradmSupportModalFieldTitleMessage']; ?>:<span class="mandatory-field">*</span></label>
            <div class="controls">
	            <textarea class="fullwith" rows="5" id="txtMessage" name="txtMessage"></textarea>
            </div>

			<!-- strFileName -->
            <label class="control-label"><? echo $_SESSION['stradmSupportModalFieldTitleAttachFile']; ?>:</label>
            <div class="controls">
                <input type="file" id="fuFileName" name="fuFileName">
            </div>
		</div>
    </div>
    <div class="modal-footer">
        <span id="ContainerBar" class="progress progress-striped" style="width:200px;border:1px solid #003300;display:none;float:left;">
          <div id="bar" class="bar"></div>
        </span>
        <a href="#" class="btn" id="btnModalSupportCancel" data-dismiss="modal"><? echo $_SESSION['strGlobalCancel']; ?></a>
        <a href="#" class="btn btn-primary" id="btnModalSupportSave" onclick="supportInsert();"><? echo $_SESSION['strGlobalSubmit']; ?></a>
    </div>
</div>

<!-- Panel for View/Insert Response -->
<div class="modal hide fade hideSelection" id="modalSupportResponse">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">�</button>
        <h4><i class="<? echo $support->strDefaultIcon; ?>"></i> <? echo $_SESSION['stradmSupportModalResponseTitle']; ?></h4>
    </div>
    <div class="modal-body">
        <div class="control-group">
			<!-- txtMessageResponse -->
            <label class="control-label"><? echo $_SESSION['stradmSupportModalResponseFieldTitleMessage']; ?>:</label>
            <div class="controls">
	            <textarea class="fullwith" rows="3" id="txtMessageResponse" name="txtMessageResponse"></textarea>
            </div>
            <div style="text-align:right">
	            <a href="#" class="btn btn-primary" id="btnModalSupportResponseSave"  onclick="supportResponseInsert();"><? echo $_SESSION['strGlobalSubmit']; ?></a>
            </div>

            <div name="divMessageResponseLog" id="divMessageResponseLog" class="controls">
            </div>
		</div>
    </div>
</div>
<script>
	function supportLoad(idSupport) {
		if (idSupport > 0) {
			var result = $.ajax({
			  url: "ajax.php?chrAction=SS&idSupport=" + idSupport + '&blnFromSupport=1'
			}).always(function() {
				if (result.responseText) {
					var response 	= result.responseText;
					var retorno 	= JSON.parse(response);
					document.getElementById('divMessageResponseLog').innerHTML = '';
					var strContent = '';
					// Load interactions
					// Responses
					var arrResponses = retorno[0]['arrResponses'];
					for (var i=0;i<arrResponses.length;i++) {
						strContent += '' +
						'<div style="border:1px solid #EEEEEE;margin:5px;padding:5px;background-color:' + (i % 2 == 1 ? '#fdfdfd' : '#f9f9f9') + '" class="rounded">' +
							'<div style="font-weight:bold">' +
								'<span class="notification yelow">' + arrResponses[i]['strDateTime'] + '</span> ' +
								'<span class="' + (arrResponses[i]['blnFromSupport'] > 0 ? 'notification green"><? echo $_SESSION['strGlobalSupport']; ?>:' : 'notification red"><? echo $_SESSION['strGlobalMe']; ?>:') + '</span> ' +
								'<i>' + arrResponses[i]['txtMessage'] + '</i>' +
							'</div>' +
					'</div>';
					}
					// First Message
					strContent += '' +
					'<div style="border:1px solid #EEEEEE;margin:5px;padding:5px;background-color:#fdfdfd" class="rounded">' +
						'<div style="font-weight:bold">' +
							'<span class="notification yelow">' + retorno[0]['strDateTime'] + '</span> ' +
							'<span class="notification red"><? echo $_SESSION['strGlobalMe']; ?>:</span> ' +
							'<i>' + retorno[0]['strSubject'] + '<br>' + retorno[0]['txtMessage'] + '</i>' +
						'</div>' +						
					'</div>';
					document.getElementById('idSupport').value = idSupport;
					document.getElementById('divMessageResponseLog').innerHTML = strContent;
					document.getElementById('txtMessageResponse').value = '';
					document.getElementById('txtMessageResponse').focus();
					$('#modalSupportResponse').modal('show');
				}
			});
		} else {
			document.getElementById('strSubject').value = '';
			document.getElementById('txtMessage').value = '';
			$('#modalSupport').modal('show');
			document.getElementById('strSubject').focus();
		}
	}

	function supportInsert() {
		if (! checkSupportFormRequiredFields()) return;
		document.getElementById('blnInsertSupport').value = 1;
		document.getElementById('frmForm').submit();
	}

	function supportResponseInsert() {
		$('#btnModalSupportResponseSave').button('loading');
		var txtMessageResponse = document.getElementById('txtMessageResponse').value;
		if (! txtMessageResponse) {
			$('#btnModalSupportResponseSave').button('reset');
			return false;
		}
		txtMessageResponse = EliminateSpecialChars(txtMessageResponse);
		txtMessageResponse = replaceAll(txtMessageResponse,'&',' ');
		txtMessageResponse = replaceAll(txtMessageResponse,'\n','<br>');
		var result = $.ajax({
		  url: "ajax.php?chrAction=SRI&idSupport=" + document.getElementById('idSupport').value + "&txtMessage=" + txtMessageResponse
		}).always(function() {
			$('#btnModalSupportResponseSave').button('reset');
			$('#modalSupportResponse').modal('hide');
			supportsLoad('tblSupports');
		});
	}

	function supportDelete(idSupport) {
		var blnDelete = confirm('<? echo $_SESSION['stradmSupportConfirmDelete']; ?>');
		if (! blnDelete) return;
		var result = $.ajax({
		  url: "ajax.php?chrAction=SD&idSupport=" + idSupport
		}).always(function() {
			if (result.responseText > 0) {
				$('#tblSupports_' + idSupport).fadeOut(800, function(){
					$('#tblSupports_' + idSupport).remove();
				});
			}
		});
	}

	function checkSupportFormRequiredFields () {
		if (! document.getElementById('strSubject').value) {
			document.getElementById('strSubject').focus();
			return false;
		}

		if (! document.getElementById('txtMessage').value) {
			document.getElementById('txtMessage').focus();
			return false;
		}
		return true;
	}

	function supportsLoad(idTable) {
		var table = document.getElementById(idTable);
		var tbody = table.getElementsByTagName("tbody")[0];
		tbody.innerHTML = '<tr><td colspan="4"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
		var result = $.ajax({
		  url: "ajax.php?chrAction=SS"
		}).always(function() {
			var response 	= result.responseText;
			var arrResult 	= JSON.parse(response);
			tbody.innerHTML = ''; // Cleaning table
			var rows = tbody.getElementsByTagName("tr").length;
			for (var i=0;i<arrResult.length;i++) {
				var row = tbody.insertRow(i);
				row.id = idTable + '_' + arrResult[i]['idSupport'];
				var cell = row.insertCell(0);
				cell.innerHTML = (i+1);
				var cell = row.insertCell(1);
				cell.innerHTML = (arrResult[i]['strFileName'] ? '<a href="' + arrResult[i]['strFileNameFull'] + '" target="_blank"><i class="icon-file" title="' + arrResult[i]['strFileName'] + '"></i></a>' : '');
				var cell = row.insertCell(2);
				cell.innerHTML = arrResult[i]['strDateTime'];
				cell.className = "hidden-phone";
				var cell = row.insertCell(3);
				cell.innerHTML = '<a href="#" title="<? echo $_SESSION['stradmSupportHintViewCall']; ?>"  onClick="supportLoad(' + arrResult[i]['idSupport'] + ');">' + arrResult[i]['strSubject'] + '</a>';
				var cell = row.insertCell(4);
				cell.innerHTML = arrResult[i]['intInteractions'] + (arrResult[i]['intAdminUnreadInteractions'] > 0 ? ' | <span style="color:#FF0000;font-weight:bold">' + arrResult[i]['intAdminUnreadInteractions'] + ' <? echo $_SESSION['stradmSupportNewMessages']; ?></span>' : '');
				cell.className = "hidden-phone";
				var cell = row.insertCell(5);
				cell.innerHTML = arrResult[i]['strDateTimeLastInteraction'] + (arrResult[i]['intUserUnreadInteractions'] > 0 ? '<br><span style="font-weight:bold;color:#FF0000">' + arrResult[i]['intUserUnreadInteractions'] + ' <? echo $_SESSION['stradmSupportNewMessages']; ?></span>': '');
				cell.className = "hidden-phone";
				var cell = row.insertCell(6);
				cell.innerHTML = '<span class="btn btn-success" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmSupportHintViewCall']; ?>" onClick="supportLoad(' + arrResult[i]['idSupport'] + ');"><i class="icon-eye-open icon-white"></i></span>' +
					(arrResult[i]['blnShowDelete'] > 0 ? '<span class="btn btn-danger" style="margin-left:3px;" data-rel="tooltip" title="<? echo $_SESSION['stradmSupportHintDelete']; ?>" onClick="supportDelete(' + arrResult[i]['idSupport'] + ');"><i class="icon-trash icon-white"></i></span>' : '');
				cell.style.whiteSpace = "nowrap";
				// Setting cells alignment
				for (var j=0;j<=6;j++) {
					tbody.rows[i].cells[j].style.textAlign = "center";
				}
				tbody.rows[i].cells[3].style.textAlign = "left";

			}
		});
	}

	$(document).ready( function () {
		$('#tblSupports').dataTable({"bFilter": false,"bPaginate": false, "bInfo": false, "bSort" : false});
		supportsLoad('tblSupports');
	});
</script>