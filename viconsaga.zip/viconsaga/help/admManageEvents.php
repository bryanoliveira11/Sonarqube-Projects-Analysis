<div id="sessionTitle"><i class="<? echo $database->strEventLogDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageUserEvents']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageEvents-overview.jpg" width="100%"