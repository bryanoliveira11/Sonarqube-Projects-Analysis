<div id="sessionTitle"><i class="<? echo $formrecord->strDefaultIcon; ?>"></i> Criar/Editar Registro</div>
<div id="sessionTitle"><i class="icon-map-marker"></i> <? echo $_SESSION['strRecordEditSessionMapTitle']; ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/recordEdit-overview.jpg" width="100%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>
	<div class="input-prepend input-append">
    <span class="dropdown-toggle add-on" data-toggle="dropdown"><i class="icon-map-marker"></i><span class="caret" style="position:relative;top:7px;"></span></span>
    <span class="add-on" style="cursor:pointer;"><img src="../img/myLocation.png" style="width:16px;height:17px;position:relative;top:-1px;"></span></td>
    </div>
    <td>Busca de uma localidade através do endereço digitado. Para efetuar a busca é necessário digitar o endereço desejado e teclar ENTER. A ação indicará no mapa o marcador <img src="../img/target.png" width="19" height="18" /> na localidade referente ao endereço buscado.<br />
Exemplo: Av Presidente Vargas, 290 - Centro. <br /><b>Essa funcionalidade utiliza o serviço <a href="https://developers.google.com/maps/documentation/geocoding/" target="_blank">Google Geocoding</a></b></td>
  </tr>
  <tr>
    <td>2</td>
    <td>
    <span>
        <a id="btnIM_1" href="#" class="btn"><img src="../<? echo $strings->strImgFilePathByidShapeType(1); ?>" style="width:16px;height:16px;"/></a>
        <a id="btnIM_2" href="#" class="btn"><img src="../<? echo $strings->strImgFilePathByidShapeType(2); ?>" style="width:16px;height:16px;"/></a>
        <a id="btnIM_3" href="#" class="btn"><img src="../<? echo $strings->strImgFilePathByidShapeType(3); ?>" style="width:16px;height:16px;"/></a>
    </span>
    </td>
    <td>
    Forma selecionada pelo usuário. Vide maiores detalhes na seção <a href="#shapetype">Tipos de Formas</a>.<br />
    Ponto - Habilita a criação de um marcador do tipo ponto ao ser selecionado.<br />
    Linha - Habilita a criação de um marcador do tipo linha ao ser selecionado.<br />
    Polígono - Habilita a criação de um marcador do tipo polígono ao ser selecionado.
    </td>
  </tr>
  <tr>
    <td>3</td>
    <td>Controle de navegação</td>
    <td>Botões de seta para mover a visualização do mapa nas direções norte, sul, leste ou oeste</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Google Street View</td>
    <td>Arraste o <img src="img/recordEdit-streetView.png" alt="" width="16" height="30" /> para um local no mapa e visualize e navegue pelas imagens de rua</td>
  </tr>
  <tr>
    <td>5</td>
    <td>
    <ul class="nav nav-tabs nav-stacked main-menu" style="cursor:pointer;white-space:nowrap;background-color:#FFFFFF">
    <li><a><i class="icon-list"></i> <? echo $_SESSION['strRecordEditSessionFieldsTitle']; ?></a></li>
    </ul>
    </td>
    <td>Campos do formulário selecionado para o cadastro de um novo registro. Para efetivar a criação do registro, o usuário deverá clicar no botão SALVAR no final da página.
Maiores detalhes acerca dos tipos de dados para preenchimento de formulários podem ser verificados na seção <a href="datatypes" target="_self">Tipos de Dados</a></td>
  </tr>
  <tr>
    <td>6</td>
    <td><a href="#" class="btn btn-success" style="margin:5px;"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></a></td>
    <td>Salva o cadastro efetuado pelo usuário</td>
  </tr>
</table>
<div id="sessionTitle"><i class="icon-file"></i> <? echo $_SESSION['strRecordEditSessionFilesTitle']; ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/recordEdit-files.jpg" width="100%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Upload<br><i class="icon-upload"></i></td>
    <td>Botão para seleção e upload de arquivo(s) relacionado(s) ao registro cadastrado</td>
  </tr>
  <tr>
    <td>2</td>
    <td><a style="margin:5px" class="btn btn-info"><i class="icon-edit icon-white"></i></a></td>
    <td>Inserir legenda descritiva referente para o arquivo anexado.</td>
  </tr>
  <tr>
    <td>3</td>
    <td><a style="margin:5px" class="btn btn-danger"><i class="icon-trash icon-white"></i></a></td>
    <td>Remove o arquivo anexado</td>
  </tr>
</table>
<div id="sessionTitle"><a name="shapetype" id="shapetype">Tipos de Formas</a></div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th style="width:10%;line-height:27px;">Formato</td>
    <th style="width:30%;text-align:center">Ponto <img src="../<? echo $strings->strImgFilePathByidShapeType(1); ?>" style="width:16px;height:16px;"/></th>
    <th style="width:30%;text-align:center">Linha <img src="../<? echo $strings->strImgFilePathByidShapeType(2); ?>" style="width:16px;height:16px;"/></th>
    <th style="width:30%;text-align:center">Polígono <img src="../<? echo $strings->strImgFilePathByidShapeType(3); ?>" style="width:16px;height:16px;"/></th>
  </tr>
  </thead>
  <tr>
    <td>Ilustração</td>
    <td><img src="img/recordEdit-marker.png" style="width:100%;height:200px"/></td>
    <td><img src="img/recordEdit-polyline.png" style="width:100%;height:200px"/></td>
    <td><img src="img/recordEdit-polygon.png" style="width:100%;height:200px"/></td>
  </tr>
  <tr>
    <td>Exemplo de aplicação</td>
    <td style="font-weight:normal">Geralmente utilizado na representação de objetos de pequenas dimensões espaciais. O tamanho ou a dimensão da entidade pode não ser uma informação importante, somente sua localização pontual<br />
      Ex: postes, árvores, hidrantes</td>
    <td>É utilizada na representação de entidades cuja largura não convém ser expressada graficamente <br />
      Ex: estradas, rios, redes de linha de transmissão de energia elétrica, redes de saneamento</td>
    <td>São usados para representar áreas e são definidos como um conjunto ordenado de pontos onde o primeiro e o último ponto coincidem.<br />
      Ex: terrenos, quarteirões, áreas devastadas</td>
  </tr>
  <tr>
    <td>Inserir marcador</td>
    <td style="font-weight:normal">Selecione a opção Ponto <img src="../<? echo $strings->strImgFilePathByidShapeType(1); ?>" style="width:16px;height:16px;"/> no canto superior direito e clique no local desejado no mapa. O ícone definido para este formulário aparecerá no local selecionado pelo usuário</td>
    <td>Selecione a opção Linha <img src="../<? echo $strings->strImgFilePathByidShapeType(2); ?>" style="width:16px;height:16px;"/> no canto superior direito e clique no local desejado no mapa para dar início ao traçado da linha. Um vértice branco aparecerá após o primeiro clique. O usuário deve clicar novamente no próximo local do mapa para então visualizar a linha traçada. Para estender a linha, basta clicar em outros locais para adicionar novos vértices e prolongá-la</td>
    <td>Selecione a opção Polígono <img src="../<? echo $strings->strImgFilePathByidShapeType(3); ?>" style="width:16px;height:16px;"/> no canto superior direito e clique no local desejado no mapa para o início do traçado do polígono. Um vértice branco aparecerá após o primeiro clique. O usuário deve clicar novamente nos próximos locais do mapa para então visualizar o polígono</td>
  </tr>
  <tr>
    <td>Editar marcador</td>
    <td style="font-weight:normal">Para mudar o marcador de posição basta clicar    sobre ele e arrastá-lo até o local desejado. <br />
      Não é possível alterar o formato do ícone nem sua cor, uma vez que o mesmo foi definido pelo gerente de projeto na criação do formulário</td>
    <td>Para apagar um vértice basta clicar com o botão direito do mouse sobre ele. <br />
      Para criar um novo vértice a partir de uma linha já traçada, clique no vértice intermediário apresentado no meio dela e o arraste para onde desejar.<br />
      Para desfazer algum movimento, clique no botão <img src="img/recordEdit-undo.jpg" align="absmiddle"/> apresentado ao lado do vértice arrastado</td>
    <td>Para apagar um vértice basta clicar com o botão direito do mouse sobre ele. <br />
      Para criar um novo vértice a partir de uma linha já traçada, clique no vértice intermediário apresentado no meio dela e o arraste para onde desejar. <br />
      Para desfazer algum movimento, clique no botão <img src="img/recordEdit-undo.jpg" align="absmiddle"/> apresentado ao lado do vértice arrastado</td>
  </tr>
</table>
