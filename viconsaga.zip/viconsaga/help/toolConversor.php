<div id="sessionTitle"><i class="icon-resize-horizontal"></i> <? echo utf8_encode($_SESSION['strHomeToolsCoordinatesConversor']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/toolConversor-GeoUTM.jpg" width="80%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Tipo de conversão</td>
    <td>Seleção da opção de entrada para a conversão de coordenadas. As opções são:
<br />
- Coordenadas Geográficas » Coordenadas UTM<br />
- Coordenadas UTM &lt;Northing (y);Easting (x);Fuso&gt; » Coordenadas Geográficas &lt;lat;long&gt;</td>
</tr>
   <tr>
    <td>2</td>
    <td><a class="btn btn-success" style="margin:5px;"/><i class="icon-play icon-white"></i> <b><? echo $_SESSION['strToolConversorBtnConvert']; ?></b></a></td>
    <td>Botão para efetivar a conversão das coordenadas inseridas no campo de entrada</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Datum de entrada</td>
    <td>Datum de entrada para conversão</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Datum de saída</td>
    <td>Datum de saída para conversão</td>
  </tr>
  <tr>
    <td>5</td>
    <td>Entrada de coordenadas</td>
  <td>Campo para inserção das coordenadas para conversão. <strong>Os dados devem estar em formato csv para serem aceitos</strong>
<br />Exemplo formato de entrada:
<br />7475000,34;650232,33;27Q
<br />7604343;644021;23J
<br />7450220,12;550203,23;34L
  </td>
  </tr>
  <tr>
    <td>6</td>
    <td><a class="btn btn-success" style="margin:5px;"/><i class="icon-download icon-white"></i></b></a></td>
    <td>Baixar tabela de conversão em arquivo</td>
  </tr>
</table>