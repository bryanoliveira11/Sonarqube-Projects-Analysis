<div id="sessionTitle">Vicon SAGA Mobile - Login</div>
<p style="color:#FF0000;font-weight:bold;font-size:16px">Para efetuar o primeiro acesso o usuário deverá estar necessariamente conectado à internet. Os demais acessos não precisam de conexão com a internet.</p>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-Login.png" width="220">
	<div id="imagemLegenda">Tela de login de usuário - Primeiro acesso</div> 
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>E-Mail</td>
    <td>Campo para digitação do e-mail de acesso ao sistema.
    <br /><b>Para efetuar login, o usuário deverá ter um cadastro em algum projeto do sistema Vicon Web</b>
    </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Senha</td>
    <td>Campo para digitação da senha de acesso ao sistema</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Entrar </td>
    <td>Botão de entrada no sistema</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Esqueci minha senha</td>
    <td>Caso esqueça sua senha, o usuário poderá redefini-la clicando no botão "Esqueci minha senha". Uma mensagem será encaminhada instantaneamente ao e-mail do usuário com uma nova senha de acesso</td>
  </tr>
  <tr>
    <td>5</td>
    <td>Sair do aplicativo</td>
    <td>Botão para fechar o aplicativo</td>
  </tr>
</table>
<div id="sessionTitle">Login - Seleção de Projeto</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-LoginProjeto.png" width="220">
	<div id="imagemLegenda">Após efetuar login -> Selecionar projeto do usuário</div> 
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Seleção de projeto</td>
    <td>Para cada projeto será apresentado um botão de seleção. O usuário deve tocar sobre o projeto desejado para selecioná-lo</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Logout</td>
    <td>Botão para efetuar logout do aplicativo</td>
  </tr>
</table>