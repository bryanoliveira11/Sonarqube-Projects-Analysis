<div id="sessionTitle"><i class="<? echo $form->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageForms']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageForms-overview.jpg" width="80%">
	<div id="imagemLegenda">Visão Geral da Administração de Formulários</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Seleção de formulário</td>
    <td>Lista de formulários do projeto. O usuário deve selecionar algum formulário da lista apresentada para gerenciar suas propriedades</td>
  </tr>
  <tr>
    <td>2</td>
    <td>
    	<a class="btn btn-success" style="margin:5px"><i class="icon-eye-open icon-white"></i></a>
		<a class="btn btn-danger" style="margin:5px"><i class="icon-eye-close icon-white"></i></a>
	</td>
    <td>Ativar/Desativar Formulário - Ao desativar o formulário selecionado, nenhum registro deste formulário será exibido para na tela de visualização de registros</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Marcador do formulário</td>
    <td>
	<img src="img/admManageForms-inserirforma.jpg" style="float:right;margin-left:10px;"/>
    Ícone definido como marcador do formulário selecionado no campo 1. O usuário pode alterar a forma clicando sobre ela. Uma tela com diversas sugestões de figuras será apresentada para escolha do usuário. Através do botão CARREGAR DE ARQUIVO será possível carregar um ícone da preferência do usuário diretamente do seu computador.
    </td>
  </tr>
  <tr>
    <td>4</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-plus-sign icon-white"></i></a></td>
    <td>Criar formulário no projeto. Após definir o nome do novo formulário, o usuário deverá adicionar os campos necessários através do botão ADICIONAR CAMPO</td>
  </tr>
  <tr>
    <td>5</td>
    <td><a class="btn btn-info" style="margin:5px"><i class="icon-refresh icon-white"></i></a></td>
    <td>Alteração do nome do formulário selecionado</td>
  </tr>
  <tr>
    <td>6</td>
    <td><a class="btn btn-danger" style="margin:5px"><i class="icon-trash icon-white"></i></a></td>
    <td>Botão para remover o formulário selecionado
		<br /><span style="color:#FF0000;font-weight:bold">ATENÇÃO: ao remover um formulário todos os seus registros serão apagados definitivamente do sistema</span>
  </td>
  </tr>
  <tr>
    <td>7</td>
    <td>Reordenar campo</td>
    <td>O usuário pode mudar a ordem de exibição de um campo no formulário. Ao clicar nesse botão o usuário indica a nova posição desejada para aquele campo</td>
  </tr>
  <tr>
    <td>8</td>
    <td>Nome do campo</td>
    <td>Nome que o campo apresentará no formulário.
<br /><b>DICA: Caso deseje criar campos de preenchimento obrigatório, marque-o com um * no final do enunciado. Ex: Proprietário*</b>
</td>
  </tr>
  <tr>
    <td>9</td>
    <td>Tipo de resposta</td>
    <td>Definição do tipo de dados que estarão contidos naquele campo. Para maiores informações consulte a seção <a href="s=tiposdados" target="_self">Tipos de Dados</a>
  </tr>
  <tr>
    <td>10</td>
    <td>Alternativas</td>
    <td>Criação de alternativas de respostas para aquele campo. Essa opção só ficará disponível para os campos com os tipos de resposta abaixo:
<br />- Única escolha
<br />- Multi escolha
<br />Para maiores informações consulte a seção <a href="s=tiposdados" target="_self">Tipos de Dados</a>
</td>
  </tr>
  <tr>
    <td>11</td>
    <td>Descrição</td>
    <td>Orientação sobre o preenchimento do campo.
    <br /><b>DICA: Fórmulas podem ser criadas usando os campos do formulário. Para a criação de um campo de fórmula é preciso assinalá-lo como tipo NUMÉRICO. Todos os campos envolvidos na fórmula também deverão ser do tipo NUMÉRICO.
    <br />Operadores aceitos: +-*/
	<br />Ex: C1+C2+C3/C4 onde C1 = Campo na posição 1
	</b>
</td>
  </tr>
  <tr>
    <td>12</td>
    <td><img src="../img/save.png" style="width:18px;height:18px;"></td>
    <td>Salvar alterações do campo no formulário</td>
  </tr>
  <tr>
    <td>13</td>
    <td><a class="btn btn-danger" style="margin:5px"><i class="icon-trash icon-white"></i></a></td>
    <td>Remover o campo formulário</td>
  </tr>
  <tr>
    <td>14</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-plus-sign icon-white"></i> Inserir campo</a></td>
    <td>Inserir novo campo no formulário</td>
  </tr>
</table>
<div id="sessionTitle"><a name="admalternatives" id="admalternatives">Editar Alternativas</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageForms-detailAlternativas.jpg">
	<div id="imagemLegenda">Editar Alternativas de Campos Única e Múltipla Escolha</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Alternativa</td>
    <td>Alternativas criadas para o campo</td>
  </tr>
  <tr>
    <td>2</td>
    <td><a class="btn btn-danger" style="margin:5px"><i class="icon-trash icon-white"></i></a></td>
    <td>Remover a alternativa</td>
  </tr>
  <tr>
    <td>3</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-plus-sign icon-white"></i></a></td>
    <td>Adicionar várias alternativas de uma só vez.  Ao clicar no botão, uma área de texto será exibida para que o usuário insira as alternativas, sendo uma em cada linha</td>
  </tr>
  <tr>
    <td>4</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-plus-sign icon-white"></i> Inserir</a></td>
    <td>Adiconar uma nova alternativa de resposta</td>
  </tr>
</table>