<div id="sessionTitle">Vicon SAGA Mobile - Menu</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-Menu.png" width="220">
	<div id="imagemLegenda">Tela do Menu Principal</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Criar registro</td>
    <td>Abrir tela para criação de um novo registro</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Meus registros</td>
    <td>Listagem dos registros cadastrados pelo usuário através do dispositivo móvel. Caso o usuário deseje editar o(s) registro(s) ou enviá-lo(s) para o servidor deverá ser feito por meio desta tela (vide seção <a href="mobrecords" target="_self">Meus Registros</a>)</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Configurações</td>
    <td>Configurações de preferências do aplicativo.  As preferências têm efeito apenas para o usuário logado</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Vicon Web </td>
    <td>Abrir o navegador do dispositivo móvel e direciona o usuário para um site customizado do Vicon Web Mobile.
    <br />O sistema mobile permite ao usuário cadastrar registros enviá-los diretamente ao servidor, bem como consultar registros e visualizá-los no mapa (vide seção Vicon Web).<b>Só é possível acessar o Vicon Web se o usuário estiver conectado à internet</b></td>
  </tr>
  <tr>
    <td>5</td>
    <td>Seleção de projetos</td>
    <td>Botão para retornar à tela de seleção de projetos e permitir que o usuário selecione outro projeto para trabalhar</td>
  </tr>
  <tr>
    <td>5</td>
    <td><img src="img/mobile-MenuFechar.png" alt="Fechar" align="absmiddle"/> Sair do aplicativo</td>
    <td>Botão para sair do aplicativo</td>
  </tr>
</table>