<div id="sessionTitle">Resultado da Busca - Termo "<? echo $_POST['helpSearchBox']; ?>"</div>
<? 
	// Performar busca
	if ($_POST['helpSearchBox']) {
		$dirAjuda = './';
		$vtFiles = $strings->returnFolderFilesList($dirAjuda);
		foreach($vtFiles as $arq) {
			if (file_exists($arq)) {
				$conteudo = file_get_contents($arq);
				$conteudo = strip_tags($conteudo);
				while (strpos($conteudo,$_POST['helpSearchBox'])) {
		            $nome = explode(".",$arq);
		            $nome = basename($nome[0]);
					// Remover tags do código
					$strTrecho =  '...' . substr($conteudo, strpos($conteudo,$_POST['helpSearchBox']) - 100, 200) . '...';
					$strTrecho =  $strings->highlightText($strTrecho, $_POST['helpSearchBox']);
					echo '<div style="line-height:35px;"><i class="icon-search"></i> <b>[' . $nome . ']</b> - <a href="?s=' . $nome . '" target="_self" style="text-decoration:none">' . $strTrecho . '</a><div>';
					$conteudo = substr($conteudo,strpos($conteudo,$_POST['helpSearchBox'])+1,strlen($conteudo));
				}
			}
		}
	}
?>