<? 
	session_start();
	include_once '../engine/database.php';
	$database = new Database();
	include_once '../engine/strings.php';
	$strings = new Strings();
	include_once '../engine/project.php';
	$project = new Project($database);
	include_once '../engine/user.php';
	$user = new User($database);
	include_once '../engine/form.php';
	$form = new Form($database);
	include_once '../engine/formrecord.php';
	$formrecord = new Formrecord($database);
	include_once '../engine/importer.php';
	$importer = new Importer($database);
	include_once '../engine/stats.php';
	$stats = new Stats($database);
	
	// Loading strings according to selected language
	$strings->loadLanguage($_SESSION['strSiteLanguage'], '../');
	
	if (! $_GET["s"]) $_GET["s"] = 'home';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><? echo $strings->strSiteName . ' - Ajuda'; ?></title>
    <link href="../css/bootstrap.css" rel="stylesheet">
	<link href="../css/bootstrap-cerulean.css" rel="stylesheet">
	<link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/main.css" rel="stylesheet">
	<link href="../css/charisma.css" rel="stylesheet">
	<link href="../css/help.css" rel="stylesheet">
    <link rel="shortcut icon" href="../img/logofav.png">
    <script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap-tooltip.js"></script>
	<script src="../js/bootstrap-button.js"></script>
	<script src="../js/jquery.dataTables.js"></script>
    <script src="../js/main.js"></script>
    <meta name="google-translate-customization" content="abd3dc1925474c63-a2869f02e2b1a887-ge0834d829e6eb832-1a"></meta>
	<style>iframe.goog-te-banner-frame{ display: none !important;}</style>
</head>
<body id="helpBody">
<form action="<? echo $_SERVER["PHP_SELF"] . '?s=search'; ?>" method="post" name="form" id="form" enctype="multipart/form-data">
	<!-- Conteúdo inferior (Menu + Conteúdo da Ajuda)  --> 
    <div id="helpMenu" class="hideSelection">
		<input name="helpSearchBox" id="helpSearchBox" style="width:90%;margin:10px;" autocomplete="off" class="helpSearchBox" type="text" placeholder="Pesquisar em Ajuda de <? echo $strings->strSiteName; ?>" value="<? echo $_POST['helpSearchBox']; ?>">
        <!--
        <div id="google_translate_element" style="width:100%;margin-bottom:-25px;text-align:center"></div>
        <script type="text/javascript">
        function googleTranslateElementInit() {
          new google.translate.TranslateElement({pageLanguage: 'pt', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false}, 'google_translate_element');
        }
        </script>
        <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        -->
        <a href="agenda" class="<? if ($_GET['s']=='agenda') echo 'menuItemSelected'; ?>"><i class="icon-font"></i> Quick Start - Agenda Cidadã</a>
        <a href="start" class="<? if ($_GET['s']=='home') echo 'menuItemSelected'; ?>"><i class="icon-eye-open"></i> Visualização de Registros</a>
        <a href="create" class="<? if ($_GET['s']=='recordEdit') echo 'menuItemSelected'; ?>"><i class="<? echo $formrecord->strDefaultIcon; ?>"></i> Criar/Editar Registro</a>
        <span class="nivel1">Menu Usuário</span>
        <a href="profile" class="nivel2 <? if ($_GET['s']=='admEditProfile') echo 'menuItemSelected'; ?>"><i class="icon-pencil"></i> <? echo utf8_encode($_SESSION['strIndexMenuEditProfile']); ?></a>
        <a href="stats" class="nivel2 <? if ($_GET['s']=='admStats') echo 'menuItemSelected'; ?>"><i class="<? echo $stats->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuStats']); ?></a>
        <span class="nivel1"><? echo utf8_encode($_SESSION['strHomeTools']); ?></span>
        <a href="geocoder" class="nivel2 <? if ($_GET['s']=='toolGeocoder') echo 'menuItemSelected'; ?>"><i class="icon-screenshot"></i> <? echo utf8_encode($_SESSION['strHomeToolsGeocoder']); ?></a>
        <a href="conversor" class="nivel2 <? if ($_GET['s']=='toolConversor') echo 'menuItemSelected'; ?>"><i class="icon-resize-horizontal"></i> <? echo utf8_encode($_SESSION['strHomeToolsCoordinatesConversor']); ?></a>
        <a href="importer" class="nivel2 <? if ($_GET['s']=='toolImporter') echo 'menuItemSelected'; ?>"><i class="<? echo $importer->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strHomeToolsDataImporter']); ?></a>
        <span class="nivel1"><? echo utf8_encode($_SESSION['strIndexMenuProjectManagement']); ?></span>
        <a href="project" class="nivel2 <? if ($_GET['s']=='admManageProject') echo 'menuItemSelected'; ?>"><i class="icon-wrench"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementConfiguration']); ?></a>
        <a href="events" class="nivel2 <? if ($_GET['s']=='admManageEvents') echo 'menuItemSelected'; ?>"><i class="<? echo $database->strEventLogDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageUserEvents']); ?></a>
        <a href="users" class="nivel2 <? if ($_GET['s']=='admManageUsers') echo 'menuItemSelected'; ?>"><i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageUsers']); ?></a>
        <a href="forms" class="nivel2 <? if ($_GET['s']=='admManageForms') echo 'menuItemSelected'; ?>"><i class="<? echo $form->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageForms']); ?></a>
        <span class="nivel1">Extras</span>
        <a href="datatypes" class="nivel2 <? if ($_GET['s']=='tiposdados') echo 'menuItemSelected'; ?>">Tipos de dados</a>
        <a href="usertypes" class="nivel2 <? if ($_GET['s']=='tiposusuarios') echo 'menuItemSelected'; ?>">Níveis e Permissões de Usuários</a>
        <a href="lesson" class="nivel2 <? if ($_GET['s']=='extexercicio') echo 'menuItemSelected'; ?>">Exercício: Criação e Consulta</a>
        <a href="api" class="nivel2 <? if ($_GET['s']=='api') echo 'menuItemSelected'; ?>">Vicon API</a>
        <a href="terms-use" class="nivel2 <? if ($_GET['s']=='terms-use') echo 'menuItemSelected'; ?>">Termos de Uso</a>
        <a href="https://play.google.com/store/apps/details?id=br.com.viconsaga.mobile&feature=search_result" target="_blank"><span class="nivel1"><img src="../img/android.png" alt="Android" height="24" align="absmiddle" style="float:right;margin-right:15px;top:-10px;position:relative"/> Vicon SAGA Mobile</a></span> 
        <a href="mobile-login" class="nivel2 <? if ($_GET['s']=='mobilelogin') echo 'menuItemSelected'; ?>">Login</a>
        <a href="mobile-menu" class="nivel2 <? if ($_GET['s']=='mobilemenu') echo 'menuItemSelected'; ?>">Menu Principal</a>
        <a href="mobile-create" class="nivel2 <? if ($_GET['s']=='mobilecriarregistro') echo 'menuItemSelected'; ?>">Criar Registro</a>
        <a href="mobile-records" class="nivel2 <? if ($_GET['s']=='mobilemeusregistros') echo 'menuItemSelected'; ?>">Meus Registros</a>
        <a href="mobile-config" class="nivel2 <? if ($_GET['s']=='mobileconfiguracoes') echo 'menuItemSelected'; ?>">Configurações</a>
    </div>
	<div id="helpContent">
   		<i class="icon-print" style="margin-right:24px;position:relative;top:35px;cursor:pointer;float:right;" onClick="window.open('print.php?s=<? echo $_GET['s']; ?>')"></i>
		<div style="padding:10px;">
		<?
        // Caso não tenha nenhum s, vou colocar ele no login
		@include($_GET['s'] . '.php');
        ?>
        </div>
	</div>	
</form>
</body>
</html>
<script>
	$(document).ready( function () {
		$("#helpMenu").resizable();
		
		// Smooth Scroll
		$(".scroll").click(function(event){
			$('html,body').animate({scrollTop:$(this.hash).offset().top}, 800);
	   });
	});
</script>