<style>
td:nth-child(2) {
	text-align:justify;
}
</style>
<div id="sessionTitle">Visualização de Registros</div>
<div id="imagem">
	<img id="imagemShot" src="home/overview.png" width="100%">
	<div id="imagemLegenda">Visão geral da tela de visualização de Registros</div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td><img src="../img/treeView.png" style="height:20px" /><br />Árvore de Registros</td>
    <td>Listagem dos formulários que contêm registros no projeto.
    <br />Marcando/desmarcando o checkbox ao lado do nome do formulário, os registros do formulário serão exibidos/ocultados no mapa.
    <br /><b>NOTA: Quando não há nenhum registro criado para um determinado formulário, ele não será disposto nesta lista.</b>
    </td>
  </tr>
  <tr>
    <td><img src="../img/tools.png" style="height:20px" /><br />Ferramentas do Mapa</td>
    <td>Abrir o <a href="#mapTools" class="scroll" target="_self">painel de ferramentas</a></td>
  </tr>
  <tr>
    <td>Mapa</td>
    <td>Mapa Google Maps com registros do projeto.</td>
  </tr>
  <tr>
    <td>Coordenadas do Cursor</td>
    <td><div id="imagem"><img src="home/coordinates.png"/></div>Informação das coordenadas geográficas &lt;latitude&gt;:&lt;longitude&gt; sob o cursor do mouse.</td>
  </tr>
  <tr>
    <td>Campo de Pesquisa</td>
    <td>
		<div id="imagem"><img src="home/searchfield.png"/></div>
    	<ul>
        	<li>
                <b>Registros:</b> Campo para busca por registros no banco de dados do projeto.
                <br />A medida que o usuário digita o termo de busca, uma lista de opções que satisfazem o termo de busca é exibida.
                <br />Ao clicar em uma opção da lista de alternativas o mapa será centrado na posição do registro selecionado.
                <div id="imagem">
                    <img id="imagemShot" src="home/searchrecordsresult.png" style="width:300px">
                    <div id="imagemLegenda">Resultados da busca por registros no campo de pesquisa</div>    
                </div>
            </li>
        	<li>
	            <b>Local:</b> Busca de localidades geográficas através da ferramenta de geocodificação de endereços do Google Maps
                <div id="imagem">
                    <img id="imagemShot" src="home/searchmapresult.png" style="width:300px">
                    <div id="imagemLegenda">Resultados da busca por local no campo de pesquisa</div>
                </div>
            </li>
        	<li>
	            <b>Coordenadas:</b> Busca de localidade geográfico a partir de um par de coordenadas no formato GRAU DECIMAL.
                <div id="imagem">
                    <img id="imagemShot" src="home/searchcoordinates.png">
                    <div id="imagemLegenda">Resultados da busca por par de coordenadas</div>
                </div>
            </li>
        </ul>
    </td>
  </tr>
</table>
<div id="sessionTitle"><a name="mapTools" id="mapTools">Ferramentas do Mapa</a></div>
<div id="imagem">
	<img id="imagemShot" src="home/mapTools.png">
	<div id="imagemLegenda">Barra de Ferramentas do Mapa</div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td><img src="../img/zoom-extent.png" style="height:16px" alt="" align="absmiddle"/> [Z] Centrar no mapa</td>
    <td>Centrar no mapa o registro selecionado na árvore de registros.</td>
  </tr>
  <tr>
    <td><i class="icon-print"></i> [P] Imprimir</td>
    <td>Abre uma nova aba do navegador com detalhes completos do registro selecionado formatado para impressão.</td>
  </tr>
  <tr>
    <td><i class="icon-edit"></i> [E] Editar</td>
    <td>Abre uma nova janela no navegador com registro selecionado no modo de edição.
    <br /><font color="#FF0000"><b>As permissões para edição de um registro seguem as regras de <a href="usertypes" target="_self">nível de usuários</a> e <a href="project" target="_self">Configurações e Aparência » Permissões » Um registro só poderá ser alterado por</b></font>
    </td>
  </tr>
  <tr>
    <td><img src="../img/shape-polygon.png" style="width:16px;" align="absmiddle"> [A] Filtrar pela área</td>
    <td>Ativa o modo de <a href="#consultaespacialpoligono" target="_self">filtragem por polígono</a>, aplicando o polígono marcado como área de consulta.
    <br /><font color="#FF0000"><b>Opção disponível apenas para registros do tipo Polígono.</b></font>
    </td>
  </tr>
  <tr>
    <td><img src="../img/pallete.png" style="width:16px;" align="absmiddle"> [C] Alterar cor</td>
    <td>Alterar a cor do registro selecionado.<br />
    <b style="color:#FF0000">Opção disponível apenas para registros do tipo Linha e Polígono.</b>
    </td>
  </tr>
  <tr>
    <td><i class="icon-trash"></i> [Del] Remover</td>
    <td>Remover o registro selecionado do projeto.<br />
    <b style="color:#FF0000">
    	As permissões para edição de um registro seguem as regras de <a href="usertypes" target="_self">nível de usuários</a>
    </b>
    </td>
  </tr> 
  <tr>
    <td><i class="icon-font"></i> [T] Inserir Toponímia de Mapa</td>
    <td>
        Para usuários logados é possível inserir textos no mapa, conforme a ilustração a seguir.<BR />
        As toponímias editáveis por este usuário estão na cor <b style="color:#006600">VERDE</b>.  Para editar uma toponímia basta dar um duplo clique sobre a mesma.<BR />
        Para REMOVER um topomínia, basta selecioná-la com um clique simples e pressionar a tecla DELETE.<br />
        <b style="color:#FF0000">
        OBS.: As toponímias criadas por um usuário poderão somente ser excluídas ou alteradas por ele mesmo.
        </b>
        <div id="imagem">
            <img id="imagemShot" src="home/toponimy.png">
            <div id="imagemLegenda">Toponímia de mapa</div>    
        </div>
    </td>
  </tr> 
  <tr>
    <td><img src="../img/target.png" style="width:16px;" align="absmiddle"> [M] Centrar nas coordenadas</td>
    <td>Acionar o modo de pesquia por par de coordenadas.</td>
  </tr>
  <tr>
    <td><img src="../img/ruller.png" style="width:16px;" align="absmiddle"> [D] Medir distâncias</td>
    <td>
		Ativar ferramenta de medição de distância através de uma polyline.
        <br />A informação da distância medida é exibida no canto inferior esquerdo do mapa.  
        <br />Para reiniciar a medição basta clicar novamente no botão "[D] Medir distâncias" do painel de ferramentas.
        <br />Para desativar o modo de medição clique no <i class="icon-remove"></i> ao lado do botão de ativação
        <div id="imagem">
            <img id="imagemShot" src="home/toolMeasureDistance.png">
            <div id="imagemLegenda">Ferramenta de "Medir distâncias" ativada.</div>    
        </div>
    </td>
  </tr>
  <tr>
    <td><i class="icon-filter"></i> [1] Filtrar Registros</td>
    <td>
    	Abrir janela de gerenciamento de filtros de consulta.  Nesta seção o usuário poderá criar regras condicionais para filtrar registros, baseados na lógica booleana.
        <br /><b>Ex.: <i>"Todos os hidrantes de coluna em situação operacional OPERANTE no bairro de COPACABANA."</i></b>
        <br />Para desativar o modo de filtragem clique no <i class="icon-remove"></i> ao lado do botão de ativação
        <br />A informação da quantidade de registros dentro da área de filtragem é exibida no canto inferior esquerdo do mapa, ao lado da informação das coordenadas do cursor.
	    <br />Maiores detalhes na seção <a href="#filtros" class="scroll" target="_self">Gerenciamento de Filtros de Busca</a>
    </td>
  </tr>
  <tr>
    <td><a name="consultaespacialpoligono" id="consultaespacialpoligono"></a><img src="../img/shape-polygon.png" style="width:16px;" align="absmiddle"> [2] Filtrar por área</td>
    <td>
    	Ativar o modo de filtragem espacial por registros dentro de um polígono irregular editado pelo usuário.
        <br />Ao ativar a ferramenta, todos os registros são ocultados.
        <br />A medida que o polígono é construído os registros localizados no interior da forma serão exibidos.
        <br /><b>Neste modo de busca apenas os registros dentro da área de busca serão exportados para relatórios e mapas.</b>
        <br />Para desativar o modo de filtragem clique no <i class="icon-remove"></i> ao lado do botão de ativação
        <br />A informação da quantidade de registros dentro da área de filtragem é exibida no canto inferior esquerdo do mapa, ao lado da informação das coordenadas do cursor.
        <div id="imagem">
            <img id="imagemShot" src="home/toolFilterByArea.png" width="80%">
            <div id="imagemLegenda">Filtragem de registros limitados a um polígono irregular</div>    
        </div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/shape-circle.png" style="width:16px;" align="absmiddle"> [3] Filtrar por raio</td>
    <td>
    	Ativar o modo de busca espacial por registros dentro de um raio (em metros) definido pelo usuário.
        <br />Ao ativar a ferramenta, todos os registros são ocultados.
        <br />O raio de busca pode ser alterado digitando o valor desejado na caixa de edição que será exibida no canto inferior central do mapa.
        <br />O raio também poderá ser alterado diretamente na forma através das alças de redimensionamento.  O centro também pode ser alterado arrastando o ponto central da forma.
        <br /><b>Neste modo de busca apenas os registros dentro da área de busca serão exportados para relatórios e mapas.</b>
        <br />Para desativar o modo de filtragem clique no <i class="icon-remove"></i> ao lado do botão de ativação
        <br />A informação da quantidade de registros dentro da área de filtragem é exibida no canto inferior esquerdo do mapa, ao lado da informação das coordenadas do cursor.
        <div id="imagem">
            <img id="imagemShot" src="home/toolFilterByRadius.png" width="80%">
            <div id="imagemLegenda">Filtragem espacial por raio (metros)</div>    
        </div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/filetypes/rs21.png" style="height:16px" align="absmiddle"> Raster/SAGA (.rs2)</td>
    <td>
    	Gerar mapa dos registros visíveis no formato Raster/SAGA - UFRJ, nativo do aplicativo Vista SAGA, do <a href="http://www.lageop.ufrj.br" target="_blank">LAGEOP/UFRJ</a>.
         <br />Maiores detalhes sobre opções de exportação disponíveis na seção <a href="#gerarmapa" class="scroll" target="_self">Gerar Mapa</a>
    </td>
  </tr>
  <tr>
    <td><img src="../img/earth.png" style="height:16px" align="absmiddle"> KML para ArcGIS (.kml)</td>
    <td>Exportar registros para arquivo em formato Google Earth KML otimizado para leitura no aplicativo <a href="https://www.arcgis.com/features/" target="_blank">Esri ArcGIS</a></td>
  </tr>
  <tr>
    <td><img src="../img/filetypes/png3.png" style="height:16px" align="absmiddle"> Imagem (.png)</td>
    <td>
    	Gerar mapa dos registros visíveis no formato de imagem PNG - <i>Portable Network Graphics</i>
        <br />Maiores detalhes sobre opções de exportação disponíveis na seção <a href="#gerarmapa" target="_self">Gerar Mapa</a>    
    </td>
  </tr>
  <tr>
    <td><img src="../img/table.png" style="width:16px" align="absmiddle"> Tabela de distâncias (.xlsx)</td>
    <td>
        Gerar uma tabela de distâncias geográficas (em linha reta) entre todos os registros do projeto.
        <br />Supondo que o projeto tenha 100 registros cadastrados, a planilha de distâncias será uma matriz identidade 100 x 100, conforme pode-se verificar na ilustração abaixo.
        <div id="imagem">
            <img id="imagemShot" src="home/distances.png" width="80%">
            <div id="imagemLegenda">Planilha de distâncias entre cada registro do projeto</div>
        </div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/filetypes/xlsx.png" style="height:16px" align="absmiddle"> Planilha Excel (.xlsx)</td>
    <td>
    	Gerar relatório dos registros visíveis no formato de Planilha XLSX - Microsoft Excel 2007 (também pode ser aberto pelo Open Office).
		<div id="imagem">
        <a href="home/report.xlsx" target="_blank">
            <img id="imagemShot" src="home/Relatorio_XLSX.jpg" style="width:80%;height:250px;" title="Relatório de registros no formato de Planilha XLSX - Microsoft Excel">
        </a>
        </div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/earth.png" style="height:16px" align="absmiddle"> Google Earth (.kml)</td>
    <td>
    	Gerar relatório dos registros visíveis no formato KML - Google Earth
		<div id="imagem">
            <a href="home/report.kml" target="_blank">
                <img id="imagemShot" src="home/Relatorio_KML.jpg" style="width:80%;" title="Relatório de registros no formato KML - Google Earth">
            </a>
		</div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/filetypes/html.png" style="height:16px" align="absmiddle"> Página HTML (.html)</td>
    <td>
    	Gerar relatório dos registros visíveis no formato HTML - Aberto em Navegadores (Google Chrome, Safari, Mozilla Firefox, Internet Explorer,...).
   		<div id="imagem">
        <a href="home/report.html" target="_blank">
            <img id="imagemShot" src="home/reportHTML.png" style="width:80%;" title="Relatório de registros no formato HTML - Aberto em Navegadores">
        </a>
        </div>
    </td>
  </tr>
  <tr>
    <td><img src="../img/filetypes/xml.png" style="height:16px" align="absmiddle"> Extensible Markup Lang (.xml)</td>
    <td>
    	Gerar relatório dos registros visíveis no formato <a href="http://pt.wikipedia.org/wiki/XML" target="_blank">XML</a>.
   		<div id="imagem">
            <a href="home/report.xml" target="_blank">
                <img id="imagemShot" src="home/Relatorio_XML.jpg" style="width:80%;" title="Relatório de registros no formato XML">
            </a>
          </div>
    </td>
  </tr>
</table>

<div id="sessionTitle"><a name="filtros" id="filtros">Gerenciamento de Filtros de Busca</a></div>
<div id="imagem">
	<img id="imagemShot" src="home/filterMarks.png">
	<div id="imagemLegenda">Janela de Gerenciamento de Filtros de Busca</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Selecionar filtro salvo</td>
    <td>
    Selecionar um filtro salvo previamente pelo usuário para edição.
    </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Novo Filtro</td>
    <td>
    Criar um novo filtro de formulário.
    </td>
  </tr>
  <tr>
    <td>3</td>
    <td>Excluir</td>
    <td>
    Excluir o filtro selecionado.
    </td>
  </tr>
  <tr>
    <td>4</td>
    <td>Formulário</td>
    <td>
    Selecionar a qual FORMULÁRIO do projeto o filtro será aplicado.
    <br /><font color="#FF0000"><b>Cada filtro se aplica APENAS a um formulário.</b></font>
    </td>
  </tr>
  <tr>
    <td>5</td>
    <td>Campo</td>
    <td>
    Selecionar a qual CAMPO do FORMULÁRIO do projeto o filtro será aplicado.
    <br /><font color="#FF0000"><b>Cada filtro se aplica APENAS a um formulário.</b></font>
    </td>
  </tr>
  <tr>
    <td>6</td>
    <td>Operador Lógico</td>
    <td>
		Operador de comparação lógica a ser aplicada na cláusula do filtro.
    </td>
  </tr>
  <tr>
    <td>7</td>
    <td>Valor</td>
    <td>Valor da condicional da cláusula do filtro.</td>
  </tr>
  <tr>
    <td>8</td>
    <td>Adicionar Cláusula</td>
    <td>
    Adicionar uma nova cláusula condicional ao filtro selecionado.
    <br /><b>NOTA: Quando existe um filtro com mais de uma cláusula o Conector booleano (campo 6) passa a ter efeito sobre o filtro.</b>
    </td>
  </tr>
  <tr>
    <td>9</td>
    <td>Exluir Cláusula</td>
    <td>
    Excluir a cláusula do filtro selecionada.
    </td>
  </tr>
  <tr>
    <td>10</td>
    <td>Renomear Filtro</td>
    <td>
    Alterar o nome do filro selecionado.
    </td>
  </tr>
</table>

<div id="sessionTitle"><a name="detalhesRegistro" id="detalhesRegistro">Detalhes de Registros</a></div>
<p>Ao clicar sobre um registro no mapa, a janela de registros será exibida contendo informações detalhadas acerca do registro selecionado, conforme ilustrado na imagem abaixo.</p>
<div id="imagem">
	<img id="imagemShot" src="home/RecordInformation.png" style="width:80%">
	<div id="imagemLegenda">Janela de informações do registro selecionado</div>    
</div>

<div id="sessionTitle"><a name="gerarmapa" id="gerarmapa">Exportar Mapa</a></div>
<div id="imagem">
	<img id="imagemShot" src="home/MapGenerate.png">
	<div id="imagemLegenda">Painel Exportar Mapa</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>LatSW<br />LngSW<br />LatNE<br />LngNE</td>
    <td>Coordenadas extremas do mapa resultante.<br />
        Para exportar os registros do projeto em forma de mapas o usuário deverá marcar a área delimitadora do mapa resultante de duas maneiras:
        <li>Clicando e arrastando as abas de redimensionamento do retângulo demarcador desenhado no mapa (visível apenas quando o Painel de Configurações da Geração de Mapa está visível)</li>
        <li>Digitando as coordenadas extremas, SW e NE no Painel de Configurações da Geração de Mapa</li>
        <font color="#FF0000"><b>Logicamente que apenas os registros localizados dentro do retângulo delimitador serão exportados para o mapa uma vez que o mapa representará esta região delimitada.</b></font>
    </td>
  </tr>
  <tr>
    <td>Área</td>
    <td>Dimensão <b>APROXIMADA</b> no terreno coberta pelo retângulo/mapa resultante.</td>
  </tr>
  <tr>
    <td>Dimensões</td>
    <td>Dimensão <b>APROXIMADA</b> em pixels da mapa resultante.</td>
  </tr>
  <tr>
    <td>Resolução (m/pixel)</td>
    <td>Resolução espacial <b>APROXIMADA</b> do mapa resultante.</td>
  </tr>
  <tr>
    <td>Exportar</td>
    <td>
	Iniciar o processo de geração de mapa.  Após o processamento, ícones dos arquivos resultantes serão exibidos ao lado deste botão.  Para baixá-los basta clicar sobre os ícones.
    <div id="imagem">
        <img id="imagemShot" src="home/MapGenerateDone.png" >
        <div id="imagemLegenda">Botão para downlaod do mapa gerado pelo processo da exportação</div>
    </div>
    </td>
  </tr>
</table>