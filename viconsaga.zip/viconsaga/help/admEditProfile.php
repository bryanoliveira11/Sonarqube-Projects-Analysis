<div id="sessionTitle"><i class="icon-pencil"></i> <? echo utf8_encode($_SESSION['strIndexMenuEditProfile']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/admEditProfile-overview.jpg" width="100%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Nome</td>
    <td>Campo para alteração do nome do usuário no sistema</td>
  </tr>
  <tr>
    <td>2</td>
    <td>E-mail</td>
    <td>Campo para alteração do e-mail de acesso ao sistema<br /><b>É muito importante que o usuário mantenha seu e-mail de cadastro correto pois toda comunicação do sistema com seus administradores são encaminhados por este canal de comunicação</b></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Senha</td>
    <td>Campo para digitação da nova senha do usuário para acesso ao projeto</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Localização</td>
    <td>Coordenadas de localização do usuário.  Clique no botão <a class="btn"><i class="icon-map-marker"></i></a> para determinar sua posição inicial no mapa</td>
  </tr>
  <tr>
    <td>5</td>
    <td><a href="#" class="btn btn-success" style="margin:5px"><i class="icon-ok-circle icon-white"></i> <b><? echo $_SESSION['strGlobalSave']; ?></b></a></td>
    <td>Salvar as alterações realizadas</td>
  </tr>
</table>