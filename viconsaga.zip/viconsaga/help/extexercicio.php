<iframe id="ipdf" src="extexercicio.pdf" style="width:100%;height:1000px;border:none;margin:0px;padding:0px;"></iframe>
<script>
	document.getElementById("ipdf").style.height = ($(document).height()-19) + "px";
	document.getElementById("helpContent").style.overflowY = "hidden";
</script>