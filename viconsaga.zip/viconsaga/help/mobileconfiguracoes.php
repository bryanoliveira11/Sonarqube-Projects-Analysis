<div id="sessionTitle">Vicon SAGA Mobile - Configurações</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-Configuracoes.png" width="220">
	<div id="imagemLegenda">Opções de configurações do aplicativo</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Voltar</td>
    <td>Volta para o Menu Principal</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Idioma</td>
    <td>Opções para seleção do idioma de preferência do usuário no aplicativo</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Enviar posição para servidor</td>
    <td>Caso a opção esteja selecionada, o aplicativo enviará a posição do usuário em tempo real para o servidor <b>enquanto ele estiver conectado à internet</b></td>
  </tr>
  <tr>
    <td>4</td>
    <td>Enviar registros automaticamente quando houver conexão</td>
    <td>Com a opção ativada, caso o dispostivo esteja conectado à Internet, após sua criação na seção <a href="mobilecreate" target="_self">Criar Registro</a>, será automaticamente enviado ao servidor.<br />
    	A posição e trajeto percorrido pelo usuário poderá ser visualizada em tempo real por usuários do projeto na <a href="home" target="_self">página inicial</a>.
	</td>
  </tr>
  <tr>
    <td>5</td>
    <td>Remover registros após envio</td>
    <td>Caso a opção esteja selecionada, os registros serão sempre removidos do aplicativo após o envio dos mesmos para o servidor, na seção <a href="?s=mobilemeusregistros" target="_self">Meus Registros</a></td>
  </tr>
</table>