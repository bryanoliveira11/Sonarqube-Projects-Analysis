<link rel="stylesheet" type="text/css" href="../components/dhtmlxCalendar/dhtmlxCalendar/codebase/dhtmlxcalendar.css"></link>
<link rel="stylesheet" type="text/css" href="../components/dhtmlxCalendar/dhtmlxCalendar/codebase/skins/dhtmlxcalendar_dhx_skyblue.css"></link>
<script src="../components/dhtmlxCalendar/dhtmlxCalendar/codebase/dhtmlxcalendar.js"></script>
<div id="sessionTitle">Tipos de Dados de Formulários</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th style="width:20%">Tipo</th>
    <th style="width:50%;">Descrição</th>
    <th style="width:30%">Exemplo</th>
  </tr>
  </thead>
  <tr>
    <td>Texto livre</td>
    <td style="text-align:justify;font-weight:normal">Valores alfanuméricos [A-Z],[0-9],símbolos. Sem limite de caracteres</td>
    <td>Nome do Proprietário:<br />
	<input type="text" id="texto" name="texto" style="width:97%;" onBlur="this.value=this.value.toUpperCase();" value="João Oliveira"/></td>
  </tr>
  <tr>
    <td>Numérico</td>
    <td style="text-align:justify;font-weight:normal">Respostas que assumam somente valores do tipo numérico (real).
    <br />
    <b>DICA: Fórmulas podem ser criadas usando os campos do formulário. Para a criação de um campo de fórmula é preciso assinalá-lo como tipo NUMÉRICO. Todos os campos envolvidos na fórmula também deverão ser do tipo NUMÉRICO. 
<br />Operadores aceitos: +-*/ 
<br />Ex: C1+C2+C3/C4 onde C1 = Campo na posição 1</b>
    </td>
    <td>Temperatura (ºC):<br />
    <input type="text" id="numerico" name="numerico" style="width:97%;"onBlur="this.value=parseFloat(this.value);" onkeypress="return SomenteNumero(event);" value="29.7"/></td>
    </td>
  </tr>
  <tr>
    <td>Única Escolha</td>
    <td style="text-align:justify;font-weight:normal">Respostas que admitem apenas UMA resposta, dentre uma lista pré-definida.
    <br /><b>DICA: Ao <a href="forms#admalternatives" target="_self">Editar Alternativas</a>, para permitir que usuários possam digitar novas opções (caso não existam na lista de escolha), o administrador deverá inserir a opção OUTRO.</b></td>
    <td>Sexo:<br />
<select id="unicaescola" name="unicaescolha" style="width:100%;">
<option>-- SELECIONE --</option>
<option>Masculino</option>
<option>Feminino</option>
</select>
</label></td>
  </tr>
  <tr>
    <td>Multi Escolha</td>
    <td style="text-align:justify;font-weight:normal">Respostas que admitem apenas UMA OU MAIS respostas, dentre uma lista pré-definida. </td>
    <td>Alimentos armazenados:<br />
     <input type="checkbox" name="checkbox" id="checkbox" /> Café 
    <input type="checkbox" name="checkbox2" id="checkbox2" /> Verdura 
    <input type="checkbox" name="checkbox3" id="checkbox3" /> Carne 
    <input type="checkbox" name="checkbox4" id="checkbox4" /> Ave
	</td>
  </tr>
  <tr>
    <td>Data</td>
    <td style="text-align:justify;font-weight:normal">Respostas que assumem valores apenas como data. Para evitar erro de digitação quanto ao formato, ao clicar no campo um calendário será exibido para a seleção da data, no formato DD:MM:AAAA.</td>
    <td>Data de Inauguração:<br />
<input type="text" id="data" name="data" style="width:97%;" maxlength="10" onKeyUp="formataData(this);" value="21/09/2012"/>
<script>var myCalendar = new dhtmlXCalendarObject('data');myCalendar.setDateFormat("%d/%m/%Y");</script>
    </td>
  </tr>
  <tr>
    <td>Hora</td>
    <td style="text-align:justify;font-weight:normal">Respostas que assumam valores no formato de hora do tipo HH:MM:SS</td>
    <td>Hora do evento:<br />
		<input type="text" id="hora" name="hora" style="width:97%;" maxlength="8" value="14:00:00"/>    
    </td>
  </tr>
  <tr>
    <td>Séries Temporais</td>
    <td style="text-align:justify;font-weight:normal">Admite um valor (textual) para cada data e hora.  Ideal para registrar fenômenos que assumem diferentes valores ao longo do tempo.</td>
    <td><img src="img/tiposdados-seriestemporais.jpg" width="100%"/>
    </td>
  </tr>               
</table>