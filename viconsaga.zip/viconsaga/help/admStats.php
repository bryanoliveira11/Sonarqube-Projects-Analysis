<div id="sessionTitle"><i class="<? echo $stats->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuStats']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/admStats-overview.jpg" width="100%">
</div>