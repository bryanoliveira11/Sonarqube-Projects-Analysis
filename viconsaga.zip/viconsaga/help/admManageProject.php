<div id="sessionTitle"><i class="icon-wrench"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementConfiguration']); ?></div>
<div id="sessionTitle"><a name="projectinfo" id="projectinfo">Informações do Projeto</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageProject-detailDados.jpg" width="80%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Subdomínio</td>
    <td>Alias para o endereço de acesso do projeto. http://www.viconsaga.com.br/subdominio</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Nome do Projeto</td>
    <td>Nome do projeto no sistema (apresentado na tela de login e outras)</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Descrição do Projeto</td>
    <td>Descrição do projeto</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Localidade</td>
    <td>Nome da localidade sede do projeto</td>
  </tr>
</table>
<div id="sessionTitle"><a name="projectcores" id="projectcores">Aparência</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageProject-detailAparencia.jpg" width="80%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Tema</td>
    <td>Tema de estilo de cores para o projeto</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Plano de Fundo</td>
    <td>Imagem de plano de fundo selecionada para o projeto.  Para carregar uma nova imagem a partir de um arquivo local, clique sobre esta imagem e busque o arquivo em seu computador</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Logotipo do Projeto</td>
    <td>Imagem do logotipo selecionada para o projeto.  Para carregar uma nova imagem a partir de um arquivo local, clique sobre esta imagem e busque o arquivo em seu computador</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Planos de Fundo</td>
    <td>Sugestões de imagens de plano de fundo do sistema.  Clique para selecionar um plano de fundo e clique em Salvar para gravar a alteração</td>
  </tr>
</table>
<div id="sessionTitle"><a name="projectpermissoes" id="projectpermissoes">Permissões</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageProject-detailPermissoes.jpg" width="80%">
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Não é necessário estar cadastrado para visualizar os registros do projeto</td>
    <td>Quando habilitado, o acesso ao sistema estará liberado para usuários não cadastrados no projeto (visitantes) visualizarem registros.</tr>
  <tr>
    <td>2</td>
    <td>Habilitar cadastro de usuários no projeto</td>
    <td>A opção marcada habilita o cadastro de usuários na página inicial do projeto. Toda vez que um novo cadastro de usuário for preenchido, um e-mail será automaticamente enviado ao administrador do projeto notificando sobre a nova solicitação de liberação de acesso ao projeto. O acesso só será liberado após a aprovação da solicitação pelo administrador</a></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Quais registros um usuário visualiza?</td>
	<td>
    Define os registros que o usuário visualizará (válido somente para os usuários dos níveis 1 a 3). As opções são:
    <ul>
      <li>Criados por ele - um usuário do projeto visualizará somente os registros criados por ele mesmo nas consultas.</li>
      <li>Criados por seu grupo de trabalho - um usuário do projeto visualizará apenas os registros criados por usuários pertencentes ao seu grupo de usuários nas consultas.</li>
      <li>Criados por todos os usuários - Todos os registros criados no projeto poderão ser visualizados pelo usuário.</li>
    </ul>
    </td>
  </tr>
  <tr>
    <td>4</td>
    <td>Um registro só poderá ser alterado por:</td>
    <td>
	Define quais usuários <b>(somente nível &ge; 2)</b> terão permissão para alterar um registro. As alternativas são:
    <ul>
      <li>Usuário que criou - apenas o usuário que criou o registro poderá realizar alterações no mesmo.</li>
      <li>Grupo do usuário que criou - apenas usuários do mesmo grupo de usuários do criador do registro poderão realizar alterações no mesmo.</li>
      <li>Todos os usuários - todos os usuários do sistema poderão alterar o registro.</li>
    </ul>
    </td>
  </tr>
</table>