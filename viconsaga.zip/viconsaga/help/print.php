<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="height=device-height,width=device-width,initial-scale=1,user-scalable=yes" />
    <meta name="generator" content="<? echo $_SESSION['PROJETO_NOME']; ?>">
    <title>Vicon Web - Imprimir Tópico de Ajuda</title>
    <link href="../css/bootstrap.css" rel="stylesheet">
	<link id="bs-css" href="../css/bootstrap-cerulean.css" rel="stylesheet">
	<link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/main.css" rel="stylesheet">
	<link href="../css/charisma.css" rel="stylesheet">
	<link href="../css/help.css" rel="stylesheet">
    <link rel="shortcut icon" href="../img/logofav.png">
    <script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap-tooltip.js"></script>
	<script src="../js/bootstrap-button.js"></script>
	<script src="../js/jquery.dataTables.js"></script>
    <script src="../js/main.js"></script>
    <link rel="stylesheet" href="../css/help.css" type="text/css" media="all">
</head>
<body style="overflow:auto;height:auto;overflow-x:hidden;padding:5px;">
<? 
if (file_exists('./' . $_GET['s'] . '.php')) {
	include('./' . $_GET['s'] . '.php');
}
echo '<script>window.print();</script>';
?>
</body>
</html>