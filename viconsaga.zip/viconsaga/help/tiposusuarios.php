<script type="text/javascript" src="../js/scripts.js" ></script>
<div id="sessionTitle">Tipos de Dados de Formulários</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Nível</th>
    <th>Título</th>
    <th>Permissões</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Visualização</td>
    <td>
<li>Geração de relatórios de registros nos formatos Planilha Excel (XLS), Acrobat Reader (PDF), Google Earth (KML) e HTML</li>
<li>Consultas filtradas por parâmetros. Ex.: "Escolas com mais de 10 professores?"</li>
<li>Consulta a registros por endereço/raio. Ex.: Todos os registros num raio de 500 metros da Avenida Presidente Vargas, 500 - Centro - Rio de Janeiro</li>
<li>Utilização de ferramentas da plataforma: Geocodificação, Conversor de Coordenadas</li>
    </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Visualização, Edição</td>
    <td>
<li>Edição de registros</li>
    </td>
  </tr>
  <tr>
    <td>3</td>
    <td>Visualização, Edição, Exclusão, Inserção</td>
    <td>
<li>Criação/Exclusão de registros</li>
<li>Importador de dados a partir de arquivos CSV, Planilhas XLS e Google Earth (KML)</li>
    </td>
  </tr>
  <tr>
    <td>4</td>
    <td>Gerente do Projeto</td>
    <td>
<li>Alteração de permissões, definição de visualizações no projeto, cores, plano de fundo, permissões de usuários</li>
<li>Administração dos formulários e campos</li>
<li>Administração de usuários e permissões do projeto</li>
    </td>
  </tr>              
</table>