<div id="sessionTitle">Vicon SAGA Mobile - Meus Registros</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-MeusRegistros.png" width="220">
	<div id="imagemLegenda">Tela de Meus Registros</div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Voltar</td>
    <td>Retornar ao Menu Principal</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Lista de Registros</td>
    <td>Apresentação dos registros criados pelo usuário através do dispositivo móvel. O usuário poderá enviar o(s) registro(s) que desejar para o servidor selecionando a(s) caixa(s) de seleção exibida(s) ao lado do(s) registro(s) e tocando no botão "Upload de Registro" (campo 4). Ou poderá apagar o(s) registro(s) tocando no botão "Apagar registro" (campo 5)</b>O usuário precisa estar conectado à internet para enviar registros para o servidor</b></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Editar registro</td>
    <td>Permite a edição das informações do registro desejado</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Upload de registro</td>
    <td>Envio do(s) registro(s) selecionado(s) (campo 2) para o servidor.<b>O usuário precisa estar conectado à internet para enviar registros para o servidor</b></td>
  </tr>
  <tr>
    <td>5</td>
    <td>Apagar registro</td>
    <td>Apagar o(s) registro(s) selecionado(s) do dispositivo móvel (campo 2)</td>
  </tr>
  <tr>
    <td>6</td>
    <td>Seleção de projetos</td>
    <td>Retornar à tela de seleção de projetos e permitir que o usuário selecione outro projeto para trabalhar</td>
  </tr>
</table>
<div id="sessionTitle">Status de upload de registro(s)</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-Enviar.png" width="220">
	<div id="imagemLegenda">Tela de andamento do envio de registro</div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Status</td>
    <td>Confirmação de envio de dado</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Confirmação do envio</td>
    <td>Confirma o envio das informações para o servidor.<b>O usuário precisa estar conectado à internet para efetuar o envio com sucesso</b><br />
Após o envio com sucesso do registro, na lista de registros, um ícone <img src="img/mobile-MeusRegistrosEnviado.png" alt="Sucesso" width="17" height="18" /> será anexado ao registro sinalizado que o mesmo já fora enviado ao servidor.</td>
  </tr>
  <tr>
    <td>3</td>
    <td>OK</td>
    <td>Retornar à tela Meus Registros</td>
  </tr>
</table>