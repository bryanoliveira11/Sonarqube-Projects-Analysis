<?
	include_once '../engine/api.php';
	$api = new Api('../');
	$arrUser['strEmail'] = 'user@domain.com';
	$arrUser['strPassword'] = '12345';
	$arrUser['idProject'] = '4';
	$arrForms = $api->form->selectForms($arrUser['idProject']);
	$arrUser['idForm'] = $arrForms[0]['idForm'];
	$arrToken = $api->login($arrUser['strEmail'], $arrUser['strPassword'], true);
?>
<style>
/* Primeira coluna */
td:first-child {
	text-align:center;
	font-weight:bold;
	width:10%;
	line-height:30px;
}

/* Segunda coluna */
td:nth-child(2) {
	text-align:justify;
	font-weight:normal;
	width:90%;
}
</style>
<div id="sessionTitle">Vicon Web API</div>
<h2 id="top">Tópicos da Referência</h2>
<p><strong><a href="#parametros" class="scroll">Descrição dos parâmetros</a></strong></p>
<p><strong>Autenticação</strong></p>
<ul>
  <li><a href="#login" class="scroll">login</a></li>
  </ul>
<p><strong>Listagem</strong></p>
<ul>
  <li><a href="#listuserprojects" class="scroll">listuserprojects</a></li>
  <li><a href="#listprojectusers" class="scroll">listprojectusers</a></li>
  <li><a href="#listprojectforms" class="scroll">listprojectforms</a></li>
  <li><a href="#listforminfo" class="scroll">listforminfo</a></li> 
</ul>
<p><strong>Inserção/Remoção de registros</strong></p>
<ul>
  <li><a href="#insertrecord" class="scroll">insertrecord</a></li>
  <li><a href="#deleterecord" class="scroll">deleterecord</a></li>
</ul>
<p><strong>Posicionamento de usuário</strong></p>
<ul>
  <li><a href="#insertuserposition" class="scroll">insertuserposition</a></li>
</ul>
<p><strong>Consulta a registros</strong></p>
<ul>
  <li><a href="#generatereport" class="scroll">generatereport</a></li>
  <li><a href="#recordinfo" class="scroll">recordinfo</a></li>
  <li><a href="#searchradius" class="scroll">searchradius</a></li>
  <li><a href="#searchrectangle" class="scroll">searchrectangle</a></li>
  <li><a href="#wfs" class="scroll">WFS - Web Feature Service</a></li>
  
</ul>
<div id="sessionTitle"><a name="parametros" id="parametros">Descrição dos Parâmetros</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Parâmetro</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>action</td>
    <td>Ação requisitada</td>
  </tr>
  <tr>
    <td>token</td>
    <td>Chave de temporária de operação acesso</td>
  </tr>
  <tr>
    <td>email</td>
    <td>E-mail de usuário cadastrado no projeto 
    <pid></td>
  </tr>
  <tr>
    <td>password</td>
    <td>Senha de acesso do usuário &lt;email&gt;
    no projeto</td>
  </tr>    
  <tr>
    <td>pid</td>
    <td>Número identificador único do projeto no projeto</td>
  </tr>
  <tr>
    <td>idform</td>
    <td>Número identificador único do formulário no projeto</td>
  </tr>
  <tr>
    <td>idrecord</td>
    <td>Número identificador do registro no projeto</td>
  </tr>
  <tr>
    <td>output</td>
    <td>Formato de impressão do resultado do processamento.  Valores possíveis: xml (default) | json</td>
  </tr>
</table>

<div id="sessionTitle"><a name="login" id="login">Classe Login</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Autenticar para receber um token a partir de um &lt;email&gt;, &lt;password&gt;</p>
<h3>Parâmetros de entrada</h3>
<p>email, password</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=login&email=' . $arrUser['strEmail'] . '&password=' . $arrUser['strPassword']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('action, email, password')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorUserInvalid()); ?></td>
  </tr>
  <tr>
    <td><? echo $arrToken['strToken']; ?></td>
    <td><? echo utf8_encode($api->strPrintLoginTokenGenerated($arrToken['strToken'])); ?></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="listuserprojects" id="listuserprojects">Classe listuserprojects</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Listar projetos do usuario a partir de um &lt;token&gt;</p>
<h3>Parâmetros de entrada</h3>
<p>email, password</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=listuserprojects&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('token')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->listuserprojects($arrToken['strToken'])); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="listprojectusers" id="listprojectusers">Classe listprojectusers</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Listar usuários de um projeto &lt;pid&gt;</p>
<h3>Parâmetros de entrada</h3>
<p>pid, token (obrigatório quando projeto não é público)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=listprojectusers&pid=' . $arrUser['idProject'] . '&token=' . $arrToken['strToken'];	?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('action, pid [,token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject(utf8_decode('Users'))); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->listprojectusers($arrUser['idProject'], $arrToken['strToken'])); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="listprojectforms" id="listprojectforms">Classe listprojectforms</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Listar formulário de um projeto &lt;pid&gt;</p>
<h3>Parâmetros de entrada</h3>
<p>pid, token (obrigatório quando projeto não é público)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=listprojectforms&pid=' . $arrUser['idProject'] . '&token=' . $arrToken['strToken'];	?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('action, pid, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject(utf8_decode('Forms'))); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->listprojectforms($arrUser['idProject'], $arrToken['strToken'])); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="listforminfo" id="listforminfo">Classe listforminfo</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Obter informações acerca do formulário &lt;idform&gt;.  Resultado no formato XML com informações dos campos do formulário.</p>
<h3>Parâmetros de entrada</h3>
<p>idform, token (obrigatório quando projeto não é público)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=listforminfo&idform=' . $arrUser['idForm'] . '&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('idform, idrecord, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject('Record')); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->listforminfo($arrUser['idForm'], $arrToken['strToken'])); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="insertrecord" id="insertrecord">Classe insertrecord</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Inserir um registro com informacoes no valor1|valor2|valor3.  Os registros devem seguir a ordem e tipo de dados dos campos do fomulários.  Para obter informação acerca da estrutura de um formulário o usuário poderá executar a requisição listforminfo.  Caso processado com sucesso, como saída retorna o id do registro criado.</p>
<h3>Parâmetros de entrada</h3>
<p>idform, lat, lng, data, token</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=insertrecord&idform=1&lat=-23.23432&lng=-43.4534&data=Tiago%20Silva|2|TESTE&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('idform, lat, lng, data, token')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-4</td>
    <td><? echo utf8_encode($api->strPrintErrorFormCreationNotPermited()); ?></td>
  </tr>
  <tr>
    <td>-5</td>
    <td><? echo utf8_encode($api->strPrintErrorFormNotExists()); ?></td>
  </tr>
  <tr>
    <td>-6</td>
    <td><? echo utf8_encode($api->strPrintErrorRecordInsertExceeded()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><? echo utf8_encode($api->strPrintRecordInsertOK(1)); ?></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="deleterecord" id="deleterecord">Classe deleterecord</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Remover registro &lt;idrecord&gt;.  Não é necessário especificar o &lt;pid&gt; e &lt;userid&gt; porque ambas informações estão vinculadas ao &lt;token&gt; (parâmetro obrigatório para esta função).</p>
<h3>Parâmetros de entrada</h3>
<p>idrecord, token</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=deleterecord&idrecord=1&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('idform, idrecord, token')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-4</td>
    <td><? echo utf8_encode($api->strPrintErrorDeletePermission()); ?></td>
  </tr>
  <tr>
    <td>-5</td>
    <td><? echo utf8_encode($api->strPrintErrorRecordNotExists()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><? echo utf8_encode($api->strPrintRecordDeleteOK()); ?></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="insertuserposition" id="insertuserposition">Classe insertuserposition</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Inserir nova posição de rota de usuário em &lt;lat&gt; e &lt;lng&gt;.  Não é necessário especificar o &lt;pid&gt; e &lt;userid&gt; porque ambas informações estão vinculadas ao &lt;token&gt; (parâmetro obrigatório para esta função).</p>
<h3>Parâmetros de entrada</h3>
<p>lat, lng, token</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=insertuserposition&lat=-22.965644300334535&lng=-43.17431688308716&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('lat, lng, token')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-4</td>
    <td><? echo utf8_encode($api->strPrintErrorUserPositionInsertPermission()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><? echo utf8_encode($api->strUserPositionInsertOK()); ?></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="generatereport" id="generatereport">Classe generatereport</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Gerar relatório de todos os registros do projeto, em um dos seguintes formatos:</p>
<li>kml - Google Earth</li>
<li>xls - Microsoft Excel, Open Office, BrOffice</li>
<li>xml - eXtensible Markup Language é uma recomendação da W3C para gerar linguagens de marcação para necessidades especiais</li>
<li>html - Hypertext Markup Language</li>
<p>Resultado no formato especificado pelo parâmetro &lt;ext&gt;</p>
<h3>Parâmetros de entrada</h3>
<p>pid, ext, token (obrigatório quando projeto não é público)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=generatereport&pid=' . $arrUser['idProject'] . '&ext=kml&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('pid, ext, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject('Report')); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><result>
<id>1</id>
<detail>Report successfully generated!</detail>
<fileName>http://localhost/viconsaga/tmp/1-19-06-2014 12-58.kml</fileName>
</result></xmp></td>
  </tr>
</table>

<div id="sessionTitle"><a name="recordinfo" id="recordinfo">Classe recordinfo</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Obter informações de um registro &lt;idrecord&gt;.  Resultado no formato XML com informações sobre o registro.</p>
<h3>Parâmetros de entrada</h3>
<p>idrecord, token (obrigatório quando projeto não é público)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=recordinfo&idrecord=1&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('pid, lat, lng, radius, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject('Records')); ?></td>
  </tr>
  <tr>
    <td>-5</td>
    <td><? echo utf8_encode($api->strPrintErrorRecordNotExists()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><result>
<idFormRecord>3649</idFormRecord>
<idUser>1</idUser>
<idForm>101</idForm>
<idDevice>1</idDevice>
<idShapeType>1</idShapeType>
<strCustomMarkerRGBColor>8</strCustomMarkerRGBColor>
<dtCreation>2014-05-21 02:09:42</dtCreation>
<dtLastUpdate>2014-05-21 02:09:42</dtLastUpdate>
<idProject>1</idProject>
<strFormName>CBMERJ</strFormName>
<idMarker>185</idMarker>
<blnActive>1</blnActive>
<strMarkerFileName>185.png</strMarkerFileName>
<idProjectMarker/>
<strName>Tiago Marino</strName>
<strEmail>tiagomarino@hotmail.com</strEmail>
<strCreation>21/05/2014 02:09</strCreation>
<strLastUpdate>21/05/2014 02:09</strLastUpdate>
<strMarkerFullPath>img/markers/185.png</strMarkerFullPath>
<strMarkerFullURL>http://localhost/viconsaga/img/markers/185.png</strMarkerFullURL>
<arrVertex>
<unknownNode>
<idFormRecordVertex>103251</idFormRecordVertex>
<idFormRecord>3649</idFormRecord>
<dblLatitude>-22.907548</dblLatitude>
<dblLongitude>-43.563438</dblLongitude>
<intPosition>1</intPosition>
</unknownNode>
</arrVertex>
<arrFiles/>
<strDevice>Web</strDevice>
<strDeviceFilePath>img/devices/1.png</strDeviceFilePath>
<dblLatitude>-22.907548</dblLatitude>
<dblLongitude>-43.563438</dblLongitude>
<dblDistanceFromCenterMts>-1</dblDistanceFromCenterMts>
<dblLatitudeUTM>7465995,54</dblLatitudeUTM>
<dblLongitudeUTM>647331,97</dblLongitudeUTM>
<intZoneUTM>23K</intZoneUTM>
</result></xmp></td>
  </tr>
</table>

<div id="sessionTitle"><a name="searchradius" id="searchradius">Classe searchradius</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Obter todos os registro de um projeto &lt;pid&gt; a um raio &lt;radius&gt; de um ponto &lt;lat&gt;, &lt;lng&gt;, contendo a palavra-chave &lt;keyword&gt;.  Resultado no formato XML com informações sobre os registros encontrado.
<br>Utilize o parâmetro &lt;fromdate&gt; para retornar somente os registros criados ou atualizados a partir de uma determinada data/hora.  Formato: YYYY-MM-DD HH:MM:SS
<br>Utilize o parâmetro &lt;todate&gt; para retornar somente os registros criados ou atualizados até uma determinada data/hora.  Formato: YYYY-MM-DD HH:MM:SS
</p>
<p><b>Esta consulta retorna até <? echo $api->intLimitResults; ?> registros por chamada.  Utilize o parâmetro &lt;start&gt; para marcar o primeiro registro a retornar.  Caso o parâmetro seja omitido, a consulta retornará os <? echo $api->intLimitResults; ?> primeiros registros.</b></p>
<h3>Parâmetros de entrada</h3>
<p>pid, lat, lng, radius, keyword (opcional), start (opcional), idform (opcional), fromdate (opcional), todate (opcional), token (obrigatório quando projeto não é público)</p>
<div id="imagem">
	<img id="imagemShot" src="img/api-searchRadius.jpg">
	<div id="imagemLegenda">Parâmetros da busca por raio</div>    
</div>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=searchradius&pid=' . $arrUser['idProject'] . '&lat=-23.24325525&lng=-43.24325525&radius=400000&limit=2&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('pid, lat, lng, radius, keyword, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject('Records')); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->search(1, $arrUser['idProject'], -23.2110583, -44.2730570, 0, 0, 4000000, '', $arrToken['strToken'], 0, 0, '', '', 2)); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="searchrectangle" id="searchrectangle">Classe searchrectangle</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Proceder uma busca espacial por registros de um projeto &lt;pid&gt; dentro de um retângulo limitado por dois pontos com pares de coordenadas &lt;latSW&gt;, &lt;lngSW&gt;, &lt;latNE&gt;, &lt;lngNE&gt;, contendo a palavra-chave &lt;keyword&gt;.  Resultado, registros em XML.
<br>Utilize o parâmetro &lt;fromdate&gt; para retornar somente os registros criados ou atualizados a partir de uma determinada data/hora.  Formato: YYYY-MM-DD HH:MM:SS
<br>Utilize o parâmetro &lt;todate&gt; para retornar somente os registros criados ou atualizados até uma determinada data/hora.  Formato: YYYY-MM-DD HH:MM:SS
</p>
<p><b>Esta consulta retorna ATÉ <? echo $api->intLimitResults; ?> por chamada.
<br>Utilize o parâmetro &lt;start&gt; para marcar o primeiro registro a retornar.  Caso o parâmetro seja omitido, a consulta retornará os <? echo $api->intLimitResults; ?> primeiros registros.</b></p>
<h3>Parâmetros de entrada</h3>
<p>pid, latSW, lngSW, latNE, lngNE, keyword (opcional), start (opcional), idform (opcional), fromdate (opcional), todate (opcional), token (obrigatório quando projeto não é público)</p>
<div id="imagem">
	<img id="imagemShot" src="img/api-searchRectangle.jpg">
	<div id="imagemLegenda">Parâmetros da busca por retângulo</div>    
</div>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=searchrectangle&pid=' . $arrUser['idProject'] . '&latSW=-90&lngSW=-180&latNE=90&lngNE=180&keyword=as&limit=2&token=' . $arrToken['strToken']; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('pid, latSW, lngSW, latNE, lngNE, [token]')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorTokenInvalid()); ?></td>
  </tr>
  <tr>
    <td>-3</td>
    <td><? echo utf8_encode($api->strPrintErrorNotPublicProject('Records')); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->search(2, $arrUser['idProject'], -90, -180, 90, 180, 0, '', $arrToken['strToken'], 0, 0, '', '', 2)); ?></xmp></td>
  </tr>  
</table>

<div id="sessionTitle"><a name="wfs" id="wfs">WFS - Web Feature Service</a><a href="#top" class="scroll"><i class="icon-chevron-up" style="float:right;cursor:pointer"></i></a></div>
<h3>Descrição</h3>
<p>Estabelecer o servico WFS para a utilização dos dados em outras aplicações que suportam este protocolo (<a href="http://docs.qgis.org/2.6/pt_BR/docs/user_manual/working_with_ogc/ogc_client_support.html#ogc-wfs" target="_blank">QGIS</a>, <a href="http://suite.opengeo.org/4.1/geoserver/webadmin/services/WFS.html" target="_blank">GeoServer</a>, <a href="http://resources.arcgis.com/EN/HELP/MAIN/10.1/index.html#//00370000000p000000" target="_blank">ESRI ArcGIS</a>, <a href="http://www.dpi.inpe.br/spring/" target="_blank">INPE Spring</a>...).
<br>Utilize o parâmetro "recordinfo" (=1) para retornar carregar os detalhes de cada registro.
<br><b>ATENÇÃO: O carregamento dos detalhes de muitos registros implica em maior tempo para o processamento da resposta.</b>
</p>
<h3>Parâmetros de entrada</h3>
<p>pid, email, password (email e password obrigatórios quando dados do projeto não são abertos ao público), recordinfo (opcional)</p>
<h3>Exemplo de Chamada</h3>
<? $strURL = $api->strURLAPI . 'action=wfs&pid=' . $arrUser['idProject'] . '&email=' . $arrUser['strEmail'] . '&password=' . $arrUser['strPassword'] ; ?>
<p><a href="<? echo $strURL; ?>" target="_blank"><? echo $strURL; ?></a></p>
<h3>Retornos</h3>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>Código</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>-1</td>
    <td><? echo utf8_encode($api->strPrintErrorParametersInvalid('pid, email, password')); ?></td>
  </tr>
  <tr>
    <td>-2</td>
    <td><? echo utf8_encode($api->strPrintErrorUserInvalid()); ?></td>
  </tr>
  <tr>
    <td>1</td>
    <td><xmp><? echo $strings->strFormatXmlString($api->wfs($arrUser['idProject'], $arrUser['strEmail'], $arrUser['strPassword'])); ?></xmp></td>
  </tr>  
</table>