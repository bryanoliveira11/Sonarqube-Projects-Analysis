<div id="sessionTitle">Termos de Uso</div>
<img src="../img/lageop.jpg" alt="Lageop/UFRJ" longdesc="http://www.lageop.ufrj.br" style="float:right;margin:5px;"/>
<p>Ao usar o Vicon Web e quaisquer dados ou informações acessadas no mesmo, você concorda em submeter-se aos nossos termos de serviço, bem como a estes termos e condições adicionais. Todo conteúdo existente num projeto é de inteira responsabilidade de seus gestores, sendo responsabilidade dos mesmos pelo controle de qualquer conteúdo considerado inadequado.</p>
<p><strong>Conteúdo fornecido por terceiros</strong></p>
<p>O Lageop/UFRJ não se responsabiliza nem concede garantias relativas à exatidão ou integridade das informações fornecidas por esses terceiros.</p>
<p><strong>Informações sobre mapas</strong></p>
<p>O sistema Vicon Web utiliza a base de Mapas Google Maps para a exibição dos resultados. Tais informações destinam-se apenas para fins ilustrativos e não se comprometem com exatidão cartográfica.</p>
<p><strong>Arquivos anexados por usuários</strong></p>
<p>As imagens fotográficas e demais arquivos anexados em projetos do Vicon Web são de inteira responsabilidade de seus gestores. Para fins de controle e seguraça, todas as informações postadas no sistema são registradas através de logs e não podem ser alteradas e/ou apagadas. Cabe ao gestor do projeto aplicar a penalização devida a quem posta conteúdo inapropriado ao projeto.</p>
<p><strong>Conduta apropriada e usos proibidos</strong></p>
<p>Você concorda que é responsável por sua própria conduta e qualquer inclusão de conteúdo, enquanto usar o Vicon Web, e por todas as conseqüências relacionadas. Você concorda em usar os serviços do Vicon Web apenas para finalidades lícitas, adequadas e condizentes com estes Termos de Serviço e com quaisquer políticas ou diretrizes aplicáveis. Apenas para fins de exemplo quando usar o vicon Web, você concordará em não:</p>
<ul>
  <li>difamar, abusar, assediar, atacar, ameaçar ou, de qualquer outra forma, violar os direitos legais (como direitos de privacidade e publicidade) de terceiros;</li>
  <li>fazer upload, postar, enviar e-mail ou transmitir, ou de qualquer outra forma, disponibilizar qualquer conteúdo ilegal, obsceno, difamatório, inadequado e infrator;</li>
  <li>fazer upload, postar, enviar e-mail, transmitir ou, de qualquer outra forma, disponibilizar qualquer conteúdo que viole direitos de patentes, marcas comerciais, marcas de serviço, segredos comerciais ou outro direito de propriedade, de qualquer parte, a menos que você seja o proprietário desses Direitos ou tenha permissão do proprietário para postar tal conteúdo;</li>
  <li>fazer upload, postar, enviar e-mail, transmitir ou, de qualquer outra forma, disponibilizar mensagens que promovam esquemas de pirâmide, cartas de correntes, mensagens comerciais ou anúncios ofensivos, ou qualquer outra prática proibida por lei, por esses Termos de Serviço ou por quaisquer diretrizes ou políticas aplicáveis.</li>
  <li>fazer download de qualquer arquivo postado por outra pessoa, que você saiba, ou devesse saber, que não pode ser distribuído legalmente dessa forma;</li>
  <li>fingir ser outra pessoa ou entidade, falsificar ou excluir quaisquer atribuições de autoria, notificações legais ou outras adequadas, ou designações de propriedade, ou marcadores da origem ou fonte de software, ou outro material;</li>
  <li>usar os serviços do Vicon Web para quaisquer fins ilegais ou não autorizados;</li>
  <li>remover qualquer aviso de direitos autorais, marca comercial ou avisos de direitos de propriedade contidos nos serviços do Vicon Web;</li>
  <li>interferir ou interromper os serviços ou servidores ou redes do Lageop/UFRJ conectadas aos serviços do Vicon Web, nem desrespeitar requisitos, procedimentos, políticas ou regulamentos de redes conectadas aos serviços do Vicon Web;</li>
  <li>usar qualquer tipo de robô, spider, aplicativos de pesquisa/recuperação de site, ou outro dispositivo para recuperar ou indexar qualquer parte dos serviços do Vicon Webou coletar informações sobre usuários para quaisquer fins não autorizados;</li>
  <li>criar contas de usuário por meios automatizados ou sob pretextos falsos ou fraudulentos;</li>
  <li>promover ou fornecer informações instrutivas sobre atividades ilegais, promover danos físicos ou ferimentos contra qualquer grupo ou indivíduo; ou</li>
  <li>transmitir vírus, worms, defeitos, cavalos de Tróia ou quaisquer itens de natureza destrutiva.</li>
</ul>
<p>Os usuários de outros países concordam em cumprir todas as regras locais relativas à conduta on-line e ao que é considerado conteúdo aceitável, incluindo as leis que regulam a exportação de dados para o Brasil ou o seu país de residência.</p>
<p>Ainda que o Lageop/UFRJ não esteja sujeito a nenhuma obrigação legal ou contratual de monitorar o conteúdo colocado pelos usuários do Vicon Web, o Lageop/UFRJ reserva-se o direito de, se aplicável e tecnicamente possível, retirar qualquer conteúdo de um projeto do Vicon Web, incluindo a possibilidade de cancelar contas de usuários, a seu exclusivo critério.</p>
<p>A disponibilização do Serviço poderá ser suspensa ou encerrada a qualquer momento e sem ônus, a exclusivo critério do Lageop/UFRJ.</p>
