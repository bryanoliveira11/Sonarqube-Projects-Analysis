<div id="sessionTitle"><i class="<? echo $user->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strIndexMenuProjectManagementManageUsers']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/admManageUsers-detailUsuarios.jpg" width="100%">
	<div id="imagemLegenda">Visão Geral da Administração de Usuários</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-plus-sign icon-white"></i> Novo Usuário</a></td>
    <td>Botão para a criação de novos usuários no sistema. Será solicitado o e-mail do novo usuário a ser cadastrado. As demais informações do usuário poderão ser preenchidas adequadamente (campos 2 a 8).<br /><b>Toda vez que um usuário for criado no sistema sua senha padrão será automaticamente definida como 12345. Para alterá-la basta digitar a nova senha (vide campo 5)</b></td>
  </tr>
  <tr>
    <td>2</td>
    <td>Inscrição</td>
    <td>Data de inscrição do usuário no projeto</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Último Acesso</td>
    <td>Data do último acesso do usuário no projeto</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Grupo</td>
    <td>Grupo de trabalho do usuário.<b>O usuário será mantido no grupo GERAL caso não seja direcionado para nenhum grupo específico</b></td>
  </tr>
  <tr>
    <td>5</td>
    <td>E-mail</td>
    <td>E-mail de cadastro do usuário no projeto</td>
  </tr>
  <tr>
    <td>6</td>
    <td>Nome</td>
    <td>Nome do usuário</td>
  </tr>
  <tr>
    <td>7</td>
    <td>Nível</td>
    <td>Definição do nível de permissão do usuário no projeto. Para maiores detalhes, consultar a seção <a href="users">Níveis e Permissões de Usuários</a></td>
  </tr>
  <tr>
    <td>8</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-edit icon-white"></i></a></td>
    <td>Abrir caixa de edição de dados do usuário</td>
  </tr>
  <tr>
    <td>9</td>
    <td><a class="btn btn-danger" style="margin:5px"><i class="icon-trash icon-white"></i></a></td>
    <td>Remoção de um usuário do sistema. O usuário que estiver selecionado através do campo 1 será removido e perderá seu acesso ao sistema.
    <br /><b>IMPORTANTE: Ao remover um usuário TODOS os registros pertencentes a este também serão removidos.  Caso não deseje perder os registros, o administrador deverá transferir a propriedade dos registro do usuário selecionado para algum outro usuário do sistema.  Esta ação poderá ser realizada através do campo 16</b></td>
  </tr>
  <tr>
    <td>10</td>
    <td>Selecionados » Mover registros de usuário</td>
    <td>Todos os registros do usuário selecionado no campo 1 serão movidos para o usuário selecionado na listagem apresentada nesse campo. Por medida de segurança, será necessário confirmar a transferência dos registros após a escolha do usuário de destino</td>
  </tr>
</table>