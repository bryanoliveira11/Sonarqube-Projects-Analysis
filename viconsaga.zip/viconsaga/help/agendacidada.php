<div id="sessionTitle">Passo a Passo para Visualização de Dados e Geração de Relatório - Projeto Agenda Cidadã</div>
<div class="alert alert-danger" style="text-align:center;width:94%;line-height:25px;font-weight:bold">
Atenção: O Projeto Agenda Cidadã disponibiliza todos seus dados para acesso aberto ao público.  Sendo assim, para consulta aos dados gerados pelo projeto, não é preciso ser usuário cadastrado no Projeto Agenda Cidadã.
</div>
<div class="alert alert-success" style="text-align:center;width:94%;line-height:25px;font-weight:bold;margin:5px;">
Para maiores detalhes sobre as ferramentas e funcionalidades da janela de consulta de registros, acesse a documentação do Vicon Web clicando no link Ajuda, no rodapé da página. 
</div>
<p>1. Abra um navegador e acesse o site do Projeto Agenda Cidadã através da URL <a href="http://www.viconsaga.com.br/agendacidada" target="_blank">http://www.viconsaga.com.br/agendacidada</a></p>
<div id="imagem">
	<img id="imagemShot" src="img/agendacidada-overview.png" width="80%">
	<div id="imagemLegenda">Tela inicial do site do Projeto Agenda Cidadã</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
<thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
</thead>
  <tr>
    <td>1</td>
    <td>Árvore de navegação</td>
    <td>Todos os registros do projeto (questionários) estão dispostos nesta lista.
    <br />Para visualizar a localização e acessar as informações de um registro, o usuário poderá navegar por esta lista.
    <br />Ao clicar sobre algum item da Árvore de Registros, o registro correspondente será centralizado no mapa e suas informações serão carregadas na janela "Informações".
    <b>DICA: No caso de haver muitos ícones muito próximos, utilize os comandos de zoom para aproximar o mapa e melhor visualizar o registro selecionado.</b>
    </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Mapa de navegação</td>
    <td>O usuário poderá navegar pelo mapa utilizando os recursos do Google Maps, clicando e arrastando o cursor para movimentar o mapa em busca de registros.</td>
  </tr>
  <tr>
    <td>3</td>
    <td><img src="home/searchfield.png" style="width:100%" /><br />Campo de Pesquisa</td>
    <td>
    	<ul>
        	<li>
                <b>Registros:</b> Campo para busca por registros no banco de dados do projeto.
                <br />A medida que o usuário digita o termo de busca, uma lista de opções que satisfazem o termo de busca é exibida.
                <br />Ao clicar em uma opção da lista de alternativas o mapa será centrado na posição do registro selecionado.
                <div id="imagem">
                    <img id="imagemShot" src="home/searchrecordsresult.png" style="width:300px">
                    <div id="imagemLegenda">Resultados da busca por registros no campo de pesquisa</div>    
                </div>
            </li>
        	<li>
	            <b>Local:</b> Busca de localidades geográficas através da ferramenta de geocodificação de endereços do Google Maps
                <div id="imagem">
                    <img id="imagemShot" src="home/searchmapresult.png" style="width:300px">
                    <div id="imagemLegenda">Resultados da busca por local no campo de pesquisa</div>
                </div>
            </li>
        	<li>
	            <b>Coordenadas:</b> Busca de localidade geográfico a partir de um par de coordenadas no formato GRAU DECIMAL.
                <div id="imagem">
                    <img id="imagemShot" src="home/searchcoordinates.png">
                    <div id="imagemLegenda">Resultados da busca por par de coordenadas</div>
                </div>
            </li>
        </ul>
    </td>
  </tr>
</table>
 
<div id="sessionTitle">Exportando Dados dos Registros Visíveis para Relatórios (Planilhas Excel (XLSX), Google Earth (KML), Página HTML)</div>
<p>1. Para exportar os registros em formato de relatórios acesse o painel <img src="../img/tools.png" style="height:20px" align="absmiddle"/> Ferramentas do Mapa (<a href="home" target="_self">clique aqui para acessar a documentação completa sobre as Ferramentas de Mapa</a>).</p>
<div id="imagem">
	<img id="imagemShot" src="img/agendacidada-mapToolsReport.png">
	<div id="imagemLegenda">Sessão Gerar Relatório no Painel de Ferramentas do Mapa</div>
</div>
<p>3. Selecione a opção <img src="../img/filetypes/xlsx.png" style="height:16px" align="absmiddle"> Planilha Excel (.xlsx)</p>
<p>4. Aguarde enquanto a confecção do relatório é processada.  Dependendo da quantidade de registros a ser exportados o processo poderá demorar.</b></p>
<p>5. Ao término do processamento, automaticamente o relatório será baixado para o computador do usuário.</b></p>
<div id="imagem">
	<img id="imagemShot" src="img/agendacidada-agendaReportDownloaded.jpg">
	<div id="imagemLegenda">O download do arquivo do relatório gerado será automaticamente iniciado</div>
</div>
<div id="imagem">
	<img id="imagemShot" src="img/agendacidada-agendaReportFileDesktop.jpg">
	<div id="imagemLegenda">Arquivo já armazenado no computador do usuário</div>
</div>
<div id="imagem">
	<img id="imagemShot" src="img/agendacidada-agendaReportExcel.jpg" width="80%">
	<div id="imagemLegenda">Relatório em forma de planilha gerado aberto no Microsoft Excel</div>
</div>
