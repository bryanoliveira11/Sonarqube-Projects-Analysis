<div id="sessionTitle">Vicon SAGA Mobile - Criar Registro</div>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-CriarRegistroFormulario.png" width="220">
	<div id="imagemLegenda">Seleção de formulário para criação de registro</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Voltar</td>
    <td>Retornar ao Menu Principal</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Seleção de Formulário</td>
    <td>Abrir a janela de criação de registro para o formulário selecionado.  Toque no botão referente ao formulário do projeto para iniciar a criação do registro para o formulário selecionado</td>
  </tr>
</table>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-CriarRegistro.png" style="width:220px">
	<div id="imagemLegenda">Criar registro</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Localização GPS</td>
    <td>Informação das Coordenada Geográficas do ponto em que o usuário se encontra <b>no momento em que entrou na tela</b>, capturada a partir do receptor GPS embutido no dispositivo móvel.<br /><b>Caso deseje inserir as coordenadas para o ponto manualmente, o usuário deverá tocar nos campos e digitar o novo valor.</b></td>
  </tr>
  <tr>
    <td>2</td>
    <td>Atualizar localização</td>
    <td>Capturar posição atual do usuário a partir do receptor GPS do dispositivo móvel.</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Campos do formulário</td>
    <td>Campos do formulário selecionado para o cadastro de um novo registro.  Maiores detalhes acerca dos tipos de dados para preenchimento de formulários podem ser verificados na seção <a href="datatypes" target="_self">Extras -> Tipos de Dados</a></td>
  </tr>
  <tr>
    <td>4</td>
    <td>Anexar imagem</td>
    <td>Botão para seleção de imagem relacionada(s) ao registro a ser cadastrado.  A imagem poderá ser capturada instantaneamente a partir do dispositivo móvel e/ou selecionada a partir do gerenciador de arquivos salvos no dispositivo</td>
  </tr>
  <tr>
    <td>5</td>
    <td>Gravação de áudio</td>
    <td>Botão para seleção de arquivo(s) de áudio relacionado(s) ao registro cadastrado.  Ao tocar no botão, o gravador de áudio do dispositivo será aberto para a gravação do áudio e anexação ao registro.</td>
  </tr>
  <tr>
    <td>6</td>
    <td>Anexar vídeo</td>
    <td>Botão para seleção de vídeo relacionada(s) ao registro a ser cadastrado.  O vídeo poderá ser capturado instantaneamente a partir do dispositivo móvel e/ou selecionado a partir do gerenciador de arquivos salvos no dispositivo</td>
  </tr>
  <tr>
    <td>7</td>
    <td>Área de visualização dos anexos ao registro</td>
    <td>Os ícones dos arquivos anexados serão exibidos nessa área da tela. O usuário poderá apagar o(s) anexo(s) que desejar selecionando a(s) caixa(s) de seleção exibida(s) ao lado do(s) ícone(s) e tocando no botão "Apagar selecionado" (campo 10)</td>
  </tr>
  <tr>
    <td>8</td>
    <td>Legenda do arquivo anexado</td>
    <td>Campo para descrição do arquivo anexado</td>
  </tr>
  <tr>
    <td>9</td>
    <td>Apagar selecionado</td>
    <td>Remove o(s) arquivo(s) selecionado(s)</td>
  </tr>
  <tr>
    <td>10</td>
    <td>Criar registro</td>
    <td>Salva o cadastro efetuado pelo usuário e retorna à tela Meus Registros</td>
  </tr>
</table>
<div id="imagem">
	<img id="imagemShot" src="img/mobile-CriarRegistroAdicionarImagem.png" style="width:220px">
	<img id="imagemShot" src="img/mobile-CriarRegistroAdicionarVideo.png" style="width:220px">
	<img id="imagemShot" src="img/mobile-CriarRegistroGravarAudio.png" style="width:220px">
</div>
<!--
<div id="imagemLegenda">Adicionar imagem(ns) ao registro</div>
<div id="imagemLegenda">Adicionar vídeo(s) ao registro</div>
<div id="imagemLegenda">Gravar áudio e anexar ao registro</div>
-->