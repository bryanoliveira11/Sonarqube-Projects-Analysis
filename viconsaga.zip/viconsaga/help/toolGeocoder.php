<div id="sessionTitle"><i class="icon-screenshot"></i> <? echo utf8_encode($_SESSION['strHomeToolsGeocoder']); ?></div>
<div id="imagem">
	<img id="imagemShot" src="img/toolGeocoder-Geocodificador.jpg" width="95%">
	<div id="imagemLegenda">Detalhe dos campos para Geocodificação</div>
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td>Caixa de Texto</td>
    <td>Caixa de texto para a digitação (ou colar) a lista de endereços a serem geocodificados</td>
  </tr>
  <tr>
    <td>2</td>
    <td><a class="btn btn-info" style="margin:5px"><i class="icon-folder-open icon-white"></i> <? echo $_SESSION['strGlobalLoad']; ?> CSV</a></td>
    <td>Seleção de arquivo em formato CSV para geocodificação</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Selecione o Logradouro...</td>
	<td>O usuário deve indicar o campo do arquivo carregado que é referente ao Nome do Logradouro</td>
  </tr>
  <tr>
    <td>4</td>
    <td>Selecione Complemento...</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente ao Complemento da Residência</td>
</tr>
   <tr>
    <td>5</td>
    <td>Selecione Bairro...</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente ao Bairro</td>
  </tr>
</tr>
   <tr>
    <td>6</td>
    <td>Selecione Cidade...</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente à Cidade</td>
  </tr>
  <tr>
    <td>7</td>
    <td>Selecione Estado...</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente ao Estado</td>
  </tr>
</tr>
   <tr>
    <td>8</td>
    <td>Selecione País...</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente ao País</td>
  </tr>
  <tr>
    <td>9</td>
    <td><a class="btn btn-info" style="margin:5px"><i class="icon-repeat icon-white"></i></a></td>
    <td>Recarregar valores iniciais da caixa de texto</td>
  </tr>
  <tr>
    <td>10</td>
    <td><a class="btn btn-success" style="margin:5px"><i class="icon-play icon-white"></i> <? echo $_SESSION['strToolGeocoderGeocoder']; ?></a></td>
    <td><img src="../img/google-geocoder.png" style="float:left;height:40px;"/>
    Esta ferramenta utiliza o serviço Google Geocoder e poderá estar sujeito a falhas quanto a precisão.
    <a href="https://developers.google.com/maps/documentation/javascript/geocoding?hl=pt-br" target="_blank">Google Geocoder</a> 
	</td>
  </tr>
  <tr>
    <td>11</td>
    <td><a class="btn btn-info" style="margin:5px"><i class="icon-download icon-white"></i></a></td>
    <td>Baixar conteúdo da caixa de texto para arquivo CSV</td>
  </tr>
</table>
<div id="imagem">
	<img id="imagemShot" src="img/toolGeocoder-ExampleExcel.jpg" width="80%">
	<div id="imagemLegenda">Exemplo de arquivo de entrada para Geocodificação - <a href="img/toolGeocoder-ExemploGeocodificador.csv" target="_blank" style="">BAIXE-O CLICANDO AQUI</a></div>
</div>
<div id="imagem">
	<img id="imagemShot" src="img/toolGeocoder-ExampleSalvarCSV.jpg" width="40%">
	<div id="imagemLegenda">Salvando arquivo no formato CSV a partir de Microsoft Excel</div>
</div>
<div id="imagem">
	<img id="imagemShot" src="img/toolGeocoder-ExampleCSV.jpg" width="80%">
	<div id="imagemLegenda">Arquivo resultante no formato CSV, pronto para ser carregado no sistema - <a href="img/toolGeocoder-ExemploGeocodificador.csv" target="_blank" style="">BAIXE-O CLICANDO AQUI</a></div>
</div>