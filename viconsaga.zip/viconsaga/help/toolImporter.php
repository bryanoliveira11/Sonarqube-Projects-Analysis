<div id="sessionTitle"><i class="<? echo $importer->strDefaultIcon; ?>"></i> <? echo utf8_encode($_SESSION['strHomeToolsDataImporter']); ?></div>
<div id="sessionTitle"><a name="kml" id="kml">Importando dados  a partir de arquivos no formato KML</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/toolImporter-KML.jpg" width="80%">
	<div id="imagemLegenda">Importação de dados no formato KML (Google Earth) - <a href="img/toolImporter-ExemploImportadorKML.kml" target="_blank" style="">BAIXE-O CLICANDO AQUI</a></div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td><a class="btn btn-info" style="margin:5px;"><i class="icon-folder-open icon-white"></i> <? echo $_SESSION['strGlobalLoad']; ?></a></td>
    <td>Importação de arquivo em <strong>formato KML</strong> para cadastro em massa de registros no sistema</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Selecione um formulário</td>
  <td>Formulário onde os registros importados (campo 1) serão cadastrados. <strong>As opções apresentadas incluem todos os formulários já existentes no sistema e a opção de criar um novo formulário</strong></td>
  </tr>
  <tr>
    <td>3</td>
    <td><a class="btn btn-success" style="margin:5px;"><i class="icon-play icon-white"></i> <? echo $_SESSION['strToolImporterImport']; ?></a></td>
    <td>Botão que inicia o processo de importação dos dados para o formulário indicado (campo 2)</td>
</tr>
   <tr>
    <td>4</td>
    <td>Campos do arquivo KML</td>
    <td>Os campos Nome e Descrição são campos padrões de arquivos no formato KML</td>
  </tr>
</table>
<div id="sessionTitle"><a name="csv" id="csv">Importando dados no formato CSV</a></div>
<div id="imagem">
	<img id="imagemShot" src="img/toolImporter-FileXLS.jpg" width="80%">
	<div id="imagemLegenda">Exemplo de arquivo de dados em forma de tabela no Microsoft Excel para importação</div>    
</div>
<div id="imagem">
	<img id="imagemShot" src="img/toolImporter-FileSaveAsCSV.jpg" width="50%">
	<div id="imagemLegenda">Arquivo &raquo; Salvar Como... - No campo Tipo, selecionar formato CSV (separado por vírgulas) (*.csv)</div>    
</div>
<div id="imagem">
	<img id="imagemShot" src="img/toolImporter-FileCSV.jpg" width="80%">
	<div id="imagemLegenda">Exemplo de arquivo de dados já em formato CSV a gravado através do Microsoft Excel a partir do arquivo da ilustração acima - <a href="img/toolImporter-ExemploImportadorCSV.csv" target="_blank" style="">BAIXE-O CLICANDO AQUI</a></div>    
</div>
<div id="imagem">
	<img id="imagemShot" src="img/toolImporter-CSV.jpg" width="80%">
	<div id="imagemLegenda">Importação de dados a partir de arquivos no formato CSV</div>    
</div>
<table class="table table-striped table-bordered bootstrap-datatable datatable" width="100%">
  <thead>
  <tr class="btn-primary">
    <th>&nbsp;</th>
    <th>Nome</th>
    <th>Descrição</th>
  </tr>
  </thead>
  <tr>
    <td>1</td>
    <td><a class="btn btn-info" style="margin:5px;"><i class="icon-folder-open icon-white"></i> <? echo $_SESSION['strGlobalLoad']; ?></a></td>
    <td>Importação de arquivo em <strong>formato CSV </strong>para cadastro em massa de registros no sistema</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Selecione um formulário</td>
  <td>Formulário onde os registros importados (campo 1) serão cadastrados. <strong>As opções apresentadas incluem todos os formulários já existentes no sistema e a opção de criar um novo formulário</strong></td>
  </tr>
  <tr>
    <td>3</td>
    <td><a class="btn btn-success" style="margin:5px;"><i class="icon-play icon-white"></i> <? echo $_SESSION['strToolImporterImport']; ?></a></td>
    <td>Botão que inicia o processo de importação dos dados para o formulário indicado (campo 2)</td>
</tr>
   <tr>
    <td>4</td>
    <td>Selecione o campo latitude</td>
    <td>O usuário deve indicar o campo do arquivo carregado que é referente à latitude do registro</td>
  </tr>
</table>