<? $strings->changePageTitle($_SESSION['strIndexMenuProjectManagementManageForms']); ?>
<div class="sessionTitle">
	<i class="icon-refresh" style="cursor:pointer" onClick="formsLoad(document.getElementById('cmbForms').value);"></i> <i class="<? echo $form->strDefaultIcon; ?>"></i> <? echo $_SESSION['strIndexMenuProjectManagementManageForms']; ?>
	(<span id="spanFormsCounter">0</span>)
</div>

<select id="cmbFieldTypes" name="cmbFieldTypes" style="display:none">
<?
	$arrFormFieldTypes = $form->selectFormFieldTypes();
	foreach ($arrFormFieldTypes as $arrFormFieldType) {
		echo '<option value="' . $arrFormFieldType['idFormFieldType'] . '">' . $arrFormFieldType['strFormFieldType'] . '</option>';
	}
?>
</select>
<table width="100%" style="margin-bottom:10px;">
<tr>
    <td width="70" style="white-space:nowrap;">
        <a id="btnFormActive" data-rel="tooltip" onClick="formUpdateActive();" class="btn btn-success" data-loading-text="..."><i class="icon-eye-open icon-white"></i></a>
        <div style="text-align: center;width: 30px;display: inline-block;">
    	<img id="imgForm" src="img/loading3.gif" style="max-height:30px;max-width:30px;cursor:pointer;" class="rounded" title="<? echo $_SESSION['stradmManageFormsMarkerClickTip']; ?>" onClick="
            $.fancybox({
                'href'	: 'markers.php?s=admManageForms&idForm=' + document.getElementById('cmbForms').value + '&idProject=<? echo $arrProject['idProject']; ?>',
                'type'	: 'iframe',
                'width'	: '100%',
                'height': '100%'
            });
        "/>
        </div>
    </td>
    <td>
		<select id="cmbForms" name="cmbForms" class="btn" style="width:100%;font-weight:bold;margin-left:5px;height:30px;text-align:left" onChange="formFieldsLoad(this.value);"></select>
    </td>
    <td width="180" align="center">
        <a class="btn btn-success" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsButtonAddTip']; ?>" onClick="formInsert();"><i class="icon-plus-sign icon-white"></i></a>
        <a class="btn btn-info" id="btnFormInsert" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsButtonUpdateTip']; ?>" onClick="formUpdate();"><i class="icon-font icon-white"></i></a>
        <a class="btn btn-danger" id="btnFormDelete" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsButtonDeleteTip']; ?>" onClick="formDelete();"><i class="icon-trash icon-white"></i></a>
        <a class="btn btn-warning" id="btnFormDeleteRecords" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsButtonDeleteRecordsTip']; ?>" onClick="formDeleteRecords();"><b>0</b></a>
    </td>
</tr>
</table>

<table id="tblForms" name="tblForms" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="background-color:#FFFFFF">
    <thead>
        <tr style="cursor:pointer;font-weight:bold;" class="btn-primary">
            <th width="10" style="text-align:center;"><i class="icon-resize-vertical" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldReorderTip']; ?>"></i></th>
            <th style="text-align:center"><i class="icon-info-sign" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldNameTip']; ?>"></i> <i class="icon-info-sign" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldNameTip2']; ?>"></i> <? echo $_SESSION['stradmManageFormsFieldName']; ?></th>
            <th style="text-align:center" width="194"><? echo $_SESSION['stradmManageFormsFieldType']; ?></th>
            <th style="text-align:center" width="250" class="hidden-phone">
            	<i class="icon-info-sign" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldDescriptionTip']; ?>"></i> 
            	<i class="icon-info-sign" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldDescriptionTip2']; ?>"></i> <? echo $_SESSION['stradmManageFormsFieldDescription']; ?>
			</th>
            <th style="text-align:center;white-space:nowrap;" width="50"><? echo $_SESSION['strGlobalActions']; ?></th>
        </tr>
    </thead>
    <tbody id="tblFormsBody">
    </tbody>
</table>
<a id="btnFieldInsert" class="btn btn-success" style="float:right" data-loading-text="..." data-rel="tooltip" onClick="formFieldInsert();"><i class="icon-plus-sign icon-white"></i> <? echo $_SESSION['stradmManageFormsFieldAdd']; ?></a>

<!-- Panel for Form Field Alternatives -->
<div class="modal hide fade hideSelection" id="modalFormFieldAlternatives">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">�</button>
        <h4><i class="icon-align-justify"></i> <? echo $_SESSION['stradmManageFormsFieldAlternativesTitle']; ?></h4>
    </div>
    <div class="modal-body" id="modalFormFieldAlternativesBody" style="padding:2px;overflow-y:auto">
    	<input type="hidden" id="idFormField" name="idFormField" />
        <table id="tblFormFieldAlternatives" name="tblFormFieldAlternatives" class="table table-striped table-bordered bootstrap-datatable datatable" width="100%" style="margin:0px">
            <thead>
                <tr style="cursor:pointer;font-weight:bold;background-color:#FFFFFF" class="btn-primary">
                    <th style="text-align:center"><i class="icon-info-sign" data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldAlternativesAlternativeTip']; ?>"></i> <? echo $_SESSION['stradmManageFormsFieldAlternativesAlternative']; ?></th>
                    <th style="text-align:center" width="1">
	                    <span id="btnFieldAlternativesDeleteAll" class="btn btn-danger" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldAlternativeDeleteAllHint']; ?>" onClick="formFieldAlternativeDeleteAll();" style="padding-top:2px;padding-bottom:2px;"><i class="icon-trash icon-white"></i></span>
                    </th>
                </tr>
            </thead>
            <tbody id="tblFormFieldAlternativesBody">
            </tbody>
        </table>
    </div>
    <div class="modal-footer" style="padding:3px">
        <table width="100%" style="margin:0px">
        <tr>
        <td width="100000">
            <textarea id="txtModalFormFieldAlternativesBatchAlternatives" placeholder="<? echo $_SESSION['stradmManageFormsFieldAlternativesBatch']; ?>" rows="3" class="fullwith"/></textarea>
        </td>
        <td width="1" valign="top" style="white-space:nowrap;text-align:center;">
            <a href="#" class="btn btn-success" id="btnModalFormFieldAlternativesBatchAdd" name="btnModalFormFieldAlternativesBatchAdd" data-loading-text="..."  onClick="formFieldAlternativeBatchInsert();"><i class="icon-plus-sign icon-white"></i></a>
        </td>
        </tr>
        </table>
    </div>
</div>

<script>
    function formsLoad(idSelected) {
		var idSelected = idSelected != null ? idSelected : -1;
		// Clear Form Combo Items
		var cmbForms = document.getElementById('cmbForms');
	    for (var i=cmbForms.options.length-1;i>=0;i--) { 
			cmbForms.remove(i); 
		}
		var result = $.ajax({
		  url: "ajax.php?chrAction=FS&idProject=<? echo $arrProject['idProject']; ?>"
		}).always(function() {
			if (result.responseText) {
				var arrResult 	= JSON.parse(result.responseText);
	            for (var i=0;i<arrResult.length;i++) {
					var opt = document.createElement('option');
					opt.value = arrResult[i]['idForm'];
					opt.text = arrResult[i]['strName'] + ' (' + arrResult[i]['intRecords'] + ')';
					opt.setAttribute("strFormName", arrResult[i]['strName']);
					if (idSelected == arrResult[i]['idForm']) opt.selected = 'selected';
					cmbForms.add(opt);
				}
				document.getElementById('spanFormsCounter').innerHTML = arrResult.length;
				formFieldsLoad(cmbForms.value);
			}
		});
    }
	
    function formInsert() {
    	var strName = prompt('<?php echo $_SESSION['stradmManageFormsInsertPrompt']; ?>:', '');
		if (! strName) return;
		var cmbForms = document.getElementById('cmbForms');
		$('#btnFormInsert').button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FI" +
                '&idUser=<? echo $arrUser['idUser']; ?>' +
                '&idProject=<? echo $arrProject['idProject']; ?>' +
                '&strName=' + strName
        }).always(function() {
			if (result.responseText) {
				var arrResult 	= JSON.parse(result.responseText);
				var opt = document.createElement('option');
				opt.value = arrResult['idForm'];
				opt.text = strName + ' (0)';
				opt.setAttribute("strFormName", strName);
				cmbForms.add(opt, 0);
				cmbForms.selectedIndex = 0;
                document.getElementById('spanFormsCounter').innerHTML = cmbForms.length;
				$('#btnFormInsert').button('reset');
				formFieldsLoad(cmbForms.value);
			}
        });
    }
	
    function formUpdate() {
		var cmbForms = document.getElementById('cmbForms');
		if (cmbForms.value <= 0) return;
		var strFormName = $('option:selected', cmbForms).attr('strFormName');
    	var strName = prompt('<? echo $_SESSION['stradmManageFormsInsertPrompt']; ?>:', strFormName);
		if (! strName) return;
        var result = $.ajax({
          url: "ajax.php?chrAction=FUP" +
                '&idForm=' + cmbForms.value + 
				"&strField=strName" + 
				"&strValue=" + strName
        }).always(function() {
			if (result.responseText) {
				cmbForms.options[cmbForms.selectedIndex].text = strName;
				showSuccessAlert();
			}
        });
    }

    function formDelete() {
		var cmbForms = document.getElementById('cmbForms');
		if (cmbForms.value <= 0) return;
        var blnDelete = confirm('<? echo $_SESSION['stradmManageFormsConfirmDelete']; ?>');
        if (! blnDelete) return;
		$('#btnFormDelete').button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FD" +
				"&idUser=<? echo $arrUser['idUser']; ?>" +
				"&idForm=" + cmbForms.value
        }).always(function() {
            if (result.responseText > 0) {
				var intIndex = cmbForms.selectedIndex - 1;
				cmbForms.remove(cmbForms.selectedIndex);
                document.getElementById('spanFormsCounter').innerHTML = cmbForms.length;
				if (intIndex > 0) {	cmbForms.selectedIndex = intIndex; }
				formFieldsLoad(cmbForms.value);
				showInfoAlert('<? echo $_SESSION['stradmManageFormsDeletedSuccess']; ?>');
				$('#btnFormDelete').button('reset');
            }
        });
    }
	
    function formDeleteRecords() {
		var cmbForms = document.getElementById('cmbForms');
		if (cmbForms.value <= 0) return;
        var blnDelete = confirm('<? echo $_SESSION['stradmManageFormsConfirmDeleteRecords']; ?>');
        if (! blnDelete) return;
		$('#btnFormDeleteRecords').button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FDR" +
				"&idUser=<? echo $arrUser['idUser']; ?>" +
				"&idForm=" + cmbForms.value
        }).always(function() {
            if (result.responseText > 0) {
				cmbForms.options[cmbForms.selectedIndex].text = cmbForms.options[cmbForms.selectedIndex].text.replace(/ *\([^)]*\) */g, " (0)");
				showInfoAlert('<? echo $_SESSION['stradmManageFormsDeletedRecordsSuccess']; ?>');
				$('#btnFormDeleteRecords').button('reset');
            }
        });
    }

	function formUpdateActive() {
		var cmbForms = document.getElementById('cmbForms');
		if (cmbForms.value <= 0) return;
		$('#btnFormActive').button('loading');
		var blnActive = document.getElementById('btnFormActive').className.indexOf('success') > 0 ? 0 : 1;
        var result = $.ajax({
          url: "ajax.php?chrAction=FUP" +
		  		"&idForm=" + cmbForms.value + 
				"&strField=blnActive" + 
				"&strValue=" + blnActive
        }).always(function() {
			document.getElementById('btnFormActive').className = 'btn btn-' + (blnActive > 0 ? 'success' : 'danger');
			document.getElementById('btnFormActive').title = '<? echo $_SESSION['stradmManageFormsButtonActiveTip']; ?> ' + (blnActive > 0 ? '<? echo strtoupper($_SESSION['strGlobalEnabled']); ?>' : '<? echo strtoupper($_SESSION['strGlobalDisabled']); ?>') + ' <? echo $_SESSION['stradmManageFormsButtonActiveTipEnd']; ?>';
			$('#btnFormActive').button('reset');
			showInfoAlert(document.getElementById('btnFormActive').title);
		});
	}

    function formFieldsLoad(idForm) {
		document.getElementById("btnFieldInsert").style.display = (idForm > 0 ? "inline-block" : "none");
		document.getElementById("imgForm").style.display = document.getElementById("btnFieldInsert").style.display;
		document.getElementById("btnFormActive").style.display = document.getElementById("btnFieldInsert").style.display;
        var table = document.getElementById('tblForms');
        var tbody = table.getElementsByTagName("tbody")[0];
        tbody.innerHTML = '<tr><td colspan="5"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
		if (idForm <= 0) { 
            tbody.innerHTML = '';
			return;
		}
		document.getElementById('imgForm').src = 'img/loading3.gif';
		showInfoAlert('<? echo $_SESSION['stradmManageFormsLoadingForm']; ?>...', 1);
        var result = $.ajax({
			url: "ajax.php?chrAction=FFS&idForm=" + idForm
        }).always(function() {
            var arrResult 	= JSON.parse(result.responseText);
			// Marker Image
			document.getElementById('imgForm').src = arrResult['arrForm']['strMarkerFullPath'];
			// Form Active Status
			document.getElementById('btnFormActive').className = 'btn btn-' + (arrResult['arrForm']['blnActive'] > 0 ? 'success' : 'danger');
			document.getElementById('btnFormActive').title = '<? echo $_SESSION['stradmManageFormsButtonActiveTip']; ?> ' + (arrResult['arrForm']['blnActive'] > 0 ? '<? echo $_SESSION['strGlobalEnabled']; ?>' : '<? echo $_SESSION['strGlobalDisabled']; ?>') + ' <? echo $_SESSION['stradmManageFormsButtonActiveTipEnd']; ?>';
			// Form Fields
            tbody.innerHTML = '';
            var rows = tbody.getElementsByTagName("tr").length;
            for (var i=0;i<arrResult['arrFields'].length;i++) {
				formFieldInsertTableRow(tbody, arrResult['arrFields'][i]);
            }
			showInfoAlert('<? echo $_SESSION['stradmManageFormsLoadingForm']; ?>...', 2);
        });	
    }
	
	function formFieldInsertTableRow(tbody, arrField) {
		var row = tbody.insertRow(tbody.rows.length);
		row.id = arrField['idFormField'];
		var cell = row.insertCell(0);
		cell.innerHTML = 'C' + tbody.rows.length;
		cell.style.textAlign = "center";
		cell.style.fontWeight = "bold";
		cell.style.cursor = "move";
		cell.style.backgroundImage="url(img/texture-bar.gif)";
		cell.style.backgroundRepeat="repeat";
		var cell = row.insertCell(1);
		cell.innerHTML = '<input type="text" id="fieldName_' + arrField['idFormField'] + '" name="fieldName_' + arrField['idFormField'] + '" style="width:100%;margin:0px;padding:0px;height:25px;text-indent:5px;" value="' + arrField['strName'] + '" onBlur="formFieldUpdate(' + arrField['idFormField'] + ');">';
		var cell = row.insertCell(2);
		formFieldBuildSelect(cell, arrField['idFormField'], arrField['idFormFieldType']);
		var cell = row.insertCell(3);
		cell.innerHTML = '<input type="text" id="fieldTip_' + arrField['idFormField'] + '" name="fieldTip_' + arrField['idFormField'] + '" style="width:100%;margin:0px;padding:0px;height:25px;text-indent:5px;" value="' + arrField['strTip'] + '"  onBlur="formFieldUpdate(' + arrField['idFormField'] + ');">';
		cell.className = "hidden-phone";
		var cell = row.insertCell(4);
		cell.innerHTML =	'<span id="btnFieldDelete_' + arrField['idFormField'] + '" class="btn btn-danger" style="margin-left:3px;" data-loading-text="..." data-rel="tooltip" title="<? echo $_SESSION['stradmManageFormsFieldDeleteHint']; ?>" onClick="formFieldDelete(' + arrField['idFormField'] + ');"><i class="icon-trash icon-white"></i></span>';
		cell.style.whiteSpace = "nowrap";
		cell.style.textAlign = "center";
	}
	
	function formFieldBuildSelect(cell, idFormField, idFormFieldType) {
		cell.innerHTML = '';
		var cmb = document.createElement('select');
		cmb.id = "fieldType_" + idFormField;
		cmb.style.margin = "0px";
		cmb.style.width = (idFormFieldType != 3 && idFormFieldType != 4 ? '100%' : '150px');
		cmb.innerHTML = document.getElementById('cmbFieldTypes').innerHTML;
		cmb.setAttribute("onChange", "formFieldBuildSelect(this.parentNode, " + idFormField + ", this.value);formFieldUpdate(" + idFormField + ");");
		comboSelectByValue(cmb, idFormFieldType);
		cell.appendChild(cmb);
		if (idFormFieldType == 3 || idFormFieldType == 4) {
			var span = document.createElement('span');
			span.className = "btn";
			span.title = "<? echo $_SESSION['stradmManageFormsFieldEditAlternativesHint']; ?>";
			span.style.float = "right";
			span.innerHTML = '<i class="icon-align-justify"></i>';
			span.setAttribute("onClick", "formFieldAlternativesLoad(" + idFormField + ");");
			cell.appendChild(span);
		}
		//cmb.focus();
	}
	
    function formFieldInsert() {
		$('#btnFieldInsert').button('loading');
		var cmbForms = document.getElementById('cmbForms');
        var result = $.ajax({
			url: "ajax.php?chrAction=FFI&idForm=" + cmbForms.value
		}).always(function() {
			var arrResult 	= JSON.parse(result.responseText);
			var table = document.getElementById('tblForms');
			var tbody = table.getElementsByTagName("tbody")[0];
			formFieldInsertTableRow(tbody, arrResult);
			document.getElementById('fieldName_' + arrResult['idFormField']).focus();
			$('#btnFieldInsert').button('reset');
        });
    }
	
    function formFieldUpdate(idFormField) {
		$('#btnFieldDelete_' + idFormField).button('loading');		
		document.getElementById('fieldTip_' + idFormField).value = strRemoveParentesis(document.getElementById('fieldTip_' + idFormField).value);
        var result = $.ajax({
          url: "ajax.php?chrAction=FFU" + 
		  		"&idFormField=" + idFormField + 
		  		"&strName=" + document.getElementById('fieldName_' + idFormField).value + 
				"&idFormFieldType=" +  document.getElementById('fieldType_' + idFormField).value + 
				"&strTip=" +  EliminateSpecialChars(document.getElementById('fieldTip_' + idFormField).value)
        }).always(function() {
            if (result.responseText > 0) {
				$('#btnFieldDelete_' + idFormField).button('reset');
				showSuccessAlert();
            }
        });		
    }

    function formFieldDelete(idFormField) {
        var blnDelete = confirm('<? echo $_SESSION['stradmManageFormsFieldConfirmDelete']; ?>');
        if (! blnDelete) return;
		$('#btnFieldDelete_' + idFormField).button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FFD&idFormField=" + idFormField
        }).always(function() {
            if (result.responseText > 0) {
                $('#' + idFormField).fadeOut(500, function(){
                    $('#' + idFormField).remove();
					formFieldReorderRows();
					$('#btnFieldDelete_' + idFormField).button('reset');
                });
            }
        });
    }

	function formFieldReorderRows(){
		var tbody = document.getElementById('tblFormsBody');
		var rows = tbody.getElementsByTagName("tr").length;
		for (var i=0;i<rows;i++) {
			var cell = tbody.rows[i].cells[0];
			cell.innerHTML = 'C' + (i+1);
		}
		showSuccessAlert();
	}

	function formFieldAlternativesLoad(idFormField) {
		showInfoAlert('<? echo $_SESSION['strGlobalLoading']; ?>...', 1);
        var table = document.getElementById('tblFormFieldAlternatives');
        var tbody = table.getElementsByTagName("tbody")[0];
		var rows = tbody.getElementsByTagName("tr").length;
        tbody.innerHTML = '<tr><td colspan="5"><div style="text-align:center"><img src="img/loading.gif"></div></td></tr>';
        var result = $.ajax({
          url: "ajax.php?chrAction=FFAS&idFormField=" + idFormField
        }).always(function() {
			var arrResult 	= JSON.parse(result.responseText);
			document.getElementById('idFormField').value = idFormField;
            tbody.innerHTML = '';
			for (var i=0;i<arrResult.length;i++) {
				formFieldAlternativesInsertTableRow(tbody, arrResult[i]);
            }
			showInfoAlert('<? echo $_SESSION['strGlobalLoading']; ?>...', 2);
			$('#modalFormFieldAlternatives').modal('show');
        });
	}
	
	function formFieldAlternativesInsertTableRow(tbody, arrField) {
		var row = tbody.insertRow(tbody.rows.length);
		row.id = "trFormFieldAlternative_" + arrField['idFormFieldAlternative'];
		var cell = row.insertCell(0);
		cell.innerHTML = '<input type="text" id="fieldAlternativeName_' + arrField['idFormFieldAlternative'] + '" style="width:100%;margin:0px;padding:0px;height:25px;text-indent:5px;" value="' + arrField['strAlternative'] + '" onBlur="formFieldAlternativeUpdate(' + arrField['idFormFieldAlternative'] + ');">' +
							(arrField['blnPublic'] == 1 ? '<br><i style="font-size:11px;color:#FF0000;font-weight:bold">* <? echo $_SESSION['stradmManageFormsFieldAlternativesPublicTip']; ?></i>' : '');
		var cell = row.insertCell(1);
		cell.innerHTML =	'<span id="btnFieldAlternativeDelete_' + arrField['idFormFieldAlternative'] + '" class="btn btn-danger" style="margin-left:3px;" data-loading-text="..." onClick="formFieldAlternativeDelete(' + arrField['idFormFieldAlternative'] + ');"><i class="icon-trash icon-white"></i></span>';
		cell.style.textAlign = "center";
	}
	
	function formFieldAlternativeBatchInsert() {
		$('#btnModalFormFieldAlternativesBatchAdd').button('loading');
		var strAlternatives = document.getElementById('txtModalFormFieldAlternativesBatchAlternatives').value;
		strAlternatives = EliminateSpecialChars(strAlternatives);
		strAlternatives = replaceAll(strAlternatives,'&',' ');
		strAlternatives = replaceAll(strAlternatives,'\n','<br>');
        var result = $.ajax({
			url: "ajax.php?chrAction=FFAIB" +
					"&idFormField=" + document.getElementById('idFormField').value +
					"&strAlternatives=" + strAlternatives
		}).always(function() {
			document.getElementById('txtModalFormFieldAlternativesBatchAlternatives').value = '';
			formFieldAlternativesLoad(document.getElementById('idFormField').value);
			$('#btnModalFormFieldAlternativesBatchAdd').button('reset');
        });	
	}
	
    function formFieldAlternativeInsert() {
		$('#btnModalFormFieldAlternativesAdd').button('loading');
        var result = $.ajax({
			url: "ajax.php?chrAction=FFAI&idFormField=" + document.getElementById('idFormField').value
		}).always(function() {
			var arrResult = JSON.parse(result.responseText);
			var table = document.getElementById('tblFormFieldAlternatives');
			var tbody = table.getElementsByTagName("tbody")[0];
			formFieldAlternativesInsertTableRow(tbody, arrResult);
			document.getElementById('fieldAlternativeName_' + arrResult['idFormFieldAlternative']).focus();
			$('#btnModalFormFieldAlternativesAdd').button('reset');
        });
    }
	
    function formFieldAlternativeUpdate(idFormFieldAlternative) {
        var result = $.ajax({
          url: "ajax.php?chrAction=FFAU" + 
		  		"&idFormFieldAlternative=" + idFormFieldAlternative + 
		  		"&strAlternative=" + document.getElementById('fieldAlternativeName_' + idFormFieldAlternative).value
        }).always(function() {
            if (result.responseText > 0) {
				showSuccessAlert();
            }
        });
    }

    function formFieldAlternativeDelete(idFormFieldAlternative) {
        var blnDelete = confirm('<? echo $_SESSION['stradmManageFormsFieldAlternativesConfirmDelete']; ?>');
        if (! blnDelete) return;
		$('#btnFieldAlternativeDelete_' + idFormFieldAlternative).button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FFAD&idFormFieldAlternative=" + idFormFieldAlternative
        }).always(function() {
            if (result.responseText > 0) {
                $("#trFormFieldAlternative_" + idFormFieldAlternative).fadeOut(50, function(){
                    $("#trFormFieldAlternative_" + idFormFieldAlternative).remove();
					$('#btnFieldAlternativeDelete_' + idFormFieldAlternative).button('reset');
                });
            }
        });
    }
	
    function formFieldAlternativeDeleteAll() {
        var blnDelete = confirm('<? echo $_SESSION['stradmManageFormsFieldAlternativesConfirmDeleteAll']; ?>');
        if (! blnDelete) return;
		$('#btnFieldAlternativesDeleteAll').button('loading');
        var result = $.ajax({
          url: "ajax.php?chrAction=FFAD&idFormField=" + document.getElementById('idFormField').value
        }).always(function() {
			formFieldAlternativesLoad(document.getElementById('idFormField').value);
			$('#btnFieldAlternativesDeleteAll').button('reset');
        });
    }

	$(document).ready( function () {
		$("#tblFormsBody").sortable({
		  update: function(event, ui) {
			var strIds = $("#tblFormsBody").sortable("toArray");
			$.ajax({url: "ajax.php?chrAction=FFR&strIds=" + strIds}).always(function() {
				formFieldReorderRows();
			});
		  }
		});	
		formsLoad(<? echo $_COOKIE['idForm']; ?>);
	});
</script>